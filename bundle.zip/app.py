# -*- coding: utf-8 -*-
"""
Legal Tracks (مسارات قانونية) - KYC Compliance Edition V10
Self-contained compliance/KYC application for pilot and production hardening.
Arabic RTL interface, dynamic counterparties, screening, sanctions import controls,
workflow actions, audit trail, backup and maintenance tools.
"""
from __future__ import annotations

import argparse
import base64
import csv
import datetime as dt
import difflib
import hashlib
import html
import io
import json
import os
import re
import secrets
import shutil
import sqlite3
import sys
import textwrap
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

APP_VERSION = "V10.5 - Simplified Regulatory Gap Closure"
APP_ENV = os.environ.get("MASARAT_APP_ENV", "UAT").strip().upper()
if APP_ENV not in {"UAT", "PRODUCTION"}:
    raise RuntimeError("MASARAT_APP_ENV must be UAT or PRODUCTION")
BASE_DIR = Path(__file__).resolve().parent
DEFAULT_ENV_DIR = BASE_DIR / "environments" / APP_ENV.lower()
DATA_DIR = Path(os.environ.get("MASARAT_KYC_DATA", str(DEFAULT_ENV_DIR / "data")))
BACKUP_DIR = Path(os.environ.get("MASARAT_KYC_BACKUPS", str(DEFAULT_ENV_DIR / "backups")))
KEY_DIR = DATA_DIR / "keys"
# V10.5.6: عند عدم تحديد MASARAT_KYC_DB يفضل ملف قاعدة البيئة المرفق مع الحزمة إن وجد
# (masarat_compliance_<env>.sqlite3) بدل إنشاء قاعدة فارغة باسم افتراضي مختلف بصمت.
_DEFAULT_DB_CANDIDATE = DATA_DIR / "masarat_kyc_v10.sqlite3"
_PACKAGED_DB_CANDIDATE = DATA_DIR / f"masarat_compliance_{APP_ENV.lower()}.sqlite3"
if os.environ.get("MASARAT_KYC_DB"):
    DB_PATH = Path(os.environ["MASARAT_KYC_DB"])
elif (not _DEFAULT_DB_CANDIDATE.exists()) and _PACKAGED_DB_CANDIDATE.exists():
    DB_PATH = _PACKAGED_DB_CANDIDATE
else:
    DB_PATH = _DEFAULT_DB_CANDIDATE
LOG_DIR = Path(os.environ.get("MASARAT_KYC_LOGS", str(DEFAULT_ENV_DIR / "logs")))
REPORT_DIR = DATA_DIR / "reports" / "screening"
RETENTION_YEARS = 10
ALLOW_DUMMY_DATA = os.environ.get("MASARAT_ALLOW_DUMMY_DATA", "1" if APP_ENV == "UAT" else "0") == "1"
ALLOW_STRESS_TEST = os.environ.get("MASARAT_ALLOW_STRESS_TEST", "1" if APP_ENV == "UAT" else "0") == "1"
# V10.5.7: SQLite lock wait (ms) so concurrent writers wait instead of failing immediately.
DB_BUSY_TIMEOUT_MS = int(os.environ.get("MASARAT_DB_BUSY_TIMEOUT_MS", "5000") or "5000")
# V10.5.7: mark the session cookie Secure behind TLS. Defaults on in PRODUCTION (always fronted
# by the TLS reverse proxy) and off in UAT so local plain-HTTP testing still works; a request
# arriving with X-Forwarded-Proto=https also forces Secure regardless of environment.
COOKIE_SECURE = os.environ.get("MASARAT_COOKIE_SECURE", "1" if APP_ENV == "PRODUCTION" else "0") == "1"
# Trusted reverse-proxy peers whose X-Forwarded-For may be believed for the audit client IP.
TRUSTED_PROXY_PEERS = {"127.0.0.1", "::1"}
# Which X-Forwarded-For entry is the real client. "leftmost" (default) is correct when the
# fronting proxy OVERWRITES XFF with the client IP (recommended IIS ARR config, and how Entra
# Application Proxy sets it). Set MASARAT_XFF_CLIENT_POSITION=rightmost if a proxy APPENDS the
# client IP to a client-supplied header instead, so a spoofed leftmost value cannot win.
XFF_CLIENT_POSITION = (os.environ.get("MASARAT_XFF_CLIENT_POSITION", "leftmost").strip().lower()
                       if os.environ.get("MASARAT_XFF_CLIENT_POSITION", "leftmost").strip().lower() in {"leftmost", "rightmost"}
                       else "leftmost")
# V10.8: التجربة التشغيلية تعمل ببيانات حقيقية — أزيلت عبارة "بيانات غير حقيقية" المضللة،
# مع إتاحة تخصيص النص عبر MASARAT_ENV_LABEL_AR دون تعديل الشيفرة.
ENV_LABEL_AR = (os.environ.get("MASARAT_ENV_LABEL_AR", "").strip()
                or ("بيئة التجربة التشغيلية (Pilot)" if APP_ENV == "UAT" else "بيئة الإنتاج – بيانات حقيقية"))

def validate_environment_safety() -> None:
    # V10.5.6 fix: كان الفحص يبحث عن uat/test/prod في المسار المطلق كاملاً، فيوقف الإنتاج
    # لمجرد استخراج الحزمة داخل مجلد يحوي إحدى هذه الكلمات. صار الفحص على اسم ملف قاعدة
    # البيانات ومسار مجلد البيئة (environments/uat|production) فقط.
    db_name = DB_PATH.name.lower()
    path_norm = str(DB_PATH).replace("\\", "/").lower()
    data_norm = str(DATA_DIR).replace("\\", "/").lower()
    if APP_ENV == "UAT" and ("production" in db_name or "/environments/production/" in path_norm or "/environments/production/" in data_norm):
        raise RuntimeError("تم إيقاف التشغيل: بيئة UAT تشير إلى مسار إنتاج")
    if APP_ENV == "PRODUCTION" and ("uat" in db_name or "test" in db_name or "/environments/uat/" in path_norm or "/environments/uat/" in data_norm):
        raise RuntimeError("تم إيقاف التشغيل: بيئة الإنتاج تشير إلى مسار تجريبي")
    if APP_ENV == "PRODUCTION" and (ALLOW_DUMMY_DATA or ALLOW_STRESS_TEST):
        raise RuntimeError("تم إيقاف التشغيل: Dummy Data أو Stress Test غير مسموح في الإنتاج")

HIGH_RISK_COUNTRIES = {
    "north korea", "iran", "syria", "yemen", "afghanistan", "iraq", "libya", "somalia",
    "كوريا الشمالية", "إيران", "سوريا", "اليمن", "أفغانستان", "العراق", "ليبيا", "الصومال"
}
DUAL_USE_KEYWORDS = {
    "dual use", "electronics", "advanced equipment", "logistics", "shipping", "freight",
    "استخدام مزدوج", "إلكترونيات", "معدات", "لوجستية", "شحن", "نقل", "بحري"
}

ARABIC_DIACRITICS = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]")
PUNCT = re.compile(r"[^\w\s\u0600-\u06FF]")


def now_iso() -> str:
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def ensure_dirs() -> None:
    for p in [DATA_DIR, BACKUP_DIR, KEY_DIR, LOG_DIR, REPORT_DIR]:
        p.mkdir(parents=True, exist_ok=True)


def get_or_create_master_key() -> Path:
    ensure_dirs()
    key_path = KEY_DIR / "kyc_master.key"
    if not key_path.exists():
        key_path.write_bytes(base64.urlsafe_b64encode(secrets.token_bytes(32)))
        try:
            os.chmod(key_path, 0o600)
        except Exception:
            pass
    return key_path


ARABIC_INDIC_DIGITS = str.maketrans({
    "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4",
    "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
    "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4",
    "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
})

# كلمات الصفة القانونية العامة. تزال فقط عند مطابقة أسماء الكيانات، ولا تزال
# عند مطابقة أسماء الأشخاص. الغرض منع تأثير كلمات مثل شركة/مؤسسة/LLC على النتيجة.
ENTITY_LEGAL_WORDS = {
    "شركة", "شركه", "الشركة", "الشركه", "مؤسسة", "مؤسسه", "المؤسسة", "المؤسسه",
    "مكتب", "المكتب", "مجموعة", "المجموعة", "قابضة", "القابضة", "محدودة", "المحدودة",
    "مساهمه", "مساهمة", "المساهمة", "مقفلة", "المقفلة", "ذات", "مسؤولية", "المسؤولية",
    "تضامنية", "توصية", "بسيطة", "فردية", "جمعية", "الجمعية", "مركز", "المركز",
    "company", "co", "ltd", "limited", "llc", "inc", "incorporated", "corporation", "corp",
    "establishment", "est", "enterprise", "enterprises", "group", "holding", "holdings",
    "plc", "psc", "pjsc", "sa", "sarl", "gmbh", "foundation", "association", "office",
}

ENTITY_CATEGORY_VALUES = {
    "company", "entity", "government", "charity", "organisation", "organization", "vessel",
    "شركة", "كيان", "جهة حكومية", "جمعية", "مؤسسة",
}

# V10.5.12: روابط النسب في الأسماء العربية (بن/ابن/بنت) تعني "ابن/ابنة فلان" وليست أسماء
# مستقلة، وهي شائعة جداً؛ تستبعد من مطابقة أسماء الأشخاص حتى لا تولّد تطابقاً وهمياً.
# القيم بصيغة normalize_name (ابن -> بن، ة -> ه).
PERSON_NAME_CONNECTORS = {"بن", "ابن", "بنت", "بنه", "ابنه"}


def normalize_identifier(value: Any) -> str:
    """توحيد الأرقام المميزة قبل المقارنة: أرقام عربية/لاتينية، فراغات وشرطات."""
    text = unicodedata.normalize("NFKC", str(value or "")).translate(ARABIC_INDIC_DIGITS).upper().strip()
    # يحتفظ بالأحرف اللاتينية للأرقام مثل الجواز/IMO، ويحذف الفواصل والمسافات والشرطات.
    return re.sub(r"[^A-Z0-9\u0600-\u06FF]", "", text)


def normalize_name(value: str) -> str:
    value = unicodedata.normalize("NFKC", str(value or ""))
    value = ARABIC_DIACRITICS.sub("", value)
    value = value.lower().strip()
    replacements = {
        "أ": "ا", "إ": "ا", "آ": "ا", "ى": "ي", "ة": "ه", "ؤ": "و", "ئ": "ي",
        "ﻻ": "لا", "إبن": "بن", "ابن": "بن",
    }
    for a, b in replacements.items():
        value = value.replace(a, b)
    value = PUNCT.sub(" ", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def normalize_entity_name(value: str) -> str:
    legal_words = {normalize_name(x) for x in ENTITY_LEGAL_WORDS}
    tokens = [t for t in normalize_name(value).split() if t and t not in legal_words]
    return " ".join(tokens)


def _longest_common_contiguous_tokens(tokens_a: List[str], tokens_b: List[str]) -> List[str]:
    if not tokens_a or not tokens_b:
        return []
    best_start = 0
    best_len = 0
    prev = [0] * (len(tokens_b) + 1)
    for i, token_a in enumerate(tokens_a, 1):
        cur = [0] * (len(tokens_b) + 1)
        for j, token_b in enumerate(tokens_b, 1):
            if token_a == token_b:
                cur[j] = prev[j - 1] + 1
                if cur[j] > best_len:
                    best_len = cur[j]
                    best_start = i - best_len
        prev = cur
    return tokens_a[best_start:best_start + best_len]


def _entity_context(name: str, registration_number: str = "", category: str = "") -> bool:
    cat = normalize_name(category)
    if cat in ENTITY_CATEGORY_VALUES or bool(normalize_identifier(registration_number)):
        return True
    tokens = set(normalize_name(name).split())
    legal_words = {normalize_name(x) for x in ENTITY_LEGAL_WORDS}
    return bool(tokens & legal_words)


def match_score(
    name_a: str,
    name_b: str,
    id_a: str = "",
    id_b: str = "",
    reg_a: str = "",
    reg_b: str = "",
    subject_category: str = "",
    candidate_category: str = "",
) -> Tuple[int, str]:
    """مطابقة مرجحة: الرقم المميز أولاً، ثم الاسم وفق قاعدة المقاطع المتصلة."""
    aid, bid = normalize_identifier(id_a), normalize_identifier(id_b)
    areg, breg = normalize_identifier(reg_a), normalize_identifier(reg_b)

    # المطابقة الرقمية مقدمة على الاسم. الحد الأدنى يمنع اعتبار قيم اختبارية قصيرة مثل 0 تطابقاً.
    if aid and bid and len(aid) >= 4 and aid == bid:
        return 100, "تطابق مؤكد في رقم الهوية/الإقامة/الجواز بعد توحيد الصيغة"
    if areg and breg and len(areg) >= 4 and areg == breg:
        return 100, "تطابق مؤكد في رقم السجل التجاري/رقم الكيان بعد توحيد الصيغة"
    if aid and breg and len(aid) >= 4 and aid == breg:
        return 100, "تطابق رقم مميز بين حقل الهوية وحقل السجل؛ يلزم التحقق من تصنيف الحقل"
    if areg and bid and len(areg) >= 4 and areg == bid:
        return 100, "تطابق رقم مميز بين حقل السجل وحقل الهوية؛ يلزم التحقق من تصنيف الحقل"

    entity_mode = _entity_context(name_a, reg_a, subject_category) or _entity_context(name_b, reg_b, candidate_category)
    na = normalize_entity_name(name_a) if entity_mode else normalize_name(name_a)
    nb = normalize_entity_name(name_b) if entity_mode else normalize_name(name_b)
    if not na or not nb:
        return 0, "لا توجد بيانات اسمية كافية للمطابقة بعد التوحيد"

    ta, tb = na.split(), nb.split()
    if not entity_mode:
        # V10.5.12: استبعاد روابط النسب (بن/ابن/بنت) من مطابقة الأشخاص؛ فلا يُحتسب "بن سعد"
        # المشترك تطابقاً على مقطعين. يُحتفظ بالأصل لو أدى الاستبعاد إلى إفراغ القائمة.
        fa = [t for t in ta if t not in PERSON_NAME_CONNECTORS]
        fb = [t for t in tb if t not in PERSON_NAME_CONNECTORS]
        ta = fa if fa else ta
        tb = fb if fb else tb
    legal_note = " بعد استبعاد الصفة القانونية العامة مثل شركة/مؤسسة/LLC" if entity_mode else ""

    if na == nb:
        if entity_mode:
            # يسمح بالاسم التجاري المميز الأحادي عند التطابق الكامل، مثل SABIC/سابك.
            if len(ta) == 1 and len(ta[0]) < 4:
                return 70, "اسم كيان أحادي قصير؛ لا يعتمد كتطابق دون رقم مميز"
            return 100, f"تطابق كامل في اسم الكيان{legal_note}"
        if len(ta) < 2:
            return 70, "تطابق على اسم شخص أحادي فقط؛ لا يعتمد دون رقم مميز أو مقطعين متصلين"
        return 100, "تطابق كامل في اسم الشخص على مقطعين متصلين أو أكثر"

    raw_score = int(round(difflib.SequenceMatcher(None, na, nb).ratio() * 100))
    contiguous = _longest_common_contiguous_tokens(ta, tb)
    contiguous_len = len(contiguous)

    # قاعدة صريحة لمنع التنبيه بسبب اسم شائع واحد مثل محمد أو أحمد.
    if contiguous_len < 2:
        single = contiguous[0] if contiguous else ""
        detail = f" ({single})" if single else ""
        return min(raw_score, 70), f"التشابه الاسمي قائم على مقطع واحد فقط{detail}؛ لا يعد تطابقاً مؤثراً دون رقم مميز"

    shorter = max(1, min(len(ta), len(tb)))
    coverage = contiguous_len / shorter
    score = max(raw_score, int(round(75 + 23 * coverage)))
    score = min(score, 99)
    phrase = " ".join(contiguous)
    if score >= 95:
        level = "تشابه اسمي مرتفع جداً"
    elif score >= 90:
        level = "تشابه اسمي كبير"
    else:
        level = "تطابق اسمي محتمل يحتاج مراجعة"
    return score, f"{level} على {contiguous_len} مقاطع متصلة: {phrase}{legal_note}"


def status_for_score(score: int, reason: str) -> str:
    # V10.5.6 fix: كل مسارات المطابقة الرقمية تعيد 100 أصلاً؛ فحص كلمة "رقم" داخل السبب
    # كان يحول تشابهاً اسمياً يتضمن الكلمة إلى "تطابق مؤكد" خطأً.
    if score >= 100:
        return "confirmed_match"
    if score >= 90:
        return "high_similarity"
    if score >= 75:
        return "potential_match"
    return "no_match"


def db() -> sqlite3.Connection:
    ensure_dirs()
    con = sqlite3.connect(DB_PATH, timeout=DB_BUSY_TIMEOUT_MS / 1000.0)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    con.execute("PRAGMA journal_mode = WAL")
    # V10.5.7 fix: انتظار القفل بدل الفشل الفوري بـ"database is locked" عند تزامن الكتابة
    # (خاصة عند تداخل الفحص الدوري/النسخ الاحتياطي مع الخدمة الحية).
    con.execute(f"PRAGMA busy_timeout={DB_BUSY_TIMEOUT_MS}")
    return con


def ensure_schema(con: sqlite3.Connection) -> None:
    stmts = [
        """
        CREATE TABLE IF NOT EXISTS schema_migrations(
            version TEXT PRIMARY KEY,
            applied_at TEXT NOT NULL
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS clients(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            updated_at TEXT,
            client_type TEXT NOT NULL DEFAULT 'company',
            legal_name TEXT NOT NULL,
            id_number TEXT,
            registration_number TEXT,
            country TEXT,
            nationality TEXT,
            listed_saudi_market INTEGER NOT NULL DEFAULT 0,
            source_of_funds TEXT,
            source_of_wealth TEXT,
            source_notes TEXT,
            source_skip_reason TEXT,
            document_type TEXT,
            document_scan_path TEXT,
            document_original_filename TEXT,
            risk_level TEXT NOT NULL DEFAULT 'normal',
            status TEXT NOT NULL DEFAULT 'draft',
            notes TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS related_parties(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            parent_type TEXT NOT NULL,
            parent_id INTEGER NOT NULL,
            party_role TEXT NOT NULL,
            full_name TEXT NOT NULL,
            id_number TEXT,
            registration_number TEXT,
            nationality TEXT,
            country TEXT,
            ownership_percent REAL,
            notes TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS matters(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            updated_at TEXT,
            client_id INTEGER NOT NULL REFERENCES clients(id),
            matter_number TEXT NOT NULL,
            title TEXT NOT NULL,
            service_type TEXT,
            description TEXT,
            status TEXT NOT NULL DEFAULT 'draft'
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS counterparties(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            matter_id INTEGER NOT NULL REFERENCES matters(id),
            party_type TEXT NOT NULL DEFAULT 'company',
            full_name TEXT NOT NULL,
            id_number TEXT,
            registration_number TEXT,
            nationality TEXT,
            country TEXT,
            role_in_matter TEXT,
            notes TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS sanctions_entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            list_name TEXT NOT NULL,
            source_url TEXT,
            list_type TEXT NOT NULL DEFAULT 'TF',
            full_name TEXT NOT NULL,
            id_number TEXT,
            registration_number TEXT,
            nationality TEXT,
            country TEXT,
            notes TEXT,
            row_hash TEXT NOT NULL UNIQUE,
            active INTEGER NOT NULL DEFAULT 1
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS sanctions_import_logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            list_name TEXT NOT NULL,
            source_url TEXT,
            filename TEXT,
            file_sha256 TEXT,
            total_records INTEGER NOT NULL DEFAULT 0,
            success_count INTEGER NOT NULL DEFAULT 0,
            failed_count INTEGER NOT NULL DEFAULT 0,
            duplicate_count INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL,
            error_details_json TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS screenings(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            updated_at TEXT,
            subject_type TEXT NOT NULL,
            subject_id INTEGER NOT NULL,
            subject_name TEXT NOT NULL,
            screening_scope TEXT NOT NULL,
            list_name TEXT,
            matched_entity_type TEXT,
            matched_entity_id INTEGER,
            matched_name TEXT,
            match_score INTEGER NOT NULL,
            match_reason TEXT,
            status TEXT NOT NULL,
            decision_reason TEXT,
            reviewed_by TEXT,
            reviewed_at TEXT
        )
        """,

        """
        CREATE TABLE IF NOT EXISTS screening_reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_number TEXT NOT NULL UNIQUE,
            created_at TEXT NOT NULL,
            created_by TEXT DEFAULT 'system',
            client_id INTEGER,
            matter_id INTEGER,
            counterparty_id INTEGER,
            screening_id INTEGER REFERENCES screenings(id),
            report_type TEXT NOT NULL DEFAULT 'screening_pdf',
            risk_level TEXT NOT NULL DEFAULT 'green',
            visual_status TEXT NOT NULL DEFAULT 'أخضر',
            decision_status TEXT,
            pdf_path TEXT NOT NULL,
            pdf_sha256 TEXT,
            summary TEXT,
            required_action TEXT,
            reviewed_by TEXT,
            reviewed_at TEXT,
            review_notes TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS screening_report_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_id INTEGER NOT NULL REFERENCES screening_reports(id),
            screening_id INTEGER,
            subject_type TEXT,
            subject_name TEXT,
            screening_scope TEXT,
            list_name TEXT,
            matched_name TEXT,
            match_score INTEGER,
            match_reason TEXT,
            status TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS compliance_actions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            screening_id INTEGER REFERENCES screenings(id),
            action_type TEXT NOT NULL,
            action_note TEXT,
            created_by TEXT DEFAULT 'system'
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS risk_flags(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id INTEGER NOT NULL,
            flag_code TEXT NOT NULL,
            flag_label TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'medium',
            notes TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS app_settings(
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS ref_client_types(
            code TEXT PRIMARY KEY,
            label_ar TEXT NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            sort_order INTEGER NOT NULL DEFAULT 100
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS ref_service_types(
            code TEXT PRIMARY KEY,
            label_ar TEXT NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            sort_order INTEGER NOT NULL DEFAULT 100
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS app_users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            full_name TEXT NOT NULL,
            user_name TEXT NOT NULL UNIQUE,
            role TEXT NOT NULL DEFAULT 'user',
            is_active INTEGER NOT NULL DEFAULT 1
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS audit_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            action TEXT NOT NULL,
            entity_type TEXT,
            entity_id INTEGER,
            details TEXT,
            user_name TEXT DEFAULT 'system',
            ip_address TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS maintenance_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            event_type TEXT NOT NULL,
            status TEXT NOT NULL,
            details TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS rollback_points(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            backup_path TEXT NOT NULL,
            notes TEXT
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_clients_name ON clients(legal_name)",
        "CREATE INDEX IF NOT EXISTS idx_rp_parent ON related_parties(parent_type, parent_id)",
        "CREATE INDEX IF NOT EXISTS idx_matter_client ON matters(client_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_matter ON counterparties(matter_id)",
        "CREATE INDEX IF NOT EXISTS idx_sanctions_name ON sanctions_entries(full_name)",
        "CREATE INDEX IF NOT EXISTS idx_screenings_subject ON screenings(subject_type, subject_id)",
        "CREATE INDEX IF NOT EXISTS idx_reports_created ON screening_reports(created_at)",
        "CREATE INDEX IF NOT EXISTS idx_reports_risk ON screening_reports(risk_level)",
        "CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_events(entity_type, entity_id)",
    ]
    for s in stmts:
        con.execute(s)
    # Safe migrations for existing pilot databases.
    cols = {r[1] for r in con.execute("PRAGMA table_info(clients)").fetchall()}
    for col, typ in {
        "source_skip_reason": "TEXT",
        "document_type": "TEXT",
        "document_scan_path": "TEXT",
        "document_original_filename": "TEXT",
    }.items():
        if col not in cols:
            con.execute(f"ALTER TABLE clients ADD COLUMN {col} {typ}")
    con.executemany("INSERT OR IGNORE INTO ref_client_types(code, label_ar, sort_order) VALUES(?,?,?)", [
        ("company", "شركة", 10),
        ("individual", "فرد", 20),
        ("government", "جهة حكومية", 30),
        ("charity", "جمعية خيرية", 40),
    ])
    con.executemany("INSERT OR IGNORE INTO ref_service_types(code, label_ar, sort_order) VALUES(?,?,?)", [
        ("contract", "عقد", 10),
        ("litigation", "قضية", 20),
        ("consulting", "استشارة قانونية", 30),
        ("corporate", "شركات وحوكمة", 40),
        ("other", "أخرى", 90),
    ])
    con.executemany("INSERT OR IGNORE INTO app_settings(key, value, updated_at) VALUES(?,?,?)", [
        ("company_name", "مكتب / شركة مستخدمة التطبيق", now_iso()),
        ("company_registration", "", now_iso()),
        ("company_national_address", "", now_iso()),
        ("company_vat_number", "", now_iso()),
    ])
    con.execute("INSERT OR IGNORE INTO app_users(created_at, full_name, user_name, role, is_active) VALUES(?,?,?,?,1)", (now_iso(), "مدير النظام", "admin", "admin"))
    con.execute("INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES(?,?)", ("V10.1.0", now_iso()))
    con.commit()


def init_db() -> None:
    ensure_dirs()
    get_or_create_master_key()
    with db() as con:
        ensure_schema(con)
        audit(con, "system_init", "database", 0, f"Initialized schema {APP_VERSION}")
        con.commit()


def audit(con: sqlite3.Connection, action: str, entity_type: str = "system", entity_id: int = 0, details: str = "", ip: str = "") -> None:
    con.execute(
        "INSERT INTO audit_events(created_at, action, entity_type, entity_id, details, ip_address) VALUES(?,?,?,?,?,?)",
        (now_iso(), action, entity_type, entity_id, details[:2000], ip),
    )


def h(value: Any) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def form_value(fields: Dict[str, List[str]], key: str, default: str = "") -> str:
    # V10.5.6 fix: القيمة الافتراضية تطبق أيضاً عندما يصل الحقل فارغاً وليس فقط عند غيابه.
    values = fields.get(key) or []
    value = (values[0] or "").strip() if values else ""
    return value or default



def get_setting(con: sqlite3.Connection, key: str, default: str = "") -> str:
    row = con.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
    return (row["value"] if row else default) or ""


def client_type_options(selected: str = "") -> str:
    with db() as con:
        ensure_schema(con)
        rows = con.execute("SELECT code, label_ar FROM ref_client_types WHERE is_active=1 ORDER BY sort_order, label_ar").fetchall()
    return "".join(f"<option value='{h(r['code'])}' {'selected' if r['code']==selected else ''}>{h(r['label_ar'])}</option>" for r in rows)


def service_type_options(selected: str = "") -> str:
    with db() as con:
        ensure_schema(con)
        rows = con.execute("SELECT code, label_ar FROM ref_service_types WHERE is_active=1 ORDER BY sort_order, label_ar").fetchall()
    return "".join(f"<option value='{h(r['code'])}' {'selected' if r['code']==selected else ''}>{h(r['label_ar'])}</option>" for r in rows)


def client_type_label(code: str) -> str:
    with db() as con:
        ensure_schema(con)
        row = con.execute("SELECT label_ar FROM ref_client_types WHERE code=?", (code,)).fetchone()
    return row["label_ar"] if row else code


def next_matter_number(con: sqlite3.Connection) -> str:
    ym = dt.datetime.now().strftime("%Y%m")
    prefix = f"PC-{ym}-"
    count = con.execute("SELECT COUNT(*) FROM matters WHERE matter_number LIKE ?", (prefix + "%",)).fetchone()[0] + 1
    return f"{prefix}{count:04d}"


def save_uploaded_client_document(client_id: int, files: Dict[str, Tuple[str, bytes]]) -> Tuple[str, str]:
    filename, content = files.get("document_scan", ("", b""))
    if not filename or not content:
        return "", ""
    safe = re.sub(r"[^A-Za-z0-9_.\-\u0600-\u06FF ]+", "_", Path(filename).name).strip() or "document.bin"
    upload_dir = DATA_DIR / "uploads" / "clients" / str(client_id)
    upload_dir.mkdir(parents=True, exist_ok=True)
    target = upload_dir / safe
    if target.exists():
        target = upload_dir / f"{target.stem}_{dt.datetime.now().strftime('%Y%m%d%H%M%S')}{target.suffix}"
    target.write_bytes(content)
    return str(target), filename


def settings_page(message: str = "") -> bytes:
    with db() as con:
        ensure_schema(con)
        company_name = get_setting(con, "company_name")
        company_registration = get_setting(con, "company_registration")
        company_national_address = get_setting(con, "company_national_address")
        company_vat_number = get_setting(con, "company_vat_number")
        client_types = con.execute("SELECT * FROM ref_client_types ORDER BY sort_order, label_ar").fetchall()
        service_types = con.execute("SELECT * FROM ref_service_types ORDER BY sort_order, label_ar").fetchall()
        users = con.execute("SELECT * FROM app_users ORDER BY id DESC LIMIT 100").fetchall()
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    ct_rows = "".join(f"<tr><td>{h(r['code'])}</td><td>{h(r['label_ar'])}</td><td>{'نشط' if r['is_active'] else 'موقوف'}</td></tr>" for r in client_types)
    st_rows = "".join(f"<tr><td>{h(r['code'])}</td><td>{h(r['label_ar'])}</td><td>{'نشط' if r['is_active'] else 'موقوف'}</td></tr>" for r in service_types)
    user_rows = "".join(f"<tr><td>{r['id']}</td><td>{h(r['full_name'])}</td><td>{h(r['user_name'])}</td><td>{h(r['role'])}</td><td>{'نشط' if r['is_active'] else 'موقوف'}</td></tr>" for r in users)
    body = f"""
<div class="card" id="settings"><h2>الإعدادات</h2>{msg}<p class="notice">هذه الصفحة مخصصة لإعدادات الشركة، أنواع العملاء، أنواع الخدمات، والمستخدمين. القوائم تظهر في نماذج إضافة العميل وفتح المشروع / القضية.</p></div>
<div class="card" id="company"><h3>إعدادات الشركة</h3>
<form method="post" action="/settings/company"><div class="grid">
<div><label>اسم الشركة / المكتب مستخدم التطبيق</label><input name="company_name" value="{h(company_name)}"></div>
<div><label>رقم السجل التجاري</label><input name="company_registration" value="{h(company_registration)}"></div>
<div><label>العنوان الوطني</label><input name="company_national_address" value="{h(company_national_address)}"></div>
<div><label>الرقم الضريبي إن وجد</label><input name="company_vat_number" value="{h(company_vat_number)}"></div>
</div><button>حفظ إعدادات الشركة</button></form></div>
<div class="grid">
<div class="card" id="client-types"><h3>إعدادات: أنواع العملاء</h3><form method="post" action="/settings/add_client_type"><div class="grid"><div><label>الكود</label><input required name="code" placeholder="e.g. nonprofit"></div><div><label>الاسم الظاهر</label><input required name="label_ar" placeholder="نوع العميل"></div></div><button>إضافة نوع عميل</button></form><table><thead><tr><th>الكود</th><th>الاسم</th><th>الحالة</th></tr></thead><tbody>{ct_rows}</tbody></table></div>
<div class="card" id="service-types"><h3>إعدادات: أنواع الخدمات</h3><form method="post" action="/settings/add_service_type"><div class="grid"><div><label>الكود</label><input required name="code" placeholder="e.g. advisory"></div><div><label>الاسم الظاهر</label><input required name="label_ar" placeholder="نوع الخدمة"></div></div><button>إضافة نوع خدمة</button></form><table><thead><tr><th>الكود</th><th>الاسم</th><th>الحالة</th></tr></thead><tbody>{st_rows}</tbody></table></div>
</div>
<div class="card" id="users"><h3>المستخدمين</h3><form method="post" action="/settings/add_user"><div class="grid"><div><label>الاسم</label><input required name="full_name"></div><div><label>البريد الإلكتروني للمستخدم</label><input required name="user_name" placeholder="name@legaltracks.sa" title="بريد إلكتروني على نطاق الشركة، مثل name@legaltracks.sa"></div><div><label>الدور</label><select name="role"><option value="admin">مدير نظام</option><option value="compliance">امتثال</option><option value="partner">شريك</option><option value="user">مستخدم</option></select></div></div><button>إضافة مستخدم</button></form><table><thead><tr><th>#</th><th>الاسم</th><th>اسم المستخدم</th><th>الدور</th><th>الحالة</th></tr></thead><tbody>{user_rows}</tbody></table></div>
"""
    return layout("الإعدادات", body, "/settings")


def save_company_settings(fields: Dict[str, List[str]], ip: str = "") -> str:
    with db() as con:
        ensure_schema(con)
        for key in ["company_name", "company_registration", "company_national_address", "company_vat_number"]:
            con.execute("INSERT INTO app_settings(key, value, updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at", (key, form_value(fields, key), now_iso()))
        audit(con, "update_company_settings", "settings", 0, "تم تحديث إعدادات الشركة", ip)
        con.commit()
    return "تم حفظ إعدادات الشركة"


def add_ref_client_type(fields: Dict[str, List[str]], ip: str = "") -> str:
    code = re.sub(r"[^A-Za-z0-9_\-]+", "_", form_value(fields, "code").lower()).strip("_")
    label = form_value(fields, "label_ar")
    if not code or not label:
        raise ValueError("الكود والاسم مطلوبان")
    with db() as con:
        ensure_schema(con)
        # V10.5.6 fix: كان INSERT OR REPLACE يعيد تفعيل كود معطل ويصفر ترتيبه دون تنبيه.
        if con.execute("SELECT 1 FROM ref_client_types WHERE code=?", (code,)).fetchone():
            return f"الكود {code} موجود مسبقاً؛ عدّل التسمية أو فعّله من الجدول أدناه"
        con.execute("INSERT INTO ref_client_types(code, label_ar, is_active, sort_order) VALUES(?,?,1,100)", (code, label))
        audit(con, "add_client_type", "settings", 0, f"{code}: {label}", ip)
        con.commit()
    return "تمت إضافة نوع العميل"


def add_ref_service_type(fields: Dict[str, List[str]], ip: str = "") -> str:
    code = re.sub(r"[^A-Za-z0-9_\-]+", "_", form_value(fields, "code").lower()).strip("_")
    label = form_value(fields, "label_ar")
    if not code or not label:
        raise ValueError("الكود والاسم مطلوبان")
    with db() as con:
        ensure_schema(con)
        # V10.5.6 fix: كان INSERT OR REPLACE يعيد تفعيل كود معطل ويصفر ترتيبه دون تنبيه.
        if con.execute("SELECT 1 FROM ref_service_types WHERE code=?", (code,)).fetchone():
            return f"الكود {code} موجود مسبقاً؛ عدّل التسمية أو فعّله من الجدول أدناه"
        con.execute("INSERT INTO ref_service_types(code, label_ar, is_active, sort_order) VALUES(?,?,1,100)", (code, label))
        audit(con, "add_service_type", "settings", 0, f"{code}: {label}", ip)
        con.commit()
    return "تمت إضافة نوع الخدمة"


def add_app_user(fields: Dict[str, List[str]], ip: str = "") -> str:
    # V10.5.6 fix: التحقق من عدم تكرار اسم المستخدم (كان INSERT OR IGNORE يتجاهل التكرار
    # ويعرض نجاحاً وهمياً) وحصر الدور بالقيم المعتمدة.
    user_name = form_value(fields, "user_name")
    full_name = form_value(fields, "full_name")
    role = form_value(fields, "role", "user")
    if role not in {"admin", "compliance", "partner", "user"}:
        raise ValueError("دور غير معتمد؛ الأدوار المتاحة: admin / compliance / partner / user")
    if not user_name:
        raise ValueError("اسم المستخدم مطلوب")
    with db() as con:
        ensure_schema(con)
        if con.execute("SELECT 1 FROM app_users WHERE user_name=?", (user_name,)).fetchone():
            return f"اسم المستخدم {user_name} موجود مسبقاً ولم يضف من جديد"
        con.execute("INSERT INTO app_users(created_at, full_name, user_name, role, is_active) VALUES(?,?,?,?,1)", (now_iso(), full_name, user_name, role))
        audit(con, "add_user", "settings", 0, user_name, ip)
        con.commit()
    return "تمت إضافة المستخدم"

def layout(title: str, body: str, active: str = "") -> bytes:
    nav = [
        ("/", "الرئيسية"),
        ("/clients", "العملاء"),
        ("/matters", "المشاريع / القضايا"),
        ("/lists", "القوائم"),
        ("/quick_screen", "الفحص السريع"),
        ("/screenings", "الفحص والتطابقات"),
        ("/reports", "التقارير"),
        ("/audit", "سجل التدقيق"),
        ("/production", "أدوات الإنتاج"),
    ]
    nav_html = "".join(f'<a class="{ "active" if href == active else "" }" href="{href}">{label}</a>' for href, label in nav)
    settings_cls = "active" if active.startswith("/settings") else ""
    nav_html += f'<div class="dropdown"><a class="{settings_cls}" href="/settings">الإعدادات</a><div class="dropdown-content"><a href="/settings#company">إعدادات الشركة</a><a href="/settings#client-types">أنواع العملاء</a><a href="/settings#service-types">أنواع الخدمات</a><a href="/settings#users">المستخدمين</a></div></div>' 
    html_doc = f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{h(title)} - Compliance Tracks مسارات الامتثال</title>
<style>
:root {{
  --bg:#f7f9fb; --panel:#ffffff; --text:#111827; --muted:#374151; --line:#cbd5e1;
  --primary:#064e3b; --primary2:#047857; --danger:#991b1b; --warn:#92400e; --ok:#065f46;
  --focus:#1d4ed8;
}}
* {{ box-sizing:border-box; }}
.env-banner {{ position:sticky; top:0; z-index:999; padding:9px 16px; text-align:center; font-weight:900; letter-spacing:.2px; border-bottom:2px solid #111827; }}
.env-uat {{ background:#facc15; color:#111827; }}
.env-prod {{ background:#991b1b; color:#ffffff; }}
body {{ margin:0; font-family: Tahoma, Arial, sans-serif; background:var(--bg); color:var(--text); line-height:1.65; font-size:16px; }}
header {{ background:var(--primary); color:#fff; padding:16px 22px; border-bottom:5px solid #10b981; }}
header h1 {{ margin:0; font-size:22px; }}
header small {{ display:block; color:#d1fae5; margin-top:4px; }}
nav {{ display:flex; flex-wrap:wrap; gap:8px; padding:12px 18px; background:#ecfdf5; border-bottom:1px solid var(--line); }}
nav a {{ color:#064e3b; text-decoration:none; padding:9px 12px; border:1px solid #a7f3d0; border-radius:8px; font-weight:700; background:#fff; }}
nav a.active, nav a:hover {{ background:#064e3b; color:#fff; }}
.dropdown {{ position:relative; display:inline-block; }}
.dropdown-content {{ display:none; position:absolute; right:0; top:44px; background:#fff; min-width:230px; border:1px solid var(--line); border-radius:10px; box-shadow:0 6px 20px rgba(0,0,0,.12); z-index:20; padding:6px; }}
.dropdown-content a {{ display:block; margin:3px 0; border-color:#d1fae5; }}
.dropdown:hover .dropdown-content {{ display:block; }}
main {{ padding:22px; max-width:1280px; margin:auto; }}
.card {{ background:var(--panel); border:1px solid var(--line); border-radius:14px; padding:18px; margin-bottom:18px; box-shadow:0 1px 3px rgba(0,0,0,.07); }}
.grid {{ display:grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap:14px; }}
.kpi {{ border-right:6px solid var(--primary2); }}
.kpi .num {{ font-size:28px; font-weight:800; color:var(--primary); }}
table {{ width:100%; border-collapse:collapse; background:#fff; margin-top:10px; }}
th, td {{ border:1px solid var(--line); padding:9px 10px; text-align:right; vertical-align:top; }}
th {{ background:#f1f5f9; color:#111827; }}
label {{ display:block; font-weight:700; margin-top:10px; }}
input, select, textarea {{ width:100%; padding:10px; border:1px solid #94a3b8; border-radius:8px; font-family:inherit; font-size:15px; background:#fff; color:var(--text); }}
textarea {{ min-height:90px; }}
button, .btn {{ display:inline-block; border:0; border-radius:9px; padding:10px 14px; background:var(--primary); color:#fff; text-decoration:none; cursor:pointer; font-weight:800; margin-top:10px; }}
.btn.secondary {{ background:#334155; }} .btn.warn {{ background:var(--warn); }} .btn.danger {{ background:var(--danger); }} .btn.ok {{ background:var(--ok); }}
.badge {{ display:inline-block; padding:4px 8px; border-radius:999px; background:#e2e8f0; color:#111827; font-weight:700; }}
.badge.ok {{ background:#dcfce7; color:#14532d; }} .badge.warn {{ background:#fef3c7; color:#78350f; }} .badge.danger {{ background:#fee2e2; color:#7f1d1d; }}
.notice {{ padding:12px; border-right:5px solid var(--focus); background:#eff6ff; border-radius:8px; }}
.error {{ padding:12px; border-right:5px solid var(--danger); background:#fef2f2; border-radius:8px; }}
.success {{ padding:12px; border-right:5px solid var(--ok); background:#ecfdf5; border-radius:8px; }}
.workflow {{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; }}
.step {{ background:#fff; border:2px solid #047857; border-radius:12px; padding:10px 12px; font-weight:800; min-width:150px; text-align:center; }}
.arrow {{ font-weight:900; color:#047857; }}
.small {{ color:var(--muted); font-size:14px; }}
hr {{ border:0; border-top:1px solid var(--line); margin:16px 0; }}
</style>
</head>
<body>
<div class="env-banner {'env-uat' if APP_ENV == 'UAT' else 'env-prod'}">{ENV_LABEL_AR}</div>
<header><h1>مسارات الامتثال — Compliance Tracks</h1><small>منصة الامتثال ومعرفة العميل من Legal Tracks · {APP_VERSION} | البيئة: {APP_ENV}</small></header>
<nav>{nav_html}</nav>
<main>{body}</main>
</body></html>"""
    return html_doc.encode("utf-8")


def badge_status(status: str) -> str:
    labels = {
        "draft": "مسودة", "active": "نشط", "under_review": "قيد المراجعة", "blocked": "محظور",
        "no_match": "لا يوجد تطابق", "potential_match": "تطابق محتمل", "high_similarity": "تشابه كبير",
        "confirmed_match": "تطابق مؤكد", "false_positive": "False Positive", "frozen": "مجمد",
        "reported": "تم الإبلاغ", "closed": "مغلق", "success": "نجاح", "partial_success": "نجاح جزئي", "failed": "فشل",
        "exempted_listed_company": "تجاوز قوائم - شركة مدرجة"
    }
    cls = "ok" if status in {"active", "no_match", "false_positive", "closed", "success", "exempted_listed_company", "green", "أخضر"} else "danger" if status in {"confirmed_match", "frozen", "reported", "blocked", "failed", "red", "أحمر"} else "warn"
    return f'<span class="badge {cls}">{h(labels.get(status, status))}</span>'


def dashboard() -> bytes:
    with db() as con:
        ensure_schema(con)
        c = con.execute("SELECT COUNT(*) FROM clients").fetchone()[0]
        m = con.execute("SELECT COUNT(*) FROM matters").fetchone()[0]
        cp = con.execute("SELECT COUNT(*) FROM counterparties").fetchone()[0]
        s = con.execute("SELECT COUNT(*) FROM sanctions_entries WHERE active=1").fetchone()[0]
        hits = con.execute("SELECT COUNT(*) FROM screenings WHERE status IN ('potential_match','high_similarity','confirmed_match','frozen')").fetchone()[0]
        imports = con.execute("SELECT COUNT(*) FROM sanctions_import_logs").fetchone()[0]
    body = f"""
<div class="grid">
 <div class="card kpi"><div>العملاء</div><div class="num">{c}</div></div>
 <div class="card kpi"><div>المشاريع / القضايا</div><div class="num">{m}</div></div>
 <div class="card kpi"><div>الأطراف المقابلة</div><div class="num">{cp}</div></div>
 <div class="card kpi"><div>سجلات القوائم</div><div class="num">{s}</div></div>
 <div class="card kpi"><div>تطابقات مفتوحة</div><div class="num">{hits}</div></div>
 <div class="card kpi"><div>عمليات رفع القوائم</div><div class="num">{imports}</div></div>
</div>
<div class="card">
<h2>خريطة العمل المختصرة</h2>
<div class="workflow">
 <div class="step">فتح عميل</div><div class="arrow">←</div>
 <div class="step">أطراف ومسيطرون</div><div class="arrow">←</div>
 <div class="step">مصدر مال/ثروة (إن وجد)</div><div class="arrow">←</div>
 <div class="step">فتح مشروع / قضية</div><div class="arrow">←</div>
 <div class="step">Counterparties متعددة</div><div class="arrow">←</div>
 <div class="step">فحص داخلي</div><div class="arrow">←</div>
 <div class="step">فحص القوائم</div><div class="arrow">←</div>
 <div class="step">تصعيد/تجميد/إبلاغ</div>
</div>
<p class="notice">تعمل V10 بمنطق الفحص المستمر وحفظ السجلات لمدة {RETENTION_YEARS} سنوات، مع سجل تدقيق لكل رفع قوائم أو نتيجة فحص أو قرار امتثال.</p>
</div>
<div class="card">
<a class="btn" href="/clients/new">إضافة عميل</a>
<a class="btn secondary" href="/matters/new">فتح مشروع / قضية</a>
<a class="btn" href="/lists">رفع القوائم</a>
<a class="btn secondary" href="/quick_screen">الفحص السريع</a>
<a class="btn warn" href="/screenings">مراجعة التطابقات</a>
</div>"""
    return layout("الرئيسية", body, "/")


def clients_list() -> bytes:
    with db() as con:
        rows = con.execute("SELECT * FROM clients ORDER BY id DESC LIMIT 200").fetchall()
    table = "".join(f"<tr><td>{r['id']}</td><td><a href='/client?id={r['id']}'>{h(r['legal_name'])}</a></td><td>{h(client_type_label(r['client_type']))}</td><td>{h(r['registration_number'] or r['id_number'])}</td><td>{'نعم' if r['listed_saudi_market'] else 'لا'}</td><td>{badge_status(r['status'])}</td></tr>" for r in rows)
    body = f"""
<div class="card"><h2>العملاء</h2><a class="btn" href="/clients/new">إضافة عميل جديد</a>
<table><thead><tr><th>#</th><th>اسم العميل</th><th>النوع</th><th>رقم الهوية/السجل</th><th>مدرجة في السوق المالية السعودية</th><th>الحالة</th></tr></thead><tbody>{table or '<tr><td colspan="6">لا توجد بيانات</td></tr>'}</tbody></table></div>
"""
    return layout("العملاء", body, "/clients")


def client_form() -> bytes:
    opts = client_type_options("company")
    body = f"""
<div class="card"><h2>إضافة عميل</h2>
<form method="post" action="/clients/new" enctype="multipart/form-data">
<div class="grid">
<div><label>نوع العميل</label><select id="client_type" name="client_type">{opts}</select></div>
<div><label>اسم العميل</label><input required name="legal_name"></div>
<div><label>رقم الهوية/الإقامة/الجواز</label><input name="id_number"></div>
<div><label>رقم السجل التجاري</label><input name="registration_number"></div>
<div><label>الرقم الموحد للمنشأة (700)</label><input name="unified_number" placeholder="7xxxxxxxxx"></div>
<div><label>الدولة</label><input name="country" value="Saudi Arabia"></div>
<div><label>الجنسية</label><input name="nationality"></div>
<div><label>شركة مدرجة في السوق المالية السعودية؟</label><select id="listed_saudi_market" name="listed_saudi_market"><option value="0">لا</option><option value="1">نعم</option></select><p class="small">يتم تفعيل هذا الخيار فقط إذا كان نوع العميل شركة.</p></div>
<div><label>مستوى المخاطر</label><select name="risk_level"><option value="normal">عادي</option><option value="medium">متوسط</option><option value="high">مرتفع</option></select></div>
<div><label>نوع الوثيقة</label><select name="document_type"><option value="">غير محدد</option><option value="commercial_registration">سجل تجاري</option><option value="national_id">هوية وطنية</option><option value="iqama">إقامة</option><option value="passport">جواز سفر</option><option value="license">ترخيص</option><option value="other">أخرى</option></select></div>
<div><label>نسخة ممسوحة للوثيقة إن وجدت</label><input type="file" name="document_scan" accept=".pdf,.png,.jpg,.jpeg,.webp"></div>
</div>
<label>مصدر المال - اختياري إذا توفرت المعلومة</label><textarea name="source_of_funds"></textarea>
<label>مصدر الثروة - اختياري إذا توفرت المعلومة</label><textarea name="source_of_wealth"></textarea>
<label>سبب تجاوز مصدر المال/الثروة إذا لم تتوفر المعلومة</label><textarea name="source_notes" placeholder="مثال: لم تتوفر المعلومة في مرحلة الرأي المبدئي، وسيتم طلبها عند ارتفاع المخاطر أو قبل القبول النهائي."></textarea>
<p class="notice">مصدر المال/الثروة ليس إلزاميًا لكل العملاء. إذا لم تتم إضافة المعلومة، يجب توثيق سبب التجاوز في الحقل أعلاه.</p>
<label>ملاحظات عامة</label><textarea name="notes"></textarea>
<button type="submit">حفظ العميل</button>
</form></div>
<script>
function toggleListedCompany(){{
  const t=document.getElementById('client_type'); const l=document.getElementById('listed_saudi_market');
  if(!t||!l) return;
  if(t.value !== 'company'){{ l.value='0'; l.disabled=true; }} else {{ l.disabled=false; }}
}}
document.addEventListener('DOMContentLoaded', toggleListedCompany);
document.addEventListener('change', function(e){{ if(e.target && e.target.id==='client_type') toggleListedCompany(); }});
</script>"""
    return layout("إضافة عميل", body, "/clients")

def create_client(fields: Dict[str, List[str]], files: Optional[Dict[str, Tuple[str, bytes]]] = None, ip: str = "") -> int:
    client_type = form_value(fields, "client_type", "company")
    listed = int(client_type == "company" and form_value(fields, "listed_saudi_market", "0") == "1")
    source_funds = form_value(fields, "source_of_funds")
    source_wealth = form_value(fields, "source_of_wealth")
    source_notes = form_value(fields, "source_notes")
    if not (source_funds or source_wealth) and not source_notes:
        raise ValueError("مصدر المال/الثروة اختياري، لكن عند تجاوزه يجب إدخال سبب التجاوز في حقل سبب تجاوز مصدر المال/الثروة.")
    with db() as con:
        ensure_schema(con)
        cur = con.execute(
            """INSERT INTO clients(created_at, updated_at, client_type, legal_name, id_number, registration_number, country, nationality, listed_saudi_market, source_of_funds, source_of_wealth, source_notes, source_skip_reason, document_type, risk_level, status, notes)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                now_iso(), now_iso(), client_type, form_value(fields, "legal_name"),
                form_value(fields, "id_number"), form_value(fields, "registration_number"), form_value(fields, "country"),
                form_value(fields, "nationality"), listed,
                # V10.5.6 fix: عمود سبب التجاوز يقرأ حقله الخاص بدل تكرار الملاحظات.
                source_funds, source_wealth, source_notes, form_value(fields, "source_skip_reason") or source_notes,
                form_value(fields, "document_type"), form_value(fields, "risk_level", "normal"), "draft", form_value(fields, "notes"),
            ),
        )
        client_id = int(cur.lastrowid)
        doc_path, original_filename = save_uploaded_client_document(client_id, files or {})
        if doc_path:
            con.execute("UPDATE clients SET document_scan_path=?, document_original_filename=? WHERE id=?", (doc_path, original_filename, client_id))
        audit(con, "create_client", "client", client_id, "تم إنشاء عميل جديد", ip)
        evaluate_client_risk(con, client_id)
        con.commit()
    return client_id

def evaluate_client_risk(con: sqlite3.Connection, client_id: int) -> None:
    c = con.execute("SELECT * FROM clients WHERE id=?", (client_id,)).fetchone()
    if not c:
        return
    con.execute("DELETE FROM risk_flags WHERE entity_type='client' AND entity_id=?", (client_id,))
    flags: List[Tuple[str, str, str, str]] = []
    text = " ".join([c["country"] or "", c["nationality"] or "", c["notes"] or "", c["source_notes"] or ""]).lower()
    if any(x in text for x in HIGH_RISK_COUNTRIES):
        flags.append(("HIGH_RISK_COUNTRY", "دولة عالية المخاطر", "high", "تم رصد دولة أو جنسية عالية المخاطر"))
    if c["risk_level"] == "high" and not (c["source_of_funds"] or c["source_of_wealth"]):
        if c["source_notes"]:
            flags.append(("SOURCE_SKIPPED", "تم تجاوز مصدر المال/الثروة مع توثيق السبب", "medium", c["source_notes"]))
        else:
            flags.append(("SOURCE_MISSING", "مصدر المال/الثروة غير موثق رغم ارتفاع المخاطر", "high", "يجب طلب المصدر أو توثيق سبب عدم الطلب"))
    if c["listed_saudi_market"]:
        flags.append(("LISTED_COMPANY", "شركة مدرجة - تجاوز فحص قوائم الملكية التفصيلية", "low", "الفحص الداخلي مستمر"))
    for code, label, severity, notes in flags:
        con.execute("INSERT INTO risk_flags(created_at, entity_type, entity_id, flag_code, flag_label, severity, notes) VALUES(?,?,?,?,?,?,?)", (now_iso(), "client", client_id, code, label, severity, notes))


def client_detail(client_id: int) -> bytes:
    with db() as con:
        c = con.execute("SELECT * FROM clients WHERE id=?", (client_id,)).fetchone()
        if not c:
            return layout("غير موجود", "<div class='error'>العميل غير موجود</div>", "/clients")
        parties = con.execute("SELECT * FROM related_parties WHERE parent_type='client' AND parent_id=? ORDER BY id DESC", (client_id,)).fetchall()
        matters = con.execute(
            "SELECT m.*, COALESCE(mc.role, CASE WHEN m.client_id=? THEN 'lead' END) AS instruction_role "
            "FROM matters m LEFT JOIN matter_clients mc ON mc.matter_id=m.id AND mc.client_id=? "
            "WHERE m.client_id=? OR mc.client_id=? ORDER BY m.id DESC", (client_id, client_id, client_id, client_id)).fetchall()
        risks = con.execute("SELECT * FROM risk_flags WHERE entity_type='client' AND entity_id=?", (client_id,)).fetchall()
        # V10.5.6 fix: فصل مساحات المعرفات - كانت النتائج تختلط مع عميل آخر رقمه يساوي رقم طرف مرتبط.
        scr = con.execute("SELECT * FROM screenings WHERE (subject_type='client' AND subject_id=?) OR (subject_type='client_related_party' AND subject_id IN (SELECT id FROM related_parties WHERE parent_type='client' AND parent_id=?)) ORDER BY id DESC LIMIT 50", (client_id, client_id)).fetchall()
    parties_html = "".join(f"<tr><td>{p['id']}</td><td>{h(p['party_role'])}</td><td>{h(p['full_name'])}</td><td>{h(p['id_number'])}</td><td>{h(p['registration_number'])}</td><td>{h(p['ownership_percent'])}</td></tr>" for p in parties)
    matters_html = "".join(f"<tr><td><a href='/matter?id={m['id']}'>{h(m['matter_number'])}</a></td><td>{h(m['title'])}</td><td>{'عميل رئيسي' if m['instruction_role']=='lead' else 'عميل مشارك'}</td><td>{badge_status(m['status'])}</td></tr>" for m in matters)
    risks_html = "".join(f"<tr><td>{h(r['flag_label'])}</td><td>{h(r['severity'])}</td><td>{h(r['notes'])}</td></tr>" for r in risks)
    scr_html = "".join(f"<tr><td>{s['id']}</td><td>{h(s['subject_name'])}</td><td>{h(s['screening_scope'])}</td><td>{h(s['matched_name'])}</td><td>{s['match_score']}</td><td>{badge_status(s['status'])}</td></tr>" for s in scr)
    source_required_note = "<p class='notice'>مصدر المال/الثروة غير إلزامي افتراضيًا، لكنه يصبح مطلوبًا عند ارتفاع المخاطر أو عند طلب مسؤول الامتثال.</p>"
    listed_note = "<p class='notice'>هذا العميل شركة مدرجة في السوق المالية السعودية: يتم توثيق تجاوز فحص القوائم التفصيلي للملكية، مع استمرار الفحص الداخلي.</p>" if c['listed_saudi_market'] else ""
    body = f"""
<div class="card"><h2>{h(c['legal_name'])}</h2>{listed_note}{source_required_note}
<table><tr><th>نوع العميل</th><td>{h(client_type_label(c['client_type']))}</td><th>الحالة</th><td>{badge_status(c['status'])}</td></tr>
<tr><th>هوية/سجل</th><td>{h(c['id_number'] or c['registration_number'])}</td><th>المخاطر</th><td>{h(c['risk_level'])}</td></tr>
<tr><th>مصدر المال</th><td>{h(c['source_of_funds'] or 'غير مضاف')}</td><th>مصدر الثروة</th><td>{h(c['source_of_wealth'] or 'غير مضاف')}</td></tr>
<tr><th>سبب التجاوز</th><td colspan="3">{h(c['source_notes'] or '')}</td></tr>
<tr><th>نوع الوثيقة</th><td>{h(c['document_type'] or '')}</td><th>النسخة الممسوحة</th><td>{h(c['document_original_filename'] or '')}</td></tr></table>
<div class="grid"><form method="post" action="/client/run_internal_screening"><input type="hidden" name="client_id" value="{client_id}"><button>المرحلة الأولى: الفحص الداخلي</button></form>
<form method="post" action="/client/run_sanctions_screening"><input type="hidden" name="client_id" value="{client_id}"><button class="btn secondary">المرحلة الثانية: الفحص مع القوائم</button></form></div>
</div>
<div class="card"><h3>الأطراف الداخلية للعميل: مجلس الإدارة / هيئة المديرين / المستفيد الحقيقي / المفوضون</h3><p class="notice">تضاف هذه البيانات بعد حفظ العميل، ثم تدخل في الفحص الداخلي وفحص القوائم.</p>
<form method="post" action="/client/add_party">
<input type="hidden" name="client_id" value="{client_id}">
<div class="grid"><div><label>الدور</label><select name="party_role"><option value="board_member">عضو مجلس إدارة</option><option value="manager">عضو هيئة مديرين</option><option value="ubo">مستفيد حقيقي</option><option value="authorized_signatory">مفوض بالتوقيع</option><option value="controller">مسيطر فعلي</option></select></div>
<div><label>الاسم</label><input required name="full_name"></div><div><label>رقم الهوية</label><input name="id_number"></div><div><label>رقم السجل</label><input name="registration_number"></div><div><label>الجنسية</label><input name="nationality"></div><div><label>الدولة</label><input name="country"></div><div><label>نسبة الملكية</label><input name="ownership_percent" type="number" step="0.01"></div></div>
<label>ملاحظات</label><textarea name="notes"></textarea><button>حفظ الطرف</button>
</form>
<table><thead><tr><th>#</th><th>الدور</th><th>الاسم</th><th>هوية</th><th>سجل</th><th>ملكية %</th></tr></thead><tbody>{parties_html or '<tr><td colspan="6">لا توجد أطراف</td></tr>'}</tbody></table></div>
<div class="card"><h3>المشاريع / القضايا</h3><a class="btn" href="/matters/new?client_id={client_id}">فتح مشروع / قضية لهذا العميل</a><table><thead><tr><th>رقم المشروع / القضية</th><th>اسم العقد / المشروع / القضية</th><th>صفة العميل</th><th>الحالة</th></tr></thead><tbody>{matters_html or '<tr><td colspan="4">لا توجد مشاريع / قضايا</td></tr>'}</tbody></table></div>
<div class="card"><h3>مؤشرات المخاطر</h3><table><thead><tr><th>المؤشر</th><th>الحدة</th><th>الملاحظة</th></tr></thead><tbody>{risks_html or '<tr><td colspan="3">لا توجد مؤشرات</td></tr>'}</tbody></table></div>
<div class="card"><h3>آخر نتائج الفحص</h3><table><thead><tr><th>#</th><th>المفحوص</th><th>النطاق</th><th>التطابق</th><th>النسبة</th><th>الحالة</th></tr></thead><tbody>{scr_html or '<tr><td colspan="6">لا توجد نتائج</td></tr>'}</tbody></table></div>
"""
    return layout("تفاصيل العميل", body, "/clients")


def add_related_party(fields: Dict[str, List[str]], parent_type: str, parent_id_key: str, ip: str = "") -> int:
    parent_id = int(form_value(fields, parent_id_key, "0") or 0)
    pct_val = form_value(fields, "ownership_percent")
    # V10.5.6 fix: قيمة نسبة غير رقمية كانت تسبب خطأ 500 غير مفسر.
    try:
        pct = float(pct_val.replace("٪", "").replace("%", "").strip()) if pct_val else None
    except ValueError:
        raise ValueError("نسبة الملكية يجب أن تكون رقماً مثل 25 أو 12.5")
    with db() as con:
        ensure_schema(con)
        cur = con.execute(
            """INSERT INTO related_parties(created_at, parent_type, parent_id, party_role, full_name, id_number, registration_number, nationality, country, ownership_percent, notes)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (now_iso(), parent_type, parent_id, form_value(fields, "party_role"), form_value(fields, "full_name"), form_value(fields, "id_number"), form_value(fields, "registration_number"), form_value(fields, "nationality"), form_value(fields, "country"), pct, form_value(fields, "notes")),
        )
        party_id = int(cur.lastrowid)
        audit(con, "add_related_party", parent_type, parent_id, f"إضافة طرف مرتبط: {form_value(fields, 'full_name')}", ip)
        con.commit()
    return party_id


def matters_list() -> bytes:
    with db() as con:
        rows = con.execute("SELECT m.*, c.legal_name FROM matters m JOIN clients c ON c.id=m.client_id ORDER BY m.id DESC LIMIT 200").fetchall()
    table = "".join(f"<tr><td>{r['id']}</td><td><a href='/matter?id={r['id']}'>{h(r['matter_number'])}</a></td><td>{h(r['title'])}</td><td>{h(r['legal_name'])}</td><td>{badge_status(r['status'])}</td></tr>" for r in rows)
    body = f"<div class='card'><h2>المشاريع / القضايا</h2><a class='btn' href='/matters/new'>فتح مشروع / قضية جديدة</a><table><thead><tr><th>#</th><th>رقم المشروع / القضية</th><th>اسم العقد / المشروع / القضية</th><th>العميل</th><th>الحالة</th></tr></thead><tbody>{table or '<tr><td colspan="5">لا توجد بيانات</td></tr>'}</tbody></table></div>"
    return layout("المشاريع / القضايا", body, "/matters")


def matter_form(prefill_client_id: str = "") -> bytes:
    with db() as con:
        ensure_schema(con)
        clients = con.execute("SELECT id, legal_name FROM clients ORDER BY legal_name").fetchall()
    opts = "".join(f"<option value='{c['id']}' {'selected' if str(c['id'])==prefill_client_id else ''}>{h(c['legal_name'])}</option>" for c in clients)
    service_opts = service_type_options()
    body = f"""
<div class="card"><h2>فتح مشروع / قضية جديدة</h2>
<form method="post" action="/matters/new">
<div class="grid"><div><label>العميل</label><select required name="client_id">{opts}</select></div><div><label>رقم المشروع / القضية</label><input name="matter_number" placeholder="يتم توليده تلقائيًا إذا تركته فارغًا"></div><div><label>اسم العقد / المشروع / القضية</label><input required name="title"></div><div><label>نوع الخدمة</label><select name="service_type">{service_opts}</select></div></div>
<label>وصف المشروع / القضية</label><textarea name="description"></textarea><button>حفظ المشروع / القضية</button>
</form></div>"""
    return layout("فتح مشروع / قضية", body, "/matters")

def create_matter(fields: Dict[str, List[str]], ip: str = "") -> int:
    with db() as con:
        ensure_schema(con)
        matter_number = form_value(fields, "matter_number") or next_matter_number(con)
        cur = con.execute("""INSERT INTO matters(created_at, updated_at, client_id, matter_number, title, service_type, description, status)
        VALUES(?,?,?,?,?,?,?,?)""", (now_iso(), now_iso(), int(form_value(fields, "client_id")), matter_number, form_value(fields, "title"), form_value(fields, "service_type"), form_value(fields, "description"), "draft"))
        matter_id = int(cur.lastrowid)
        audit(con, "create_matter", "matter", matter_id, f"تم فتح مشروع / قضية جديدة برقم {matter_number}", ip)
        con.commit()
    return matter_id

def matter_detail(matter_id: int) -> bytes:
    with db() as con:
        m = con.execute("SELECT m.*, c.legal_name FROM matters m JOIN clients c ON c.id=m.client_id WHERE m.id=?", (matter_id,)).fetchone()
        if not m:
            return layout("غير موجود", "<div class='error'>المشروع / القضية غير موجود</div>", "/matters")
        cps = con.execute("SELECT * FROM counterparties WHERE matter_id=? ORDER BY id DESC", (matter_id,)).fetchall()
        cp_ids = [r["id"] for r in cps]
        cp_parties = []
        if cp_ids:
            q = ",".join("?" for _ in cp_ids)
            cp_parties = con.execute(f"SELECT * FROM related_parties WHERE parent_type='counterparty' AND parent_id IN ({q}) ORDER BY id DESC", cp_ids).fetchall()
        scr = con.execute("SELECT * FROM screenings WHERE subject_type IN ('counterparty','counterparty_related_party') ORDER BY id DESC LIMIT 100").fetchall()
    cps_html = "".join(f"<tr><td><a href='/counterparty?id={cp['id']}'>{cp['id']}</a></td><td>{h(cp['full_name'])}</td><td>{h(cp['party_type'])}</td><td>{h(cp['id_number'])}</td><td>{h(cp['registration_number'])}</td><td>{h(cp['role_in_matter'])}</td></tr>" for cp in cps)
    parties_html = "".join(f"<tr><td>{p['parent_id']}</td><td>{h(p['party_role'])}</td><td>{h(p['full_name'])}</td><td>{h(p['id_number'])}</td><td>{h(p['registration_number'])}</td></tr>" for p in cp_parties)
    scr_html = "".join(f"<tr><td>{s['id']}</td><td>{h(s['subject_name'])}</td><td>{h(s['screening_scope'])}</td><td>{h(s['matched_name'])}</td><td>{s['match_score']}</td><td>{badge_status(s['status'])}</td></tr>" for s in scr if True)
    body = f"""
<div class="card"><h2>{h(m['matter_number'])} - {h(m['title'])}</h2><p>العميل: <a href="/client?id={m['client_id']}">{h(m['legal_name'])}</a></p>
<div class="grid"><form method="post" action="/matter/run_internal_screening"><input type="hidden" name="matter_id" value="{matter_id}"><button>المرحلة الأولى: الفحص الداخلي للأطراف المقابلة</button></form><form method="post" action="/matter/run_sanctions_screening"><input type="hidden" name="matter_id" value="{matter_id}"><button class="btn secondary">المرحلة الثانية: فحص الأطراف المقابلة مع القوائم</button></form></div></div>
<div class="card"><h3>إضافة Counterparty ديناميكي</h3>
<form method="post" action="/counterparty/new"><input type="hidden" name="matter_id" value="{matter_id}">
<div class="grid"><div><label>نوع الطرف</label><select name="party_type"><option value="company">شركة</option><option value="individual">فرد</option><option value="government">جهة حكومية</option><option value="other">أخرى</option></select></div><div><label>اسم الطرف</label><input required name="full_name"></div><div><label>رقم الهوية</label><input name="id_number"></div><div><label>رقم السجل</label><input name="registration_number"></div><div><label>الجنسية</label><input name="nationality"></div><div><label>الدولة</label><input name="country"></div><div><label>صفة الطرف في المشروع / القضية</label><input name="role_in_matter"></div></div>
<label>ملاحظات</label><textarea name="notes"></textarea><button>حفظ الطرف</button> <span class="small">بعد الحفظ يمكنك الضغط على زر إضافة طرف آخر وستظهر نفس الشاشة لإضافة الطرف التالي.</span></form>
<table><thead><tr><th>#</th><th>الاسم</th><th>النوع</th><th>هوية</th><th>سجل</th><th>الصفة</th></tr></thead><tbody>{cps_html or '<tr><td colspan="6">لم تتم إضافة أطراف مقابلة بعد</td></tr>'}</tbody></table></div>
<div class="card"><h3>أعضاء مجلس/مديرون/مستفيدون للأطراف المقابلة</h3><table><thead><tr><th>رقم Counterparty</th><th>الدور</th><th>الاسم</th><th>هوية</th><th>سجل</th></tr></thead><tbody>{parties_html or '<tr><td colspan="5">لا توجد بيانات</td></tr>'}</tbody></table></div>
<div class="card"><h3>آخر نتائج الفحص للمشروع / القضية</h3><table><thead><tr><th>#</th><th>المفحوص</th><th>النطاق</th><th>التطابق</th><th>النسبة</th><th>الحالة</th></tr></thead><tbody>{scr_html or '<tr><td colspan="6">لا توجد نتائج</td></tr>'}</tbody></table></div>
"""
    return layout("تفاصيل المشروع / القضية", body, "/matters")


def create_counterparty(fields: Dict[str, List[str]], ip: str = "") -> int:
    matter_id = int(form_value(fields, "matter_id", "0"))
    with db() as con:
        ensure_schema(con)
        cur = con.execute("""INSERT INTO counterparties(created_at, matter_id, party_type, full_name, id_number, registration_number, nationality, country, role_in_matter, notes)
        VALUES(?,?,?,?,?,?,?,?,?,?)""", (now_iso(), matter_id, form_value(fields, "party_type"), form_value(fields, "full_name"), form_value(fields, "id_number"), form_value(fields, "registration_number"), form_value(fields, "nationality"), form_value(fields, "country"), form_value(fields, "role_in_matter"), form_value(fields, "notes")))
        cp_id = int(cur.lastrowid)
        audit(con, "create_counterparty", "counterparty", cp_id, f"إضافة طرف مقابل للمشروع / القضية {matter_id}", ip)
        con.commit()
    return cp_id


def counterparty_detail(cp_id: int) -> bytes:
    with db() as con:
        cp = con.execute("SELECT * FROM counterparties WHERE id=?", (cp_id,)).fetchone()
        if not cp:
            return layout("غير موجود", "<div class='error'>الطرف المقابل غير موجود</div>", "/matters")
        parties = con.execute("SELECT * FROM related_parties WHERE parent_type='counterparty' AND parent_id=? ORDER BY id DESC", (cp_id,)).fetchall()
    parties_html = "".join(f"<tr><td>{p['id']}</td><td>{h(p['party_role'])}</td><td>{h(p['full_name'])}</td><td>{h(p['id_number'])}</td><td>{h(p['registration_number'])}</td></tr>" for p in parties)
    body = f"""
<div class="card"><h2>الطرف المقابل: {h(cp['full_name'])}</h2><p><a class="btn secondary" href="/matter?id={cp['matter_id']}">العودة للمشروع / القضية</a></p></div>
<div class="card"><h3>إضافة أعضاء مجلس/مديرين/مستفيدين لهذا الطرف المقابل</h3>
<form method="post" action="/counterparty/add_party"><input type="hidden" name="counterparty_id" value="{cp_id}">
<div class="grid"><div><label>الدور</label><select name="party_role"><option value="board_member">عضو مجلس إدارة</option><option value="manager">عضو هيئة مديرين</option><option value="ubo">مستفيد حقيقي</option><option value="authorized_signatory">مفوض بالتوقيع</option><option value="controller">مسيطر فعلي</option></select></div><div><label>الاسم</label><input required name="full_name"></div><div><label>رقم الهوية</label><input name="id_number"></div><div><label>رقم السجل</label><input name="registration_number"></div><div><label>الجنسية</label><input name="nationality"></div><div><label>الدولة</label><input name="country"></div><div><label>نسبة الملكية</label><input type="number" step="0.01" name="ownership_percent"></div></div>
<label>ملاحظات</label><textarea name="notes"></textarea><button>حفظ</button></form>
<table><thead><tr><th>#</th><th>الدور</th><th>الاسم</th><th>هوية</th><th>سجل</th></tr></thead><tbody>{parties_html or '<tr><td colspan="5">لا توجد بيانات</td></tr>'}</tbody></table></div>
"""
    return layout("تفاصيل Counterparty", body, "/matters")


def subject_tuple(entity_type: str, row: sqlite3.Row, subject_type: str) -> Dict[str, Any]:
    keys = set(row.keys())
    if "client_type" in keys:
        category = row["client_type"] or "company"
    elif "party_type" in keys:
        category = row["party_type"] or "company"
    else:
        category = "company" if (row["registration_number"] if "registration_number" in keys else "") else "individual"
    return {
        "subject_type": subject_type,
        "subject_id": int(row["id"]),
        "subject_name": row["legal_name"] if "legal_name" in keys else row["full_name"],
        "id_number": row["id_number"] or "",
        "registration_number": row["registration_number"] or "",
        "country": row["country"] or "" if "country" in keys else "",
        "nationality": row["nationality"] or "" if "nationality" in keys else "",
        "entity_category": category,
    }



def insert_screening(con: sqlite3.Connection, subject: Dict[str, Any], scope: str, match: Dict[str, Any], score: int, reason: str, status: str) -> None:
    con.execute(
        """INSERT INTO screenings(created_at, updated_at, subject_type, subject_id, subject_name, screening_scope, list_name, matched_entity_type, matched_entity_id, matched_name, match_score, match_reason, status)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            now_iso(), now_iso(), subject["subject_type"], subject["subject_id"], subject["subject_name"], scope,
            match.get("list_name"), match.get("matched_entity_type"), match.get("matched_entity_id"), match.get("matched_name"), score, reason, status,
        ),
    )


def all_internal_entities(con: sqlite3.Connection) -> List[Dict[str, Any]]:
    entities: List[Dict[str, Any]] = []
    for r in con.execute("SELECT id, client_type, legal_name, id_number, registration_number, country, nationality FROM clients").fetchall():
        entities.append({"matched_entity_type": "client", "matched_entity_id": r["id"], "matched_name": r["legal_name"], "id_number": r["id_number"] or "", "registration_number": r["registration_number"] or "", "entity_category": r["client_type"] or "company"})
    for r in con.execute("SELECT id, party_type, full_name, id_number, registration_number FROM counterparties").fetchall():
        entities.append({"matched_entity_type": "counterparty", "matched_entity_id": r["id"], "matched_name": r["full_name"], "id_number": r["id_number"] or "", "registration_number": r["registration_number"] or "", "entity_category": r["party_type"] or "company"})
    for r in con.execute("SELECT id, full_name, id_number, registration_number, parent_type FROM related_parties").fetchall():
        category = "company" if r["registration_number"] else "individual"
        entities.append({"matched_entity_type": f"{r['parent_type']}_related_party", "matched_entity_id": r["id"], "matched_name": r["full_name"], "id_number": r["id_number"] or "", "registration_number": r["registration_number"] or "", "entity_category": category})
    return entities



def screen_subjects(con: sqlite3.Connection, subjects: List[Dict[str, Any]], skip_sanctions: bool = False, ip: str = "", screening_mode: str = "both") -> Dict[str, int]:
    created = 0
    hits = 0
    warnings = 0
    internal_entities = all_internal_entities(con) if screening_mode in {"internal", "both"} else []
    sanctions = con.execute("SELECT * FROM sanctions_entries WHERE active=1 ORDER BY list_name, id").fetchall() if screening_mode in {"sanctions", "both"} else []

    for sub in subjects:
        if screening_mode in {"internal", "both"}:
            internal_hits = 0
            for ent in internal_entities:
                if ent["matched_entity_type"] == sub["subject_type"] and ent["matched_entity_id"] == sub["subject_id"]:
                    continue
                score, reason = match_score(
                    sub["subject_name"], ent["matched_name"], sub["id_number"], ent.get("id_number", ""),
                    sub["registration_number"], ent.get("registration_number", ""),
                    sub.get("entity_category", ""), ent.get("entity_category", ""),
                )
                if score >= 75:
                    status = status_for_score(score, reason)
                    insert_screening(con, sub, "internal", ent, score, reason, status)
                    created += 1; hits += 1; internal_hits += 1
            if internal_hits == 0:
                insert_screening(con, sub, "internal", {
                    "list_name": "INTERNAL_REGISTRY", "matched_entity_type": "none", "matched_entity_id": 0, "matched_name": "-"
                }, 0, "تم فحص السجل الداخلي بالأرقام المميزة والأسماء متعددة المقاطع ولم يوجد تطابق مؤثر", "no_match")
                created += 1

        if screening_mode not in {"sanctions", "both"}:
            continue

        applicable = list(sanctions)
        # الشركة المدرجة لا تتجاوز جميع القوائم: يستثنى فقط الفحص الوطني 1373 للشركة نفسها،
        # بينما تستمر قوائم الأمم المتحدة، كما يستمر فحص الأطراف المرتبطة دون استثناء.
        if skip_sanctions and sub.get("subject_type") == "client":
            national_ids = {se["id"] for se in applicable if str(se["list_type"] or "").upper() == "NATIONAL" or "1373" in str(se["list_name"] or "")}
            # V10.5.6 fix: لا يوثق استثناء لقائمة وطنية غير محملة أصلاً، والمقارنة بالمعرف بدل مسح صفوف كامل.
            if national_ids:
                applicable = [se for se in applicable if se["id"] not in national_ids]
                insert_screening(con, sub, "sanctions", {
                    "list_name": "NATIONAL_1373", "matched_entity_type": "listed_company_exemption", "matched_entity_id": 0,
                    "matched_name": "استثناء القائمة الوطنية للشركة المدرجة"
                }, 0, "استثناء موثق للقائمة الوطنية 1373 فقط؛ استمر فحص قوائم الأمم المتحدة", "exempted_listed_company")
                created += 1

        if not applicable:
            insert_screening(con, sub, "sanctions", {
                "list_name": "NO_ACTIVE_LISTS", "matched_entity_type": "system_warning", "matched_entity_id": 0, "matched_name": "-"
            }, 0, "تعذر إصدار نتيجة سليمة: لا توجد قوائم عقوبات نشطة قابلة للفحص ضمن النطاق المطلوب", "list_unavailable")
            created += 1; warnings += 1
            continue

        sanctions_hits = 0
        screened_lists = set()
        for se in applicable:
            screened_lists.add(str(se["list_name"] or ""))
            ent = {"list_name": se["list_name"], "matched_entity_type": "sanctions_entry", "matched_entity_id": se["id"], "matched_name": se["full_name"], "id_number": se["id_number"] or "", "registration_number": se["registration_number"] or "", "entity_category": "company" if se["registration_number"] else ""}
            score, reason = match_score(
                sub["subject_name"], se["full_name"], sub["id_number"], se["id_number"] or "",
                sub["registration_number"], se["registration_number"] or "",
                sub.get("entity_category", ""), ent.get("entity_category", ""),
            )
            if score >= 75:
                status = status_for_score(score, reason)
                insert_screening(con, sub, "sanctions", ent, score, reason, status)
                created += 1; hits += 1; sanctions_hits += 1
        if sanctions_hits == 0:
            list_label = ", ".join(sorted(x for x in screened_lists if x))[:500] or "ALL_ACTIVE_LISTS"
            insert_screening(con, sub, "sanctions", {
                "list_name": list_label, "matched_entity_type": "none", "matched_entity_id": 0, "matched_name": "-"
            }, 0, f"تم فحص {len(applicable)} سجل نشط في {len(screened_lists)} قائمة بالأرقام المميزة والأسماء متعددة المقاطع ولم يوجد تطابق مؤثر", "no_match")
            created += 1

    audit(con, "run_screening", "screening", 0, f"تم إنشاء {created} نتيجة؛ تطابقات={hits}؛ تحذيرات={warnings}", ip)
    return {"created": created, "hits": hits, "warnings": warnings}



def run_client_screening(client_id: int, ip: str = "", screening_mode: str = "both") -> Dict[str, int]:
    with db() as con:
        ensure_schema(con)
        c = con.execute("SELECT * FROM clients WHERE id=?", (client_id,)).fetchone()
        if not c:
            return {"created": 0, "hits": 0, "warnings": 0}
        subjects = [subject_tuple("client", c, "client")]
        for p in con.execute("SELECT * FROM related_parties WHERE parent_type='client' AND parent_id=?", (client_id,)).fetchall():
            subjects.append(subject_tuple("related_party", p, "client_related_party"))
        skip = bool(c["listed_saudi_market"])
        result = screen_subjects(con, subjects, skip_sanctions=skip, ip=ip, screening_mode=screening_mode)
        # V10.5.6 fix: الفحص لا يخفف حالة عميل محظور/مجمد بقرار امتثال،
        # ولا تعتمد حالة "نشط" إلا بعد فحص يشمل القوائم والسجل الداخلي معاً.
        if result.get("hits", 0) or result.get("warnings", 0):
            con.execute("UPDATE clients SET status='under_review', updated_at=? WHERE id=? AND status NOT IN ('blocked','frozen')", (now_iso(), client_id))
        elif screening_mode == "both":
            con.execute("UPDATE clients SET status='active', updated_at=? WHERE id=? AND status NOT IN ('blocked','frozen')", (now_iso(), client_id))
        con.commit()
        return result



def run_matter_screening(matter_id: int, ip: str = "", screening_mode: str = "both") -> Dict[str, int]:
    with db() as con:
        ensure_schema(con)
        subjects: List[Dict[str, Any]] = []
        cps = con.execute("SELECT * FROM counterparties WHERE matter_id=?", (matter_id,)).fetchall()
        for cp in cps:
            subjects.append(subject_tuple("counterparty", cp, "counterparty"))
            for p in con.execute("SELECT * FROM related_parties WHERE parent_type='counterparty' AND parent_id=?", (cp["id"],)).fetchall():
                subjects.append(subject_tuple("related_party", p, "counterparty_related_party"))
        # V10.5.6 fix: مشروع بلا أطراف مقابلة لا يعتبر مفحوصاً ولا تتغير حالته.
        if not subjects:
            audit(con, "matter_screening_no_subjects", "matter", matter_id, "لا توجد أطراف مقابلة مسجلة؛ لم يجر فحص ولم تتغير حالة المشروع", ip)
            con.commit()
            return {"created": 0, "hits": 0, "warnings": 1}
        result = screen_subjects(con, subjects, skip_sanctions=False, ip=ip, screening_mode=screening_mode)
        # V10.5.6 fix: عدم تخفيف حالة مشروع محظور، واعتماد "نشط" فقط بعد فحص يشمل النطاقين.
        if result.get("hits", 0) or result.get("warnings", 0):
            con.execute("UPDATE matters SET status='under_review', updated_at=? WHERE id=? AND status NOT IN ('blocked','frozen')", (now_iso(), matter_id))
        elif screening_mode == "both":
            con.execute("UPDATE matters SET status='active', updated_at=? WHERE id=? AND status NOT IN ('blocked','frozen')", (now_iso(), matter_id))
        con.commit()
        return result




def quick_screen_form(message: str = "") -> bytes:
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    body = f"""
<div class="card"><h2>الفحص السريع</h2>{msg}
<p class="notice">يبدأ البحث بالأرقام المميزة مثل الهوية والجواز والسجل التجاري. مطابقة أسماء الأشخاص لا تعتمد على اسم منفرد مثل محمد أو أحمد، بل تتطلب مقطعين متصلين على الأقل. أسماء الكيانات تفحص بعد استبعاد الصفة القانونية العامة مثل شركة أو مؤسسة.</p>
<form method="post" action="/quick_screen"><div class="grid">
<div><label>صفة الفحص</label><select name="subject_type"><option value="client_candidate">عميل محتمل</option><option value="counterparty_candidate">طرف مقابل محتمل</option></select></div>
<div><label>نوع الشخص / الكيان</label><select name="entity_category"><option value="individual">فرد</option><option value="company">شركة / مؤسسة / كيان</option><option value="government">جهة حكومية</option><option value="other">أخرى</option></select></div>
<div><label>الاسم</label><input required name="subject_name"></div>
<div><label>رقم الهوية/الإقامة/الجواز</label><input name="id_number"></div>
<div><label>رقم السجل التجاري / رقم الكيان</label><input name="registration_number"></div>
<div><label>الدولة</label><input name="country"></div>
<div><label>الجنسية</label><input name="nationality"></div>
</div><button>تشغيل الفحص السريع</button></form></div>"""
    return layout("الفحص السريع", body, "/quick_screen")



def run_quick_screening(fields: Dict[str, List[str]], ip: str = "") -> bytes:
    subject = {
        "subject_type": form_value(fields, "subject_type", "client_candidate"),
        "subject_id": 0,
        "subject_name": form_value(fields, "subject_name"),
        "id_number": form_value(fields, "id_number"),
        "registration_number": form_value(fields, "registration_number"),
        "country": form_value(fields, "country"),
        "nationality": form_value(fields, "nationality"),
        "entity_category": form_value(fields, "entity_category", "individual"),
    }
    if not subject["subject_name"]:
        raise ValueError("اسم الطرف مطلوب للفحص السريع")
    internal_hits = []
    sanctions_hits = []
    lists_available = True
    with db() as con:
        ensure_schema(con)
        for ent in all_internal_entities(con):
            score, reason = match_score(subject["subject_name"], ent["matched_name"], subject["id_number"], ent.get("id_number", ""), subject["registration_number"], ent.get("registration_number", ""), subject.get("entity_category", ""), ent.get("entity_category", ""))
            if score >= 75:
                internal_hits.append((ent, score, reason, status_for_score(score, reason)))
        active_lists = con.execute("SELECT * FROM sanctions_entries WHERE active=1").fetchall()
        lists_available = bool(active_lists)
        for se in active_lists:
            candidate_category = "company" if se["registration_number"] else ""
            score, reason = match_score(subject["subject_name"], se["full_name"], subject["id_number"], se["id_number"] or "", subject["registration_number"], se["registration_number"] or "", subject.get("entity_category", ""), candidate_category)
            if score >= 75:
                sanctions_hits.append(({"matched_name": se["full_name"], "list_name": se["list_name"]}, score, reason, status_for_score(score, reason)))
        audit(con, "quick_screening", "screening", 0, f"{subject['subject_name']}: internal={len(internal_hits)}, sanctions={len(sanctions_hits)}, lists_available={lists_available}", ip)
        con.commit()
    all_hits = internal_hits + sanctions_hits
    max_score = max([x[1] for x in all_hits], default=0)
    # V10.5.6 fix: التطابقات الفعلية لا تحجب بغياب القوائم؛ غياب القوائم يظهر
    # كتحذير مستقل، ويصبح حالة النتيجة فقط عند عدم وجود أي تطابق مؤثر.
    if max_score >= 100:
        status = "confirmed_match"
    elif max_score >= 90:
        status = "high_similarity"
    elif max_score >= 75:
        status = "potential_match"
    else:
        status = "list_unavailable" if not lists_available else "no_match"
    risk_level, visual_status, required_action = risk_visual_for_screening(status, max_score)
    rows = ""
    for ent, score, reason, st in internal_hits:
        rows += f"<tr><td>داخلي</td><td>{h(ent.get('matched_name'))}</td><td>-</td><td>{score}</td><td>{h(reason)}</td><td>{badge_status(st)}</td></tr>"
    for ent, score, reason, st in sanctions_hits:
        rows += f"<tr><td>قوائم</td><td>{h(ent.get('matched_name'))}</td><td>{h(ent.get('list_name'))}</td><td>{score}</td><td>{h(reason)}</td><td>{badge_status(st)}</td></tr>"
    if not lists_available:
        rows += f"<tr><td>قوائم</td><td>-</td><td>لا توجد قوائم نشطة</td><td>0</td><td>لا يمكن اعتبار الفحص سليماً قبل رفع وتفعيل القوائم الرسمية</td><td>{badge_status('list_unavailable')}</td></tr>"
    no_rows = '<tr><td colspan="6">لا توجد تطابقات مؤثرة</td></tr>'
    body = f"""
<div class="card"><h2>نتيجة الفحص السريع</h2>
<table><tr><th>الاسم المفحوص</th><td>{h(subject['subject_name'])}</td><th>المؤشر البصري</th><td>{badge_status(visual_status)}</td></tr>
<tr><th>أعلى درجة تشابه</th><td>{max_score}</td><th>الإجراء المقترح</th><td>{h(required_action)}</td></tr></table>
<p class="notice">الأرقام المميزة تفحص بعد توحيد الأرقام العربية واللاتينية وإزالة المسافات والشرطات. الاسم المنفرد للشخص لا يولد تطابقاً بمفرده.</p>
<table><thead><tr><th>النطاق</th><th>الاسم المطابق</th><th>القائمة</th><th>النسبة</th><th>السبب</th><th>الحالة</th></tr></thead><tbody>{rows or no_rows}</tbody></table>
<p><a class="btn" href="/clients/new">إضافة عميل بناءً على النتيجة</a> <a class="btn secondary" href="/quick_screen">فحص سريع جديد</a></p></div>"""
    return layout("نتيجة الفحص السريع", body, "/quick_screen")


def lists_page(message: str = "") -> bytes:
    with db() as con:
        logs = con.execute("SELECT * FROM sanctions_import_logs ORDER BY id DESC LIMIT 50").fetchall()
        total = con.execute("SELECT COUNT(*) FROM sanctions_entries WHERE active=1").fetchone()[0]
    log_html = "".join(
        f"<tr><td>{l['id']}</td><td>{h(l['list_name'])}</td><td>{h(l['filename'])}</td><td>{l['total_records']}</td><td>{l['success_count']}</td><td>{l['failed_count']}</td><td>{l['duplicate_count']}</td><td>{badge_status(l['status'])}</td><td><pre>{h(l['error_details_json'])}</pre></td></tr>"
        for l in logs
    )
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    body = f"""
<div class="card"><h2>إدارة ورفع القوائم - Multi Format Import Engine</h2>{msg}
<p class="notice">إجمالي السجلات النشطة في القوائم: <b>{total}</b>. يدعم V10 رفع CSV و Excel متعدد الصفحات XLSX و XML و HTML و PDF مع سجل رقابي يوضح عدد السجلات، المرفوع، الفاشل، المكرر، اسم القائمة، السطر/الصفحة/Sheet الذي فشل.</p>
<form method="post" action="/lists/upload" enctype="multipart/form-data">
<div class="grid"><div><label>اسم القائمة</label><input required name="list_name" placeholder="UN_1267 / UN_1988 / NATIONAL_1373 / UN_1718 / UN_2231"></div><div><label>رابط المصدر الرسمي</label><input name="source_url"></div><div><label>نوع القائمة</label><select name="list_type"><option value="TF">تمويل الإرهاب</option><option value="PF">تمويل انتشار التسلح</option><option value="NATIONAL">وطنية</option></select></div><div><label>ملف القائمة</label><input required type="file" name="list_file" accept=".csv,.xlsx,.xls,.xml,.html,.htm,.pdf"></div></div>
<button>رفع القائمة</button> <a class="btn secondary" href="/templates/sanctions_import_template.csv">قالب CSV</a> <a class="btn secondary" href="/templates/sanctions_import_template.xlsx">قالب Excel</a> <a class="btn secondary" href="/templates/sanctions_import_template.xml">قالب XML</a> <a class="btn secondary" href="/templates/sanctions_import_template.html">قالب HTML</a>
<p class="small">ملاحظة: PDF يعالج كاستخراج أولي ويظهر أي سطور غير قابلة للقراءة في سجل الفشل للمراجعة الرقابية.</p>
</form></div>
<div class="card"><h3>سجل عمليات الرفع الرقابي</h3><table><thead><tr><th>#</th><th>القائمة</th><th>الملف</th><th>عدد الملف</th><th>نجاح</th><th>فشل</th><th>مكرر</th><th>الحالة</th><th>تفاصيل الفشل</th></tr></thead><tbody>{log_html or '<tr><td colspan="9">لا توجد عمليات رفع</td></tr>'}</tbody></table></div>
"""
    return layout("القوائم", body, "/lists")

def _hash_field(value: Any) -> str:
    # V10.5.6 fix: تحييد الفاصل | داخل القيم حتى لا تتصادم بصمات صفوف مختلفة.
    return str(value or "").replace("|", "¦")


def row_hash(row: Dict[str, str]) -> str:
    basis = "|".join([_hash_field(row.get("list_name", "")), _hash_field(row.get("full_name", "")), _hash_field(row.get("id_number", "")), _hash_field(row.get("registration_number", "")), _hash_field(row.get("list_type", ""))])
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()


def import_sanctions_csv(fields: Dict[str, List[str]], files: Dict[str, Tuple[str, bytes]], ip: str = "") -> str:
    list_name_default = form_value(fields, "list_name", "UN_LIST")
    source_url_default = form_value(fields, "source_url")
    list_type_default = form_value(fields, "list_type", "TF")
    filename, content = files.get("csv_file", ("uploaded.csv", b""))
    file_sha = hashlib.sha256(content).hexdigest()
    text = content.decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(text))
    total = success = failed = dup = 0
    errors = []
    with db() as con:
        ensure_schema(con)
        if not reader.fieldnames:
            failed = 1
            errors.append({"row": 1, "error": "الملف فارغ أو لا يحتوي على رؤوس أعمدة"})
        else:
            for idx, raw in enumerate(reader, start=2):
                total += 1
                row = {k: (v or "").strip() for k, v in raw.items() if k is not None}
                row.setdefault("list_name", list_name_default)
                row.setdefault("source_url", source_url_default)
                row.setdefault("list_type", list_type_default)
                if not row.get("list_name"):
                    row["list_name"] = list_name_default
                if not row.get("source_url"):
                    row["source_url"] = source_url_default
                if not row.get("list_type"):
                    row["list_type"] = list_type_default
                if not row.get("full_name"):
                    failed += 1
                    errors.append({"row": idx, "error": "اسم الشخص/الكيان full_name مطلوب"})
                    continue
                rh = row_hash(row)
                try:
                    con.execute("""INSERT INTO sanctions_entries(created_at, list_name, source_url, list_type, full_name, id_number, registration_number, nationality, country, notes, row_hash, active)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,1)""", (now_iso(), row.get("list_name"), row.get("source_url"), row.get("list_type"), row.get("full_name"), row.get("id_number"), row.get("registration_number"), row.get("nationality"), row.get("country"), row.get("notes"), rh))
                    success += 1
                except sqlite3.IntegrityError:
                    dup += 1
                except Exception as exc:
                    failed += 1
                    errors.append({"row": idx, "error": str(exc)[:300]})
        status = "success" if failed == 0 else "partial_success" if success > 0 else "failed"
        con.execute("""INSERT INTO sanctions_import_logs(created_at, list_name, source_url, filename, file_sha256, total_records, success_count, failed_count, duplicate_count, status, error_details_json)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), list_name_default, source_url_default, filename, file_sha, total, success, failed, dup, status, json.dumps(errors, ensure_ascii=False)))
        audit(con, "import_sanctions_list", "sanctions_import", 0, f"{list_name_default}: total={total}, success={success}, failed={failed}, duplicate={dup}", ip)
        con.commit()
    return f"القائمة: {list_name_default} | عدد السجلات في الملف: {total} | تم رفع: {success} | فشل: {failed} | مكرر: {dup} | الحالة: {status}"



FIELD_ALIASES = {
    "full_name": {"full_name", "name", "listed_name", "entity_name", "person_name", "الاسم", "اسم", "اسم الشخص", "اسم الكيان", "الاسم الكامل"},
    "id_number": {"id_number", "id", "national_id", "passport", "passport_number", "رقم الهوية", "هوية", "جواز", "رقم الجواز"},
    "registration_number": {"registration_number", "reg_no", "cr", "commercial_registration", "رقم السجل", "السجل التجاري", "سجل تجاري"},
    "nationality": {"nationality", "الجنسية"},
    "country": {"country", "state", "jurisdiction", "الدولة", "البلد"},
    "notes": {"notes", "remarks", "comment", "ملاحظات", "ملاحظة"},
    "list_name": {"list_name", "list", "source_list", "اسم القائمة", "القائمة"},
    "source_url": {"source_url", "url", "source", "رابط المصدر", "المصدر"},
    "list_type": {"list_type", "type", "نوع القائمة"},
}


def canonical_field(name: str) -> str:
    key = normalize_name(str(name or "")).replace(" ", "_")
    plain = str(name or "").strip().lower()
    for canonical, aliases in FIELD_ALIASES.items():
        if plain in aliases or key in {normalize_name(a).replace(" ", "_") for a in aliases}:
            return canonical
    return plain or "unknown"


def normalize_import_row(raw: Dict[str, Any], defaults: Dict[str, str]) -> Dict[str, str]:
    row: Dict[str, str] = {}
    for k, v in raw.items():
        ck = canonical_field(k)
        if ck in {"full_name", "id_number", "registration_number", "nationality", "country", "notes", "list_name", "source_url", "list_type"}:
            value = str(v or "").strip()
            # V10.5.6 fix: عمود مرادف فارغ لا يمسح قيمة صالحة التقطت قبله لنفس الحقل.
            if value or ck not in row:
                row[ck] = value
    for k, v in defaults.items():
        if not row.get(k):
            row[k] = v
    return row


def decode_import_text(content: bytes) -> str:
    """V10.5.6: فك ترميز ملفات الاستيراد النصية بأمان: UTF-8 أولاً ثم Windows-1256
    (ترميز Excel العربي الشائع). كان الاستبدال الصامت للأحرف يحول الأسماء العربية إلى
    رموز تالفة تستورد "بنجاح" ثم لا تطابق أي فحص - فشل امتثال صامت."""
    for enc in ("utf-8-sig", "utf-8"):
        try:
            return content.decode(enc)
        except UnicodeDecodeError:
            continue
    try:
        return content.decode("cp1256")
    except UnicodeDecodeError:
        return content.decode("utf-8-sig", errors="replace")


def parse_delimited_text(text: str, defaults: Dict[str, str], source_label: str = "CSV") -> Tuple[List[Dict[str, str]], List[Dict[str, Any]]]:
    errors: List[Dict[str, Any]] = []
    rows: List[Dict[str, str]] = []
    sample = text[:4096]
    delimiter = ","
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        delimiter = dialect.delimiter
    except Exception:
        if "\t" in sample:
            delimiter = "\t"
        elif "|" in sample:
            delimiter = "|"
        elif ";" in sample:
            delimiter = ";"
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    if not reader.fieldnames:
        return [], [{"location": source_label, "row": 1, "error": "لا توجد رؤوس أعمدة قابلة للقراءة"}]
    for idx, raw in enumerate(reader, start=2):
        row = normalize_import_row(raw, defaults)
        if not row.get("full_name"):
            errors.append({"location": source_label, "row": idx, "error": "اسم الشخص/الكيان full_name مطلوب"})
            continue
        row["_location"] = f"{source_label}:row:{idx}"
        rows.append(row)
    return rows, errors


class SimpleTableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.in_cell = False
        self.current_cell: List[str] = []
        self.current_row: List[str] = []
        self.tables: List[List[List[str]]] = []
        self.current_table: List[List[str]] = []
        self.in_table = False

    def handle_starttag(self, tag: str, attrs: List[Tuple[str, str]]) -> None:
        tag = tag.lower()
        if tag == "table":
            self.in_table = True
            self.current_table = []
        elif self.in_table and tag == "tr":
            self.current_row = []
        elif self.in_table and tag in {"td", "th"}:
            self.in_cell = True
            self.current_cell = []

    def handle_data(self, data: str) -> None:
        if self.in_cell:
            self.current_cell.append(data)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if self.in_table and tag in {"td", "th"}:
            self.in_cell = False
            self.current_row.append(" ".join(self.current_cell).strip())
        elif self.in_table and tag == "tr":
            if any(x.strip() for x in self.current_row):
                self.current_table.append(self.current_row)
        elif tag == "table" and self.in_table:
            if self.current_table:
                self.tables.append(self.current_table)
            self.in_table = False


def parse_html_tables(content: bytes, defaults: Dict[str, str]) -> Tuple[List[Dict[str, str]], List[Dict[str, Any]]]:
    parser = SimpleTableParser()
    parser.feed(decode_import_text(content))
    rows: List[Dict[str, str]] = []
    errors: List[Dict[str, Any]] = []
    if not parser.tables:
        return [], [{"location": "HTML", "row": 1, "error": "لم يتم العثور على جداول HTML"}]
    for ti, table in enumerate(parser.tables, start=1):
        if len(table) < 2:
            errors.append({"location": f"HTML table {ti}", "row": 1, "error": "الجدول لا يحتوي على بيانات كافية"})
            continue
        headers = table[0]
        for ri, cells in enumerate(table[1:], start=2):
            raw = {headers[i] if i < len(headers) else f"col_{i}": cells[i] if i < len(cells) else "" for i in range(max(len(headers), len(cells)))}
            row = normalize_import_row(raw, defaults)
            if not row.get("full_name"):
                errors.append({"location": f"HTML table {ti}", "row": ri, "error": "اسم الشخص/الكيان full_name مطلوب"})
                continue
            row["_location"] = f"HTML:table:{ti}:row:{ri}"
            rows.append(row)
    return rows, errors


def parse_xlsx(content: bytes, defaults: Dict[str, str], filename: str) -> Tuple[List[Dict[str, str]], List[Dict[str, Any]]]:
    rows: List[Dict[str, str]] = []
    errors: List[Dict[str, Any]] = []
    if filename.lower().endswith(".xls"):
        try:
            import xlrd  # type: ignore
            book = xlrd.open_workbook(file_contents=content)
        except Exception as exc:
            return [], [{"location": filename, "row": 1, "error": f"ملفات XLS القديمة تحتاج xlrd أو تحويلها إلى XLSX: {exc}"}]
        for sheet in book.sheets():
            header = None
            for row_no in range(sheet.nrows):
                vals = ["" if sheet.cell_value(row_no, c) is None else str(sheet.cell_value(row_no, c)).strip() for c in range(sheet.ncols)]
                if not any(vals):
                    continue
                if header is None:
                    header = vals
                    continue
                raw = {header[i] if i < len(header) else f"col_{i}": vals[i] if i < len(vals) else "" for i in range(max(len(header), len(vals)))}
                row = normalize_import_row(raw, defaults)
                if not row.get("full_name"):
                    errors.append({"location": f"Sheet {sheet.name}", "row": row_no + 1, "error": "اسم الشخص/الكيان full_name مطلوب"})
                    continue
                row["_location"] = f"Excel-XLS:sheet:{sheet.name}:row:{row_no + 1}"
                rows.append(row)
            if header is None:
                errors.append({"location": f"Sheet {sheet.name}", "row": 1, "error": "Sheet فارغ"})
        return rows, errors
    try:
        import openpyxl  # type: ignore
        wb = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    except Exception as exc:
        return [], [{"location": filename, "row": 1, "error": f"تعذر قراءة ملف Excel: {exc}"}]
    for ws in wb.worksheets:
        header = None
        for row_no, values in enumerate(ws.iter_rows(values_only=True), start=1):
            vals = ["" if v is None else str(v).strip() for v in values]
            if not any(vals):
                continue
            if header is None:
                header = vals
                continue
            raw = {header[i] if i < len(header) else f"col_{i}": vals[i] if i < len(vals) else "" for i in range(max(len(header), len(vals)))}
            row = normalize_import_row(raw, defaults)
            if not row.get("full_name"):
                errors.append({"location": f"Sheet {ws.title}", "row": row_no, "error": "اسم الشخص/الكيان full_name مطلوب"})
                continue
            row["_location"] = f"Excel-XLSX:sheet:{ws.title}:row:{row_no}"
            rows.append(row)
        if header is None:
            errors.append({"location": f"Sheet {ws.title}", "row": 1, "error": "Sheet فارغ"})
    return rows, errors


def parse_xml(content: bytes, defaults: Dict[str, str]) -> Tuple[List[Dict[str, str]], List[Dict[str, Any]]]:
    rows: List[Dict[str, str]] = []
    errors: List[Dict[str, Any]] = []
    try:
        root = ET.fromstring(content.decode("utf-8-sig", errors="replace"))
    except Exception as exc:
        return [], [{"location": "XML", "row": 1, "error": f"XML غير صالح: {exc}"}]
    candidates = []
    for elem in root.iter():
        children = list(elem)
        if not children and not elem.attrib:
            continue
        raw: Dict[str, Any] = dict(elem.attrib)
        for ch in children:
            tag = ch.tag.split("}")[-1]
            text = " ".join((ch.itertext())) if list(ch) else (ch.text or "")
            if text.strip():
                raw[tag] = text.strip()
        if raw:
            candidates.append(raw)
    for idx, raw in enumerate(candidates, start=1):
        row = normalize_import_row(raw, defaults)
        if not row.get("full_name"):
            # Ignore containers silently unless they look like records.
            if any(canonical_field(k) in {"id_number", "registration_number", "country", "nationality"} for k in raw):
                errors.append({"location": "XML", "row": idx, "error": "اسم الشخص/الكيان full_name مطلوب"})
            continue
        row["_location"] = f"XML:element:{idx}"
        rows.append(row)
    if not rows and not errors:
        errors.append({"location": "XML", "row": 1, "error": "لم يتم العثور على عناصر قابلة للتحويل إلى سجلات قوائم"})
    return rows, errors


def parse_pdf_text(content: bytes, defaults: Dict[str, str]) -> Tuple[List[Dict[str, str]], List[Dict[str, Any]]]:
    errors: List[Dict[str, Any]] = []
    pages_text: List[str] = []
    try:
        from pypdf import PdfReader  # type: ignore
        reader = PdfReader(io.BytesIO(content))
        for pageno, page in enumerate(reader.pages, start=1):
            pages_text.append(page.extract_text() or "")
    except Exception as exc:
        return [], [{"location": "PDF", "row": 1, "error": f"تعذر استخراج نص PDF: {exc}"}]
    all_rows: List[Dict[str, str]] = []
    for pageno, text in enumerate(pages_text, start=1):
        lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
        delimited = "\n".join([ln for ln in lines if "," in ln or "|" in ln or "\t" in ln or ";" in ln])
        # V10.5.6 fix: اشتراط سطر رؤوس حقيقي في أول أسطر الجزء المجدول بدل مجرد ورود
        # كلمة name في أي موضع، حتى لا يفسر نص عادي كملف مفصول بفواصل.
        delimited_lines = delimited.splitlines()
        has_header = bool(delimited_lines) and any(
            canonical_field(tok.strip()) == "full_name"
            for tok in re.split(r"[,;|\t]", delimited_lines[0]))
        if delimited and has_header:
            rows, errs = parse_delimited_text(delimited, defaults, f"PDF page {pageno}")
            all_rows.extend(rows)
            errors.extend(errs)
        else:
            # Fallback: each visible line can become a name for preview-controlled import.
            for li, ln in enumerate(lines, start=1):
                if len(ln) < 3 or len(ln) > 180:
                    continue
                row = normalize_import_row({"full_name": ln, "notes": "PDF extracted line - يرجى المراجعة"}, defaults)
                row["_location"] = f"PDF:page:{pageno}:line:{li}"
                all_rows.append(row)
            if lines:
                # V10.5.6 ضابط رقابي: أسطر PDF الحرة لا تعتمد قائمة نهائية تلقائياً؛
                # تسجل خطأً موقفاً للتفعيل حتى تراجع وتصحح عبر ملف CSV/XLSX/XML منظم.
                errors.append({"location": f"PDF:page:{pageno}", "row": 0,
                               "error": "ملف PDF بدون جدول منظم: الأسطر المستخرجة تحتاج مراجعة يدوية قبل الاعتماد؛ استخدم ملف CSV/XLSX/XML رسمياً للتفعيل المباشر"})
    if not all_rows:
        errors.append({"location": "PDF", "row": 1, "error": "لم يتم استخراج سجلات من PDF؛ قد يكون الملف صورة أو غير منظم"})
    return all_rows, errors


def parse_sanctions_file(filename: str, content: bytes, defaults: Dict[str, str]) -> Tuple[List[Dict[str, str]], List[Dict[str, Any]]]:
    ext = Path(filename or "").suffix.lower()
    if ext in {".csv", ".txt"}:
        return parse_delimited_text(decode_import_text(content), defaults, "CSV")
    if ext in {".xlsx", ".xls"}:
        return parse_xlsx(content, defaults, filename)
    if ext == ".xml":
        return parse_xml(content, defaults)
    if ext in {".html", ".htm"}:
        return parse_html_tables(content, defaults)
    if ext == ".pdf":
        return parse_pdf_text(content, defaults)
    return [], [{"location": filename, "row": 1, "error": f"صيغة غير مدعومة: {ext}"}]


def import_sanctions_file(fields: Dict[str, List[str]], files: Dict[str, Tuple[str, bytes]], ip: str = "") -> str:
    list_name_default = form_value(fields, "list_name", "UN_LIST")
    source_url_default = form_value(fields, "source_url")
    list_type_default = form_value(fields, "list_type", "TF")
    filename, content = files.get("list_file", files.get("csv_file", ("uploaded.csv", b"")))
    defaults = {"list_name": list_name_default, "source_url": source_url_default, "list_type": list_type_default}
    file_sha = hashlib.sha256(content).hexdigest()
    parsed_rows, errors = parse_sanctions_file(filename, content, defaults)
    total = len(parsed_rows) + len([e for e in errors if "اسم الشخص" in str(e.get("error", ""))])
    success = failed = dup = 0
    with db() as con:
        ensure_schema(con)
        for row in parsed_rows:
            if not row.get("full_name"):
                failed += 1
                errors.append({"location": row.get("_location", filename), "error": "اسم الشخص/الكيان full_name مطلوب"})
                continue
            rh = row_hash(row)
            try:
                con.execute("""INSERT INTO sanctions_entries(created_at, list_name, source_url, list_type, full_name, id_number, registration_number, nationality, country, notes, row_hash, active)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,1)""", (now_iso(), row.get("list_name"), row.get("source_url"), row.get("list_type"), row.get("full_name"), row.get("id_number"), row.get("registration_number"), row.get("nationality"), row.get("country"), (row.get("notes") or "") + (" | " + row.get("_location", "") if row.get("_location") else ""), rh))
                success += 1
            except sqlite3.IntegrityError:
                dup += 1
            except Exception as exc:
                failed += 1
                errors.append({"location": row.get("_location", filename), "error": str(exc)[:300]})
        failed += len([e for e in errors if "تعذر" in str(e.get("error", "")) or "غير" in str(e.get("error", "")) or "لا توجد" in str(e.get("error", "")) or "مطلوب" in str(e.get("error", ""))])
        status = "success" if failed == 0 else "partial_success" if success > 0 else "failed"
        con.execute("""INSERT INTO sanctions_import_logs(created_at, list_name, source_url, filename, file_sha256, total_records, success_count, failed_count, duplicate_count, status, error_details_json)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), list_name_default, source_url_default, filename, file_sha, total, success, failed, dup, status, json.dumps(errors[:200], ensure_ascii=False)))
        audit(con, "import_sanctions_list_multiformat", "sanctions_import", 0, f"{filename}; {list_name_default}: total={total}, success={success}, failed={failed}, duplicate={dup}", ip)
        con.commit()
    return f"القائمة: {list_name_default} | الملف: {filename} | عدد السجلات المقروءة: {total} | تم رفع: {success} | فشل: {failed} | مكرر: {dup} | الحالة: {status}"

def parse_multipart(headers: Dict[str, str], body: bytes) -> Tuple[Dict[str, List[str]], Dict[str, Tuple[str, bytes]]]:
    ctype = headers.get("content-type", "")
    # V10.5.6 fix: التقاط قيمة boundary وحدها ولو تبعتها معاملات أخرى مثل charset.
    m = re.search(r'boundary="?([^";]+)"?', ctype)
    if not m:
        return {}, {}
    boundary = m.group(1).strip().encode()
    fields: Dict[str, List[str]] = {}
    files: Dict[str, Tuple[str, bytes]] = {}
    for part in body.split(b"--" + boundary):
        if not part or part in (b"--\r\n", b"--"):
            continue
        # V10.5.6 fix: إزالة CRLF واحد فقط من كل طرف بدل strip الذي كان يقص أسطر
        # النهاية الشرعية من الملفات المرفوعة فيغير بصمة SHA-256 الموثقة للملف.
        if part.startswith(b"\r\n"):
            part = part[2:]
        if part.endswith(b"\r\n"):
            part = part[:-2]
        if b"\r\n\r\n" not in part:
            continue
        head, data = part.split(b"\r\n\r\n", 1)
        head_text = head.decode("utf-8", errors="replace")
        disp = re.search(r'Content-Disposition: form-data;\s*name="([^"]+)"(?:;\s*filename="([^"]*)")?', head_text, re.I)
        if not disp:
            continue
        name, filename = disp.group(1), disp.group(2)
        if filename is not None:
            files[name] = (filename or "uploaded.csv", data)
        else:
            fields.setdefault(name, []).append(data.decode("utf-8", errors="replace"))
    return fields, files



def risk_visual_for_screening(status: str, score: int) -> Tuple[str, str, str]:
    if status in {"confirmed_match", "frozen", "reported", "blocked"} or score >= 100:
        return "red", "أحمر", "خطر جدًا - يحتاج تجميد/حظر تعامل/إبلاغ حسب نتيجة المراجعة"
    if status in {"potential_match", "high_similarity", "under_review"} or score >= 75:
        return "yellow", "أصفر", "عليه تحفظ - يحتاج مراجعة مسؤول الامتثال وعناية أكبر"
    return "green", "أخضر", "ناجح - لا يوجد تطابق مؤثر"


def next_report_number(con: sqlite3.Connection) -> str:
    today = dt.datetime.now().strftime("%Y%m%d")
    count = con.execute("SELECT COUNT(*) FROM screening_reports WHERE report_number LIKE ?", (f"SCR-{today}-%",)).fetchone()[0] + 1
    return f"SCR-{today}-{count:05d}"


def report_context_for_screening(con: sqlite3.Connection, r: sqlite3.Row) -> Tuple[Optional[int], Optional[int], Optional[int]]:
    client_id = matter_id = counterparty_id = None
    st = r["subject_type"]
    sid = r["subject_id"]
    if st == "client":
        client_id = sid
    elif st == "client_related_party":
        p = con.execute("SELECT parent_id FROM related_parties WHERE id=? AND parent_type='client'", (sid,)).fetchone()
        if p:
            client_id = p["parent_id"]
    elif st == "counterparty":
        cp = con.execute("SELECT id, matter_id FROM counterparties WHERE id=?", (sid,)).fetchone()
        if cp:
            counterparty_id = cp["id"]
            matter_id = cp["matter_id"]
            m = con.execute("SELECT client_id FROM matters WHERE id=?", (matter_id,)).fetchone()
            client_id = m["client_id"] if m else None
    elif st == "counterparty_related_party":
        p = con.execute("SELECT parent_id FROM related_parties WHERE id=? AND parent_type='counterparty'", (sid,)).fetchone()
        if p:
            counterparty_id = p["parent_id"]
            cp = con.execute("SELECT matter_id FROM counterparties WHERE id=?", (counterparty_id,)).fetchone()
            if cp:
                matter_id = cp["matter_id"]
                m = con.execute("SELECT client_id FROM matters WHERE id=?", (matter_id,)).fetchone()
                client_id = m["client_id"] if m else None
    return client_id, matter_id, counterparty_id


def find_pdf_font() -> Optional[str]:
    # V10.5.6: توسيع قائمة الخطوط المرشحة الداعمة للعربية (خاصة خارج Windows).
    candidates = [
        BASE_DIR / "assets" / "fonts" / "DejaVuSans.ttf",
        Path("C:/Windows/Fonts/arial.ttf"),
        Path("C:/Windows/Fonts/tahoma.ttf"),
        Path("C:/Windows/Fonts/segoeui.ttf"),
        Path("C:/Windows/Fonts/trado.ttf"),
        Path("/usr/share/fonts/truetype/noto/NotoNaskhArabic-Regular.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return None


def pdf_text(value: Any) -> str:
    # Simple RTL-safe fallback for environments without Arabic shaping packages.
    text = str(value or "")
    try:
        import arabic_reshaper  # type: ignore
        from bidi.algorithm import get_display  # type: ignore
        return get_display(arabic_reshaper.reshape(text))
    except Exception:
        return text


def generate_screening_pdf(path: Path, report_number: str, r: sqlite3.Row, visual: str, required_action: str) -> None:
    try:
        from reportlab.lib.pagesizes import A4  # type: ignore
        from reportlab.lib import colors  # type: ignore
        from reportlab.pdfbase import pdfmetrics  # type: ignore
        from reportlab.pdfbase.ttfonts import TTFont  # type: ignore
        from reportlab.pdfgen import canvas  # type: ignore
    except Exception as exc:
        raise RuntimeError("توليد PDF يتطلب تثبيت reportlab من ملف requirements.txt") from exc
    path.parent.mkdir(parents=True, exist_ok=True)
    font_name = "Helvetica"
    fp = find_pdf_font()
    if fp:
        try:
            pdfmetrics.registerFont(TTFont("LegalTracksArabic", fp))
            font_name = "LegalTracksArabic"
        except Exception:
            font_name = "Helvetica"
    c = canvas.Canvas(str(path), pagesize=A4)
    w, hgt = A4
    margin = 42
    y = hgt - margin
    color = colors.green if visual == "أخضر" else colors.orange if visual == "أصفر" else colors.red
    c.setFillColor(colors.HexColor("#064e3b"))
    c.rect(0, hgt-70, w, 70, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont(font_name, 15)
    c.drawRightString(w-margin, hgt-35, pdf_text("تقرير نتيجة الفحص والامتثال"))
    c.setFont(font_name, 10)
    c.drawRightString(w-margin, hgt-55, pdf_text(f"Legal Tracks V10 | {report_number}"))
    y -= 80
    c.setFillColor(color)
    c.roundRect(margin, y-28, 120, 30, 8, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont(font_name, 13)
    c.drawCentredString(margin+60, y-8, pdf_text(visual))
    c.setFillColor(colors.black)
    y -= 48
    lines = [
        ("رقم التقرير", report_number),
        ("تاريخ الإصدار", now_iso()),
        ("اسم المفحوص", r["subject_name"]),
        ("نوع المفحوص", r["subject_type"]),
        ("نطاق الفحص", r["screening_scope"]),
        ("القائمة", r["list_name"] or "-") ,
        ("الاسم المطابق", r["matched_name"] or "-"),
        ("درجة التشابه", str(r["match_score"])),
        ("سبب النتيجة", r["match_reason"] or "-"),
        ("حالة الفحص", r["status"]),
        ("الإجراء المطلوب", required_action),
        ("ملاحظة رقابية", "يحفظ هذا التقرير ضمن سجل التقارير ويمكن مراجعته في أي وقت. لا يتم كشف التطابق للعميل أو أي طرف خارجي إلا وفق الإجراء النظامي."),
    ]
    c.setFont(font_name, 11)
    for label, value in lines:
        if y < 80:
            c.showPage(); y = hgt - margin; c.setFont(font_name, 11)
        c.setFillColor(colors.HexColor("#f1f5f9"))
        c.roundRect(margin, y-18, w-2*margin, 24, 4, fill=1, stroke=0)
        c.setFillColor(colors.HexColor("#111827"))
        c.drawRightString(w-margin-8, y-10, pdf_text(f"{label}: {value}"))
        y -= 31
    c.setFont(font_name, 8)
    c.setFillColor(colors.grey)
    c.drawString(margin, 25, f"Generated by Compliance Tracks (مسارات الامتثال) - Legal Tracks V10 - {report_number}")
    c.save()


def create_screening_report(screening_id: int, ip: str = "") -> Tuple[int, str, str]:
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT * FROM screenings WHERE id=?", (screening_id,)).fetchone()
        if not r:
            raise ValueError("نتيجة الفحص غير موجودة")
        risk_level, visual_status, required_action = risk_visual_for_screening(r["status"], int(r["match_score"] or 0))
        report_number = next_report_number(con)
        pdf_path = REPORT_DIR / f"{report_number}.pdf"
        generate_screening_pdf(pdf_path, report_number, r, visual_status, required_action)
        pdf_sha = hashlib.sha256(pdf_path.read_bytes()).hexdigest()
        client_id, matter_id, counterparty_id = report_context_for_screening(con, r)
        cur = con.execute("""INSERT INTO screening_reports(created_at, report_number, created_by, client_id, matter_id, counterparty_id, screening_id, risk_level, visual_status, decision_status, pdf_path, pdf_sha256, summary, required_action)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), report_number, "compliance", client_id, matter_id, counterparty_id, screening_id, risk_level, visual_status, r["status"], str(pdf_path), pdf_sha, f"{r['subject_name']} - {r['status']} - score {r['match_score']}", required_action))
        report_id = int(cur.lastrowid)
        con.execute("""INSERT INTO screening_report_items(report_id, screening_id, subject_type, subject_name, screening_scope, list_name, matched_name, match_score, match_reason, status)
        VALUES(?,?,?,?,?,?,?,?,?,?)""", (report_id, screening_id, r["subject_type"], r["subject_name"], r["screening_scope"], r["list_name"], r["matched_name"], r["match_score"], r["match_reason"], r["status"]))
        audit(con, "create_screening_pdf_report", "screening_report", report_id, f"{report_number}; risk={risk_level}; sha={pdf_sha[:16]}", ip)
        con.commit()
    return report_id, report_number, str(pdf_path)


def get_report_file(report_id: int) -> Tuple[Optional[Path], str]:
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT * FROM screening_reports WHERE id=?", (report_id,)).fetchone()
        if not r:
            return None, ""
        return Path(r["pdf_path"]), r["report_number"]

def screenings_page(message: str = "") -> bytes:
    with db() as con:
        rows = con.execute("SELECT * FROM screenings ORDER BY id DESC LIMIT 300").fetchall()
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    parts = []
    for r in rows:
        risk_level, visual_status, required_action = risk_visual_for_screening(r['status'], int(r['match_score'] or 0))
        parts.append(f"""<tr><td>{r['id']}</td><td>{h(r['subject_type'])}</td><td>{h(r['subject_name'])}</td><td>{h(r['screening_scope'])}</td><td>{h(r['list_name'])}</td><td>{h(r['matched_name'])}</td><td>{r['match_score']}</td><td>{h(r['match_reason'])}</td><td>{badge_status(r['status'])}</td><td>{badge_status(visual_status)}<br><span class='small'>{h(required_action)}</span></td><td><form method='post' action='/screening/update'><input type='hidden' name='screening_id' value='{r['id']}'><select name='status'><option value='under_review'>قيد المراجعة</option><option value='false_positive'>False Positive</option><option value='confirmed_match'>تطابق مؤكد</option><option value='frozen'>تجميد/حظر تعامل</option><option value='reported'>تم الإبلاغ</option><option value='closed'>إغلاق</option></select><input name='decision_reason' placeholder='سبب القرار'><button>تحديث</button></form></td><td><form method='post' action='/screening/report'><input type='hidden' name='screening_id' value='{r['id']}'><button class='btn secondary'>إصدار PDF</button></form></td></tr>""")
    table = "".join(parts)
    body = f"""
<div class="card"><h2>الفحص والتطابقات</h2>{msg}<p class="notice">أي تطابق مؤكد أو تشابه كبير يتطلب مراجعة مسؤول الامتثال، مع مراعاة السرية وحظر التنبيه وعدم إفشاء الإجراء للعميل أو الأطراف الخارجية. في V10 يمكن إصدار تقرير PDF لكل نتيجة وحفظه في سجل التقارير.</p>
<table><thead><tr><th>#</th><th>نوع المفحوص</th><th>الاسم</th><th>النطاق</th><th>القائمة</th><th>التطابق</th><th>النسبة</th><th>السبب</th><th>الحالة</th><th>المؤشر البصري</th><th>قرار الامتثال</th><th>تقرير PDF</th></tr></thead><tbody>{table or '<tr><td colspan="12">لا توجد نتائج</td></tr>'}</tbody></table></div>
"""
    return layout("الفحص", body, "/screenings")

def update_screening(fields: Dict[str, List[str]], ip: str = "") -> str:
    sid = int(form_value(fields, "screening_id", "0"))
    status = form_value(fields, "status", "under_review")
    reason = form_value(fields, "decision_reason")
    with db() as con:
        ensure_schema(con)
        con.execute("UPDATE screenings SET status=?, decision_reason=?, reviewed_by='compliance', reviewed_at=?, updated_at=? WHERE id=?", (status, reason, now_iso(), now_iso(), sid))
        if status in {"frozen", "reported", "confirmed_match", "false_positive", "closed"}:
            con.execute("INSERT INTO compliance_actions(created_at, screening_id, action_type, action_note, created_by) VALUES(?,?,?,?,?)", (now_iso(), sid, status, reason, "compliance"))
        audit(con, "update_screening_status", "screening", sid, f"status={status}; reason={reason}", ip)
        con.commit()
    return f"تم تحديث نتيجة الفحص رقم {sid} إلى {status}"


def reports_page() -> bytes:
    with db() as con:
        imports = con.execute("SELECT status, COUNT(*) c FROM sanctions_import_logs GROUP BY status").fetchall()
        screen = con.execute("SELECT status, COUNT(*) c FROM screenings GROUP BY status").fetchall()
        risk = con.execute("SELECT severity, COUNT(*) c FROM risk_flags GROUP BY severity").fetchall()
        reps = con.execute("SELECT * FROM screening_reports ORDER BY id DESC LIMIT 200").fetchall()
    def rows(rs):
        return "".join(f"<tr><td>{h(r[0])}</td><td>{r[1]}</td></tr>" for r in rs)
    rep_rows = "".join(f"<tr><td>{r['id']}</td><td>{h(r['report_number'])}</td><td>{h(r['created_at'])}</td><td>{badge_status(r['visual_status'])}</td><td>{h(r['summary'])}</td><td>{h(r['required_action'])}</td><td>{h((r['pdf_sha256'] or '')[:16])}...</td><td><a class='btn secondary' href='/reports/download?id={r['id']}'>عرض PDF</a></td></tr>" for r in reps)
    body = f"""
<div class="card"><h2>تقارير رقابية</h2><p class="notice">تستخدم هذه التقارير لإظهار حالة القوائم، نتائج الفحص، مؤشرات المخاطر، وسجل تقارير PDF الصادرة. الألوان: أخضر = ناجح، أصفر = عليه تحفظ، أحمر = خطر جدًا ويحتاج تصعيد/إبلاغ حسب المراجعة.</p></div>
<div class="grid"><div class="card"><h3>حالة رفع القوائم</h3><table>{rows(imports) or '<tr><td>لا توجد بيانات</td></tr>'}</table></div>
<div class="card"><h3>حالة نتائج الفحص</h3><table>{rows(screen) or '<tr><td>لا توجد بيانات</td></tr>'}</table></div>
<div class="card"><h3>مؤشرات المخاطر</h3><table>{rows(risk) or '<tr><td>لا توجد بيانات</td></tr>'}</table></div></div>
<div class="card"><h3>سجل تقارير الفحص المصدرة</h3><table><thead><tr><th>#</th><th>رقم التقرير</th><th>التاريخ</th><th>اللون</th><th>الملخص</th><th>الإجراء المطلوب</th><th>SHA256</th><th>PDF</th></tr></thead><tbody>{rep_rows or '<tr><td colspan="8">لا توجد تقارير PDF مصدرة بعد</td></tr>'}</tbody></table></div>
"""
    return layout("التقارير", body, "/reports")

def audit_page() -> bytes:
    with db() as con:
        rows = con.execute("SELECT * FROM audit_events ORDER BY id DESC LIMIT 300").fetchall()
    table = "".join(f"<tr><td>{r['id']}</td><td>{h(r['created_at'])}</td><td>{h(r['action'])}</td><td>{h(r['entity_type'])}</td><td>{h(r['entity_id'])}</td><td>{h(r['details'])}</td></tr>" for r in rows)
    body = f"<div class='card'><h2>سجل التدقيق غير القابل للحذف من الواجهة</h2><table><thead><tr><th>#</th><th>التاريخ</th><th>الإجراء</th><th>الكيان</th><th>الرقم</th><th>التفاصيل</th></tr></thead><tbody>{table or '<tr><td colspan="6">لا توجد بيانات</td></tr>'}</tbody></table></div>"
    return layout("سجل التدقيق", body, "/audit")


def create_backup(note: str = "manual") -> str:
    ensure_dirs()
    init_db()
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"masarat_kyc_v10_backup_{stamp}.zip"
    with zipfile.ZipFile(backup_path, "w", zipfile.ZIP_DEFLATED) as z:
        if DB_PATH.exists():
            z.write(DB_PATH, arcname="data/masarat_kyc_v10.sqlite3")
        # V10.5.7 fix: master key intentionally NOT bundled into the backup archive.
        z.writestr("backup_manifest.json", json.dumps({"created_at": now_iso(), "version": APP_VERSION, "note": note}, ensure_ascii=False, indent=2))
    sha = hashlib.sha256(backup_path.read_bytes()).hexdigest()
    (backup_path.with_suffix(".sha256.txt")).write_text(f"{sha}  {backup_path.name}\n", encoding="utf-8")
    with db() as con:
        ensure_schema(con)
        con.execute("INSERT INTO rollback_points(created_at, backup_path, notes) VALUES(?,?,?)", (now_iso(), str(backup_path), note))
        audit(con, "create_backup", "backup", 0, str(backup_path))
        con.commit()
    return str(backup_path)


def maintenance_check() -> Dict[str, Any]:
    init_db()
    result: Dict[str, Any] = {"version": APP_VERSION, "database": str(DB_PATH), "checks": []}
    with db() as con:
        ensure_schema(con)
        checks = [
            ("clients", con.execute("SELECT COUNT(*) FROM clients").fetchone()[0]),
            ("matters", con.execute("SELECT COUNT(*) FROM matters").fetchone()[0]),
            ("counterparties", con.execute("SELECT COUNT(*) FROM counterparties").fetchone()[0]),
            ("sanctions_entries", con.execute("SELECT COUNT(*) FROM sanctions_entries").fetchone()[0]),
            ("screenings", con.execute("SELECT COUNT(*) FROM screenings").fetchone()[0]),
        ]
        result["checks"] = checks
        integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
        result["integrity"] = integrity
        con.execute("INSERT INTO maintenance_events(created_at, event_type, status, details) VALUES(?,?,?,?)", (now_iso(), "integrity_check", "success" if integrity == "ok" else "failed", json.dumps(result, ensure_ascii=False)))
        audit(con, "maintenance_check", "database", 0, f"integrity={integrity}")
        con.commit()
    return result


def production_page(message: str = "") -> bytes:
    key_path = get_or_create_master_key()
    key_hash = hashlib.sha256(key_path.read_bytes()).hexdigest()[:16]
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    body = f"""
<div class="card"><h2>أدوات الإنتاج والصيانة</h2>{msg}
<table><tr><th>مسار قاعدة البيانات</th><td>{h(DB_PATH)}</td></tr><tr><th>مسار مفتاح التشفير</th><td>{h(key_path)}</td></tr><tr><th>بصمة المفتاح</th><td>{h(key_hash)}...</td></tr><tr><th>مدة حفظ سجلات الامتثال</th><td>{RETENTION_YEARS} سنوات</td></tr></table>
<form method="post" action="/production/backup"><button>إنشاء نسخة احتياطية الآن</button></form>
<form method="post" action="/production/maintenance"><button class="btn secondary">فحص وصيانة داخلية</button></form>
</div>
"""
    return layout("الإنتاج", body, "/production")


def send_redirect(handler: BaseHTTPRequestHandler, location: str) -> None:
    # V10.5.6 fix: تعقيم قيمة Location لمنع حقن ترويسات CRLF وأخطاء الترميز
    # عندما تأتي قيمة معرف من نموذج معدل يدوياً.
    from urllib.parse import quote
    safe = str(location or "/").replace("\r", "").replace("\n", "")
    safe = quote(safe, safe="/?&=#%+._-~:@")
    handler.send_response(303)
    handler.send_header("Location", safe or "/")
    handler.end_headers()


class AppHandler(BaseHTTPRequestHandler):
    server_version = "LegalTracks/10"

    def _send(self, data: bytes | str, status: int = 200, content_type: str = "text/html; charset=utf-8") -> None:
        # Some legacy/extension pages return HTML as str while the HTTP socket requires bytes.
        # Normalize centrally to prevent TypeError: a bytes-like object is required, not 'str'.
        if isinstance(data, str):
            data = data.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt: str, *args: Any) -> None:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        with (LOG_DIR / "access.log").open("a", encoding="utf-8") as f:
            f.write(f"{now_iso()} {_real_client_ip(self)} {fmt % args}\n")

    def do_GET(self) -> None:
        init_db()
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)
        if path == "/":
            return self._send(dashboard())
        if path == "/clients":
            return self._send(clients_list())
        if path == "/clients/new":
            return self._send(client_form())
        if path == "/client":
            return self._send(client_detail(int(qs.get("id", ["0"])[0])))
        if path == "/matters":
            return self._send(matters_list())
        if path == "/matters/new":
            return self._send(matter_form(qs.get("client_id", [""])[0]))
        if path == "/matter":
            return self._send(matter_detail(int(qs.get("id", ["0"])[0])))
        if path == "/counterparty":
            return self._send(counterparty_detail(int(qs.get("id", ["0"])[0])))
        if path == "/quick_screen":
            return self._send(quick_screen_form())
        if path == "/lists":
            return self._send(lists_page())
        if path.startswith("/templates/"):
            safe_name = Path(path).name
            p = BASE_DIR / "templates" / safe_name
            if p.exists() and p.is_file():
                ctype = "application/octet-stream"
                if p.suffix.lower() == ".csv": ctype = "text/csv; charset=utf-8"
                elif p.suffix.lower() == ".xlsx": ctype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                elif p.suffix.lower() == ".xml": ctype = "application/xml; charset=utf-8"
                elif p.suffix.lower() in {".html", ".htm"}: ctype = "text/html; charset=utf-8"
                return self._send(p.read_bytes(), 200, ctype)
        if path == "/screenings":
            return self._send(screenings_page())
        if path == "/reports":
            return self._send(reports_page())
        if path == "/reports/download":
            rid = int(qs.get("id", ["0"])[0])
            pdf_path, report_number = get_report_file(rid)
            if not pdf_path or not pdf_path.exists():
                return self._send(layout("غير موجود", "<div class='error'>تقرير PDF غير موجود</div>", "/reports"), 404)
            return self._send(pdf_path.read_bytes(), 200, "application/pdf")
        if path == "/audit":
            return self._send(audit_page())
        if path == "/settings":
            return self._send(settings_page())
        if path == "/production":
            return self._send(production_page())
        if path == "/api/health":
            data = json.dumps({"ok": True, "version": APP_VERSION, "environment": APP_ENV, "db": str(DB_PATH), "time": now_iso()}, ensure_ascii=False).encode("utf-8")
            return self._send(data, 200, "application/json; charset=utf-8")
        return self._send(layout("غير موجود", "<div class='error'>الصفحة غير موجودة</div>"), 404)

    def do_POST(self) -> None:
        init_db()
        parsed = urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length)
        ctype = self.headers.get("Content-Type", "")
        ip = _real_client_ip(self)
        if ctype.startswith("multipart/form-data"):
            fields, files = parse_multipart({k.lower(): v for k, v in self.headers.items()}, body)
        else:
            fields = parse_qs(body.decode("utf-8", errors="replace"))
            files = {}
        try:
            if path == "/clients/new":
                cid = create_client(fields, files, ip)
                return send_redirect(self, f"/client?id={cid}")
            if path == "/client/add_party":
                add_related_party(fields, "client", "client_id", ip)
                return send_redirect(self, f"/client?id={form_value(fields, 'client_id')}")
            if path == "/client/run_screening":
                cid = int(form_value(fields, "client_id", "0"))
                res = run_client_screening(cid, ip, "both")
                return self._send(layout("نتيجة الفحص", f"<div class='success'>تم تشغيل الفحص. النتائج المنشأة: {res['created']}، التطابقات: {res['hits']}، التحذيرات: {res.get('warnings', 0)}</div><p><a class='btn' href='/client?id={cid}'>العودة للعميل</a></p>", "/clients"))
            if path == "/client/run_internal_screening":
                cid = int(form_value(fields, "client_id", "0"))
                res = run_client_screening(cid, ip, "internal")
                return self._send(layout("نتيجة الفحص الداخلي", f"<div class='success'>تم تشغيل المرحلة الأولى: الفحص الداخلي. النتائج المنشأة: {res['created']}، التطابقات: {res['hits']}، التحذيرات: {res.get('warnings', 0)}</div><p><a class='btn' href='/client?id={cid}'>العودة للعميل</a></p>", "/clients"))
            if path == "/client/run_sanctions_screening":
                cid = int(form_value(fields, "client_id", "0"))
                res = run_client_screening(cid, ip, "sanctions")
                return self._send(layout("نتيجة فحص القوائم", f"<div class='success'>تم تشغيل المرحلة الثانية: فحص القوائم. النتائج المنشأة: {res['created']}، التطابقات: {res['hits']}، التحذيرات: {res.get('warnings', 0)}</div><p><a class='btn' href='/client?id={cid}'>العودة للعميل</a></p>", "/clients"))
            if path == "/matters/new":
                mid = create_matter(fields, ip)
                return send_redirect(self, f"/matter?id={mid}")
            if path == "/counterparty/new":
                cp_id = create_counterparty(fields, ip)
                return self._send(layout("تم حفظ الطرف", f"<div class='success'>تم حفظ الطرف المقابل رقم {cp_id}.</div><p><a class='btn' href='/matter?id={form_value(fields, 'matter_id')}'>إضافة طرف آخر / العودة للمشروع / القضية</a> <a class='btn secondary' href='/counterparty?id={cp_id}'>إضافة مجلس/مديرين لهذا الطرف</a></p>", "/matters"))
            if path == "/counterparty/add_party":
                add_related_party(fields, "counterparty", "counterparty_id", ip)
                return send_redirect(self, f"/counterparty?id={form_value(fields, 'counterparty_id')}")
            if path == "/matter/run_screening":
                mid = int(form_value(fields, "matter_id", "0"))
                res = run_matter_screening(mid, ip, "both")
                return self._send(layout("نتيجة الفحص", f"<div class='success'>تم فحص الأطراف المقابلة. النتائج المنشأة: {res['created']}، التطابقات: {res['hits']}، التحذيرات: {res.get('warnings', 0)}</div><p><a class='btn' href='/matter?id={mid}'>العودة للمشروع / القضية</a></p>", "/matters"))
            if path == "/matter/run_internal_screening":
                mid = int(form_value(fields, "matter_id", "0"))
                res = run_matter_screening(mid, ip, "internal")
                return self._send(layout("نتيجة الفحص الداخلي", f"<div class='success'>تم تشغيل المرحلة الأولى للأطراف المقابلة: الفحص الداخلي. النتائج المنشأة: {res['created']}، التطابقات: {res['hits']}، التحذيرات: {res.get('warnings', 0)}</div><p><a class='btn' href='/matter?id={mid}'>العودة للمشروع / القضية</a></p>", "/matters"))
            if path == "/matter/run_sanctions_screening":
                mid = int(form_value(fields, "matter_id", "0"))
                res = run_matter_screening(mid, ip, "sanctions")
                return self._send(layout("نتيجة فحص القوائم", f"<div class='success'>تم تشغيل المرحلة الثانية للأطراف المقابلة: فحص القوائم. النتائج المنشأة: {res['created']}، التطابقات: {res['hits']}، التحذيرات: {res.get('warnings', 0)}</div><p><a class='btn' href='/matter?id={mid}'>العودة للمشروع / القضية</a></p>", "/matters"))
            if path == "/quick_screen":
                return self._send(run_quick_screening(fields, ip))
            if path == "/lists/upload":
                msg = import_sanctions_file(fields, files, ip)
                return self._send(lists_page(msg))
            if path == "/screening/update":
                msg = update_screening(fields, ip)
                return self._send(screenings_page(msg))
            if path == "/screening/report":
                rid, rnum, pdf_path = create_screening_report(int(form_value(fields, "screening_id", "0")), ip)
                return self._send(layout("تم إصدار التقرير", f"<div class='success'>تم إصدار تقرير PDF رقم {h(rnum)} وحفظه في سجل التقارير.</div><p><a class='btn' href='/reports/download?id={rid}'>عرض PDF</a> <a class='btn secondary' href='/reports'>سجل التقارير</a></p>", "/reports"))
            if path == "/settings/company":
                msg = save_company_settings(fields, ip)
                return self._send(settings_page(msg))
            if path == "/settings/add_client_type":
                msg = add_ref_client_type(fields, ip)
                return self._send(settings_page(msg))
            if path == "/settings/add_service_type":
                msg = add_ref_service_type(fields, ip)
                return self._send(settings_page(msg))
            if path == "/settings/add_user":
                msg = add_app_user(fields, ip)
                return self._send(settings_page(msg))
            if path == "/production/backup":
                bp = create_backup("manual from web")
                return self._send(production_page(f"تم إنشاء نسخة احتياطية: {bp}"))
            if path == "/production/maintenance":
                result = maintenance_check()
                return self._send(production_page(f"نتيجة الفحص الداخلي: {result.get('integrity')}"))
        except Exception as exc:
            return self._send(layout("خطأ", f"<div class='error'>حدث خطأ: {h(exc)}</div>"), 500)
        return self._send(layout("غير موجود", "<div class='error'>المسار غير معروف</div>"), 404)



# ---------------------------------------------------------------------------
# V10.2 UAT Navigation & Settings Fix Extension
# Adds: editable settings lists, document vault for all entities, articles of
# association documents, complex ownership tracing, and demo AML/Compliance data.
# ---------------------------------------------------------------------------

_base_ensure_schema_v102 = ensure_schema

def ensure_schema(con: sqlite3.Connection) -> None:  # type: ignore[override]
    _base_ensure_schema_v102(con)
    extra_stmts = [
        """
        CREATE TABLE IF NOT EXISTS entity_documents(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id INTEGER NOT NULL,
            document_type TEXT NOT NULL,
            document_title TEXT,
            original_filename TEXT,
            file_path TEXT NOT NULL,
            file_sha256 TEXT,
            notes TEXT,
            uploaded_by TEXT DEFAULT 'system'
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS ownership_tracing(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            client_id INTEGER NOT NULL REFERENCES clients(id),
            sequence_no INTEGER NOT NULL DEFAULT 1,
            owner_name TEXT NOT NULL,
            owner_type TEXT NOT NULL DEFAULT 'company',
            id_number TEXT,
            registration_number TEXT,
            country TEXT,
            ownership_percent REAL,
            parent_owner TEXT,
            control_description TEXT,
            notes TEXT
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_entity_documents_entity ON entity_documents(entity_type, entity_id)",
        "CREATE INDEX IF NOT EXISTS idx_ownership_client ON ownership_tracing(client_id)",
    ]
    for st in extra_stmts:
        con.execute(st)
    con.execute("INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES(?,?)", ("V10.2.0", now_iso()))
    con.commit()


def document_type_options(selected: str = "") -> str:
    options = [
        ("commercial_registration", "سجل تجاري"),
        ("articles_of_association", "عقد التأسيس / النظام الأساس"),
        ("national_id", "هوية وطنية"),
        ("iqama", "إقامة"),
        ("passport", "جواز سفر"),
        ("license", "ترخيص"),
        ("poa_authorization", "وكالة / تفويض"),
        ("board_resolution", "قرار مجلس إدارة / قرار الشركاء"),
        ("ownership_chart", "مخطط الملكية / تتبع الملكية"),
        ("contract", "عقد / اتفاقية"),
        ("other", "أخرى"),
    ]
    return "".join(f"<option value='{h(code)}' {'selected' if code==selected else ''}>{h(label)}</option>" for code, label in options)


def doc_type_label(code: str) -> str:
    labels = {
        "commercial_registration": "سجل تجاري",
        "articles_of_association": "عقد التأسيس / النظام الأساس",
        "national_id": "هوية وطنية",
        "iqama": "إقامة",
        "passport": "جواز سفر",
        "license": "ترخيص",
        "poa_authorization": "وكالة / تفويض",
        "board_resolution": "قرار مجلس إدارة / قرار الشركاء",
        "ownership_chart": "مخطط الملكية / تتبع الملكية",
        "contract": "عقد / اتفاقية",
        "other": "أخرى",
    }
    return labels.get(code or "", code or "غير محدد")


def save_entity_document(fields: Dict[str, List[str]], files: Dict[str, Tuple[str, bytes]], ip: str = "") -> int:
    entity_type = form_value(fields, "entity_type")
    entity_id = int(form_value(fields, "entity_id", "0"))
    document_type = form_value(fields, "document_type", "other")
    document_title = form_value(fields, "document_title") or doc_type_label(document_type)
    filename, content = files.get("document_file", ("", b""))
    if entity_type not in {"client", "matter", "counterparty"}:
        raise ValueError("نوع الكيان غير مدعوم لحفظ الوثائق")
    if not entity_id:
        raise ValueError("رقم الكيان غير صحيح")
    if not filename or not content:
        raise ValueError("يجب اختيار نسخة ممسوحة للوثيقة")
    safe = re.sub(r"[^A-Za-z0-9_.\-\u0600-\u06FF ]+", "_", Path(filename).name).strip() or "document.bin"
    upload_dir = DATA_DIR / "uploads" / entity_type / str(entity_id) / "documents"
    upload_dir.mkdir(parents=True, exist_ok=True)
    target = upload_dir / safe
    if target.exists():
        target = upload_dir / f"{target.stem}_{dt.datetime.now().strftime('%Y%m%d%H%M%S')}{target.suffix}"
    target.write_bytes(content)
    file_sha = hashlib.sha256(content).hexdigest()
    with db() as con:
        ensure_schema(con)
        cur = con.execute("""INSERT INTO entity_documents(created_at, entity_type, entity_id, document_type, document_title, original_filename, file_path, file_sha256, notes, uploaded_by)
        VALUES(?,?,?,?,?,?,?,?,?,?)""", (now_iso(), entity_type, entity_id, document_type, document_title, filename, str(target), file_sha, form_value(fields, "notes"), "uat_user"))
        doc_id = int(cur.lastrowid)
        audit(con, "upload_entity_document", entity_type, entity_id, f"doc={doc_id}; type={document_type}; sha={file_sha[:16]}", ip)
        con.commit()
    return doc_id


def documents_table(con: sqlite3.Connection, entity_type: str, entity_id: int) -> str:
    rows = con.execute("SELECT * FROM entity_documents WHERE entity_type=? AND entity_id=? ORDER BY id DESC", (entity_type, entity_id)).fetchall()
    return "".join(
        f"<tr><td>{r['id']}</td><td>{h(doc_type_label(r['document_type']))}</td><td>{h(r['document_title'])}</td><td>{h(r['original_filename'])}</td><td>{h((r['file_sha256'] or '')[:16])}...</td><td><a class='btn secondary' href='/documents/download?id={r['id']}'>فتح الوثيقة</a></td></tr>"
        for r in rows
    ) or "<tr><td colspan='6'>لا توجد وثائق محفوظة</td></tr>"


def document_upload_form(entity_type: str, entity_id: int, default_type: str = "other") -> str:
    return f"""
<form method="post" action="/documents/upload" enctype="multipart/form-data">
<input type="hidden" name="entity_type" value="{h(entity_type)}"><input type="hidden" name="entity_id" value="{entity_id}">
<div class="grid"><div><label>نوع الوثيقة</label><select name="document_type">{document_type_options(default_type)}</select></div><div><label>وصف / عنوان الوثيقة</label><input name="document_title" placeholder="مثال: عقد تأسيس العميل / سجل تجاري / تفويض"></div><div><label>نسخة ممسوحة للوثيقة</label><input type="file" required name="document_file" accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx,.xls,.xlsx"></div></div>
<label>ملاحظات الوثيقة</label><textarea name="notes"></textarea><button>حفظ الوثيقة</button>
</form>
"""


def get_document_file(doc_id: int) -> Tuple[Optional[Path], str]:
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT * FROM entity_documents WHERE id=?", (doc_id,)).fetchone()
        if not r:
            return None, ""
        return Path(r["file_path"]), r["original_filename"] or Path(r["file_path"]).name


def add_ownership_trace(fields: Dict[str, List[str]], ip: str = "") -> int:
    client_id = int(form_value(fields, "client_id", "0"))
    pct_raw = form_value(fields, "ownership_percent")
    pct = float(pct_raw) if pct_raw else None
    seq = int(form_value(fields, "sequence_no", "1") or "1")
    with db() as con:
        ensure_schema(con)
        cur = con.execute("""INSERT INTO ownership_tracing(created_at, client_id, sequence_no, owner_name, owner_type, id_number, registration_number, country, ownership_percent, parent_owner, control_description, notes)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), client_id, seq, form_value(fields, "owner_name"), form_value(fields, "owner_type", "company"), form_value(fields, "id_number"), form_value(fields, "registration_number"), form_value(fields, "country"), pct, form_value(fields, "parent_owner"), form_value(fields, "control_description"), form_value(fields, "notes")))
        oid = int(cur.lastrowid)
        con.execute("INSERT INTO risk_flags(created_at, entity_type, entity_id, flag_code, flag_label, severity, notes) VALUES(?,?,?,?,?,?,?)", (now_iso(), "client", client_id, "COMPLEX_OWNERSHIP_TRACE", "تتبع ملكية لكيان معقد", "medium", f"تمت إضافة طبقة ملكية رقم {seq}: {form_value(fields, 'owner_name')}"))
        audit(con, "add_ownership_trace", "client", client_id, f"owner={form_value(fields, 'owner_name')}; seq={seq}", ip)
        con.commit()
    return oid


def ownership_trace_table(con: sqlite3.Connection, client_id: int) -> str:
    rows = con.execute("SELECT * FROM ownership_tracing WHERE client_id=? ORDER BY sequence_no, id", (client_id,)).fetchall()
    return "".join(f"<tr><td>{r['sequence_no']}</td><td>{h(r['owner_name'])}</td><td>{h(r['owner_type'])}</td><td>{h(r['registration_number'] or r['id_number'])}</td><td>{h(r['country'])}</td><td>{h(r['ownership_percent'])}</td><td>{h(r['parent_owner'])}</td><td>{h(r['control_description'])}</td></tr>" for r in rows) or "<tr><td colspan='8'>لا يوجد تتبع ملكية</td></tr>"


def client_form() -> bytes:  # type: ignore[override]
    opts = client_type_options("company")
    body = f"""
<div class="card"><h2>إضافة عميل</h2>
<form method="post" action="/clients/new" enctype="multipart/form-data">
<div class="grid">
<div><label>نوع العميل</label><select id="client_type" name="client_type">{opts}</select></div>
<div><label>اسم العميل</label><input required name="legal_name"></div>
<div><label>رقم الهوية/الإقامة/الجواز</label><input name="id_number"></div>
<div><label>رقم السجل التجاري</label><input name="registration_number"></div>
<div><label>الرقم الموحد للمنشأة (700)</label><input name="unified_number" placeholder="7xxxxxxxxx"></div>
<div><label>الدولة</label><input name="country" value="Saudi Arabia"></div>
<div><label>الجنسية</label><input name="nationality"></div>
<div><label>شركة مدرجة في السوق المالية السعودية؟</label><select id="listed_saudi_market" name="listed_saudi_market"><option value="0">لا</option><option value="1">نعم</option></select><p class="small">يتم تفعيل هذا الخيار فقط إذا كان نوع العميل شركة.</p></div>
<div><label>مستوى المخاطر</label><select name="risk_level"><option value="normal">عادي</option><option value="medium">متوسط</option><option value="high">مرتفع</option></select></div>
<div><label>نوع الوثيقة الرئيسية</label><select name="document_type">{document_type_options('commercial_registration')}</select></div>
<div><label>نسخة ممسوحة للوثيقة الرئيسية إن وجدت</label><input type="file" name="document_scan" accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx,.xls,.xlsx"></div>
</div>
<label>مصدر المال - اختياري إذا توفرت المعلومة</label><textarea name="source_of_funds"></textarea>
<label>مصدر الثروة - اختياري إذا توفرت المعلومة</label><textarea name="source_of_wealth"></textarea>
<label>سبب تجاوز مصدر المال/الثروة إذا لم تتوفر المعلومة</label><textarea name="source_notes" placeholder="مثال: لم تتوفر المعلومة في مرحلة الرأي المبدئي، وسيتم طلبها عند ارتفاع المخاطر أو قبل القبول النهائي."></textarea>
<p class="notice">مصدر المال/الثروة ليس إلزاميًا لكل العملاء. إذا لم تتم إضافة المعلومة، يجب توثيق سبب التجاوز في الحقل أعلاه.</p>
<label>ملاحظات عامة</label><textarea name="notes"></textarea>
<button type="submit">حفظ العميل</button>
</form></div>
<script>
function toggleListedCompany(){{
  const t=document.getElementById('client_type'); const l=document.getElementById('listed_saudi_market');
  if(!t||!l) return;
  if(t.value !== 'company'){{ l.value='0'; l.disabled=true; }} else {{ l.disabled=false; }}
}}
document.addEventListener('DOMContentLoaded', toggleListedCompany);
document.addEventListener('change', function(e){{ if(e.target && e.target.id==='client_type') toggleListedCompany(); }});
</script>"""
    return layout("إضافة عميل", body, "/clients")


def client_detail(client_id: int) -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        c = con.execute("SELECT * FROM clients WHERE id=?", (client_id,)).fetchone()
        if not c:
            return layout("غير موجود", "<div class='error'>العميل غير موجود</div>", "/clients")
        parties = con.execute("SELECT * FROM related_parties WHERE parent_type='client' AND parent_id=? ORDER BY id DESC", (client_id,)).fetchall()
        matters = con.execute(
            "SELECT m.*, COALESCE(mc.role, CASE WHEN m.client_id=? THEN 'lead' END) AS instruction_role "
            "FROM matters m LEFT JOIN matter_clients mc ON mc.matter_id=m.id AND mc.client_id=? "
            "WHERE m.client_id=? OR mc.client_id=? ORDER BY m.id DESC", (client_id, client_id, client_id, client_id)).fetchall()
        risks = con.execute("SELECT * FROM risk_flags WHERE entity_type='client' AND entity_id=?", (client_id,)).fetchall()
        # V10.5.6 fix: فصل مساحات المعرفات - كانت النتائج تختلط مع عميل آخر رقمه يساوي رقم طرف مرتبط.
        scr = con.execute("SELECT * FROM screenings WHERE (subject_type='client' AND subject_id=?) OR (subject_type='client_related_party' AND subject_id IN (SELECT id FROM related_parties WHERE parent_type='client' AND parent_id=?)) ORDER BY id DESC LIMIT 50", (client_id, client_id)).fetchall()
        docs_html = documents_table(con, "client", client_id)
        ownership_html = ownership_trace_table(con, client_id)
    parties_html = "".join(f"<tr><td>{p['id']}</td><td>{h(p['party_role'])}</td><td>{h(p['full_name'])}</td><td>{h(p['id_number'])}</td><td>{h(p['registration_number'])}</td><td>{h(p['ownership_percent'])}</td></tr>" for p in parties)
    matters_html = "".join(f"<tr><td><a href='/matter?id={m['id']}'>{h(m['matter_number'])}</a></td><td>{h(m['title'])}</td><td>{'عميل رئيسي' if m['instruction_role']=='lead' else 'عميل مشارك'}</td><td>{badge_status(m['status'])}</td></tr>" for m in matters)
    risks_html = "".join(f"<tr><td>{h(r['flag_label'])}</td><td>{h(r['severity'])}</td><td>{h(r['notes'])}</td></tr>" for r in risks)
    scr_html = "".join(f"<tr><td>{s['id']}</td><td>{h(s['subject_name'])}</td><td>{h(s['screening_scope'])}</td><td>{h(s['matched_name'])}</td><td>{s['match_score']}</td><td>{badge_status(s['status'])}</td></tr>" for s in scr)
    listed_note = "<p class='notice'>هذا العميل شركة مدرجة في السوق المالية السعودية: يتم توثيق تجاوز فحص القوائم التفصيلي للملكية، مع استمرار الفحص الداخلي.</p>" if c['listed_saudi_market'] else ""
    body = f"""
<div class="card"><h2>{h(c['legal_name'])}</h2>{listed_note}<p class="notice">مصدر المال/الثروة غير إلزامي افتراضيًا، لكنه يصبح مطلوبًا عند ارتفاع المخاطر أو عند طلب مسؤول الامتثال. في حال عدم توفره يجب توثيق سبب التجاوز.</p>
<table><tr><th>نوع العميل</th><td>{h(client_type_label(c['client_type']))}</td><th>الحالة</th><td>{badge_status(c['status'])}</td></tr>
<tr><th>هوية/سجل</th><td>{h(c['id_number'] or c['registration_number'])}</td><th>المخاطر</th><td>{h(c['risk_level'])}</td></tr>
<tr><th>مصدر المال</th><td>{h(c['source_of_funds'] or 'غير مضاف')}</td><th>مصدر الثروة</th><td>{h(c['source_of_wealth'] or 'غير مضاف')}</td></tr>
<tr><th>سبب التجاوز</th><td colspan="3">{h(c['source_notes'] or '')}</td></tr>
<tr><th>نوع الوثيقة الرئيسية</th><td>{h(doc_type_label(c['document_type'] or ''))}</td><th>النسخة الممسوحة</th><td>{h(c['document_original_filename'] or '')}</td></tr></table>
<div class="grid"><form method="post" action="/client/run_internal_screening"><input type="hidden" name="client_id" value="{client_id}"><button>المرحلة الأولى: الفحص الداخلي</button></form>
<form method="post" action="/client/run_sanctions_screening"><input type="hidden" name="client_id" value="{client_id}"><button class="btn secondary">المرحلة الثانية: الفحص مع القوائم</button></form></div>
</div>
<div class="card"><h3>الأطراف الداخلية للعميل: مجلس الإدارة / هيئة المديرين / المستفيد الحقيقي / المفوضون</h3><p class="notice">هذه البيانات تدخل في الفحص الداخلي وفحص القوائم.</p>
<form method="post" action="/client/add_party"><input type="hidden" name="client_id" value="{client_id}">
<div class="grid"><div><label>الدور</label><select name="party_role"><option value="board_member">عضو مجلس إدارة</option><option value="manager">عضو هيئة مديرين</option><option value="ubo">مستفيد حقيقي</option><option value="authorized_signatory">مفوض بالتوقيع</option><option value="controller">مسيطر فعلي</option></select></div><div><label>الاسم</label><input required name="full_name"></div><div><label>رقم الهوية</label><input name="id_number"></div><div><label>رقم السجل</label><input name="registration_number"></div><div><label>الجنسية</label><input name="nationality"></div><div><label>الدولة</label><input name="country"></div><div><label>نسبة الملكية</label><input name="ownership_percent" type="number" step="0.01"></div></div>
<label>ملاحظات</label><textarea name="notes"></textarea><button>حفظ الطرف</button></form>
<table><thead><tr><th>#</th><th>الدور</th><th>الاسم</th><th>هوية</th><th>سجل</th><th>ملكية %</th></tr></thead><tbody>{parties_html or '<tr><td colspan="6">لا توجد أطراف</td></tr>'}</tbody></table></div>
<div class="card"><h3>الوثائق والنسخ الممسوحة للعميل</h3><p class="notice">يمكن إضافة أكثر من وثيقة، بما في ذلك عقد التأسيس / النظام الأساس، السجل التجاري، التراخيص، التفويضات، ومخططات الملكية.</p>{document_upload_form('client', client_id, 'articles_of_association')}
<table><thead><tr><th>#</th><th>نوع الوثيقة</th><th>العنوان</th><th>الملف</th><th>SHA256</th><th>فتح</th></tr></thead><tbody>{docs_html}</tbody></table></div>
<div class="card"><h3>تتبع الملكية في حالة الكيانات المعقدة</h3><p class="notice">استخدم هذا القسم عند وجود طبقات ملكية متعددة أو شركات وسيطة أو سيطرة فعلية غير مباشرة.</p>
<form method="post" action="/client/add_ownership_trace"><input type="hidden" name="client_id" value="{client_id}"><div class="grid"><div><label>ترتيب الطبقة</label><input type="number" name="sequence_no" value="1"></div><div><label>اسم المالك / الكيان الوسيط</label><input required name="owner_name"></div><div><label>نوع المالك</label><select name="owner_type"><option value="company">شركة</option><option value="individual">فرد</option><option value="trust">ترتيب قانوني / صندوق</option><option value="government">جهة حكومية</option><option value="other">أخرى</option></select></div><div><label>رقم الهوية</label><input name="id_number"></div><div><label>رقم السجل</label><input name="registration_number"></div><div><label>الدولة</label><input name="country"></div><div><label>نسبة الملكية</label><input type="number" step="0.01" name="ownership_percent"></div><div><label>المالك الأعلى / التابع له</label><input name="parent_owner"></div></div><label>وصف السيطرة الفعلية</label><textarea name="control_description"></textarea><label>ملاحظات</label><textarea name="notes"></textarea><button>إضافة طبقة ملكية</button></form>
<table><thead><tr><th>الطبقة</th><th>المالك</th><th>النوع</th><th>هوية/سجل</th><th>الدولة</th><th>النسبة</th><th>المالك الأعلى</th><th>وصف السيطرة</th><th>الإجراء</th></tr></thead><tbody>{ownership_html}</tbody></table></div>
<div class="card"><h3>المشاريع / القضايا</h3><a class="btn" href="/matters/new?client_id={client_id}">فتح مشروع / قضية لهذا العميل</a><table><thead><tr><th>رقم المشروع / القضية</th><th>اسم العقد / المشروع / القضية</th><th>صفة العميل</th><th>الحالة</th></tr></thead><tbody>{matters_html or '<tr><td colspan="4">لا توجد مشاريع / قضايا</td></tr>'}</tbody></table></div>
<div class="card"><h3>مؤشرات المخاطر</h3><table><thead><tr><th>المؤشر</th><th>الحدة</th><th>الملاحظة</th></tr></thead><tbody>{risks_html or '<tr><td colspan="3">لا توجد مؤشرات</td></tr>'}</tbody></table></div>
<div class="card"><h3>آخر نتائج الفحص</h3><table><thead><tr><th>#</th><th>المفحوص</th><th>النطاق</th><th>التطابق</th><th>النسبة</th><th>الحالة</th></tr></thead><tbody>{scr_html or '<tr><td colspan="6">لا توجد نتائج</td></tr>'}</tbody></table></div>
"""
    return layout("تفاصيل العميل", body, "/clients")


def matter_detail(matter_id: int) -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        m = con.execute("SELECT m.*, c.legal_name FROM matters m JOIN clients c ON c.id=m.client_id WHERE m.id=?", (matter_id,)).fetchone()
        if not m:
            return layout("غير موجود", "<div class='error'>المشروع / القضية غير موجود</div>", "/matters")
        cps = con.execute("SELECT * FROM counterparties WHERE matter_id=? ORDER BY id DESC", (matter_id,)).fetchall()
        cp_ids = [r["id"] for r in cps]
        cp_parties = []
        if cp_ids:
            q = ",".join("?" for _ in cp_ids)
            cp_parties = con.execute(f"SELECT * FROM related_parties WHERE parent_type='counterparty' AND parent_id IN ({q}) ORDER BY id DESC", cp_ids).fetchall()
        # V10.5.6 fix: تقييد نتائج الفحص بأطراف هذا المشروع فقط بدلاً من آخر نتائج كل المشاريع.
        scr = []
        if cp_ids:
            rp_ids = [p["id"] for p in cp_parties]
            conds = [f"(subject_type='counterparty' AND subject_id IN ({','.join('?' for _ in cp_ids)}))"]
            scr_params: List[Any] = list(cp_ids)
            if rp_ids:
                conds.append(f"(subject_type='counterparty_related_party' AND subject_id IN ({','.join('?' for _ in rp_ids)}))")
                scr_params += rp_ids
            scr = con.execute(f"SELECT * FROM screenings WHERE {' OR '.join(conds)} ORDER BY id DESC LIMIT 100", scr_params).fetchall()
        docs_html = documents_table(con, "matter", matter_id)
    cps_html = "".join(f"<tr><td><a href='/counterparty?id={cp['id']}'>{cp['id']}</a></td><td>{h(cp['full_name'])}</td><td>{h(cp['party_type'])}</td><td>{h(cp['id_number'])}</td><td>{h(cp['registration_number'])}</td><td>{h(cp['role_in_matter'])}</td></tr>" for cp in cps)
    parties_html = "".join(f"<tr><td>{p['parent_id']}</td><td>{h(p['party_role'])}</td><td>{h(p['full_name'])}</td><td>{h(p['id_number'])}</td><td>{h(p['registration_number'])}</td></tr>" for p in cp_parties)
    scr_html = "".join(f"<tr><td>{s['id']}</td><td>{h(s['subject_name'])}</td><td>{h(s['screening_scope'])}</td><td>{h(s['matched_name'])}</td><td>{s['match_score']}</td><td>{badge_status(s['status'])}</td></tr>" for s in scr)
    body = f"""
<div class="card"><h2>{h(m['matter_number'])} - {h(m['title'])}</h2><p>العميل: <a href="/client?id={m['client_id']}">{h(m['legal_name'])}</a></p>
<div class="grid"><form method="post" action="/matter/run_internal_screening"><input type="hidden" name="matter_id" value="{matter_id}"><button>المرحلة الأولى: الفحص الداخلي للأطراف المقابلة</button></form><form method="post" action="/matter/run_sanctions_screening"><input type="hidden" name="matter_id" value="{matter_id}"><button class="btn secondary">المرحلة الثانية: فحص الأطراف المقابلة مع القوائم</button></form></div></div>
<div class="card"><h3>إضافة طرف مقابل جديد</h3><form method="post" action="/counterparty/new"><input type="hidden" name="matter_id" value="{matter_id}"><div class="grid"><div><label>نوع الطرف</label><select name="party_type"><option value="company">شركة</option><option value="individual">فرد</option><option value="government">جهة حكومية</option><option value="charity">جمعية خيرية</option><option value="other">أخرى</option></select></div><div><label>اسم الطرف</label><input required name="full_name"></div><div><label>رقم الهوية</label><input name="id_number"></div><div><label>رقم السجل</label><input name="registration_number"></div><div><label>الجنسية</label><input name="nationality"></div><div><label>الدولة</label><input name="country"></div><div><label>صفة الطرف في المشروع / القضية</label><input name="role_in_matter"></div></div><label>ملاحظات</label><textarea name="notes"></textarea><button>حفظ الطرف</button> <span class="small">بعد الحفظ يمكنك إضافة طرف آخر، أو فتح صفحة الطرف لإضافة مجلس الإدارة / المديرين / UBO.</span></form>
<table><thead><tr><th>#</th><th>الاسم</th><th>النوع</th><th>هوية</th><th>سجل</th><th>الصفة</th></tr></thead><tbody>{cps_html or '<tr><td colspan="6">لم تتم إضافة أطراف مقابلة بعد</td></tr>'}</tbody></table></div>
<div class="card"><h3>وثائق المشروع / القضية</h3>{document_upload_form('matter', matter_id, 'contract')}<table><thead><tr><th>#</th><th>نوع الوثيقة</th><th>العنوان</th><th>الملف</th><th>SHA256</th><th>فتح</th></tr></thead><tbody>{docs_html}</tbody></table></div>
<div class="card"><h3>أعضاء مجلس/مديرون/مستفيدون للأطراف المقابلة</h3><table><thead><tr><th>رقم Counterparty</th><th>الدور</th><th>الاسم</th><th>هوية</th><th>سجل</th></tr></thead><tbody>{parties_html or '<tr><td colspan="5">لا توجد بيانات</td></tr>'}</tbody></table></div>
<div class="card"><h3>آخر نتائج الفحص للمشروع / القضية</h3><table><thead><tr><th>#</th><th>المفحوص</th><th>النطاق</th><th>التطابق</th><th>النسبة</th><th>الحالة</th></tr></thead><tbody>{scr_html or '<tr><td colspan="6">لا توجد نتائج</td></tr>'}</tbody></table></div>
"""
    return layout("تفاصيل المشروع / القضية", body, "/matters")


def counterparty_detail(cp_id: int) -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        cp = con.execute("SELECT * FROM counterparties WHERE id=?", (cp_id,)).fetchone()
        if not cp:
            return layout("غير موجود", "<div class='error'>الطرف المقابل غير موجود</div>", "/matters")
        parties = con.execute("SELECT * FROM related_parties WHERE parent_type='counterparty' AND parent_id=? ORDER BY id DESC", (cp_id,)).fetchall()
        docs_html = documents_table(con, "counterparty", cp_id)
    parties_html = "".join(f"<tr><td>{p['id']}</td><td>{h(p['party_role'])}</td><td>{h(p['full_name'])}</td><td>{h(p['id_number'])}</td><td>{h(p['registration_number'])}</td></tr>" for p in parties)
    body = f"""
<div class="card"><h2>الطرف المقابل: {h(cp['full_name'])}</h2><p><a class="btn secondary" href="/matter?id={cp['matter_id']}">العودة للمشروع / القضية</a></p></div>
<div class="card"><h3>إضافة أعضاء مجلس/مديرين/مستفيدين لهذا الطرف المقابل</h3><form method="post" action="/counterparty/add_party"><input type="hidden" name="counterparty_id" value="{cp_id}"><div class="grid"><div><label>الدور</label><select name="party_role"><option value="board_member">عضو مجلس إدارة</option><option value="manager">عضو هيئة مديرين</option><option value="ubo">مستفيد حقيقي</option><option value="authorized_signatory">مفوض بالتوقيع</option><option value="controller">مسيطر فعلي</option></select></div><div><label>الاسم</label><input required name="full_name"></div><div><label>رقم الهوية</label><input name="id_number"></div><div><label>رقم السجل</label><input name="registration_number"></div><div><label>الجنسية</label><input name="nationality"></div><div><label>الدولة</label><input name="country"></div><div><label>نسبة الملكية</label><input type="number" step="0.01" name="ownership_percent"></div></div><label>ملاحظات</label><textarea name="notes"></textarea><button>حفظ</button></form><table><thead><tr><th>#</th><th>الدور</th><th>الاسم</th><th>هوية</th><th>سجل</th></tr></thead><tbody>{parties_html or '<tr><td colspan="5">لا توجد بيانات</td></tr>'}</tbody></table></div>
<div class="card"><h3>وثائق الطرف المقابل</h3>{document_upload_form('counterparty', cp_id, 'commercial_registration')}<table><thead><tr><th>#</th><th>نوع الوثيقة</th><th>العنوان</th><th>الملف</th><th>SHA256</th><th>فتح</th></tr></thead><tbody>{docs_html}</tbody></table></div>
"""
    return layout("تفاصيل Counterparty", body, "/matters")


def settings_page(message: str = "") -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        company_name = get_setting(con, "company_name")
        company_registration = get_setting(con, "company_registration")
        company_national_address = get_setting(con, "company_national_address")
        company_vat_number = get_setting(con, "company_vat_number")
        client_types = con.execute("SELECT * FROM ref_client_types ORDER BY sort_order, label_ar").fetchall()
        service_types = con.execute("SELECT * FROM ref_service_types ORDER BY sort_order, label_ar").fetchall()
        users = con.execute("SELECT * FROM app_users ORDER BY id DESC LIMIT 100").fetchall()
        client_usage = {r['client_type']: r['n'] for r in con.execute("SELECT client_type, COUNT(*) n FROM clients GROUP BY client_type").fetchall()}
        service_usage = {r['service_type']: r['n'] for r in con.execute("SELECT service_type, COUNT(*) n FROM matters GROUP BY service_type").fetchall()}
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    ct_rows = "".join(f"""<tr><td>{h(r['code'])}</td><td>{h(r['label_ar'])}</td><td>{'نشط' if r['is_active'] else 'موقوف'}</td><td>{client_usage.get(r['code'],0)}</td><td><form method='post' action='/settings/update_client_type'><input type='hidden' name='code' value='{h(r['code'])}'><input name='label_ar' value='{h(r['label_ar'])}'><button>تعديل</button></form></td><td><form method='post' action='/settings/toggle_client_type'><input type='hidden' name='code' value='{h(r['code'])}'><button class='btn warn'>{'إيقاف' if r['is_active'] else 'تفعيل'}</button></form></td><td><form method='post' action='/settings/delete_client_type'><input type='hidden' name='code' value='{h(r['code'])}'><button class='btn danger'>حذف/تعطيل آمن</button></form></td></tr>""" for r in client_types)
    st_rows = "".join(f"""<tr><td>{h(r['code'])}</td><td>{h(r['label_ar'])}</td><td>{'نشط' if r['is_active'] else 'موقوف'}</td><td>{service_usage.get(r['code'],0)}</td><td><form method='post' action='/settings/update_service_type'><input type='hidden' name='code' value='{h(r['code'])}'><input name='label_ar' value='{h(r['label_ar'])}'><button>تعديل</button></form></td><td><form method='post' action='/settings/toggle_service_type'><input type='hidden' name='code' value='{h(r['code'])}'><button class='btn warn'>{'إيقاف' if r['is_active'] else 'تفعيل'}</button></form></td><td><form method='post' action='/settings/delete_service_type'><input type='hidden' name='code' value='{h(r['code'])}'><button class='btn danger'>حذف/تعطيل آمن</button></form></td></tr>""" for r in service_types)
    user_rows = "".join(f"<tr><td>{r['id']}</td><td>{h(r['full_name'])}</td><td>{h(r['user_name'])}</td><td>{h(r['role'])}</td><td>{'نشط' if r['is_active'] else 'موقوف'}</td></tr>" for r in users)
    body = f"""
<div class="card" id="settings"><h2>الإعدادات</h2>{msg}<p class="notice">أنواع العملاء والخدمات مرتبطة مباشرة بالقوائم المنسدلة. الحذف النهائي مسموح فقط إذا لم يكن النوع مستخدمًا، وإذا كان مستخدمًا يتم تعطيله حفاظًا على السجلات التاريخية.</p></div>
<div class="card" id="company"><h3>إعدادات الشركة</h3><form method="post" action="/settings/company"><div class="grid"><div><label>اسم الشركة / المكتب مستخدم التطبيق</label><input name="company_name" value="{h(company_name)}"></div><div><label>رقم السجل التجاري</label><input name="company_registration" value="{h(company_registration)}"></div><div><label>العنوان الوطني</label><input name="company_national_address" value="{h(company_national_address)}"></div><div><label>الرقم الضريبي إن وجد</label><input name="company_vat_number" value="{h(company_vat_number)}"></div></div><button>حفظ إعدادات الشركة</button></form></div>
<div class="card" id="client-types"><h3>إعدادات: أنواع العملاء</h3><form method="post" action="/settings/add_client_type"><div class="grid"><div><label>الكود</label><input required name="code" placeholder="e.g. nonprofit"></div><div><label>الاسم الظاهر</label><input required name="label_ar" placeholder="نوع العميل"></div></div><button>إضافة نوع عميل</button></form><table><thead><tr><th>الكود</th><th>الاسم</th><th>الحالة</th><th>الاستخدام</th><th>تعديل</th><th>تفعيل/إيقاف</th><th>حذف/تعطيل</th></tr></thead><tbody>{ct_rows}</tbody></table></div>
<div class="card" id="service-types"><h3>إعدادات: أنواع الخدمات</h3><form method="post" action="/settings/add_service_type"><div class="grid"><div><label>الكود</label><input required name="code" placeholder="e.g. advisory"></div><div><label>الاسم الظاهر</label><input required name="label_ar" placeholder="نوع الخدمة"></div></div><button>إضافة نوع خدمة</button></form><table><thead><tr><th>الكود</th><th>الاسم</th><th>الحالة</th><th>الاستخدام</th><th>تعديل</th><th>تفعيل/إيقاف</th><th>حذف/تعطيل</th></tr></thead><tbody>{st_rows}</tbody></table></div>
<div class="card" id="users"><h3>المستخدمين</h3><form method="post" action="/settings/add_user"><div class="grid"><div><label>الاسم</label><input required name="full_name"></div><div><label>البريد الإلكتروني للمستخدم</label><input required name="user_name" placeholder="name@legaltracks.sa" title="بريد إلكتروني على نطاق الشركة، مثل name@legaltracks.sa"></div><div><label>الدور</label><select name="role"><option value="admin">مدير نظام</option><option value="compliance">امتثال</option><option value="partner">شريك</option><option value="user">مستخدم</option></select></div></div><button>إضافة مستخدم</button></form><table><thead><tr><th>#</th><th>الاسم</th><th>اسم المستخدم</th><th>الدور</th><th>الحالة</th></tr></thead><tbody>{user_rows}</tbody></table></div>
"""
    return layout("الإعدادات", body, "/settings")


def update_ref_client_type(fields: Dict[str, List[str]], ip: str = "") -> str:
    code, label = form_value(fields, "code"), form_value(fields, "label_ar")
    if not code or not label:
        raise ValueError("الكود والاسم مطلوبان")
    with db() as con:
        ensure_schema(con)
        con.execute("UPDATE ref_client_types SET label_ar=? WHERE code=?", (label, code))
        audit(con, "update_client_type", "settings", 0, f"{code}: {label}", ip)
        con.commit()
    return "تم تعديل نوع العميل"


def toggle_ref_client_type(fields: Dict[str, List[str]], ip: str = "") -> str:
    code = form_value(fields, "code")
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT is_active FROM ref_client_types WHERE code=?", (code,)).fetchone()
        if r:
            con.execute("UPDATE ref_client_types SET is_active=? WHERE code=?", (0 if r['is_active'] else 1, code))
            audit(con, "toggle_client_type", "settings", 0, code, ip)
        con.commit()
    return "تم تحديث حالة نوع العميل"


def delete_ref_client_type(fields: Dict[str, List[str]], ip: str = "") -> str:
    code = form_value(fields, "code")
    with db() as con:
        ensure_schema(con)
        used = con.execute("SELECT COUNT(*) FROM clients WHERE client_type=?", (code,)).fetchone()[0]
        if used:
            con.execute("UPDATE ref_client_types SET is_active=0 WHERE code=?", (code,))
            msg = "النوع مستخدم سابقًا؛ تم تعطيله بدل حذفه"
        else:
            con.execute("DELETE FROM ref_client_types WHERE code=?", (code,))
            msg = "تم حذف نوع العميل لأنه غير مستخدم"
        audit(con, "delete_or_disable_client_type", "settings", 0, f"{code}; used={used}", ip)
        con.commit()
    return msg


def update_ref_service_type(fields: Dict[str, List[str]], ip: str = "") -> str:
    code, label = form_value(fields, "code"), form_value(fields, "label_ar")
    if not code or not label:
        raise ValueError("الكود والاسم مطلوبان")
    with db() as con:
        ensure_schema(con)
        con.execute("UPDATE ref_service_types SET label_ar=? WHERE code=?", (label, code))
        audit(con, "update_service_type", "settings", 0, f"{code}: {label}", ip)
        con.commit()
    return "تم تعديل نوع الخدمة"


def toggle_ref_service_type(fields: Dict[str, List[str]], ip: str = "") -> str:
    code = form_value(fields, "code")
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT is_active FROM ref_service_types WHERE code=?", (code,)).fetchone()
        if r:
            con.execute("UPDATE ref_service_types SET is_active=? WHERE code=?", (0 if r['is_active'] else 1, code))
            audit(con, "toggle_service_type", "settings", 0, code, ip)
        con.commit()
    return "تم تحديث حالة نوع الخدمة"


def delete_ref_service_type(fields: Dict[str, List[str]], ip: str = "") -> str:
    code = form_value(fields, "code")
    with db() as con:
        ensure_schema(con)
        used = con.execute("SELECT COUNT(*) FROM matters WHERE service_type=?", (code,)).fetchone()[0]
        if used:
            con.execute("UPDATE ref_service_types SET is_active=0 WHERE code=?", (code,))
            msg = "نوع الخدمة مستخدم سابقًا؛ تم تعطيله بدل حذفه"
        else:
            con.execute("DELETE FROM ref_service_types WHERE code=?", (code,))
            msg = "تم حذف نوع الخدمة لأنه غير مستخدم"
        audit(con, "delete_or_disable_service_type", "settings", 0, f"{code}; used={used}", ip)
        con.commit()
    return msg


def _parse_request_fields(handler: BaseHTTPRequestHandler) -> Tuple[Dict[str, List[str]], Dict[str, Tuple[str, bytes]], str]:
    length = int(handler.headers.get("Content-Length", "0"))
    body = handler.rfile.read(length)
    ctype = handler.headers.get("Content-Type", "")
    if ctype.startswith("multipart/form-data"):
        fields, files = parse_multipart({k.lower(): v for k, v in handler.headers.items()}, body)
    else:
        fields = parse_qs(body.decode("utf-8", errors="replace")); files = {}
    return fields, files, _real_client_ip(handler)


_base_do_get_v102 = AppHandler.do_GET

def _do_get_v102(self: AppHandler) -> None:
    init_db()
    parsed = urlparse(self.path)
    path = parsed.path
    qs = parse_qs(parsed.query)
    if path == "/documents/download":
        try:
            doc_id = int(qs.get("id", ["0"])[0])
        except ValueError:
            return self._send(layout("طلب غير صالح", "<div class='error'>معرف وثيقة غير صالح</div>"), 400)
        fpath, fname = get_document_file(doc_id)
        if not fpath or not fpath.exists():
            return self._send(layout("غير موجود", "<div class='error'>الوثيقة غير موجودة</div>"), 404)
        # V10.5.6 fix: تنزيل باسم الملف الصحيح بدل ملف بلا امتداد.
        return _send_binary_with_disposition(self, fpath.read_bytes(), "application/octet-stream", fname or fpath.name)
    return _base_do_get_v102(self)

AppHandler.do_GET = _do_get_v102

_base_do_post_v102 = AppHandler.do_POST

def _do_post_v102(self: AppHandler) -> None:
    path = urlparse(self.path).path
    special = {
        "/documents/upload", "/client/add_ownership_trace",
        "/settings/update_client_type", "/settings/toggle_client_type", "/settings/delete_client_type",
        "/settings/update_service_type", "/settings/toggle_service_type", "/settings/delete_service_type",
    }
    if path not in special:
        return _base_do_post_v102(self)
    init_db()
    try:
        fields, files, ip = _parse_request_fields(self)
        if path == "/documents/upload":
            save_entity_document(fields, files, ip)
            et, eid = form_value(fields, "entity_type"), form_value(fields, "entity_id")
            loc = f"/{et}?id={eid}" if et in {"client", "matter", "counterparty"} else "/"
            return send_redirect(self, loc)
        if path == "/client/add_ownership_trace":
            add_ownership_trace(fields, ip)
            return send_redirect(self, f"/client?id={form_value(fields, 'client_id')}")
        if path == "/settings/update_client_type":
            return self._send(settings_page(update_ref_client_type(fields, ip)))
        if path == "/settings/toggle_client_type":
            return self._send(settings_page(toggle_ref_client_type(fields, ip)))
        if path == "/settings/delete_client_type":
            return self._send(settings_page(delete_ref_client_type(fields, ip)))
        if path == "/settings/update_service_type":
            return self._send(settings_page(update_ref_service_type(fields, ip)))
        if path == "/settings/toggle_service_type":
            return self._send(settings_page(toggle_ref_service_type(fields, ip)))
        if path == "/settings/delete_service_type":
            return self._send(settings_page(delete_ref_service_type(fields, ip)))
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>حدث خطأ: {h(exc)}</div>"), 500)
    return _base_do_post_v102(self)

AppHandler.do_POST = _do_post_v102


def write_demo_file(relative: str, content: bytes) -> str:
    target = DATA_DIR / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    return str(target)


def seed_v102_dummy_data(clear_existing: bool = True) -> Dict[str, Any]:
    # V10.5.6 fix: حارس بيئة صريح - الدالة تحذف 12 جدولاً ولم يكن فيها أي منع
    # لتشغيلها على قاعدة الإنتاج من خارج main().
    if APP_ENV != "UAT" or not ALLOW_DUMMY_DATA:
        raise RuntimeError("زرع البيانات التجريبية مسموح في بيئة UAT فقط مع تفعيل MASARAT_ALLOW_DUMMY_DATA=1")
    init_db()
    with db() as con:
        ensure_schema(con)
        if clear_existing:
            for table in ["screening_report_items", "screening_reports", "compliance_actions", "screenings", "risk_flags", "ownership_tracing", "entity_documents", "related_parties", "counterparties", "matters", "clients", "sanctions_entries", "sanctions_import_logs"]:
                con.execute(f"DELETE FROM {table}")
            con.commit()
        demo_csv = "list_name,source_url,list_type,full_name,id_number,registration_number,nationality,country,notes\nUN_1267_DEMO,https://example.invalid/un1267,TF,شركة مدرجة للعقوبات التجريبية,,SAN-1000,,High Risk,Demo sanctions list hit\nUN_1267_DEMO,https://example.invalid/un1267,TF,يوسف مدرج دولي,SAN-ID-999,,,High Risk,Demo individual hit\n"
        demo_file = write_demo_file("demo_imports/demo_sanctions_v102.csv", demo_csv.encode("utf-8-sig"))
        defaults = {"list_name": "UN_1267_DEMO", "source_url": "https://example.invalid/un1267", "list_type": "TF"}
        rows, errors = parse_sanctions_file("demo_sanctions_v102.csv", demo_csv.encode("utf-8-sig"), defaults)
        success = dup = failed = 0
        for row in rows:
            try:
                con.execute("""INSERT INTO sanctions_entries(created_at, list_name, source_url, list_type, full_name, id_number, registration_number, nationality, country, notes, row_hash, active)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,1)""", (now_iso(), row.get("list_name"), row.get("source_url"), row.get("list_type"), row.get("full_name"), row.get("id_number"), row.get("registration_number"), row.get("nationality"), row.get("country"), row.get("notes"), row_hash(row)))
                success += 1
            except sqlite3.IntegrityError:
                dup += 1
        con.execute("""INSERT INTO sanctions_import_logs(created_at, list_name, source_url, filename, file_sha256, total_records, success_count, failed_count, duplicate_count, status, error_details_json)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), "UN_1267_DEMO", "https://example.invalid/un1267", "demo_sanctions_v102.csv", hashlib.sha256(demo_csv.encode("utf-8-sig")).hexdigest(), len(rows), success, failed, dup, "success", json.dumps(errors, ensure_ascii=False)))
        # Client 1/2: internal conflict via same registration number.
        cur = con.execute("""INSERT INTO clients(created_at, updated_at, client_type, legal_name, registration_number, country, listed_saudi_market, source_notes, risk_level, status, notes)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), now_iso(), "company", "شركة ألفا التجريبية للمحاماة", "CR-DEMO-100", "Saudi Arabia", 0, "بيانات تدريبية", "normal", "active", "عميل Dummy للاختبار"))
        alpha_id = int(cur.lastrowid)
        con.execute("INSERT INTO related_parties(created_at, parent_type, parent_id, party_role, full_name, id_number, nationality, country, ownership_percent, notes) VALUES(?,?,?,?,?,?,?,?,?,?)", (now_iso(), "client", alpha_id, "board_member", "سالم تضارب داخلي", "ID-555", "Saudi", "Saudi Arabia", 0, "عضو مجلس إدارة Dummy"))
        cur = con.execute("""INSERT INTO clients(created_at, updated_at, client_type, legal_name, registration_number, country, listed_saudi_market, source_notes, risk_level, status, notes)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), now_iso(), "company", "شركة ألفا التجريبية للمحاماة فرع الرياض", "CR-DEMO-100", "Saudi Arabia", 0, "بيانات تدريبية", "normal", "draft", "ينتج عنها تضارب داخلي مع العميل الأول بسبب رقم السجل"))
        beta_id = int(cur.lastrowid)
        con.execute("INSERT INTO related_parties(created_at, parent_type, parent_id, party_role, full_name, id_number, nationality, country, ownership_percent, notes) VALUES(?,?,?,?,?,?,?,?,?,?)", (now_iso(), "client", beta_id, "manager", "سالم تضارب داخلي", "ID-555", "Saudi", "Saudi Arabia", 0, "ينتج عنها تضارب داخلي مع طرف مرتبط"))
        # Client 3: complex ownership + matter + counterparty that matches sanctions list.
        cur = con.execute("""INSERT INTO clients(created_at, updated_at, client_type, legal_name, registration_number, country, listed_saudi_market, source_notes, risk_level, status, notes)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), now_iso(), "company", "شركة الامتثال المعقدة القابضة", "CR-DEMO-300", "Saudi Arabia", 0, "لم تتوفر مصادر الثروة في مرحلة الاختبار وتم التوثيق كبيانات Dummy", "high", "draft", "كيان معقد لاختبار تتبع الملكية"))
        complex_id = int(cur.lastrowid)
        con.execute("INSERT INTO related_parties(created_at, parent_type, parent_id, party_role, full_name, id_number, nationality, country, ownership_percent, notes) VALUES(?,?,?,?,?,?,?,?,?,?)", (now_iso(), "client", complex_id, "ubo", "يوسف مدرج دولي", "SAN-ID-999", "Unknown", "High Risk", 65, "UBO Dummy يطابق القائمة"))
        con.execute("INSERT INTO ownership_tracing(created_at, client_id, sequence_no, owner_name, owner_type, registration_number, country, ownership_percent, parent_owner, control_description, notes) VALUES(?,?,?,?,?,?,?,?,?,?,?)", (now_iso(), complex_id, 1, "شركة وسيطة أولى المحدودة", "company", "OFF-001", "UAE", 70, "شركة الامتثال المعقدة القابضة", "ملكية غير مباشرة", "Dummy ownership layer"))
        con.execute("INSERT INTO ownership_tracing(created_at, client_id, sequence_no, owner_name, owner_type, id_number, country, ownership_percent, parent_owner, control_description, notes) VALUES(?,?,?,?,?,?,?,?,?,?,?)", (now_iso(), complex_id, 2, "يوسف مدرج دولي", "individual", "SAN-ID-999", "High Risk", 65, "شركة وسيطة أولى المحدودة", "سيطرة فعلية عبر شركة وسيطة", "Dummy sanctioned UBO"))
        con.execute("INSERT INTO risk_flags(created_at, entity_type, entity_id, flag_code, flag_label, severity, notes) VALUES(?,?,?,?,?,?,?)", (now_iso(), "client", complex_id, "COMPLEX_OWNERSHIP_TRACE", "تتبع ملكية لكيان معقد", "medium", "تم إنشاء طبقات ملكية Dummy"))
        cur = con.execute("INSERT INTO matters(created_at, updated_at, client_id, matter_number, title, service_type, description, status) VALUES(?,?,?,?,?,?,?,?)", (now_iso(), now_iso(), complex_id, next_matter_number(con), "مشروع اختبار تضارب القوائم", "contract", "مشروع Dummy لفحص Counterparty", "draft"))
        matter_id = int(cur.lastrowid)
        cur = con.execute("INSERT INTO counterparties(created_at, matter_id, party_type, full_name, registration_number, country, role_in_matter, notes) VALUES(?,?,?,?,?,?,?,?)", (now_iso(), matter_id, "company", "شركة مدرجة للعقوبات التجريبية", "SAN-1000", "High Risk", "طرف مقابل", "ينتج عنها تضارب قوائم"))
        cp_id = int(cur.lastrowid)
        con.execute("INSERT INTO related_parties(created_at, parent_type, parent_id, party_role, full_name, id_number, country, ownership_percent, notes) VALUES(?,?,?,?,?,?,?,?,?)", (now_iso(), "counterparty", cp_id, "manager", "يوسف مدرج دولي", "SAN-ID-999", "High Risk", 80, "مدير / UBO للطرف المقابل يطابق القائمة"))
        # Demo documents (small text files with PDF-like names for UAT download trail).
        for et, eid, dtype, title in [("client", alpha_id, "commercial_registration", "سجل تجاري Dummy"), ("client", complex_id, "articles_of_association", "عقد تأسيس Dummy"), ("matter", matter_id, "contract", "عقد مشروع Dummy"), ("counterparty", cp_id, "commercial_registration", "سجل طرف مقابل Dummy")]:
            path = write_demo_file(f"uploads/{et}/{eid}/documents/{dtype}_demo.txt", f"وثيقة تجريبية: {title}\nEntity: {et}/{eid}\n".encode("utf-8"))
            b = Path(path).read_bytes()
            con.execute("INSERT INTO entity_documents(created_at, entity_type, entity_id, document_type, document_title, original_filename, file_path, file_sha256, notes, uploaded_by) VALUES(?,?,?,?,?,?,?,?,?,?)", (now_iso(), et, eid, dtype, title, Path(path).name, path, hashlib.sha256(b).hexdigest(), "Dummy document", "seed"))
        con.commit()
    # Run screens and generate PDF reports outside the seed transaction.
    run_client_screening(beta_id, screening_mode="internal")
    run_client_screening(complex_id, screening_mode="sanctions")
    run_matter_screening(matter_id, screening_mode="sanctions")
    generated_reports = 0
    with db() as con:
        ensure_schema(con)
        rows = con.execute("SELECT id FROM screenings WHERE status IN ('potential_match','high_similarity','confirmed_match') ORDER BY id LIMIT 6").fetchall()
    for r in rows:
        try:
            create_screening_report(int(r["id"]))
            generated_reports += 1
        except Exception:
            pass
    return {"demo_file": demo_file, "clients": 3, "matter_id": matter_id, "counterparty_id": cp_id, "reports": generated_reports}



# ---------------------------------------------------------------------------
# V10.3 MOJ Guide Compliance Hardening Extension
# Adds: clearer workflow states, blocking/freeze propagation, compliance dashboard,
# stronger red flags, 10-year retention evidence, and high contrast UI.
# ---------------------------------------------------------------------------

_base_ensure_schema_v103 = ensure_schema

def _ensure_column(con: sqlite3.Connection, table: str, column: str, column_type: str) -> None:
    cols = {r[1] for r in con.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in cols:
        con.execute(f"ALTER TABLE {table} ADD COLUMN {column} {column_type}")


def ensure_schema(con: sqlite3.Connection) -> None:  # type: ignore[override]
    _base_ensure_schema_v103(con)
    # Minimal safe schema hardening for V10.3.  Existing pilot databases are migrated in-place.
    _ensure_column(con, "counterparties", "status", "TEXT NOT NULL DEFAULT 'draft'")
    _ensure_column(con, "counterparties", "risk_level", "TEXT NOT NULL DEFAULT 'normal'")
    _ensure_column(con, "matters", "risk_level", "TEXT NOT NULL DEFAULT 'normal'")
    _ensure_column(con, "screenings", "retention_until", "TEXT")
    _ensure_column(con, "screening_reports", "retention_until", "TEXT")
    extra = [
        """
        CREATE TABLE IF NOT EXISTS compliance_cases(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            updated_at TEXT,
            screening_id INTEGER REFERENCES screenings(id),
            client_id INTEGER,
            matter_id INTEGER,
            counterparty_id INTEGER,
            case_status TEXT NOT NULL DEFAULT 'under_review',
            visual_status TEXT NOT NULL DEFAULT 'أصفر',
            action_required TEXT,
            assigned_to TEXT DEFAULT 'compliance',
            decision_reason TEXT,
            confidentiality_note TEXT NOT NULL DEFAULT 'سري - يحظر تنبيه العميل أو أي طرف خارجي',
            retention_until TEXT,
            created_by TEXT DEFAULT 'system'
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS compliance_governance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            item_type TEXT NOT NULL,
            item_title TEXT NOT NULL,
            owner TEXT,
            status TEXT NOT NULL DEFAULT 'active',
            evidence_notes TEXT,
            next_review_at TEXT,
            retention_until TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS continuous_screening_runs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            run_type TEXT NOT NULL DEFAULT 'manual',
            clients_checked INTEGER NOT NULL DEFAULT 0,
            matters_checked INTEGER NOT NULL DEFAULT 0,
            results_created INTEGER NOT NULL DEFAULT 0,
            hits_created INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'success',
            details_json TEXT
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_compliance_cases_screening ON compliance_cases(screening_id)",
        "CREATE INDEX IF NOT EXISTS idx_compliance_cases_status ON compliance_cases(case_status)",
        "CREATE INDEX IF NOT EXISTS idx_risk_flags_entity_code ON risk_flags(entity_type, entity_id, flag_code)",
    ]
    for st in extra:
        con.execute(st)
    # V10.5.6 fix: كان INSERT OR IGNORE بلا قيد فريد يضيف نسخاً مكررة من بندي الحوكمة
    # عند كل استدعاء ensure_schema (عدة مرات لكل طلب HTTP) فيتضخم الجدول بلا حد.
    con.execute("DELETE FROM compliance_governance WHERE id NOT IN (SELECT MIN(id) FROM compliance_governance GROUP BY item_type, item_title)")
    if con.execute("SELECT COUNT(*) FROM compliance_governance").fetchone()[0] == 0:
        con.executemany("INSERT INTO compliance_governance(created_at, item_type, item_title, owner, status, evidence_notes, retention_until) VALUES(?,?,?,?,?,?,?)", [
            (now_iso(), "policy", "سياسة العقوبات المالية المستهدفة والتصعيد", "مسؤول الامتثال", "active", "تغطي الفحص، التجميد/حظر التعامل، السرية، الإبلاغ، وحفظ السجلات.", (dt.datetime.now()+dt.timedelta(days=365*RETENTION_YEARS)).date().isoformat()),
            (now_iso(), "training", "تدريب مستخدمي النظام على السرية وحظر التنبيه", "مسؤول الامتثال", "active", "يجب تحديث التدريب دوريًا وتوثيق الحضور.", (dt.datetime.now()+dt.timedelta(days=365*RETENTION_YEARS)).date().isoformat()),
        ])
    # Repair absolute paths captured during previous packaging/testing so the
    # portable ZIP works after extraction to a different folder.
    try:
        for rr in con.execute("SELECT id, pdf_path FROM screening_reports").fetchall():
            oldp = Path(rr["pdf_path"] or "")
            candidate = REPORT_DIR / oldp.name
            if oldp.name and (not oldp.exists()) and candidate.exists():
                con.execute("UPDATE screening_reports SET pdf_path=? WHERE id=?", (str(candidate), rr["id"]))
        for dd in con.execute("SELECT id, file_path FROM entity_documents").fetchall():
            oldp = Path(dd["file_path"] or "")
            # Prefer current data directory preserving the last path components after uploads/.
            parts = list(oldp.parts)
            if "uploads" in parts:
                rel = Path(*parts[parts.index("uploads"):])
                candidate = DATA_DIR / rel
                if (not oldp.exists()) and candidate.exists():
                    con.execute("UPDATE entity_documents SET file_path=? WHERE id=?", (str(candidate), dd["id"]))
    except Exception:
        pass
    con.execute("INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES(?,?)", ("V10.3.0", now_iso()))
    con.commit()


def retention_until_date() -> str:
    return (dt.datetime.now() + dt.timedelta(days=365 * RETENTION_YEARS)).date().isoformat()


def _severity_rank(severity: str) -> int:
    return {"low": 1, "medium": 2, "high": 3, "critical": 4}.get((severity or "").lower(), 0)


def _contains_any(text: str, terms: Iterable[str]) -> bool:
    # V10.5.6 fix: مطابقة على مستوى الكلمات بعد التوحيد بدل البحث الجزئي داخل السلاسل،
    # حتى لا تولد أسماء مثل Miranda مؤشر "iran" أو كلمة "اليمنى" مؤشر "اليمن".
    normalized = normalize_name(text or "")
    if not normalized:
        return False
    tokens = set(normalized.split())
    padded = f" {normalized} "
    for term in terms:
        t = normalize_name(str(term or ""))
        if not t:
            continue
        if " " in t:
            if f" {t} " in padded:
                return True
        elif t in tokens:
            return True
    return False


def _add_risk_flag(con: sqlite3.Connection, entity_type: str, entity_id: int, code: str, label: str, severity: str, notes: str) -> None:
    # Keep one current flag per entity/code to avoid duplicated red flags after repeated UAT use.
    con.execute("DELETE FROM risk_flags WHERE entity_type=? AND entity_id=? AND flag_code=?", (entity_type, entity_id, code))
    con.execute("INSERT INTO risk_flags(created_at, entity_type, entity_id, flag_code, flag_label, severity, notes) VALUES(?,?,?,?,?,?,?)", (now_iso(), entity_type, entity_id, code, label, severity, notes))


def evaluate_client_risk(con: sqlite3.Connection, client_id: int) -> None:  # type: ignore[override]
    c = con.execute("SELECT * FROM clients WHERE id=?", (client_id,)).fetchone()
    if not c:
        return
    con.execute("DELETE FROM risk_flags WHERE entity_type='client' AND entity_id=?", (client_id,))
    text_parts = [c["legal_name"] or "", c["country"] or "", c["nationality"] or "", c["notes"] or "", c["source_notes"] or "", c["source_of_funds"] or "", c["source_of_wealth"] or ""]
    ownership_rows = con.execute("SELECT * FROM ownership_tracing WHERE client_id=?", (client_id,)).fetchall()
    for o in ownership_rows:
        text_parts += [o["owner_name"] or "", o["country"] or "", o["control_description"] or "", o["notes"] or ""]
    text = " ".join(text_parts).lower()
    if any(x in text for x in HIGH_RISK_COUNTRIES):
        _add_risk_flag(con, "client", client_id, "HIGH_RISK_COUNTRY", "دولة أو جنسية عالية المخاطر", "high", "تحتاج عناية معززة وتوثيق سبب القبول أو الرفض")
    if c["risk_level"] == "high" and not (c["source_of_funds"] or c["source_of_wealth"]):
        if c["source_notes"]:
            _add_risk_flag(con, "client", client_id, "SOURCE_SKIPPED", "تم تجاوز مصدر المال/الثروة مع توثيق السبب", "medium", c["source_notes"])
        else:
            _add_risk_flag(con, "client", client_id, "SOURCE_MISSING", "مصدر المال/الثروة غير موثق رغم ارتفاع المخاطر", "high", "يجب طلب المصدر أو توثيق سبب عدم الطلب")
    if c["listed_saudi_market"]:
        _add_risk_flag(con, "client", client_id, "LISTED_COMPANY", "شركة مدرجة - تجاوز فحص الملكية التفصيلي فقط", "low", "الفحص الداخلي وفحص اسم الشركة لا يزالان مستمرين")
    if len(ownership_rows) >= 2:
        _add_risk_flag(con, "client", client_id, "COMPLEX_OWNERSHIP", "هيكل ملكية متعدد الطبقات", "medium", f"عدد طبقات الملكية المسجلة: {len(ownership_rows)}")
    if _contains_any(text, ["pep", "سياسي", "سياسياً", "politically exposed"]):
        _add_risk_flag(con, "client", client_id, "PEP_INDICATOR", "مؤشر شخص معرض سياسيًا PEP", "high", "يحتاج مراجعة امتثال وعناية معززة")
    if _contains_any(text, DUAL_USE_KEYWORDS):
        _add_risk_flag(con, "client", client_id, "PF_DUAL_USE", "مؤشر تمويل انتشار التسلح / استخدام مزدوج", "high", "تحقق من طبيعة الخدمة والأطراف النهائية وسلسلة التوريد")
    if _contains_any(text, ["cash", "نقد", "مناطق متعددة", "multiple jurisdictions", "cross border", "عابر للحدود"]):
        _add_risk_flag(con, "client", client_id, "TF_UNUSUAL_FLOW", "مؤشر تدفقات أو تعاملات غير معتادة", "medium", "يحتاج تفسير اقتصادي واضح وتوثيق")


def evaluate_counterparty_risk(con: sqlite3.Connection, counterparty_id: int) -> None:
    cp = con.execute("SELECT * FROM counterparties WHERE id=?", (counterparty_id,)).fetchone()
    if not cp:
        return
    con.execute("DELETE FROM risk_flags WHERE entity_type='counterparty' AND entity_id=?", (counterparty_id,))
    text = " ".join([cp["full_name"] or "", cp["country"] or "", cp["nationality"] or "", cp["role_in_matter"] or "", cp["notes"] or ""]).lower()
    severity = "normal"
    if any(x in text for x in HIGH_RISK_COUNTRIES):
        _add_risk_flag(con, "counterparty", counterparty_id, "HIGH_RISK_COUNTRY", "طرف مقابل مرتبط بدولة عالية المخاطر", "high", "فحص قوائم وعناية معززة")
        severity = "high"
    if _contains_any(text, DUAL_USE_KEYWORDS):
        _add_risk_flag(con, "counterparty", counterparty_id, "PF_DUAL_USE", "طرف مقابل مرتبط بمؤشر تمويل انتشار التسلح", "high", "تحقق من الاستخدام النهائي والوسطاء")
        severity = "high"
    if _contains_any(text, ["front", "shell", "واجهة", "وهمية", "وسيط", "broker"]):
        _add_risk_flag(con, "counterparty", counterparty_id, "SHELL_OR_INTERMEDIARY", "كيان واجهة أو وسيط محتمل", "medium", "يجب توثيق المالك والمستفيد الحقيقي")
        if severity != "high": severity = "medium"
    con.execute("UPDATE counterparties SET risk_level=? WHERE id=?", (severity, counterparty_id))


def evaluate_matter_risk(con: sqlite3.Connection, matter_id: int) -> None:
    m = con.execute("SELECT * FROM matters WHERE id=?", (matter_id,)).fetchone()
    if not m:
        return
    con.execute("DELETE FROM risk_flags WHERE entity_type='matter' AND entity_id=?", (matter_id,))
    text = " ".join([m["title"] or "", m["service_type"] or "", m["description"] or ""]).lower()
    severity = "normal"
    if _contains_any(text, DUAL_USE_KEYWORDS):
        _add_risk_flag(con, "matter", matter_id, "PF_SERVICE_INDICATOR", "خدمة أو مشروع قد يرتبط بمخاطر تمويل انتشار التسلح", "high", "ينبغي فحص الأطراف وسلسلة التوريد والاستخدام النهائي")
        severity = "high"
    if _contains_any(text, ["تحصيل ديون", "debt collection", "عابر للحدود", "cross border", "لوجست", "shipping", "freight"]):
        _add_risk_flag(con, "matter", matter_id, "TF_PF_SERVICE_PATTERN", "نمط خدمة يحتاج عناية إضافية", "medium", "راجع الغرض التجاري ومصدر الأموال والأطراف")
        if severity != "high": severity = "medium"
    con.execute("UPDATE matters SET risk_level=? WHERE id=?", (severity, matter_id))


_base_create_matter_v103 = create_matter

def create_matter(fields: Dict[str, List[str]], ip: str = "") -> int:  # type: ignore[override]
    mid = _base_create_matter_v103(fields, ip)
    with db() as con:
        ensure_schema(con)
        evaluate_matter_risk(con, mid)
        audit(con, "evaluate_matter_risk", "matter", mid, "V10.3 red flags evaluated", ip)
        con.commit()
    return mid


_base_create_counterparty_v103 = create_counterparty

def create_counterparty(fields: Dict[str, List[str]], ip: str = "") -> int:  # type: ignore[override]
    cp_id = _base_create_counterparty_v103(fields, ip)
    with db() as con:
        ensure_schema(con)
        evaluate_counterparty_risk(con, cp_id)
        cp = con.execute("SELECT matter_id FROM counterparties WHERE id=?", (cp_id,)).fetchone()
        if cp:
            evaluate_matter_risk(con, int(cp["matter_id"]))
        audit(con, "evaluate_counterparty_risk", "counterparty", cp_id, "V10.3 red flags evaluated", ip)
        con.commit()
    return cp_id


_base_add_related_party_v103 = add_related_party

def add_related_party(fields: Dict[str, List[str]], parent_type: str, parent_id_key: str, ip: str = "") -> int:  # type: ignore[override]
    pid = _base_add_related_party_v103(fields, parent_type, parent_id_key, ip)
    parent_id = int(form_value(fields, parent_id_key, "0"))
    with db() as con:
        ensure_schema(con)
        if parent_type == "client":
            evaluate_client_risk(con, parent_id)
        elif parent_type == "counterparty":
            evaluate_counterparty_risk(con, parent_id)
        audit(con, "evaluate_related_party_risk", parent_type, parent_id, f"related_party={pid}", ip)
        con.commit()
    return pid


def risk_visual_for_screening(status: str, score: int) -> Tuple[str, str, str]:  # type: ignore[override]
    # V10.5.6 fix: قرارات الإغلاق الموثقة تتقدم على الدرجة حتى لا يبقى False Positive
    # بدرجة 100 معروضاً كأحمر دائم بعد قرار الامتثال.
    if status in {"false_positive", "closed", "exempted_listed_company"}:
        return "green", "أخضر", "مغلق أو مستثنى بتوثيق: يحفظ القرار وأدلته"
    if status in {"confirmed_match", "frozen", "reported", "blocked"} or score >= 100:
        return "red", "أحمر", "خطر مرتفع: يوقف التعامل ويحال لمسؤول الامتثال للتجميد/الإبلاغ حسب الحالة"
    if status in {"potential_match", "high_similarity", "under_review", "list_unavailable"} or score >= 75:
        if status == "list_unavailable":
            return "yellow", "أصفر", "الفحص غير مكتمل: يجب رفع وتفعيل القوائم الرسمية قبل اعتماد النتيجة"
        return "yellow", "أصفر", "يتطلب مراجعة: لا يعتمد العميل أو المشروع قبل قرار الامتثال"
    return "green", "أخضر", "لا يوجد تطابق مؤثر"



def badge_status(status: str) -> str:  # type: ignore[override]
    labels = {
        "draft": "مسودة", "active": "نشط", "under_review": "قيد المراجعة", "blocked": "محظور التعامل",
        "no_match": "لا يوجد تطابق", "potential_match": "تطابق محتمل", "high_similarity": "تشابه كبير",
        "confirmed_match": "تطابق مؤكد", "false_positive": "False Positive موثق", "frozen": "مجمد / محظور",
        "reported": "تم الإبلاغ", "closed": "مغلق", "success": "نجاح", "partial_success": "نجاح جزئي", "failed": "فشل",
        "list_unavailable": "الفحص غير مكتمل - لا توجد قوائم نشطة",
        "exempted_listed_company": "استثناء موثق - شركة مدرجة", "green": "أخضر", "أخضر": "أخضر", "yellow": "أصفر", "أصفر": "أصفر", "red": "أحمر", "أحمر": "أحمر",
        "normal": "عادي", "medium": "متوسط", "high": "مرتفع", "critical": "حرج"
    }
    danger = {"confirmed_match", "frozen", "reported", "blocked", "failed", "red", "أحمر", "critical"}
    warn = {"potential_match", "high_similarity", "under_review", "partial_success", "list_unavailable", "yellow", "أصفر", "medium", "high"}
    cls = "danger" if status in danger else "warn" if status in warn else "ok"
    return f'<span class="badge {cls}" role="status">{h(labels.get(status, status))}</span>'



def layout(title: str, body: str, active: str = "") -> bytes:  # type: ignore[override]
    nav = [
        ("/", "الرئيسية"), ("/clients", "العملاء"), ("/matters", "المشاريع / القضايا"),
        ("/lists", "القوائم"), ("/quick_screen", "الفحص السريع"), ("/screenings", "الفحص والتطابقات"),
        ("/compliance", "لوحة الامتثال"), ("/reports", "التقارير"), ("/audit", "سجل التدقيق"), ("/production", "أدوات الإنتاج"),
    ]
    nav_html = "".join(f'<a class="{ "active" if href == active else "" }" href="{href}">{label}</a>' for href, label in nav)
    settings_cls = "active" if active.startswith("/settings") else ""
    nav_html += f'<div class="dropdown"><a class="{settings_cls}" href="/settings">الإعدادات</a><div class="dropdown-content"><a href="/settings#company">إعدادات الشركة</a><a href="/settings#client-types">أنواع العملاء</a><a href="/settings#service-types">أنواع الخدمات</a><a href="/settings#users">المستخدمين</a></div></div>'
    doc = f"""<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{h(title)} - Compliance Tracks مسارات الامتثال {h(APP_VERSION)}</title>
<style>
:root {{ --bg:#eef2f7; --panel:#ffffff; --text:#06121f; --muted:#263244; --line:#64748b; --primary:#063b2f; --primary2:#006c50; --danger:#7f1d1d; --danger2:#991b1b; --warn:#7c2d12; --warn2:#b45309; --ok:#064e3b; --ok2:#047857; --focus:#1d4ed8; }}
* {{ box-sizing:border-box; }}
.env-banner {{ position:sticky; top:0; z-index:999; padding:9px 16px; text-align:center; font-weight:900; letter-spacing:.2px; border-bottom:2px solid #111827; }}
.env-uat {{ background:#facc15; color:#111827; }}
.env-prod {{ background:#991b1b; color:#ffffff; }}
body {{ margin:0; font-family:Tahoma, Arial, sans-serif; background:var(--bg); color:var(--text); line-height:1.7; font-size:17px; }}
header {{ background:linear-gradient(90deg,#03251f,#07543f); color:#fff; padding:18px 24px; border-bottom:7px solid #34d399; }}
header h1 {{ margin:0; font-size:24px; font-weight:900; }} header small {{ display:block; color:#eafff7; margin-top:4px; font-weight:700; }}
nav {{ display:flex; flex-wrap:wrap; gap:8px; padding:12px 18px; background:#d1fae5; border-bottom:2px solid #065f46; }}
nav a {{ color:#042f24; text-decoration:none; padding:10px 13px; border:2px solid #047857; border-radius:10px; font-weight:900; background:#fff; }}
nav a.active, nav a:hover, nav a:focus {{ background:#063b2f; color:#fff; outline:3px solid #facc15; outline-offset:1px; }}
.dropdown {{ position:relative; display:inline-block; }} .dropdown-content {{ display:none; position:absolute; right:0; top:48px; background:#fff; min-width:260px; border:2px solid var(--line); border-radius:12px; box-shadow:0 10px 28px rgba(0,0,0,.2); z-index:20; padding:8px; }} .dropdown-content a {{ display:block; margin:4px 0; }} .dropdown:hover .dropdown-content {{ display:block; }}
main {{ padding:24px; max-width:1340px; margin:auto; }}
.card {{ background:var(--panel); border:2px solid var(--line); border-radius:16px; padding:18px; margin-bottom:18px; box-shadow:0 2px 8px rgba(0,0,0,.10); }}
.grid {{ display:grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap:14px; }}
.kpi {{ border-right:8px solid var(--primary2); }} .kpi .num {{ font-size:32px; font-weight:900; color:var(--primary); }}
table {{ width:100%; border-collapse:collapse; background:#fff; margin-top:10px; }} th, td {{ border:1.8px solid #64748b; padding:10px 11px; text-align:right; vertical-align:top; }} th {{ background:#dbeafe; color:#06121f; font-weight:900; }}
label {{ display:block; font-weight:900; margin-top:10px; }} input, select, textarea {{ width:100%; padding:11px; border:2px solid #475569; border-radius:9px; font-family:inherit; font-size:16px; background:#fff; color:var(--text); }} input:focus, select:focus, textarea:focus {{ outline:3px solid #facc15; border-color:#1d4ed8; }} textarea {{ min-height:96px; }}
button, .btn {{ display:inline-block; border:0; border-radius:10px; padding:11px 16px; background:#063b2f; color:#fff; text-decoration:none; cursor:pointer; font-weight:900; margin-top:10px; box-shadow:0 2px 0 rgba(0,0,0,.3); }} button:hover, .btn:hover {{ filter:brightness(1.08); }} .btn.secondary {{ background:#1e293b; }} .btn.warn {{ background:#9a3412; }} .btn.danger {{ background:#7f1d1d; }} .btn.ok {{ background:#065f46; }}
.badge {{ display:inline-block; padding:6px 11px; border-radius:999px; font-weight:900; border:2px solid currentColor; background:#fff; color:#111827; white-space:nowrap; }} .badge.ok {{ background:#dcfce7; color:#064e3b; }} .badge.warn {{ background:#fef3c7; color:#7c2d12; }} .badge.danger {{ background:#fee2e2; color:#7f1d1d; }}
.notice {{ padding:13px; border-right:7px solid #1d4ed8; background:#dbeafe; border-radius:10px; font-weight:700; }} .error {{ padding:13px; border-right:7px solid #7f1d1d; background:#fee2e2; border-radius:10px; font-weight:800; }} .success {{ padding:13px; border-right:7px solid #065f46; background:#dcfce7; border-radius:10px; font-weight:800; }}
.workflow {{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; }} .step {{ background:#fff; border:3px solid #047857; border-radius:14px; padding:11px 13px; font-weight:900; min-width:155px; text-align:center; }} .arrow {{ font-weight:900; color:#047857; }} .small {{ color:#1f2937; font-size:14px; font-weight:700; }} hr {{ border:0; border-top:2px solid var(--line); margin:16px 0; }}
.status-red {{ border-right:9px solid #7f1d1d; background:#fff1f2; }} .status-yellow {{ border-right:9px solid #b45309; background:#fffbeb; }} .status-green {{ border-right:9px solid #047857; background:#ecfdf5; }}
pre {{ white-space:pre-wrap; word-break:break-word; font-family:Consolas, monospace; direction:ltr; text-align:left; }}
</style></head><body><div class="env-banner {'env-uat' if APP_ENV == 'UAT' else 'env-prod'}">{ENV_LABEL_AR}</div><header><h1>مسارات الامتثال — Compliance Tracks</h1><small>منصة الامتثال ومعرفة العميل من Legal Tracks · {APP_VERSION} | البيئة: {APP_ENV}</small></header><nav>{nav_html}</nav><main>{body}</main></body></html>"""
    return doc.encode("utf-8")


def _case_for_screening(con: sqlite3.Connection, screening_id: int, status: str, reason: str, ip: str = "") -> None:
    r = con.execute("SELECT * FROM screenings WHERE id=?", (screening_id,)).fetchone()
    if not r:
        return
    client_id, matter_id, counterparty_id = report_context_for_screening(con, r)
    risk_level, visual, action = risk_visual_for_screening(status, int(r["match_score"] or 0))
    # V10.5.6 fix: قضية واحدة لكل نتيجة فحص تُحدّث عند كل قرار، بدل قضية جديدة عند كل مراجعة
    # كانت تضخم مؤشرات لوحة الامتثال ولا تغلق أبداً.
    existing_case = con.execute("SELECT id FROM compliance_cases WHERE screening_id=? ORDER BY id DESC LIMIT 1", (screening_id,)).fetchone()
    if existing_case:
        con.execute("UPDATE compliance_cases SET updated_at=?, case_status=?, visual_status=?, action_required=?, decision_reason=? WHERE id=?",
                    (now_iso(), status, visual, action, reason, int(existing_case["id"])))
    else:
        con.execute("""INSERT INTO compliance_cases(created_at, updated_at, screening_id, client_id, matter_id, counterparty_id, case_status, visual_status, action_required, decision_reason, retention_until, created_by)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), now_iso(), screening_id, client_id, matter_id, counterparty_id, status, visual, action, reason, retention_until_date(), "compliance"))
    if status in {"confirmed_match", "frozen", "reported"}:
        if client_id:
            con.execute("UPDATE clients SET status='blocked', updated_at=? WHERE id=?", (now_iso(), client_id))
        if matter_id:
            con.execute("UPDATE matters SET status='blocked', updated_at=? WHERE id=?", (now_iso(), matter_id))
        if counterparty_id:
            con.execute("UPDATE counterparties SET status='blocked' WHERE id=?", (counterparty_id,))
    elif status in {"under_review", "high_similarity", "potential_match"}:
        if client_id:
            con.execute("UPDATE clients SET status='under_review', updated_at=? WHERE id=? AND status NOT IN ('blocked')", (now_iso(), client_id))
        if matter_id:
            con.execute("UPDATE matters SET status='under_review', updated_at=? WHERE id=? AND status NOT IN ('blocked')", (now_iso(), matter_id))
        if counterparty_id:
            con.execute("UPDATE counterparties SET status='under_review' WHERE id=? AND status NOT IN ('blocked')", (counterparty_id,))
    elif status in {"false_positive", "closed"}:
        # V10.5.6 fix: مسار رجوع موثق - إذا أُغلقت النتيجة ولم تتبق نتائج مفتوحة مؤثرة أخرى
        # لنفس الكيان، تعاد حالته من محظور/قيد المراجعة إلى نشط بدلاً من بقائه محظوراً للأبد.
        open_states = ("confirmed_match", "high_similarity", "potential_match", "frozen", "reported")
        placeholders = ",".join("?" for _ in open_states)
        if client_id:
            other = con.execute(
                f"SELECT COUNT(*) FROM screenings s WHERE s.id<>? AND s.status IN ({placeholders}) AND ((s.subject_type='client' AND s.subject_id=?) OR (s.subject_type='client_related_party' AND s.subject_id IN (SELECT id FROM related_parties WHERE parent_type='client' AND parent_id=?)))",
                (screening_id, *open_states, client_id, client_id)).fetchone()[0]
            if not other:
                con.execute("UPDATE clients SET status='active', updated_at=? WHERE id=? AND status IN ('blocked','under_review')", (now_iso(), client_id))
        if matter_id:
            other = con.execute(
                f"SELECT COUNT(*) FROM screenings s WHERE s.id<>? AND s.status IN ({placeholders}) AND ((s.subject_type='counterparty' AND s.subject_id IN (SELECT id FROM counterparties WHERE matter_id=?)) OR (s.subject_type='counterparty_related_party' AND s.subject_id IN (SELECT id FROM related_parties WHERE parent_type='counterparty' AND parent_id IN (SELECT id FROM counterparties WHERE matter_id=?))))",
                (screening_id, *open_states, matter_id, matter_id)).fetchone()[0]
            if not other:
                con.execute("UPDATE matters SET status='active', updated_at=? WHERE id=? AND status IN ('blocked','under_review')", (now_iso(), matter_id))
        if counterparty_id:
            other = con.execute(
                f"SELECT COUNT(*) FROM screenings s WHERE s.id<>? AND s.status IN ({placeholders}) AND ((s.subject_type='counterparty' AND s.subject_id=?) OR (s.subject_type='counterparty_related_party' AND s.subject_id IN (SELECT id FROM related_parties WHERE parent_type='counterparty' AND parent_id=?)))",
                (screening_id, *open_states, counterparty_id, counterparty_id)).fetchone()[0]
            if not other:
                con.execute("UPDATE counterparties SET status='active' WHERE id=? AND status IN ('blocked','under_review')", (counterparty_id,))
    audit(con, "compliance_case_created", "screening", screening_id, f"status={status}; visual={visual}; client={client_id}; matter={matter_id}; cp={counterparty_id}; reason={reason}", ip)


def update_screening(fields: Dict[str, List[str]], ip: str = "") -> str:  # type: ignore[override]
    sid = int(form_value(fields, "screening_id", "0") or 0)
    status = form_value(fields, "status", "under_review")
    # V10.5.6 fix: حصر حالات القرار بالقيم المعتمدة والتحقق من وجود النتيجة قبل التحديث.
    allowed_statuses = {"no_match", "potential_match", "high_similarity", "confirmed_match",
                        "false_positive", "frozen", "reported", "closed", "under_review"}
    if status not in allowed_statuses:
        raise ValueError("حالة قرار غير معتمدة")
    reason = form_value(fields, "decision_reason")
    with db() as con:
        ensure_schema(con)
        if not con.execute("SELECT id FROM screenings WHERE id=?", (sid,)).fetchone():
            raise ValueError(f"نتيجة الفحص رقم {sid} غير موجودة")
        con.execute("UPDATE screenings SET status=?, decision_reason=?, reviewed_by='compliance', reviewed_at=?, updated_at=?, retention_until=? WHERE id=?", (status, reason, now_iso(), now_iso(), retention_until_date(), sid))
        con.execute("INSERT INTO compliance_actions(created_at, screening_id, action_type, action_note, created_by) VALUES(?,?,?,?,?)", (now_iso(), sid, status, reason, "compliance"))
        _case_for_screening(con, sid, status, reason, ip)
        audit(con, "update_screening_status", "screening", sid, f"status={status}; reason={reason}", ip)
        con.commit()
    return f"تم تحديث نتيجة الفحص رقم {sid} إلى {status} وتسجيلها في لوحة الامتثال"


def compliance_page(message: str = "") -> bytes:
    with db() as con:
        ensure_schema(con)
        cases = con.execute("SELECT cc.*, s.subject_name, s.screening_scope, s.match_score, s.matched_name FROM compliance_cases cc LEFT JOIN screenings s ON s.id=cc.screening_id ORDER BY cc.id DESC LIMIT 200").fetchall()
        gov = con.execute("SELECT * FROM compliance_governance ORDER BY id DESC LIMIT 50").fetchall()
        red = con.execute("SELECT COUNT(*) FROM compliance_cases WHERE visual_status='أحمر'").fetchone()[0]
        yellow = con.execute("SELECT COUNT(*) FROM compliance_cases WHERE visual_status='أصفر'").fetchone()[0]
        blocked = con.execute("SELECT COUNT(*) FROM clients WHERE status='blocked'").fetchone()[0]
        flags = con.execute("SELECT entity_type, entity_id, flag_label, severity, notes, created_at FROM risk_flags ORDER BY id DESC LIMIT 150").fetchall()
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    case_rows = "".join(f"<tr><td>{r['id']}</td><td>{h(r['created_at'])}</td><td>{h(r['subject_name'])}</td><td>{h(r['screening_scope'])}</td><td>{h(r['matched_name'])}</td><td>{h(r['match_score'])}</td><td>{badge_status(r['case_status'])}</td><td>{badge_status(r['visual_status'])}</td><td>{h(r['action_required'])}</td><td>{h(r['confidentiality_note'])}</td></tr>" for r in cases)
    gov_rows = "".join(f"<tr><td>{r['id']}</td><td>{h(r['item_type'])}</td><td>{h(r['item_title'])}</td><td>{h(r['owner'])}</td><td>{badge_status(r['status'])}</td><td>{h(r['evidence_notes'])}</td></tr>" for r in gov)
    flag_rows = "".join(f"<tr><td>{h(r['created_at'])}</td><td>{h(r['entity_type'])}/{h(r['entity_id'])}</td><td>{h(r['flag_label'])}</td><td>{badge_status(r['severity'])}</td><td>{h(r['notes'])}</td></tr>" for r in flags)
    body = f"""
<div class="card"><h2>لوحة الامتثال حسب الدليل الإرشادي</h2>{msg}<p class="notice">هذه اللوحة تجمع حالات التطابق، التجميد/حظر التعامل، الإبلاغ، السرية، مؤشرات المخاطر، وسجلات الحوكمة. جميع السجلات تحفظ لمدة لا تقل عن {RETENTION_YEARS} سنوات.</p></div>
<div class="grid"><div class="card kpi status-red"><div>حالات حمراء</div><div class="num">{red}</div></div><div class="card kpi status-yellow"><div>حالات صفراء</div><div class="num">{yellow}</div></div><div class="card kpi status-red"><div>عملاء محظورون</div><div class="num">{blocked}</div></div></div>
<div class="card"><h3>حالات الامتثال والتصعيد</h3><table><thead><tr><th>#</th><th>التاريخ</th><th>المفحوص</th><th>النطاق</th><th>التطابق</th><th>النسبة</th><th>الحالة</th><th>اللون</th><th>الإجراء المطلوب</th><th>السرية</th></tr></thead><tbody>{case_rows or '<tr><td colspan="10">لا توجد حالات امتثال</td></tr>'}</tbody></table></div>
<div class="card"><h3>مؤشرات المخاطر Red Flags</h3><table><thead><tr><th>التاريخ</th><th>الكيان</th><th>المؤشر</th><th>الحدة</th><th>الملاحظة</th></tr></thead><tbody>{flag_rows or '<tr><td colspan="5">لا توجد مؤشرات</td></tr>'}</tbody></table></div>
<div class="card"><h3>الحوكمة والتدريب والرقابة</h3><table><thead><tr><th>#</th><th>النوع</th><th>العنوان</th><th>المسؤول</th><th>الحالة</th><th>الدليل/الملاحظة</th></tr></thead><tbody>{gov_rows or '<tr><td colspan="6">لا توجد سجلات حوكمة</td></tr>'}</tbody></table></div>
"""
    return layout("لوحة الامتثال", body, "/compliance")


def screenings_page(message: str = "") -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        rows = con.execute("SELECT * FROM screenings ORDER BY id DESC LIMIT 300").fetchall()
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    parts = []
    for r in rows:
        risk_level, visual_status, required_action = risk_visual_for_screening(r['status'], int(r['match_score'] or 0))
        row_cls = "status-red" if visual_status == "أحمر" else "status-yellow" if visual_status == "أصفر" else "status-green"
        parts.append(f"""<tr class="{row_cls}"><td>{r['id']}</td><td>{h(r['subject_type'])}</td><td>{h(r['subject_name'])}</td><td>{h(r['screening_scope'])}</td><td>{h(r['list_name'])}</td><td>{h(r['matched_name'])}</td><td>{r['match_score']}</td><td>{h(r['match_reason'])}</td><td>{badge_status(r['status'])}</td><td>{badge_status(visual_status)}<br><span class='small'>{h(required_action)}</span></td><td><form method='post' action='/screening/update'><input type='hidden' name='screening_id' value='{r['id']}'><select name='status'><option value='under_review'>قيد المراجعة</option><option value='false_positive'>False Positive موثق</option><option value='confirmed_match'>تطابق مؤكد</option><option value='frozen'>تجميد/حظر تعامل</option><option value='reported'>تم الإبلاغ</option><option value='closed'>إغلاق</option></select><input name='decision_reason' placeholder='سبب القرار - إلزامي تشغيليًا'><button>تحديث وتسجيل حالة امتثال</button></form></td><td><form method='post' action='/screening/report'><input type='hidden' name='screening_id' value='{r['id']}'><button class='btn secondary'>إصدار PDF</button></form></td></tr>""")
    body = f"""
<div class="card"><h2>الفحص والتطابقات</h2>{msg}<p class="notice">الأحمر يعني خطر مرتفع ويجب عدم اعتماد العميل أو فتح/استمرار المشروع قبل قرار الامتثال. الأصفر يعني مراجعة. الأخضر يعني لا يوجد تطابق جوهري أو إغلاق موثق. لا يتم تنبيه العميل أو أي طرف خارجي.</p></div>
<div class="card"><table><thead><tr><th>#</th><th>نوع المفحوص</th><th>الاسم</th><th>النطاق</th><th>القائمة</th><th>التطابق</th><th>النسبة</th><th>السبب</th><th>الحالة</th><th>المؤشر البصري</th><th>قرار الامتثال</th><th>تقرير PDF</th></tr></thead><tbody>{''.join(parts) or '<tr><td colspan="12">لا توجد نتائج</td></tr>'}</tbody></table></div>
"""
    return layout("الفحص", body, "/screenings")


def production_page(message: str = "") -> bytes:  # type: ignore[override]
    key_path = get_or_create_master_key()
    key_hash = hashlib.sha256(key_path.read_bytes()).hexdigest()[:16]
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    body = f"""
<div class="card"><h2>أدوات الإنتاج والصيانة</h2>{msg}
<table><tr><th>الإصدار</th><td>{h(APP_VERSION)}</td></tr><tr><th>مسار قاعدة البيانات</th><td>{h(DB_PATH)}</td></tr><tr><th>مسار مفتاح التشفير</th><td>{h(key_path)}</td></tr><tr><th>بصمة المفتاح</th><td>{h(key_hash)}...</td></tr><tr><th>مدة حفظ سجلات الامتثال</th><td>{RETENTION_YEARS} سنوات</td></tr></table>
<div class="grid"><form method="post" action="/production/backup"><button>إنشاء نسخة احتياطية الآن</button></form><form method="post" action="/production/maintenance"><button class="btn secondary">فحص وصيانة داخلية</button></form><form method="post" action="/production/daily_screening"><button class="btn warn">تشغيل الفحص المستمر الآن</button></form></div>
<p class="notice">الفحص المستمر يعيد فحص العملاء والأطراف المقابلة عند تحديث القوائم أو عند الطلب، ويحفظ نتيجة التشغيل في سجل مستقل.</p></div>
"""
    return layout("الإنتاج", body, "/production")


def run_daily_screening() -> Dict[str, int]:  # type: ignore[override]
    init_db()
    totals = {"created": 0, "hits": 0, "clients_checked": 0, "matters_checked": 0}
    with db() as con:
        ensure_schema(con)
        client_ids = [r[0] for r in con.execute("SELECT id FROM clients").fetchall()]
        matter_ids = [r[0] for r in con.execute("SELECT id FROM matters").fetchall()]
    failures: List[str] = []
    for cid in client_ids:
        try:
            res = run_client_screening(cid)
            totals["clients_checked"] += 1; totals["created"] += res["created"]; totals["hits"] += res["hits"]
        except Exception as exc:  # V10.5.6 fix: فشل سجل واحد لا يوقف بقية الفحص الدوري.
            failures.append(f"client:{cid}: {exc}")
    for mid in matter_ids:
        try:
            res = run_matter_screening(mid)
            totals["matters_checked"] += 1; totals["created"] += res["created"]; totals["hits"] += res["hits"]
        except Exception as exc:
            failures.append(f"matter:{mid}: {exc}")
    with db() as con:
        ensure_schema(con)
        run_status = "success" if not failures else "partial_success"
        details = dict(totals)
        if failures:
            details["failures"] = failures[:50]
        con.execute("INSERT INTO continuous_screening_runs(created_at, run_type, clients_checked, matters_checked, results_created, hits_created, status, details_json) VALUES(?,?,?,?,?,?,?,?)", (now_iso(), "manual_or_cli", totals["clients_checked"], totals["matters_checked"], totals["created"], totals["hits"], run_status, json.dumps(details, ensure_ascii=False)))
        audit(con, "daily_continuous_screening", "screening", 0, json.dumps(totals, ensure_ascii=False))
        con.commit()
    return totals


_base_do_get_v103 = AppHandler.do_GET

def _do_get_v103(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    if parsed.path == "/compliance":
        init_db()
        return self._send(compliance_page())
    return _base_do_get_v103(self)

AppHandler.do_GET = _do_get_v103

_base_do_post_v103 = AppHandler.do_POST

def _do_post_v103(self: AppHandler) -> None:
    path = urlparse(self.path).path
    if path == "/production/daily_screening":
        try:
            result = run_daily_screening()
            return self._send(production_page(f"تم تشغيل الفحص المستمر: نتائج جديدة {result['created']}، تطابقات {result['hits']}"))
        except Exception as exc:
            return self._send(layout("خطأ", f"<div class='error'>حدث خطأ: {h(exc)}</div>"), 500)
    return _base_do_post_v103(self)

AppHandler.do_POST = _do_post_v103

def run_server(host: str = "127.0.0.1", port: int = 8088) -> None:
    init_db()
    # V10.5.6 fix: طباعة الإصدار الفعلي بدل نص V10.5.3 الثابت القديم.
    print(f"Legal Tracks (مسارات الامتثال) KYC Compliance Edition {APP_VERSION} running at http://{host}:{port}")
    ThreadingHTTPServer((host, port), AppHandler).serve_forever()


# V10.5.6 fix: أزيل من هنا تعريف قديم مكرر لدالة run_daily_screening كان يلغي - بحكم
# ترتيب التعريفات - نسخة V10.3 الأعلى ويمنع تسجيل الفحص المستمر في جدول
# continuous_screening_runs، فكانت لوحة الإنتاج تعرض "آخر فحص دوري: لم يتم التشغيل" دائماً.



# ---------------------------------------------------------------------------
# V10.3.1 Language + Official Lists + Import Validator Patch
# Adds: Arabic/English report generation, better report register alignment,
# official sanctions source catalogue, and readable import validation results.
# ---------------------------------------------------------------------------

OFFICIAL_LIST_SOURCES = [
    {
        "code": "NATIONAL_1373",
        "name_ar": "القائمة الوطنية للإرهاب (1373)",
        "name_en": "Saudi National Terrorism List (1373)",
        "list_type": "NATIONAL",
        "page_url": "https://pctc.pss.gov.sa/wps/portal/departments/pcct/sl/%21ut/p/z0/04_Sj9CPykssy0xPLMnMz0vMAfIjo8zizYx8nA09LIy8LYJDjQzMvFy9Pb083AwMjIz0g1Pz9AuyHRUBHaHudw%21%21/",
        "download_url": "https://pctc.pss.gov.sa/portal/pcct/slist/js/slistEN.xlsx",
        "expected_format": "XLSX",
        "expected_sheets": ["Vessels", "Entities", "Individuals"],
        "notes": "ملف Excel مباشر متعدد الأوراق من رئاسة أمن الدولة / اللجنة الدائمة لمكافحة الإرهاب وتمويله",
    },
    {
        "code": "UN_TF_1267_ALQAIDA",
        "name_ar": "قائمة الأمم المتحدة - داعش والقاعدة 1267/1989/2253",
        "name_en": "UN ISIL (Da'esh) & Al-Qaida Sanctions List",
        "list_type": "TF",
        "download_url": "https://scsanctions.un.org/xml/en/al-qaida",
        "notes": "XML مباشر من موقع قوائم عقوبات مجلس الأمن",
    },
    {
        "code": "UN_TF_1988_TALIBAN",
        "name_ar": "قائمة الأمم المتحدة - لجنة 1988",
        "name_en": "UN 1988 Sanctions List",
        "list_type": "TF",
        "download_url": "https://scsanctions.un.org/xml/en/taliban",
        "notes": "XML مباشر من موقع قوائم عقوبات مجلس الأمن",
    },
    {
        "code": "UN_PF_1718_DPRK",
        "name_ar": "قائمة الأمم المتحدة - تمويل انتشار التسلح 1718 كوريا الشمالية",
        "name_en": "UN 1718 DPRK Sanctions List",
        "list_type": "PF",
        "download_url": "https://scsanctions.un.org/xml/en/dprk",
        "notes": "XML مباشر لمخاطر تمويل انتشار التسلح",
    },
    {
        "code": "UN_PF_1737_IRAN",
        "name_ar": "قائمة الأمم المتحدة - تمويل انتشار التسلح 1737/2231 إيران",
        "name_en": "UN 1737/2231 Iran Sanctions List",
        "list_type": "PF",
        "download_url": "https://scsanctions.un.org/xml/en/iran",
        "notes": "XML مباشر لمخاطر تمويل انتشار التسلح",
    },
]


def auto_dir(value: Any) -> str:
    return f"<span dir='auto'>{h(value)}</span>"


def status_text_ar(status: str) -> str:
    labels = {
        "success": "ناجح", "partial_success": "ناجح جزئيًا", "failed": "فاشل",
        "no_match": "لا يوجد تطابق", "potential_match": "تطابق محتمل", "high_similarity": "تشابه كبير",
        "confirmed_match": "تطابق مؤكد", "false_positive": "False Positive موثق", "frozen": "تجميد/حظر تعامل",
        "reported": "تم الإبلاغ", "closed": "مغلق", "under_review": "قيد المراجعة",
        "list_unavailable": "الفحص غير مكتمل - لا توجد قوائم نشطة",
        "exempted_listed_company": "استثناء موثق - شركة مدرجة",
        "أخضر": "أخضر", "أصفر": "أصفر", "أحمر": "أحمر",
    }
    return labels.get(status or "", status or "-")



def status_text_en(status: str) -> str:
    labels = {
        "success": "Success", "partial_success": "Partial Success", "failed": "Failed",
        "no_match": "No Match", "potential_match": "Potential Match", "high_similarity": "High Similarity",
        "confirmed_match": "Confirmed Match", "false_positive": "Documented False Positive", "frozen": "Frozen / Blocked",
        "reported": "Reported", "closed": "Closed", "under_review": "Under Review",
        "list_unavailable": "Incomplete Screening - No Active Lists",
        "exempted_listed_company": "Documented Exemption - Listed Company",
        "أخضر": "Green", "أصفر": "Yellow", "أحمر": "Red",
        "green": "Green", "yellow": "Yellow", "red": "Red",
    }
    return labels.get(status or "", status or "-")



def official_list_cards() -> str:
    cards = []
    for src in OFFICIAL_LIST_SOURCES:
        cards.append(f"""
        <div class='card'>
          <h3>{h(src['name_ar'])}</h3>
          <p class='small' dir='auto'>{h(src['name_en'])}</p>
          <table>
            <tr><th>كود القائمة</th><td dir='ltr'>{h(src['code'])}</td></tr>
            <tr><th>نوع القائمة</th><td>{h(src['list_type'])}</td></tr>
            <tr><th>رابط التنزيل / المصدر</th><td dir='ltr'><a href="{h(src['download_url'])}" target="_blank" rel="noopener">{h(src['download_url'])}</a></td></tr>
            <tr><th>ملاحظة</th><td>{h(src['notes'])}</td></tr>
          </table>
          <button type='button' class='btn secondary' onclick="useOfficialList('{h(src['code'])}','{h(src['download_url'])}','{h(src['list_type'])}')">استخدام هذه البيانات في نموذج الرفع</button>
        </div>
        """)
    return "<div class='grid'>" + "".join(cards) + "</div>"


def format_import_errors(errors_json: str, max_rows: int = 25) -> str:
    try:
        errors = json.loads(errors_json or "[]")
    except Exception:
        errors = [{"location": "-", "row": "-", "error": errors_json or "-"}]
    if not errors:
        return "<span class='small'>لا توجد أخطاء مسجلة</span>"
    rows = []
    for idx, e in enumerate(errors[:max_rows], start=1):
        if not isinstance(e, dict):
            # V10.5.6 fix: سجل خطأ نصي غير منظم كان يسبب انهيار صفحة القوائم.
            e = {"location": "-", "row": "-", "error": str(e)}
        loc = e.get("location", e.get("sheet", e.get("source", "-")))
        row = e.get("row", e.get("line", "-"))
        err = e.get("error", e.get("message", str(e)))
        rows.append(f"<tr><td>{idx}</td><td dir='auto'>{h(loc)}</td><td>{h(row)}</td><td dir='auto'>{h(err)}</td></tr>")
    more = "" if len(errors) <= max_rows else f"<p class='small'>تم عرض أول {max_rows} أخطاء من أصل {len(errors)}.</p>"
    return f"<table><thead><tr><th>#</th><th>الموضع / Sheet / الصفحة</th><th>رقم السطر</th><th>سبب الفشل</th></tr></thead><tbody>{''.join(rows)}</tbody></table>{more}"


def lists_page(message: str = "") -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        logs = con.execute("SELECT * FROM sanctions_import_logs ORDER BY id DESC LIMIT 50").fetchall()
        total = con.execute("SELECT COUNT(*) FROM sanctions_entries WHERE active=1").fetchone()[0]
    log_rows = []
    for l in logs:
        result_label = badge_status(l['status'])
        error_details = format_import_errors(l['error_details_json']) if l['failed_count'] else "<span class='small'>لا توجد أخطاء</span>"
        log_rows.append(f"""
        <tr>
          <td>{l['id']}</td>
          <td dir='auto'>{h(l['list_name'])}</td>
          <td dir='auto'>{h(l['filename'])}</td>
          <td>{l['total_records']}</td>
          <td>{l['success_count']}</td>
          <td>{l['failed_count']}</td>
          <td>{l['duplicate_count']}</td>
          <td>{result_label}<br><span class='small'>{h(status_text_ar(l['status']))}</span></td>
          <td>{error_details}</td>
        </tr>
        """)
    source_options = "".join(f"<option value='{h(s['code'])}' data-url='{h(s['download_url'])}' data-type='{h(s['list_type'])}'>{h(s['name_ar'])} / {h(s['name_en'])}</option>" for s in OFFICIAL_LIST_SOURCES)
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    body = f"""
<div class="card"><h2>إدارة ورفع القوائم - Multi Format Import Engine</h2>{msg}
<p class="notice">إجمالي السجلات النشطة في القوائم: <b>{total}</b>. يدعم النظام CSV و Excel متعدد الصفحات XLSX و XML و HTML و PDF، مع مدقق يوضح: عدد السجلات في القائمة، عدد السجلات التي تم رفعها، عدد السجلات الفاشلة، النتيجة، سبب الفشل، ورقم السطر/الصفحة/Sheet.</p></div>
<div class="card"><h3>مصادر القوائم الرسمية وروابط التنزيل</h3>
<p class="notice">اختر مصدر القائمة من البطاقات التالية أو من القائمة المنسدلة. يمكن تنزيل الملف من الرابط الرسمي ثم رفعه في النموذج أدناه بعد المراجعة.</p>
{official_list_cards()}</div>
<div class="card"><h3>رفع قائمة جديدة</h3>
<form method="post" action="/lists/upload" enctype="multipart/form-data">
<div class="grid">
<div><label>اختيار سريع من المصادر الرسمية</label><select id="official_source" onchange="applyOfficialListSelect()"><option value="">-- اختر مصدرًا --</option>{source_options}</select></div>
<div><label>اسم القائمة</label><input id="list_name" required name="list_name" placeholder="NATIONAL_1373 / UN_TF_1267_ALQAIDA / UN_PF_1718_DPRK"></div>
<div><label>رابط تنزيل القائمة / المصدر الرسمي</label><input id="source_url" name="source_url" placeholder="https://..."></div>
<div><label>نوع القائمة</label><select id="list_type" name="list_type"><option value="TF">تمويل الإرهاب</option><option value="PF">تمويل انتشار التسلح</option><option value="NATIONAL">وطنية</option></select></div>
<div><label>ملف القائمة</label><input required type="file" name="list_file" accept=".csv,.xlsx,.xls,.xml,.html,.htm,.pdf,.txt"></div>
</div>
<button>رفع القائمة وتشغيل المدقق</button> <a class="btn secondary" href="/templates/sanctions_import_template.csv">قالب CSV</a> <a class="btn secondary" href="/templates/sanctions_import_template.xlsx">قالب Excel</a> <a class="btn secondary" href="/templates/sanctions_import_template.xml">قالب XML</a> <a class="btn secondary" href="/templates/sanctions_import_template.html">قالب HTML</a>
<p class="small">المدقق لا يعتمد القائمة إلا بعد قراءة السجلات. أي سجل يفشل يظهر مع السبب ورقم السطر أو الصفحة أو Sheet بحسب نوع الملف.</p>
</form></div>
<div class="card"><h3>مدقق القوائم المرفوعة / Import Validation Log</h3><table><thead><tr><th>#</th><th>اسم القائمة</th><th>الملف</th><th>عدد السجلات في القائمة</th><th>عدد السجلات التي تم رفعها</th><th>فشل</th><th>مكرر</th><th>النتيجة</th><th>سبب الفشل ورقم السطر</th></tr></thead><tbody>{''.join(log_rows) or '<tr><td colspan="9">لا توجد عمليات رفع</td></tr>'}</tbody></table></div>
<script>
function useOfficialList(code, url, typ) {{
  document.getElementById('list_name').value = code;
  document.getElementById('source_url').value = url;
  document.getElementById('list_type').value = typ;
}}
function applyOfficialListSelect() {{
  var sel = document.getElementById('official_source');
  var opt = sel.options[sel.selectedIndex];
  if (!opt || !opt.value) return;
  useOfficialList(opt.value, opt.getAttribute('data-url') || '', opt.getAttribute('data-type') || 'TF');
}}
</script>
"""
    return layout("القوائم", body, "/lists")


def import_sanctions_file(fields: Dict[str, List[str]], files: Dict[str, Tuple[str, bytes]], ip: str = "") -> str:  # type: ignore[override]
    list_name_default = form_value(fields, "list_name", "UN_LIST")
    source_url_default = form_value(fields, "source_url")
    list_type_default = form_value(fields, "list_type", "TF")
    filename, content = files.get("list_file", files.get("csv_file", ("", b"")))
    if not filename or not content:
        file_sha = hashlib.sha256(content or b"").hexdigest()
        errors = [{"location": "upload", "row": 1, "error": "لم يتم اختيار ملف أو أن الملف فارغ"}]
        with db() as con:
            ensure_schema(con)
            con.execute("""INSERT INTO sanctions_import_logs(created_at, list_name, source_url, filename, file_sha256, total_records, success_count, failed_count, duplicate_count, status, error_details_json)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), list_name_default, source_url_default, filename or "-", file_sha, 0, 0, 1, 0, "failed", json.dumps(errors, ensure_ascii=False)))
            audit(con, "import_sanctions_list_multiformat_failed", "sanctions_import", 0, "empty upload", ip)
            con.commit()
        return "فشل رفع القائمة: لم يتم اختيار ملف أو أن الملف فارغ"
    defaults = {"list_name": list_name_default, "source_url": source_url_default, "list_type": list_type_default}
    file_sha = hashlib.sha256(content).hexdigest()
    parsed_rows, parse_errors = parse_sanctions_file(filename, content, defaults)
    total = len(parsed_rows) + len(parse_errors)
    success = failed = dup = 0
    errors = list(parse_errors)
    with db() as con:
        ensure_schema(con)
        for row in parsed_rows:
            if not row.get("full_name"):
                failed += 1
                errors.append({"location": row.get("_location", filename), "row": row.get("_row", "-"), "error": "اسم الشخص/الكيان full_name مطلوب"})
                continue
            rh = row_hash(row)
            try:
                con.execute("""INSERT INTO sanctions_entries(created_at, list_name, source_url, list_type, full_name, id_number, registration_number, nationality, country, notes, row_hash, active)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,1)""", (now_iso(), row.get("list_name") or list_name_default, row.get("source_url") or source_url_default, row.get("list_type") or list_type_default, row.get("full_name"), row.get("id_number"), row.get("registration_number"), row.get("nationality"), row.get("country"), (row.get("notes") or "") + (" | " + row.get("_location", "") if row.get("_location") else ""), rh))
                success += 1
            except sqlite3.IntegrityError:
                dup += 1
            except Exception as exc:
                failed += 1
                errors.append({"location": row.get("_location", filename), "row": row.get("_row", "-"), "error": str(exc)[:300]})
        failed += len(parse_errors)
        status = "success" if failed == 0 else "partial_success" if success > 0 else "failed"
        con.execute("""INSERT INTO sanctions_import_logs(created_at, list_name, source_url, filename, file_sha256, total_records, success_count, failed_count, duplicate_count, status, error_details_json)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), list_name_default, source_url_default, filename, file_sha, total, success, failed, dup, status, json.dumps(errors[:500], ensure_ascii=False)))
        audit(con, "import_sanctions_list_multiformat_validated", "sanctions_import", 0, f"{filename}; {list_name_default}: total={total}, success={success}, failed={failed}, duplicate={dup}, status={status}", ip)
        con.commit()
    return f"القائمة: {list_name_default} | عدد السجلات في القائمة: {total} | عدد السجلات التي تم رفعها: {success} | تم رفع: {success} | فشل: {failed} | مكرر: {dup} | النتيجة: {status_text_ar(status)}"


def contains_arabic(value: Any) -> bool:
    return bool(re.search(r"[\u0600-\u06FF]", str(value or "")))


def pdf_rtl(value: Any) -> str:
    text = str(value or "")
    if not text:
        return ""
    try:
        import arabic_reshaper  # type: ignore
        from bidi.algorithm import get_display  # type: ignore
        return get_display(arabic_reshaper.reshape(text))
    except Exception:
        return text


def pdf_value(value: Any) -> str:
    text = str(value or "-")
    return pdf_rtl(text) if contains_arabic(text) else text


def report_value_for_language(key: str, value: Any, lang: str) -> str:
    if key == "status":
        return status_text_en(str(value)) if lang == "en" else status_text_ar(str(value))
    if key == "visual":
        return status_text_en(str(value)) if lang == "en" else status_text_ar(str(value))
    if key == "scope":
        maps_ar = {"internal": "فحص داخلي", "sanctions": "فحص القوائم"}
        maps_en = {"internal": "Internal Screening", "sanctions": "Sanctions Screening"}
        return (maps_en if lang == "en" else maps_ar).get(str(value), str(value or "-"))
    if key == "subject_type":
        maps_ar = {"client": "عميل", "client_related_party": "طرف مرتبط بالعميل", "counterparty": "طرف مقابل", "counterparty_related_party": "طرف مرتبط بالطرف المقابل"}
        maps_en = {"client": "Client", "client_related_party": "Client Related Party", "counterparty": "Counterparty", "counterparty_related_party": "Counterparty Related Party"}
        return (maps_en if lang == "en" else maps_ar).get(str(value), str(value or "-"))
    return str(value or "-")


def screening_report_details(con: sqlite3.Connection, r: sqlite3.Row) -> Dict[str, Any]:
    details: Dict[str, Any] = {"subject_id_number": "", "subject_registration_number": "", "matched_id_number": "", "matched_registration_number": "", "client_name": "", "client_code": "", "matter_number": "", "matter_title": ""}
    st, sid = r["subject_type"], int(r["subject_id"] or 0)
    if st == "client":
        row = con.execute("SELECT legal_name,id_number,registration_number,client_code FROM clients WHERE id=?", (sid,)).fetchone()
        if row:
            details.update(subject_id_number=row["id_number"] or "", subject_registration_number=row["registration_number"] or "", client_name=row["legal_name"] or "", client_code=row["client_code"] or "")
    elif st == "client_related_party":
        row = con.execute("SELECT rp.*,c.legal_name,c.client_code FROM related_parties rp LEFT JOIN clients c ON c.id=rp.parent_id WHERE rp.id=? AND rp.parent_type='client'", (sid,)).fetchone()
        if row:
            details.update(subject_id_number=row["id_number"] or "", subject_registration_number=row["registration_number"] or "", client_name=row["legal_name"] or "", client_code=row["client_code"] or "")
    elif st == "counterparty":
        row = con.execute("""SELECT cp.id_number,cp.registration_number,m.matter_number,m.title,c.legal_name,c.client_code
            FROM counterparties cp LEFT JOIN matters m ON m.id=cp.matter_id LEFT JOIN clients c ON c.id=m.client_id WHERE cp.id=?""", (sid,)).fetchone()
        if row:
            details.update(subject_id_number=row["id_number"] or "", subject_registration_number=row["registration_number"] or "", matter_number=row["matter_number"] or "", matter_title=row["title"] or "", client_name=row["legal_name"] or "", client_code=row["client_code"] or "")
    elif st == "counterparty_related_party":
        row = con.execute("""SELECT rp.id_number,rp.registration_number,m.matter_number,m.title,c.legal_name,c.client_code
            FROM related_parties rp LEFT JOIN counterparties cp ON cp.id=rp.parent_id
            LEFT JOIN matters m ON m.id=cp.matter_id LEFT JOIN clients c ON c.id=m.client_id
            WHERE rp.id=? AND rp.parent_type='counterparty'""", (sid,)).fetchone()
        if row:
            details.update(subject_id_number=row["id_number"] or "", subject_registration_number=row["registration_number"] or "", matter_number=row["matter_number"] or "", matter_title=row["title"] or "", client_name=row["legal_name"] or "", client_code=row["client_code"] or "")
    if r["matched_entity_type"] == "sanctions_entry" and r["matched_entity_id"]:
        mr = con.execute("SELECT id_number,registration_number FROM sanctions_entries WHERE id=?", (r["matched_entity_id"],)).fetchone()
        if mr:
            details.update(matched_id_number=mr["id_number"] or "", matched_registration_number=mr["registration_number"] or "")
    return details

def generate_screening_pdf(path: Path, report_number: str, r: sqlite3.Row, visual: str, required_action: str, report_language: str = "ar", details: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    try:
        from reportlab.lib.pagesizes import A4  # type: ignore
        from reportlab.lib import colors  # type: ignore
        from reportlab.pdfbase import pdfmetrics  # type: ignore
        from reportlab.pdfbase.ttfonts import TTFont  # type: ignore
        from reportlab.pdfgen import canvas  # type: ignore
    except Exception as exc:
        raise RuntimeError("توليد PDF يتطلب تثبيت reportlab من ملف requirements.txt") from exc
    path.parent.mkdir(parents=True, exist_ok=True)
    details = details or {}
    font_name = "Helvetica"
    fp = find_pdf_font()
    if fp:
        try:
            pdfmetrics.registerFont(TTFont("LegalTracksArabic", fp)); font_name = "LegalTracksArabic"
        except Exception:
            font_name = "Helvetica"

    report_language = "en" if report_language == "en" else "ar"
    # V10.5.6 fix: فشل مبكر واضح عند غياب خط يدعم العربية بدل PDF بمربعات أو خطأ ترميز غامض.
    if font_name == "Helvetica" and (report_language == "ar" or contains_arabic(str(r["subject_name"] or "")) or contains_arabic(str(r["matched_name"] or ""))):
        raise RuntimeError("لا يتوفر خط يدعم العربية (Arial/Tahoma/DejaVuSans). ثبت خطاً مناسباً أو أضف ملف TTF داخل assets/fonts")
    c = canvas.Canvas(str(path), pagesize=A4)
    w, page_h = A4; margin = 38
    status_color = colors.green if visual == "أخضر" else colors.orange if visual == "أصفر" else colors.red

    def wrap_lines(text: Any, max_width: float, font_size: float, rtl: bool) -> List[str]:
        logical = str(text if text not in (None, "") else "-").strip()
        words = logical.split() or ["-"]
        # V10.5.6 fix: تقسيم الكلمة/الرابط الأطول من عرض الخانة إلى مقاطع بدل تجاوز الهوامش.
        split_words: List[str] = []
        for word in words:
            probe = pdf_rtl(word) if rtl and contains_arabic(word) else word
            if pdfmetrics.stringWidth(probe, font_name, font_size) <= max_width:
                split_words.append(word)
                continue
            chunk = ""
            for ch in word:
                trial_chunk = chunk + ch
                probe2 = pdf_rtl(trial_chunk) if rtl and contains_arabic(trial_chunk) else trial_chunk
                if chunk and pdfmetrics.stringWidth(probe2, font_name, font_size) > max_width:
                    split_words.append(chunk); chunk = ch
                else:
                    chunk = trial_chunk
            if chunk:
                split_words.append(chunk)
        words = split_words or ["-"]
        out: List[str] = []; current: List[str] = []
        for word in words:
            trial = " ".join(current + [word])
            display = pdf_rtl(trial) if rtl and contains_arabic(trial) else trial
            if current and pdfmetrics.stringWidth(display, font_name, font_size) > max_width:
                line = " ".join(current); out.append(pdf_rtl(line) if rtl and contains_arabic(line) else line); current = [word]
            else:
                current.append(word)
        if current:
            line = " ".join(current); out.append(pdf_rtl(line) if rtl and contains_arabic(line) else line)
        return out or ["-"]

    def page_header(first: bool = False) -> float:
        c.setFillColor(colors.HexColor("#064e3b")); c.rect(0, page_h-76, w, 76, fill=1, stroke=0)
        c.setFillColor(colors.white)
        if report_language == "ar":
            c.setFont(font_name, 15); c.drawRightString(w-margin, page_h-34, pdf_rtl("تقرير نتيجة الفحص والامتثال"))
            c.setFont(font_name, 9); c.drawRightString(w-margin, page_h-55, f"{report_number} | Legal Tracks {APP_VERSION}")
        else:
            c.setFont(font_name, 15); c.drawString(margin, page_h-34, "Screening & Compliance Result Report")
            c.setFont(font_name, 9); c.drawString(margin, page_h-55, f"Legal Tracks {APP_VERSION} | {report_number}")
        return page_h - 98

    y = page_header(True)
    c.setFillColor(status_color); c.roundRect(margin, y-31, 150, 34, 8, fill=1, stroke=0)
    c.setFillColor(colors.white); c.setFont(font_name, 12)
    badge = report_value_for_language("visual", visual, report_language)
    c.drawCentredString(margin+75, y-10, pdf_rtl(badge) if report_language == "ar" else badge)
    y -= 48

    if report_language == "ar":
        fields = [
            ("رقم التقرير", report_number), ("تاريخ الإصدار", now_iso()),
            ("العميل", details.get("client_name") or "-"), ("رقم العميل", details.get("client_code") or "-"),
            ("المشروع / القضية", details.get("matter_title") or "-"), ("رقم المشروع", details.get("matter_number") or "-"),
            ("اسم المفحوص", r["subject_name"]), ("نوع المفحوص", report_value_for_language("subject_type", r["subject_type"], "ar")),
            ("رقم هوية/جواز المفحوص", details.get("subject_id_number") or "-"), ("رقم سجل/كيان المفحوص", details.get("subject_registration_number") or "-"),
            ("نطاق الفحص", report_value_for_language("scope", r["screening_scope"], "ar")), ("اسم القائمة", r["list_name"] or "-"),
            ("الاسم المطابق", r["matched_name"] or "-"), ("رقم هوية/جواز المطابق", details.get("matched_id_number") or "-"),
            ("رقم سجل/كيان المطابق", details.get("matched_registration_number") or "-"), ("درجة التشابه", str(r["match_score"])),
            ("سبب النتيجة", r["match_reason"] or "-"), ("حالة الفحص", report_value_for_language("status", r["status"], "ar")),
            ("الإجراء المطلوب", required_action),
            ("ملاحظة رقابية", "يحفظ هذا التقرير في سجل التقارير. يمنع تنبيه العميل أو أي طرف خارجي بوجود تطابق أو تصعيد أو تجميد إلا وفق الإجراء النظامي المعتمد."),
        ]
    else:
        fields = [
            ("Report No.", report_number), ("Issue Date", now_iso()), ("Client", details.get("client_name") or "-"),
            ("Client No.", details.get("client_code") or "-"), ("Matter", details.get("matter_title") or "-"),
            ("Matter No.", details.get("matter_number") or "-"), ("Screened Name", r["subject_name"]),
            ("Subject Type", report_value_for_language("subject_type", r["subject_type"], "en")),
            ("Subject ID/Passport", details.get("subject_id_number") or "-"), ("Subject Registration No.", details.get("subject_registration_number") or "-"),
            ("Screening Scope", report_value_for_language("scope", r["screening_scope"], "en")), ("List Name", r["list_name"] or "-"),
            ("Matched Name", r["matched_name"] or "-"), ("Matched ID/Passport", details.get("matched_id_number") or "-"),
            ("Matched Registration No.", details.get("matched_registration_number") or "-"), ("Match Score", str(r["match_score"])),
            ("Reason", r["match_reason"] or "-"), ("Status", report_value_for_language("status", r["status"], "en")),
            ("Required Action", required_action),
            ("Regulatory Note", "This report is retained in the screening register. Do not disclose a match, escalation, or freeze to the client or external parties except through the approved regulatory process."),
        ]

    font_size = 9.2; line_h = 13; label_w = 145; value_w = w - (2*margin) - label_w - 22
    for label, value in fields:
        # V10.5.6 fix: تشكيل RTL يتبع محتوى القيمة نفسها لا لغة التقرير، حتى لا تطبع
        # الأسماء العربية في التقرير الإنجليزي بأحرف مفككة معكوسة.
        value_lines = wrap_lines(value, value_w, font_size, contains_arabic(value))
        row_h = max(30, 12 + line_h * len(value_lines))
        if y - row_h < 52:
            c.showPage(); y = page_header(False)
        c.setFillColor(colors.HexColor("#f1f5f9")); c.roundRect(margin, y-row_h, w-2*margin, row_h-3, 4, fill=1, stroke=0)
        c.setFillColor(colors.HexColor("#0f172a")); c.setFont(font_name, font_size)
        if report_language == "ar":
            c.drawRightString(w-margin-8, y-18, pdf_rtl(label))
            value_right = w-margin-label_w-12
            for i, line in enumerate(value_lines):
                if contains_arabic(line): c.drawRightString(value_right, y-18-(i*line_h), line)
                else: c.drawRightString(value_right, y-18-(i*line_h), str(line))
        else:
            c.drawString(margin+8, y-18, label)
            value_left = margin+label_w+12
            for i, line in enumerate(value_lines):
                if contains_arabic(line): c.drawRightString(w-margin-8, y-18-(i*line_h), line)
                else: c.drawString(value_left, y-18-(i*line_h), str(line))
        y -= row_h + 4

    c.setFont(font_name, 7.5); c.setFillColor(colors.grey)
    c.drawString(margin, 24, f"Generated by Compliance Tracks (مسارات الامتثال) - Legal Tracks {APP_VERSION} - {report_number}")
    c.save()



def create_screening_report(screening_id: int, ip: str = "", report_language: str = "ar") -> Tuple[int, str, str]:  # type: ignore[override]
    report_language = "en" if report_language == "en" else "ar"
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT * FROM screenings WHERE id=?", (screening_id,)).fetchone()
        if not r:
            raise ValueError("نتيجة الفحص غير موجودة")
        risk_level, visual_status, required_action = risk_visual_for_screening(r["status"], int(r["match_score"] or 0))
        report_number = next_report_number(con)
        pdf_path = REPORT_DIR / f"{report_number}_{report_language}.pdf"
        details = screening_report_details(con, r)
        generate_screening_pdf(pdf_path, report_number, r, visual_status, required_action, report_language, details)
        pdf_sha = hashlib.sha256(pdf_path.read_bytes()).hexdigest()
        client_id, matter_id, counterparty_id = report_context_for_screening(con, r)
        summary = f"{r['subject_name']} | {status_text_ar(r['status'])} | score {r['match_score']}"
        cur = con.execute("""INSERT INTO screening_reports(created_at, report_number, created_by, client_id, matter_id, counterparty_id, screening_id, report_type, risk_level, visual_status, decision_status, pdf_path, pdf_sha256, summary, required_action)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (now_iso(), report_number, "compliance", client_id, matter_id, counterparty_id, screening_id, f"screening_pdf_{report_language}", risk_level, visual_status, r["status"], str(pdf_path), pdf_sha, summary, required_action))
        report_id = int(cur.lastrowid)
        con.execute("""INSERT INTO screening_report_items(report_id, screening_id, subject_type, subject_name, screening_scope, list_name, matched_name, match_score, match_reason, status)
        VALUES(?,?,?,?,?,?,?,?,?,?)""", (report_id, screening_id, r["subject_type"], r["subject_name"], r["screening_scope"], r["list_name"], r["matched_name"], r["match_score"], r["match_reason"], r["status"]))
        audit(con, "create_screening_pdf_report", "screening_report", report_id, f"{report_number}; lang={report_language}; risk={risk_level}; sha={pdf_sha[:16]}", ip)
        con.commit()
    return report_id, report_number, str(pdf_path)



def screenings_page(message: str = "") -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        rows_ = con.execute("SELECT * FROM screenings ORDER BY id DESC LIMIT 400").fetchall()
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    parts = []
    for r in rows_:
        risk_level, visual_status, required_action = risk_visual_for_screening(r['status'], int(r['match_score'] or 0))
        row_cls = "status-red" if visual_status == "أحمر" else "status-yellow" if visual_status == "أصفر" else "status-green"
        parts.append(f"""<tr class="{row_cls}"><td>{r['id']}</td><td>{h(report_value_for_language('subject_type', r['subject_type'], 'ar'))}</td><td>{auto_dir(r['subject_name'])}</td><td>{h(report_value_for_language('scope', r['screening_scope'], 'ar'))}</td><td>{auto_dir(r['list_name'])}</td><td>{auto_dir(r['matched_name'])}</td><td>{r['match_score']}</td><td>{auto_dir(r['match_reason'])}</td><td>{badge_status(r['status'])}</td><td>{badge_status(visual_status)}<br><span class='small'>{h(required_action)}</span></td><td><form method='post' action='/screening/update'><input type='hidden' name='screening_id' value='{r['id']}'><select name='status'><option value='under_review'>قيد المراجعة</option><option value='false_positive'>False Positive موثق</option><option value='confirmed_match'>تطابق مؤكد</option><option value='frozen'>تجميد/حظر تعامل</option><option value='reported'>تم الإبلاغ</option><option value='closed'>إغلاق</option></select><input name='decision_reason' placeholder='سبب القرار - إلزامي تشغيليًا'><button>تحديث وتسجيل حالة امتثال</button></form></td><td><form method='post' action='/screening/report'><input type='hidden' name='screening_id' value='{r['id']}'><select name='report_language'><option value='ar'>تقرير عربي</option><option value='en'>English Report</option></select><button class='btn secondary'>إصدار PDF</button></form></td></tr>""")
    body = f"""
<div class="card"><h2>الفحص والتطابقات</h2>{msg}<p class="notice">تمت مواءمة التقارير بحيث تقبل العربية والإنجليزية. عند إصدار التقرير اختر لغة التقرير، وسيتم فصل النصوص العربية عن الإنجليزية داخل PDF لتفادي عكس الكلمات أو تداخلها.</p></div>
<div class="card"><table><thead><tr><th>#</th><th>نوع المفحوص</th><th>الاسم</th><th>النطاق</th><th>القائمة</th><th>التطابق</th><th>النسبة</th><th>السبب</th><th>الحالة</th><th>المؤشر البصري</th><th>قرار الامتثال</th><th>تقرير PDF</th></tr></thead><tbody>{''.join(parts) or '<tr><td colspan="12">لا توجد نتائج</td></tr>'}</tbody></table></div>
"""
    return layout("الفحص", body, "/screenings")


def reports_page() -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        imports = con.execute("SELECT status, COUNT(*) c FROM sanctions_import_logs GROUP BY status").fetchall()
        screen = con.execute("SELECT status, COUNT(*) c FROM screenings GROUP BY status").fetchall()
        risk = con.execute("SELECT severity, COUNT(*) c FROM risk_flags GROUP BY severity").fetchall()
        reps = con.execute("""SELECT sr.*, s.subject_name, s.subject_type, s.screening_scope, s.list_name, s.matched_name, s.match_score
                              FROM screening_reports sr LEFT JOIN screenings s ON s.id=sr.screening_id
                              ORDER BY sr.id DESC LIMIT 250""").fetchall()
    def rows_count(rs):
        return "".join(f"<tr><td>{badge_status(r[0])}</td><td>{r[1]}</td></tr>" for r in rs)
    rep_rows = []
    for r in reps:
        lang = "English" if (r['report_type'] or '').endswith('_en') else "عربي"
        rep_rows.append(f"""<tr>
          <td>{r['id']}</td><td dir='ltr'>{h(r['report_number'])}</td><td>{h(r['created_at'])}</td><td>{h(lang)}</td>
          <td>{badge_status(r['visual_status'])}</td><td>{badge_status(r['decision_status'])}</td>
          <td>{auto_dir(r['subject_name'] or '')}</td><td>{h(report_value_for_language('subject_type', r['subject_type'] or '', 'ar'))}</td>
          <td>{h(report_value_for_language('scope', r['screening_scope'] or '', 'ar'))}</td><td>{auto_dir(r['list_name'] or '')}</td><td>{auto_dir(r['matched_name'] or '')}</td><td>{h(r['match_score'] if r['match_score'] is not None else '')}</td>
          <td>{h(r['required_action'])}</td><td dir='ltr'>{h((r['pdf_sha256'] or '')[:16])}...</td><td><a class='btn secondary' href='/reports/download?id={r['id']}'>عرض PDF</a></td>
        </tr>""")
    body = f"""
<div class="card"><h2>تقارير رقابية</h2><p class="notice">تمت مواءمة سجل تقارير الفحص المصدرة لعرض العربية والإنجليزية بدون تداخل. القيم النصية تستخدم اتجاهًا تلقائيًا، والتقرير نفسه يمكن إصداره بالعربية أو الإنجليزية من صفحة الفحص.</p></div>
<div class="grid"><div class="card"><h3>حالة رفع القوائم</h3><table>{rows_count(imports) or '<tr><td>لا توجد بيانات</td></tr>'}</table></div>
<div class="card"><h3>حالة نتائج الفحص</h3><table>{rows_count(screen) or '<tr><td>لا توجد بيانات</td></tr>'}</table></div>
<div class="card"><h3>مؤشرات المخاطر</h3><table>{rows_count(risk) or '<tr><td>لا توجد بيانات</td></tr>'}</table></div></div>
<div class="card"><h3>سجل تقارير الفحص المصدرة</h3><table><thead><tr><th>#</th><th>رقم التقرير</th><th>التاريخ</th><th>اللغة</th><th>اللون</th><th>حالة القرار</th><th>اسم المفحوص</th><th>نوع المفحوص</th><th>النطاق</th><th>القائمة</th><th>الاسم المطابق</th><th>الدرجة</th><th>الإجراء المطلوب</th><th>SHA256</th><th>PDF</th></tr></thead><tbody>{''.join(rep_rows) or '<tr><td colspan="15">لا توجد تقارير PDF مصدرة بعد</td></tr>'}</tbody></table></div>
"""
    return layout("التقارير", body, "/reports")


_base_do_post_v1031 = AppHandler.do_POST

def _do_post_v1031(self: AppHandler) -> None:
    path = urlparse(self.path).path
    if path == "/screening/report":
        init_db()
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length)
        ctype = self.headers.get("Content-Type", "")
        if ctype.startswith("multipart/form-data"):
            fields, files = parse_multipart({k.lower(): v for k, v in self.headers.items()}, body)
        else:
            fields = parse_qs(body.decode("utf-8", errors="replace"))
        try:
            lang = form_value(fields, "report_language", "ar")
            rid, rnum, pdf_path = create_screening_report(int(form_value(fields, "screening_id", "0")), _real_client_ip(self), lang)
            return self._send(layout("تم إصدار التقرير", f"<div class='success'>تم إصدار تقرير PDF رقم {h(rnum)} باللغة {'الإنجليزية' if lang == 'en' else 'العربية'} وحفظه في سجل التقارير.</div><p><a class='btn' href='/reports/download?id={rid}'>عرض PDF</a> <a class='btn secondary' href='/reports'>سجل التقارير</a></p>", "/reports"))
        except Exception as exc:
            return self._send(layout("خطأ", f"<div class='error'>حدث خطأ: {h(exc)}</div>"), 500)
    return _base_do_post_v1031(self)

AppHandler.do_POST = _do_post_v1031




# ---------------------------------------------------------------------------
# V10.4.1 UI/UX + Controlled Imports Patch
# - Redesigned navigation, official-list controls, settings and operations center
# - Controlled client/project import wizard (CSV/XLSX) with validation and audit
# ---------------------------------------------------------------------------
APP_VERSION = "V10.4.5 - Direct List Update + Strict Validation + Rejected Recovery"

_base_ensure_schema_v1041 = ensure_schema
def ensure_schema(con: sqlite3.Connection) -> None:  # type: ignore[override]
    _base_ensure_schema_v1041(con)
    existing = {r[1] for r in con.execute("PRAGMA table_info(clients)").fetchall()}
    for name, ddl in {
        "client_code": "TEXT",
        "phone": "TEXT",
        "email": "TEXT",
        "address": "TEXT",
    }.items():
        if name not in existing:
            con.execute(f"ALTER TABLE clients ADD COLUMN {name} {ddl}")
    con.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_clients_client_code ON clients(client_code) WHERE client_code IS NOT NULL")
    con.execute("""CREATE TABLE IF NOT EXISTS data_import_logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, import_type TEXT NOT NULL,
        filename TEXT NOT NULL, file_sha256 TEXT NOT NULL, total_rows INTEGER NOT NULL DEFAULT 0,
        clients_created INTEGER NOT NULL DEFAULT 0, clients_updated INTEGER NOT NULL DEFAULT 0,
        matters_created INTEGER NOT NULL DEFAULT 0, skipped_rows INTEGER NOT NULL DEFAULT 0,
        failed_rows INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL, details_json TEXT, created_by TEXT
    )""")
    # Generate permanent six-digit client accounts for existing records.
    rows = con.execute("SELECT id FROM clients WHERE client_code IS NULL OR client_code='' ORDER BY id").fetchall()
    for r in rows:
        con.execute("UPDATE clients SET client_code=? WHERE id=?", (f"{int(r['id']):06d}", int(r['id'])))


def _client_code_for_id(con: sqlite3.Connection, client_id: int) -> str:
    row = con.execute("SELECT client_code FROM clients WHERE id=?", (client_id,)).fetchone()
    return (row[0] if row and row[0] else f"{client_id:06d}")


def _next_client_project_number(con: sqlite3.Connection, client_id: int) -> str:
    code = _client_code_for_id(con, client_id)
    rows = con.execute("SELECT matter_number FROM matters WHERE client_id=?", (client_id,)).fetchall()
    nums = []
    for r in rows:
        m = re.search(r"\.(\d{6})$", str(r[0] or ""))
        if m: nums.append(int(m.group(1)))
    return f"{code}.{(max(nums) + 1 if nums else 1):06d}"


_base_create_matter_v1041 = create_matter
def create_matter(fields: Dict[str, List[str]], ip: str = "") -> int:  # type: ignore[override]
    # Enforce client-account.project-account numbering if the user leaves it blank.
    if not form_value(fields, "matter_number"):
        cid = int(form_value(fields, "client_id", "0"))
        with db() as con:
            ensure_schema(con)
            generated = _next_client_project_number(con, cid)
        fields = dict(fields)
        fields["matter_number"] = [generated]
    return _base_create_matter_v1041(fields, ip)


_base_layout_v1041 = layout
def layout(title: str, body: str, active: str = "") -> bytes:  # type: ignore[override]
    raw = _base_layout_v1041(title, body, active).decode("utf-8")
    nav = f'''<nav class="main-nav" aria-label="القائمة الرئيسية">
      <a class="{'active' if active == '/' else ''}" href="/">الرئيسية</a>
      <div class="dropdown"><a class="{'active' if active in {'/clients','/matters','/data-import'} else ''}" href="/clients">إدارة العملاء</a><div class="dropdown-content"><a href="/clients">العملاء</a><a href="/matters">المشروعات / القضايا</a><a href="/data-import">استيراد العملاء والمشروعات</a></div></div>
      <div class="dropdown"><a class="{'active' if active in {'/quick_screen','/screenings','/lists','/compliance'} else ''}" href="/compliance">الامتثال</a><div class="dropdown-content"><a href="/quick_screen">الفحص السريع</a><a href="/screenings">الفحص والتطابقات</a><a href="/lists">القوائم وضوابطها</a><a href="/compliance">لوحة الامتثال</a></div></div>
      <a class="{'active' if active == '/reports' else ''}" href="/reports">التقارير</a>
      <div class="dropdown"><a class="{'active' if active in {'/audit','/production','/settings'} else ''}" href="/production">الإدارة</a><div class="dropdown-content"><a href="/audit">سجل التدقيق</a><a href="/production">مركز التحكم والصيانة</a><a href="/settings">الإعدادات</a></div></div>
    </nav>'''
    raw = re.sub(r"<nav>.*?</nav>", nav, raw, count=1, flags=re.S)
    css = r'''
.main-nav{position:sticky;top:43px;z-index:800;align-items:center;justify-content:flex-start;direction:rtl;width:100%;overflow:visible!important;box-shadow:0 3px 10px rgba(15,23,42,.12);padding-right:max(22px,calc((100vw - 1340px)/2 + 22px));padding-left:22px}
.main-nav>a,.main-nav .dropdown>a{min-width:118px;text-align:center}
.main-nav .dropdown{position:relative;display:inline-flex;overflow:visible!important;padding-bottom:0}
.main-nav .dropdown-content{display:none;position:absolute;right:0;top:100%;margin-top:0;background:#fff;min-width:270px;border:2px solid var(--line);border-radius:0 0 12px 12px;box-shadow:0 12px 30px rgba(0,0,0,.22);z-index:99999;padding:8px;overflow:visible!important}
.main-nav .dropdown-content:before{content:"";position:absolute;right:0;left:0;top:-8px;height:8px;background:transparent}
.main-nav .dropdown:hover>.dropdown-content,.main-nav .dropdown:focus-within>.dropdown-content{display:block}
.main-nav .dropdown-content:hover{display:block}
.main-nav .dropdown-content a{display:block;width:100%;margin:4px 0;text-align:right;white-space:nowrap}
header,.env-banner{overflow:visible!important}
.page-toolbar{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 18px}.page-toolbar a{background:#e2e8f0;color:#0f172a;padding:9px 13px;border-radius:9px;text-decoration:none;font-weight:900;border:1px solid #94a3b8}.page-toolbar a:hover{background:#dbeafe}
.section-title{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}.muted-panel{background:#f8fafc;border:1px solid #cbd5e1;border-radius:12px;padding:12px}.status-dot{display:inline-block;width:11px;height:11px;border-radius:50%;margin-left:6px}.dot-ok{background:#059669}.dot-warn{background:#d97706}.dot-bad{background:#dc2626}.control-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.control-row .btn,.control-row button{margin-top:0;padding:8px 11px}.list-card{display:flex;flex-direction:column;min-height:350px}.list-card .list-meta{display:grid;grid-template-columns:120px 1fr;gap:0;border:1px solid #cbd5e1;border-radius:10px;overflow:hidden;margin:10px 0}.list-card .list-meta b,.list-card .list-meta span{padding:8px;border-bottom:1px solid #cbd5e1}.list-card .list-meta b{background:#eff6ff}.list-card .actions{margin-top:auto}.tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}.tabs a{padding:9px 13px;border-radius:999px;background:#e2e8f0;text-decoration:none;color:#0f172a;font-weight:900}.table-wrap{overflow:auto;max-width:100%}.health-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}.health-item{border:1px solid #cbd5e1;border-radius:13px;padding:14px;background:#f8fafc}.health-item strong{display:block;margin-bottom:5px}.danger-zone{border-color:#fca5a5;background:#fff1f2}.import-steps{counter-reset:step}.import-step{position:relative;padding-right:48px;margin:14px 0}.import-step:before{counter-increment:step;content:counter(step);position:absolute;right:0;top:0;width:34px;height:34px;border-radius:50%;background:#065f46;color:white;display:grid;place-items:center;font-weight:900}
.official-lists-stack{display:flex;flex-direction:column;gap:12px}.official-list-row{display:grid;grid-template-columns:minmax(260px,1.15fr) minmax(330px,1.5fr) minmax(340px,1.35fr);gap:16px;align-items:center;border:1px solid #94a3b8;border-radius:14px;padding:16px;background:#fff;box-shadow:0 3px 10px rgba(15,23,42,.08)}.official-list-row h3{margin:0 0 4px}.official-list-meta{display:grid;grid-template-columns:1fr 1fr;gap:8px 14px;font-size:.94rem}.official-list-meta span{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:7px}.official-list-actions{display:flex;flex-direction:column;gap:10px}.inline-list-upload{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:end;background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:10px}.inline-list-upload label{grid-column:1/-1;margin:0}.inline-list-upload input[type=file]{margin:0;min-width:0}.inline-list-upload button{margin:0;white-space:nowrap}.template-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}.template-card{display:flex;flex-direction:column;gap:8px;border:2px solid #a7f3d0;border-radius:14px;padding:16px;background:#f0fdf4;text-decoration:none;color:#0f172a}.template-card strong{font-size:1.08rem}.template-card b{color:#065f46}.template-card:hover{border-color:#047857;box-shadow:0 5px 16px rgba(4,120,87,.16)}
@media(max-width:1050px){.official-list-row{grid-template-columns:1fr}.official-list-actions{border-top:1px solid #e2e8f0;padding-top:12px}}
@media(max-width:760px){body{font-size:15px}main{padding:12px}.main-nav{justify-content:flex-start;overflow-x:auto!important;overflow-y:visible!important;flex-wrap:nowrap;padding-right:12px;padding-left:12px}.main-nav>a,.main-nav .dropdown>a{min-width:max-content}.main-nav .dropdown-content{position:fixed;top:auto;right:12px;left:12px;min-width:0;max-height:65vh;overflow-y:auto!important;border-radius:12px}.grid{grid-template-columns:1fr}.list-card .list-meta{grid-template-columns:100px 1fr}.inline-list-upload{grid-template-columns:1fr}.inline-list-upload button{width:100%}}
'''
    raw = raw.replace("</style>", css + "</style>")
    if title == "الإعدادات":
        raw = raw.replace("<main>", "<main><div class='page-toolbar'><a href='#company'>إعدادات المكتب</a><a href='#client-types'>أنواع العملاء</a><a href='#service-types'>أنواع الخدمات</a><a href='#users'>المستخدمون والصلاحيات</a></div>", 1)
    return raw.encode("utf-8")


def official_list_cards() -> str:  # type: ignore[override]
    rows=[]
    for src in OFFICIAL_LIST_SOURCES:
        ext = Path(urlparse(src["download_url"]).path).suffix.upper().lstrip(".") or "WEB"
        rows.append(f'''<article class="official-list-row">
          <div class="official-list-title">
            <div class="section-title"><h3>{h(src["name_ar"])}</h3><span class="badge ok"><span class="status-dot dot-ok"></span>مصدر معتمد</span></div>
            <div class="small" dir="ltr">{h(src["name_en"])}</div>
          </div>
          <div class="official-list-meta">
            <span><b>الكود:</b> <span dir="ltr">{h(src["code"])}</span></span>
            <span><b>التصنيف:</b> {h(src["list_type"])}</span>
            <span><b>الصيغة:</b> {h(ext)}</span>
            <span><b>الملاحظة:</b> {h(src.get("notes", ""))}</span>
          </div>
          <div class="official-list-actions">
            <div class="control-row">
              <a class="btn secondary" target="_blank" rel="noopener" href="{h(src.get("page_url", src["download_url"]))}">صفحة المصدر</a>
              <a class="btn" target="_blank" rel="noopener" href="{h(src["download_url"])}">تنزيل</a>
              <a class="btn warn" href="#list-control">الضوابط</a>
            </div>
            <form method="post" action="/lists/upload" enctype="multipart/form-data" class="inline-list-upload">
              <input type="hidden" name="list_name" value="{h(src["code"])}">
              <input type="hidden" name="list_type" value="{h(src["list_type"])}">
              <input type="hidden" name="source_url" value="{h(src["download_url"])}">
              <label>رفع ملف القائمة</label>
              <input required type="file" name="list_file" accept=".csv,.xlsx,.xls,.xml,.html,.htm,.pdf,.txt">
              <button>رفع وتشغيل المدقق</button>
            </form>
          </div>
        </article>''')
    return "<div class='official-lists-stack'>"+"".join(rows)+"</div>"


def lists_page(message: str = "") -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        logs=con.execute("SELECT * FROM sanctions_import_logs ORDER BY id DESC LIMIT 60").fetchall()
        total=con.execute("SELECT COUNT(*) FROM sanctions_entries WHERE active=1").fetchone()[0]
        last_ok=con.execute("SELECT created_at FROM sanctions_import_logs WHERE status IN ('success','partial_success') ORDER BY id DESC LIMIT 1").fetchone()
    msg=f"<div class='success'>{h(message)}</div>" if message else ""
    opts="".join(f"<option value='{h(x['code'])}' data-url='{h(x['download_url'])}' data-type='{h(x['list_type'])}'>{h(x['name_ar'])}</option>" for x in OFFICIAL_LIST_SOURCES)
    rows=[]
    for l in logs:
        rows.append(f"<tr><td>{l['id']}</td><td dir='auto'>{h(l['list_name'])}</td><td>{h(l['created_at'])}</td><td dir='auto'>{h(l['filename'])}</td><td>{l['total_records']}</td><td>{l['success_count']}</td><td>{l['failed_count']}</td><td>{l['duplicate_count']}</td><td>{badge_status(l['status'])}</td><td><details><summary>التفاصيل</summary>{format_import_errors(l['error_details_json'],12)}</details></td></tr>")
    body=f'''
<div class="card"><div class="section-title"><div><h2>القوائم وضوابط الاستيراد</h2><p class="small">رفع يدوي منضبط، تحقق قبل الاعتماد، سجل كامل، وعدم تعطيل آخر نسخة سليمة عند فشل الملف الجديد.</p></div><div class="control-row"><a class="btn" href="#upload-list">رفع قائمة</a><a class="btn secondary" href="#validation-log">سجل الرفع</a></div></div>{msg}</div>
<div class="health-grid"><div class="health-item"><strong>السجلات النشطة</strong><div class="num">{total}</div></div><div class="health-item"><strong>آخر رفع ناجح</strong><div>{h(last_ok[0] if last_ok else 'لا يوجد')}</div></div><div class="health-item"><strong>الاحتفاظ</strong><div>{RETENTION_YEARS} سنوات</div></div><div class="health-item"><strong>البيئة</strong><div>{h(ENV_LABEL_AR)}</div></div></div>
<div class="card"><div class="section-title"><h3>المصادر الرسمية</h3><span class="small">زر الرفع موجود داخل كل بطاقة بالقرب من اسم القائمة</span></div>{official_list_cards()}</div>
<div class="card" id="list-control"><h3>عنصر الضبط Control</h3><div class="grid"><div><label>سياسة التفعيل</label><select><option>مراجعة واعتماد يدوي قبل التفعيل</option><option>تفعيل تلقائي عند نجاح جميع الضوابط</option></select></div><div><label>تنبيه تغير عدد السجلات</label><select><option>10%</option><option>20%</option><option>30%</option></select></div><div><label>الفحص بعد التحديث</label><select><option>إضافة مهمة إعادة فحص تدريجية</option><option>يتطلب تشغيل يدوي</option></select></div><div><label>حماية النسخة السابقة</label><input value="مفعلة دائماً" readonly></div></div><p class="notice">هذه الإعدادات تمثل واجهة الضبط الرقابي. التفعيل الآلي الكامل سيطبق بعد إضافة نظام إصدارات القوائم والتفعيل الذري.</p></div>
<div class="card" id="upload-list"><h3>رفع / تحديث القائمة</h3><form method="post" action="/lists/upload" enctype="multipart/form-data"><div class="grid"><div><label>المصدر الرسمي</label><select id="official_source" onchange="applyOfficialListSelect()"><option value="">-- اختر --</option>{opts}</select></div><div><label>اسم القائمة</label><input id="list_name" required name="list_name"></div><div><label>نوع القائمة</label><select id="list_type" name="list_type"><option value="TF">تمويل الإرهاب</option><option value="PF">تمويل انتشار التسلح</option><option value="NATIONAL">وطنية</option></select></div><div><label>رابط المصدر</label><input id="source_url" name="source_url"></div><div><label>الملف</label><input required type="file" name="list_file" accept=".csv,.xlsx,.xls,.xml,.html,.htm,.pdf,.txt"></div></div><div class="control-row"><button>رفع وتشغيل المدقق</button><a class="btn secondary" href="/templates/sanctions_import_template.xlsx">قالب Excel</a><a class="btn secondary" href="/templates/sanctions_import_template.csv">قالب CSV</a></div></form></div>
<div class="card" id="validation-log"><h3>سجل التحقق والرفع</h3><div class="table-wrap"><table><thead><tr><th>#</th><th>القائمة</th><th>التاريخ</th><th>الملف</th><th>الخام</th><th>المقبول</th><th>الفاشل</th><th>المكرر</th><th>الحالة</th><th>التفاصيل</th></tr></thead><tbody>{''.join(rows) or '<tr><td colspan="10">لا توجد عمليات</td></tr>'}</tbody></table></div></div>
<script>function useOfficialList(c,u,t){{document.getElementById('list_name').value=c;document.getElementById('source_url').value=u;document.getElementById('list_type').value=t;document.getElementById('upload-list').scrollIntoView({{behavior:'smooth'}})}}function applyOfficialListSelect(){{var s=document.getElementById('official_source'),o=s.options[s.selectedIndex];if(o&&o.value)useOfficialList(o.value,o.dataset.url||'',o.dataset.type||'TF')}}</script>'''
    return layout("القوائم",body,"/lists")


def production_page(message: str = "") -> bytes:  # type: ignore[override]
    key_path=get_or_create_master_key(); msg=f"<div class='success'>{h(message)}</div>" if message else ""
    with db() as con:
        ensure_schema(con)
        integrity=con.execute("PRAGMA integrity_check").fetchone()[0]
        clients_n=con.execute("SELECT COUNT(*) FROM clients").fetchone()[0]
        matters_n=con.execute("SELECT COUNT(*) FROM matters").fetchone()[0]
        lists_n=con.execute("SELECT COUNT(*) FROM sanctions_entries WHERE active=1").fetchone()[0]
        last_run=con.execute("SELECT created_at,status FROM continuous_screening_runs ORDER BY id DESC LIMIT 1").fetchone()
    backups=list(BACKUP_DIR.glob('*.zip')) if BACKUP_DIR.exists() else []
    last_backup=max(backups,key=lambda x:x.stat().st_mtime).name if backups else "لا توجد نسخة"
    body=f'''
<div class="card"><div class="section-title"><div><h2>مركز التحكم والصيانة</h2><p class="small">معلومات تشغيلية مختصرة للمستخدم، مع إخفاء المسارات والمفاتيح الحساسة عن العرض الرئيسي.</p></div><span class="badge {'ok' if integrity=='ok' else 'danger'}">حالة النظام: {'جيدة' if integrity=='ok' else 'تحتاج مراجعة'}</span></div>{msg}</div>
<div class="health-grid"><div class="health-item"><strong><span class="status-dot {'dot-ok' if integrity=='ok' else 'dot-bad'}"></span>قاعدة البيانات</strong><div>{'متصلة وسليمة' if integrity=='ok' else h(integrity)}</div></div><div class="health-item"><strong><span class="status-dot dot-ok"></span>مفتاح التشفير</strong><div>صالح وموجود</div></div><div class="health-item"><strong>آخر نسخة احتياطية</strong><div dir="auto">{h(last_backup)}</div></div><div class="health-item"><strong>آخر فحص دوري</strong><div>{h(last_run['created_at'] if last_run else 'لم يتم التشغيل')}</div></div></div>
<div class="grid"><section class="card"><h3>صحة النظام</h3><table><tr><th>الإصدار</th><td>{h(APP_VERSION)}</td></tr><tr><th>البيئة</th><td>{h(ENV_LABEL_AR)}</td></tr><tr><th>العملاء</th><td>{clients_n}</td></tr><tr><th>المشروعات</th><td>{matters_n}</td></tr><tr><th>سجلات القوائم</th><td>{lists_n}</td></tr><tr><th>مدة الحفظ</th><td>{RETENTION_YEARS} سنوات</td></tr></table></section>
<section class="card"><h3>النسخ الاحتياطي والصيانة</h3><form method="post" action="/production/backup"><button>إنشاء نسخة احتياطية</button></form><form method="post" action="/production/maintenance"><button class="btn secondary">تشغيل فحص السلامة</button></form><p class="small">لا يتم عرض مسار قاعدة البيانات أو مسار مفتاح التشفير في الواجهة العامة.</p></section>
<section class="card"><h3>الفحص الدوري</h3><p>يعمل على دفعات مع حفظ النتائج في سجل مستقل.</p><form method="post" action="/production/daily_screening"><button class="btn warn">تشغيل الفحص الآن</button></form><div class="muted-panel">الوضع المستهدف: Queue + Batch + Checkpoint لمنع تأثير الفحص الكبير على المستخدمين.</div></section>
<section class="card"><h3>فحص الجاهزية</h3><ul><li>قاعدة البيانات: {'ناجح' if integrity=='ok' else 'فشل'}</li><li>مفتاح التشفير: {'ناجح' if key_path.exists() else 'فشل'}</li><li>مجلد النسخ: {'ناجح' if BACKUP_DIR.exists() else 'يُنشأ عند أول نسخة'}</li><li>الفصل بين البيئات: {h(APP_ENV)}</li></ul><a class="btn secondary" href="/api/health">عرض Health API</a></section></div>
<div class="card danger-zone"><h3>التفاصيل الفنية المقيدة</h3><details><summary>عرض معلومات مدير النظام</summary><p>قاعدة البيانات: <code dir="ltr">{h(DB_PATH.name)}</code></p><p>مفتاح التشفير: موجود داخل مجلد بيانات البيئة وغير معروض كاملاً.</p></details></div>'''
    return layout("مركز التحكم والصيانة",body,"/production")


def _normalize_header(v: Any) -> str:
    return re.sub(r"[\s_\-]+","",str(v or "").strip().lower())

_IMPORT_ALIASES={
 "legal_name":["اسمالعميل","الاسمالعربي","الاسمالانجليزي","clientname","legalname","name"],
 "registration_number":["السجلالتجاري","رقمالسجلالتجاري","crnumber","registrationnumber"],
 "id_number":["رقمالهوية","رقمالاقامة","رقمجوازالسفر","passportnumber","idnumber"],
 "phone":["الهاتف","رقمالهاتف","الجوال","mobile","phone"],
 "email":["البريدالالكتروني","email"], "country":["الدولة","country"], "nationality":["الجنسية","nationality"],
 "address":["العنوان","address"],
 "client_type":["نوعالعميل","clienttype"], "project_title":["اسمالمشروع","المشروع","projectname","mattertitle"],
 "service_type":["نوعالخدمة","servicetype"], "description":["وصفالمشروع","description"],
}

def _mapped(row: Dict[str,Any], key: str) -> str:
    normalized={_normalize_header(k):str(v or '').strip() for k,v in row.items()}
    for a in _IMPORT_ALIASES[key]:
        if a in normalized and normalized[a]: return normalized[a]
    return ""

def _read_tabular(filename: str, content: bytes) -> List[Dict[str,Any]]:
    ext=Path(filename).suffix.lower()
    if ext=='.csv':
        text=decode_import_text(content); return list(csv.DictReader(io.StringIO(text)))
    if ext in {'.xlsx','.xlsm'}:
        from openpyxl import load_workbook
        wb=load_workbook(io.BytesIO(content),read_only=True,data_only=True); out=[]
        for ws in wb.worksheets:
            rows=ws.iter_rows(values_only=True); headers=next(rows,None)
            if not headers: continue
            for vals in rows:
                if not any(v not in (None,'') for v in vals): continue
                out.append({str(headers[i] or f'col_{i+1}'): vals[i] if i<len(vals) else '' for i in range(len(headers))})
        return out
    raise ValueError('الصيغة المدعومة للاستيراد: CSV أو XLSX')


def import_clients_projects(fields: Dict[str,List[str]], files: Dict[str,Tuple[str,bytes]], ip: str='') -> str:
    filename,content=files.get('data_file',('',b''))
    if not filename or not content: raise ValueError('اختر ملف الاستيراد')
    rows=_read_tabular(filename,content); stats={'clients_created':0,'clients_updated':0,'matters_created':0,'skipped':0,'failed':0}; errors=[]
    with db() as con:
        ensure_schema(con)
        for n,row in enumerate(rows,start=2):
            try:
                name=_mapped(row,'legal_name'); reg=_mapped(row,'registration_number'); ident=_mapped(row,'id_number')
                project=_mapped(row,'project_title')
                if not name: stats['skipped']+=1; errors.append({'row':n,'error':'اسم العميل مفقود'}); continue
                found=None
                if reg: found=con.execute("SELECT * FROM clients WHERE registration_number=?",(reg,)).fetchone()
                if not found and ident: found=con.execute("SELECT * FROM clients WHERE id_number=?",(ident,)).fetchone()
                if not found: found=con.execute("SELECT * FROM clients WHERE lower(legal_name)=lower(?)",(name,)).fetchone()
                if found:
                    cid=int(found['id']); con.execute("UPDATE clients SET updated_at=?,phone=COALESCE(NULLIF(?,''),phone),email=COALESCE(NULLIF(?,''),email),country=COALESCE(NULLIF(?,''),country),nationality=COALESCE(NULLIF(?,''),nationality) WHERE id=?",(now_iso(),_mapped(row,'phone'),_mapped(row,'email'),_mapped(row,'country'),_mapped(row,'nationality'),cid)); stats['clients_updated']+=1
                else:
                    cur=con.execute("INSERT INTO clients(created_at,updated_at,client_type,legal_name,id_number,registration_number,country,nationality,risk_level,status,notes,phone,email,address) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(now_iso(),now_iso(),_mapped(row,'client_type') or 'company',name,ident,reg,_mapped(row,'country'),_mapped(row,'nationality'),'normal','draft','Imported through controlled wizard',_mapped(row,'phone'),_mapped(row,'email'),_mapped(row,'address'))); cid=int(cur.lastrowid); con.execute("UPDATE clients SET client_code=? WHERE id=?",(f'{cid:06d}',cid)); stats['clients_created']+=1
                if project and form_value(fields,'import_type','clients_projects') != 'clients':
                    exists=con.execute("SELECT 1 FROM matters WHERE client_id=? AND lower(title)=lower(?)",(cid,project)).fetchone()
                    if not exists:
                        _mc=con.execute("INSERT INTO matters(created_at,updated_at,client_id,matter_number,title,service_type,description,status) VALUES(?,?,?,?,?,?,?,?)",(now_iso(),now_iso(),cid,_next_client_project_number(con,cid),project,_mapped(row,'service_type'),_mapped(row,'description'),'draft')); con.execute("INSERT OR IGNORE INTO matter_clients(created_at,matter_id,client_id,role) VALUES(?,?,?, 'lead')",(now_iso(),int(_mc.lastrowid),cid)); stats['matters_created']+=1
            except Exception as exc:
                stats['failed']+=1; errors.append({'row':n,'error':str(exc)[:250]})
        # V10.5.6 fix: الحالة تعكس الفشل الفعلي فقط؛ الصفوف المتجاوزة لا تجعل العملية "جزئية".
        status='success' if stats['failed']==0 else ('partial_success' if stats['clients_created']+stats['clients_updated'] else 'failed')
        con.execute("INSERT INTO data_import_logs(created_at,import_type,filename,file_sha256,total_rows,clients_created,clients_updated,matters_created,skipped_rows,failed_rows,status,details_json,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(now_iso(),form_value(fields,'import_type','clients_projects'),filename,hashlib.sha256(content).hexdigest(),len(rows),stats['clients_created'],stats['clients_updated'],stats['matters_created'],stats['skipped'],stats['failed'],status,json.dumps(errors[:500],ensure_ascii=False),ip)); audit(con,'controlled_clients_projects_import','data_import',0,f'{filename}; {stats}',ip); con.commit()
    return f"تمت معالجة {len(rows)} صف: عملاء جدد {stats['clients_created']}، تحديث عملاء {stats['clients_updated']}، مشروعات جديدة {stats['matters_created']}، متجاوز {stats['skipped']}، فشل {stats['failed']}."


def data_import_page(message: str='') -> bytes:
    with db() as con:
        ensure_schema(con); logs=con.execute("SELECT * FROM data_import_logs ORDER BY id DESC LIMIT 30").fetchall()
    msg=f"<div class='success'>{h(message)}</div>" if message else ''
    rows=''.join(f"<tr><td>{r['id']}</td><td>{h(r['created_at'])}</td><td dir='auto'>{h(r['filename'])}</td><td>{r['total_rows']}</td><td>{r['clients_created']}</td><td>{r['clients_updated']}</td><td>{r['matters_created']}</td><td>{r['skipped_rows']}</td><td>{r['failed_rows']}</td><td>{badge_status(r['status'])}</td></tr>" for r in logs)
    body=f'''<div class="card"><div class="section-title"><div><h2>استيراد العملاء والمشروعات</h2><p class="notice">ابدأ بتنزيل القالب المناسب، عبّئ البيانات دون تغيير أسماء الأعمدة، ثم ارفع الملف للتحقق والاستيراد.</p></div><div class="control-row"><a class="btn" href="/templates/clients_import_template.xlsx">تنزيل قالب العملاء</a><a class="btn secondary" href="/templates/clients_projects_import_template.xlsx">تنزيل قالب العملاء والمشروعات</a></div></div>{msg}</div>
<div class="card"><div class="import-step"><h3>1. تنزيل القالب</h3><div class="template-grid"><a class="template-card" href="/templates/clients_import_template.xlsx"><strong>قالب العملاء فقط</strong><span>البيانات الأساسية للعميل دون مشروعات.</span><b>تنزيل Excel</b></a><a class="template-card" href="/templates/clients_projects_import_template.xlsx"><strong>قالب العملاء والمشروعات</strong><span>بيانات العميل مع اسم المشروع ونوع الخدمة والوصف.</span><b>تنزيل Excel</b></a></div></div>
<div class="import-step"><h3>2. رفع الملف</h3><form method="post" action="/data-import" enctype="multipart/form-data"><div class="grid"><div><label>نوع الاستيراد</label><select name="import_type"><option value="clients_projects">عملاء ومشروعات</option><option value="clients">عملاء فقط</option></select></div><div><label>ملف CSV / XLSX</label><input required type="file" name="data_file" accept=".csv,.xlsx"></div></div><button>تحقق واستيراد</button></form></div>
<div class="import-step"><h3>3. الأعمدة المدعومة</h3><p>اسم العميل، الاسم العربي، الاسم الإنجليزي، نوع العميل، رقم السجل التجاري، رقم الهوية/الإقامة/الجواز، الجنسية، الدولة، الهاتف، البريد الإلكتروني، العنوان، الملاحظات، اسم المشروع، نوع الخدمة، وصف المشروع.</p></div>
<div class="import-step"><h3>4. ضوابط الاستيراد</h3><ul><li>لا تغيّر أسماء الأعمدة الموجودة في القالب.</li><li>احذف الصف التجريبي قبل الرفع.</li><li>لا يستبدل النظام البيانات الحالية بقيم فارغة.</li><li>يمنع تكرار العميل بالسجل التجاري ثم الهوية/الجواز ثم الاسم.</li><li>يصدر سجل تدقيق وبصمة SHA-256 للملف.</li><li>اختبر الملف في UAT قبل Production.</li></ul></div></div>
<div class="card"><h3>سجل عمليات الاستيراد</h3><div class="table-wrap"><table><thead><tr><th>#</th><th>التاريخ</th><th>الملف</th><th>الصفوف</th><th>عملاء جدد</th><th>محدث</th><th>مشروعات</th><th>متجاوز</th><th>فشل</th><th>الحالة</th></tr></thead><tbody>{rows or '<tr><td colspan="10">لا توجد عمليات</td></tr>'}</tbody></table></div></div>'''
    return layout('استيراد العملاء والمشروعات',body,'/data-import')


_base_do_get_v1041=AppHandler.do_GET
def _do_get_v1041(self: AppHandler) -> None:
    if urlparse(self.path).path=='/data-import': init_db(); return self._send(data_import_page())
    return _base_do_get_v1041(self)
AppHandler.do_GET=_do_get_v1041

_base_do_post_v1041=AppHandler.do_POST
def _do_post_v1041(self: AppHandler) -> None:
    if urlparse(self.path).path=='/data-import':
        init_db(); length=int(self.headers.get('Content-Length','0')); body=self.rfile.read(length); fields,files=parse_multipart({k.lower():v for k,v in self.headers.items()},body)
        try: return self._send(data_import_page(import_clients_projects(fields,files,_real_client_ip(self))))
        except Exception as exc: return self._send(data_import_page(f'فشل الاستيراد: {exc}'),500)
    return _base_do_post_v1041(self)
AppHandler.do_POST=_do_post_v1041


# ===== V10.4.4 robust official-list parsers =====
def _clean_header(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).lower()


def _first_value(raw: Dict[str, Any], names: List[str]) -> str:
    normalized = {_clean_header(k): str(v or "").strip() for k, v in raw.items()}
    for name in names:
        value = normalized.get(_clean_header(name), "")
        if value:
            return value
    return ""


def _official_row(raw: Dict[str, Any], defaults: Dict[str, str], sheet_name: str = "") -> Dict[str, str]:
    row = normalize_import_row(raw, defaults)
    row["full_name"] = row.get("full_name") or _first_value(raw, [
        "Full Name", "Entities Name", "Entity Name", "Vessel Name", "Name", "Listed Name",
        "الاسم الكامل", "اسم الكيان", "اسم السفينة"
    ])
    row["registration_number"] = row.get("registration_number") or _first_value(raw, [
        "Registration Number", "IMO No.", "IMO No", "Commercial Registration", "CR Number"
    ])
    row["id_number"] = row.get("id_number") or _first_value(raw, [
        "Document No.", "Document No", "Passport Number", "National ID", "ID Number"
    ])
    row["nationality"] = row.get("nationality") or _first_value(raw, ["Nationality", "Vessel Flag"])
    row["country"] = row.get("country") or _first_value(raw, ["COB", "Country", "Issuing Country", "Address"])
    note_keys = [
        "Aliases", "Additional info.", "Additional Information", "Owner Name", "Owner information",
        "Link of Terrorism Org.", "DOB", "POB", "Document Type", "Issuing Country", "Address",
        "Designated Date", "Comments", "Remarks"
    ]
    notes=[]
    for key in note_keys:
        value=_first_value(raw,[key])
        if value:
            notes.append(f"{key}: {value}")
    if sheet_name:
        notes.append(f"Source sheet: {sheet_name.strip()}")
    existing=row.get("notes","")
    if existing:
        notes.insert(0,existing)
    row["notes"]=" | ".join(notes)
    return row


def parse_xlsx(content: bytes, defaults: Dict[str, str], filename: str) -> Tuple[List[Dict[str, str]], List[Dict[str, Any]]]:  # type: ignore[override]
    rows: List[Dict[str, str]]=[]; errors: List[Dict[str, Any]]=[]
    try:
        import openpyxl  # type: ignore
        wb=openpyxl.load_workbook(io.BytesIO(content),read_only=True,data_only=True)
    except Exception as exc:
        return [], [{"location":filename,"row":1,"error":f"تعذر قراءة ملف Excel: {exc}"}]
    for ws in wb.worksheets:
        header=None
        for row_no, values in enumerate(ws.iter_rows(values_only=True),start=1):
            vals=["" if v is None else str(v).strip() for v in values]
            while vals and vals[-1]=="": vals.pop()
            if not any(vals): continue
            if header is None:
                header=vals; continue
            raw={header[i] if i < len(header) and header[i] else f"col_{i+1}": vals[i] if i < len(vals) else "" for i in range(max(len(header),len(vals)))}
            row=_official_row(raw,defaults,ws.title)
            if not row.get("full_name"):
                errors.append({"location":f"Sheet {ws.title}","row":row_no,"error":"تعذر تحديد اسم الشخص/الكيان/السفينة","raw":raw}); continue
            row["_location"]=f"Excel-XLSX:sheet:{ws.title}:row:{row_no}"; row["_row"]=str(row_no)
            rows.append(row)
        if header is None:
            errors.append({"location":f"Sheet {ws.title}","row":1,"error":"ورقة فارغة"})
    return rows,errors


def _xml_text(elem: ET.Element, path: str) -> str:
    child=elem.find(path)
    return " ".join(" ".join(child.itertext()).split()) if child is not None else ""


def parse_xml(content: bytes, defaults: Dict[str, str]) -> Tuple[List[Dict[str, str]], List[Dict[str, Any]]]:  # type: ignore[override]
    rows=[]; errors=[]
    try:
        # V10.5.6 fix: تمرير البايتات مباشرة ليحترم المحلل ترويسة ترميز XML، مع مسار احتياطي نصي.
        try:
            root=ET.fromstring(content)
        except ET.ParseError:
            root=ET.fromstring(decode_import_text(content))
    except Exception as exc:
        return [], [{"location":"XML","row":1,"error":f"XML غير صالح: {exc}"}]
    records=[]
    for elem in root.iter():
        tag=elem.tag.split('}')[-1].upper()
        if tag in {'INDIVIDUAL','ENTITY'}:
            records.append((tag,elem))
    for idx,(kind,elem) in enumerate(records,start=1):
        parts=[_xml_text(elem,x) for x in ['FIRST_NAME','SECOND_NAME','THIRD_NAME','FOURTH_NAME']]
        full_name=' '.join(x for x in parts if x).strip()
        original=_xml_text(elem,'NAME_ORIGINAL_SCRIPT')
        if not full_name: full_name=original
        aliases=[]
        alias_tag='INDIVIDUAL_ALIAS' if kind=='INDIVIDUAL' else 'ENTITY_ALIAS'
        for a in elem.findall(alias_tag):
            val=_xml_text(a,'ALIAS_NAME')
            if val: aliases.append(val)
        nationalities=[" ".join(v.itertext()).strip() for v in elem.findall('./NATIONALITY/VALUE') if " ".join(v.itertext()).strip()]
        docs=[]
        doc_tag='INDIVIDUAL_DOCUMENT' if kind=='INDIVIDUAL' else 'ENTITY_DOCUMENT'
        for d in elem.findall(doc_tag):
            num=_xml_text(d,'NUMBER')
            if num: docs.append(num)
        countries=[]
        for c in elem.findall('.//COUNTRY'):
            val=' '.join(c.itertext()).strip()
            if val and val not in countries: countries.append(val)
        notes=[]
        if original and original != full_name: notes.append(f"Original script: {original}")
        if aliases: notes.append("Aliases: " + '; '.join(aliases))
        ref=_xml_text(elem,'REFERENCE_NUMBER')
        if ref: notes.append(f"Reference: {ref}")
        listed=_xml_text(elem,'LISTED_ON')
        if listed: notes.append(f"Listed on: {listed}")
        comments=_xml_text(elem,'COMMENTS1')
        if comments: notes.append("Comments: " + comments)
        if not full_name:
            errors.append({"location":f"XML {kind}","row":idx,"error":"تعذر تحديد الاسم","raw":{"kind":kind,"reference":_xml_text(elem,"REFERENCE_NUMBER"),"original_script":original}}); continue
        row={"full_name":full_name,"id_number":"; ".join(docs),"registration_number":"","nationality":"; ".join(nationalities),"country":"; ".join(countries),"notes":" | ".join(notes),**defaults}
        row["_location"]=f"XML:{kind.lower()}:{idx}"; row["_row"]=str(idx)
        rows.append(row)
    if not rows and not errors:
        errors.append({"location":"XML","row":1,"error":"لم يتم العثور على عناصر INDIVIDUAL أو ENTITY"})
    return rows,errors

# ===== End V10.4.4 parsers =====

# ===== V10.4.5 list governance, direct update and rejected-record recovery =====
_ensure_schema_v1045_base = ensure_schema

def ensure_schema(con: sqlite3.Connection) -> None:  # type: ignore[override]
    _ensure_schema_v1045_base(con)
    existing={r[1] for r in con.execute("PRAGMA table_info(sanctions_import_logs)").fetchall()}
    if "import_method" not in existing:
        con.execute("ALTER TABLE sanctions_import_logs ADD COLUMN import_method TEXT NOT NULL DEFAULT 'manual'")
    if "parent_log_id" not in existing:
        con.execute("ALTER TABLE sanctions_import_logs ADD COLUMN parent_log_id INTEGER")
    con.execute("""CREATE TABLE IF NOT EXISTS sanctions_import_staging(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        log_id INTEGER NOT NULL,
        row_json TEXT NOT NULL,
        row_hash TEXT NOT NULL,
        UNIQUE(log_id,row_hash)
    )""")
    con.commit()


def _save_import_log(con: sqlite3.Connection, *, list_name: str, source_url: str, filename: str,
                     file_sha: str, total: int, success: int, failed: int, dup: int,
                     status: str, errors: List[Dict[str,Any]], import_method: str='manual',
                     parent_log_id: Optional[int]=None) -> int:
    cur=con.execute("""INSERT INTO sanctions_import_logs(
        created_at,list_name,source_url,filename,file_sha256,total_records,success_count,
        failed_count,duplicate_count,status,error_details_json,import_method,parent_log_id)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (now_iso(),list_name,source_url,filename,file_sha,total,success,failed,dup,status,
         json.dumps(errors[:1000],ensure_ascii=False),import_method,parent_log_id))
    return int(cur.lastrowid)


def _activate_complete_list(con: sqlite3.Connection, list_name: str, source_url: str,
                            list_type: str, rows: List[Dict[str,str]]) -> Tuple[int,int]:
    con.execute("UPDATE sanctions_entries SET active=0 WHERE list_name=?",(list_name,))
    inserted=0; reused=0
    for row in rows:
        rh=row_hash(row)
        old=con.execute("SELECT id FROM sanctions_entries WHERE row_hash=?",(rh,)).fetchone()
        notes=(row.get('notes') or '') + ((" | "+row.get('_location','')) if row.get('_location') else '')
        if old:
            con.execute("""UPDATE sanctions_entries SET created_at=?,list_name=?,source_url=?,list_type=?,
                full_name=?,id_number=?,registration_number=?,nationality=?,country=?,notes=?,active=1 WHERE id=?""",
                (now_iso(),list_name,source_url,list_type,row.get('full_name'),row.get('id_number'),
                 row.get('registration_number'),row.get('nationality'),row.get('country'),notes,int(old['id'])))
            reused+=1
        else:
            con.execute("""INSERT INTO sanctions_entries(created_at,list_name,source_url,list_type,full_name,
                id_number,registration_number,nationality,country,notes,row_hash,active)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,1)""",
                (now_iso(),list_name,source_url,list_type,row.get('full_name'),row.get('id_number'),
                 row.get('registration_number'),row.get('nationality'),row.get('country'),notes,rh))
            inserted+=1
    return inserted,reused


def import_sanctions_file(fields: Dict[str,List[str]], files: Dict[str,Tuple[str,bytes]], ip: str='') -> str:  # type: ignore[override]
    list_name=form_value(fields,'list_name','UN_LIST').strip()
    source_url=form_value(fields,'source_url').strip()
    list_type=form_value(fields,'list_type','TF').strip()
    method=form_value(fields,'import_method','manual').strip() or 'manual'
    parent_raw=form_value(fields,'parent_log_id','').strip()
    parent_log_id=int(parent_raw) if parent_raw.isdigit() else None
    filename,content=files.get('list_file',files.get('csv_file',('uploaded.csv',b'')))
    if not filename or not content:
        raise ValueError('لم يتم اختيار ملف أو أن الملف فارغ')
    defaults={'list_name':list_name,'source_url':source_url,'list_type':list_type}
    parsed,errors=parse_sanctions_file(filename,content,defaults)
    with db() as con:
        ensure_schema(con)
        if parent_log_id:
            parent=con.execute("SELECT * FROM sanctions_import_logs WHERE id=?",(parent_log_id,)).fetchone()
            if not parent: raise ValueError('عملية الرفع الأصلية غير موجودة')
            list_name=parent['list_name']; source_url=parent['source_url'] or source_url
            staged=[json.loads(r['row_json']) for r in con.execute("SELECT row_json FROM sanctions_import_staging WHERE log_id=?",(parent_log_id,)).fetchall()]
            parsed=staged+parsed
        unique=[]; seen=set(); internal_dup=0
        for row in parsed:
            if not row.get('full_name'):
                errors.append({'location':row.get('_location',filename),'row':row.get('_row','-'),'error':'الاسم الأساسي مفقود','raw':row})
                continue
            rh=row_hash(row)
            if rh in seen: internal_dup+=1; continue
            seen.add(rh); unique.append(row)
        total=len(unique)+len(errors)+internal_dup
        file_sha=hashlib.sha256(content).hexdigest()
        if errors:
            log_id=_save_import_log(con,list_name=list_name,source_url=source_url,filename=filename,file_sha=file_sha,
                total=total,success=0,failed=len(errors),dup=internal_dup,status='partial_success',errors=errors,
                import_method=method,parent_log_id=parent_log_id)
            for row in unique:
                con.execute("INSERT OR IGNORE INTO sanctions_import_staging(log_id,row_json,row_hash) VALUES(?,?,?)",
                            (log_id,json.dumps(row,ensure_ascii=False),row_hash(row)))
            con.commit()
            return (f"لم تُفعّل القائمة لأن {len(errors)} سجل/صف يحتاج تصحيحاً. "
                    f"تم حفظ {len(unique)} سجلاً صالحاً مؤقتاً دون المساس بالنسخة الفعالة. "
                    f"رقم العملية {log_id}. نزّل السجلات المرفوضة، صححها، ثم ارفعها من سجل الرفع.")
        inserted,reused=_activate_complete_list(con,list_name,source_url,list_type,unique)
        log_id=_save_import_log(con,list_name=list_name,source_url=source_url,filename=filename,file_sha=file_sha,
            total=len(unique),success=len(unique),failed=0,dup=internal_dup,status='success',errors=[],
            import_method=method,parent_log_id=parent_log_id)
        if parent_log_id:
            con.execute("DELETE FROM sanctions_import_staging WHERE log_id=?",(parent_log_id,))
        con.commit()
    return f"تم اعتماد وتفعيل القائمة كاملة: {list_name} | السجلات: {len(unique)} | جديد: {inserted} | معاد تفعيله: {reused} | رقم العملية: {log_id}"


def _infer_download_filename(url: str, content_type: str='') -> str:
    from urllib.parse import urlparse
    name=Path(urlparse(url).path).name
    if name and '.' in name: return name
    ct=(content_type or '').lower()
    if 'xml' in ct: return 'official_list.xml'
    if 'spreadsheet' in ct or 'excel' in ct: return 'official_list.xlsx'
    if 'html' in ct: return 'official_list.html'
    if 'pdf' in ct: return 'official_list.pdf'
    return 'official_list.xml'


def direct_update_list(fields: Dict[str,List[str]], ip: str='') -> str:
    import urllib.request
    list_name=form_value(fields,'list_name').strip(); list_type=form_value(fields,'list_type','TF')
    source_cfg=next((x for x in OFFICIAL_LIST_SOURCES if x.get('code')==list_name), {})
    # V10.5.6 fix (SSRF): التحديث المباشر مقصور على القوائم الرسمية المسجلة في الدليل فقط،
    # ويستخدم دائماً رابط التنزيل الحاكم عبر HTTPS؛ كان بالإمكان تمرير أي رابط (حتى file://)
    # فيقرأ الخادم ملفات محلية أو عناوين داخلية ويخزنها كقائمة عقوبات.
    if not source_cfg.get('download_url'):
        raise ValueError('التحديث المباشر متاح فقط للقوائم الرسمية المسجلة؛ استخدم الرفع اليدوي للملفات الأخرى')
    url=source_cfg['download_url']
    list_type=source_cfg.get('list_type') or list_type
    if not str(url).lower().startswith('https://'):
        raise ValueError('رابط التنزيل الحاكم يجب أن يكون HTTPS')
    req=urllib.request.Request(url,headers={'User-Agent':'LegalTracks-Compliance/10.5.7','Accept':'*/*'})
    try:
        with urllib.request.urlopen(req,timeout=45) as resp:
            content=resp.read(50*1024*1024+1)
            if len(content)>50*1024*1024: raise ValueError('حجم الملف يتجاوز 50 MB')
            content_type=resp.headers.get('Content-Type','')
            filename=_infer_download_filename(resp.geturl(),content_type)
            expected=(source_cfg.get('expected_format') or '').upper()
            head=content[:512].lstrip().lower()
            if expected=='XLSX':
                # XLSX files are ZIP containers and must start with PK. Reject HTML error/login pages.
                if not content.startswith(b'PK'):
                    if head.startswith(b'<!doctype html') or head.startswith(b'<html') or b'<html' in head:
                        raise ValueError('المصدر أعاد صفحة HTML بدلاً من ملف XLSX. تحقق من رابط التنزيل المباشر أو صلاحية الوصول للموقع الرسمي.')
                    raise ValueError('الملف المستلم ليس XLSX صالحاً (توقيع ZIP غير موجود).')
                filename='slistEN.xlsx'
            elif expected=='XML':
                if b'<' not in head:
                    raise ValueError('الملف المستلم ليس XML صالحاً.')
    except Exception as exc:
        with db() as con:
            ensure_schema(con)
            _save_import_log(con,list_name=list_name,source_url=url,filename='direct-download',file_sha='',total=0,
                success=0,failed=1,dup=0,status='failed',errors=[{'location':'المصدر الرسمي','row':'-','error':str(exc)[:500]}],import_method='direct')
            con.commit()
        raise ValueError(f'فشل التنزيل المباشر: {exc}')
    ff={'list_name':[list_name],'source_url':[url],'list_type':[list_type],'import_method':['direct']}
    return import_sanctions_file(ff,{'list_file':(filename,content)},ip)


def _list_state(con: sqlite3.Connection, code: str) -> Dict[str,Any]:
    last=con.execute("SELECT * FROM sanctions_import_logs WHERE list_name=? ORDER BY id DESC LIMIT 1",(code,)).fetchone()
    last_ok=con.execute("SELECT * FROM sanctions_import_logs WHERE list_name=? AND status='success' ORDER BY id DESC LIMIT 1",(code,)).fetchone()
    count=con.execute("SELECT COUNT(*) FROM sanctions_entries WHERE list_name=? AND active=1",(code,)).fetchone()[0]
    return {'last':last,'last_ok':last_ok,'count':count}


def official_list_cards() -> str:  # type: ignore[override]
    rows=[]
    with db() as con:
        ensure_schema(con)
        for src in OFFICIAL_LIST_SOURCES:
            st=_list_state(con,src['code']); last=st['last']; ok=st['last_ok']
            state='محدثة ونشطة' if ok else ('فشل آخر تحديث' if last and last['status']=='failed' else 'لم يتم الرفع')
            method='مباشر' if last and last['import_method']=='direct' else ('يدوي' if last else '-')
            last_date=ok['created_at'] if ok else '-'
            ext=src.get('expected_format') or Path(src['download_url']).suffix.upper().lstrip('.') or ('XML' if '/xml/' in src['download_url'] else 'WEB')
            rows.append(f'''<article class="official-list-row">
              <div class="official-list-main"><h3>{h(src['name_ar'])}</h3><p class="small" dir="auto">{h(src['name_en'])}</p>
                <div class="official-list-meta"><span><b>الحالة:</b> {h(state)}</span><span><b>السجلات الفعالة:</b> {st['count']}</span><span><b>آخر تحديث:</b> {h(last_date)}</span><span><b>طريقة التحديث:</b> {h(method)}</span><span><b>الكود:</b> <span dir="ltr">{h(src['code'])}</span></span><span><b>الصيغة:</b> {h(ext)}</span></div></div>
              <div class="official-list-actions"><div class="control-row"><a class="btn secondary" target="_blank" rel="noopener" href="{h(src.get('page_url',src['download_url']))}">المصدر</a><a class="btn" target="_blank" rel="noopener" href="{h(src['download_url'])}">تنزيل</a>
              <form method="post" action="/lists/direct-update" enctype="multipart/form-data" class="inline-form"><input type="hidden" name="list_name" value="{h(src['code'])}"><input type="hidden" name="list_type" value="{h(src['list_type'])}"><input type="hidden" name="source_url" value="{h(src['download_url'])}"><button class="btn warn">تحديث مباشر</button></form></div>
              <form method="post" action="/lists/upload" enctype="multipart/form-data" class="inline-list-upload"><input type="hidden" name="list_name" value="{h(src['code'])}"><input type="hidden" name="list_type" value="{h(src['list_type'])}"><input type="hidden" name="source_url" value="{h(src['download_url'])}"><input type="hidden" name="import_method" value="manual"><label>رفع ملف القائمة</label><input required type="file" name="list_file" accept=".csv,.xlsx,.xls,.xml,.html,.htm,.pdf,.txt"><button>تحقق واعتماد</button></form></div></article>''')
    return "<div class='official-lists-stack'>"+''.join(rows)+"</div>"


def _rejected_actions(log: sqlite3.Row) -> str:
    if not log['failed_count']:
        return "<span class='small'>لا توجد سجلات مرفوضة</span>"
    list_type=next((x.get('list_type','TF') for x in OFFICIAL_LIST_SOURCES if x.get('code')==log['list_name']),'TF')
    return f'''<div class="control-row"><a class="btn secondary" href="/lists/rejected.csv?id={log['id']}">تنزيل المرفوض CSV</a></div>
    <form method="post" action="/lists/upload" enctype="multipart/form-data" class="inline-list-upload">
      <input type="hidden" name="parent_log_id" value="{log['id']}"><input type="hidden" name="list_name" value="{h(log['list_name'])}"><input type="hidden" name="source_url" value="{h(log['source_url'] or '')}"><input type="hidden" name="list_type" value="{h(list_type)}"><input type="hidden" name="import_method" value="retry_corrected">
      <label>رفع السجلات المصححة فقط</label><input required type="file" name="list_file" accept=".csv,.xlsx,.xml"><button>إعادة المحاولة والدمج</button></form>'''

def lists_page(message: str='') -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con); logs=con.execute("SELECT * FROM sanctions_import_logs ORDER BY id DESC LIMIT 80").fetchall(); total=con.execute("SELECT COUNT(*) FROM sanctions_entries WHERE active=1").fetchone()[0]
    msg=f"<div class='success'>{h(message)}</div>" if message else ''
    log_rows=[]
    for l in logs:
        details=format_import_errors(l['error_details_json'],30) if l['failed_count'] else '<span class="small">لا توجد أخطاء</span>'
        log_rows.append(f'''<tr><td>{l['id']}</td><td dir="auto">{h(l['list_name'])}</td><td>{h(l['created_at'])}</td><td>{h(l['import_method'])}</td><td dir="auto">{h(l['filename'])}</td><td>{l['total_records']}</td><td>{l['success_count']}</td><td>{l['failed_count']}</td><td>{l['duplicate_count']}</td><td>{badge_status(l['status'])}</td><td><details><summary>التفاصيل والإجراء</summary>{details}{_rejected_actions(l)}</details></td></tr>''')
    body=f'''<div class="card"><div class="section-title"><div><h2>القوائم والتحقق والاعتماد</h2><p class="small">يجب استيراد القائمة كاملة. عند وجود فشل جزئي لا تتغير النسخة الفعالة، وتُحفظ السجلات الصالحة مؤقتاً حتى تصحيح المرفوض وإعادة المحاولة.</p></div><a class="btn secondary" href="#validation-log">سجل الرفع</a></div>{msg}</div>
    <div class="health-grid"><div class="health-item"><strong>إجمالي السجلات الفعالة</strong><div class="num">{total}</div></div><div class="health-item"><strong>سياسة الاعتماد</strong><div>اكتمال 100%</div></div><div class="health-item"><strong>الحماية</strong><div>آخر نسخة سليمة لا تتأثر بالفشل</div></div><div class="health-item"><strong>البيئة</strong><div>{h(ENV_LABEL_AR)}</div></div></div>
    <div class="card"><div class="section-title"><h3>المصادر الرسمية</h3><span class="small">رفع يدوي أو تحديث مباشر من المصدر الرسمي</span></div>{official_list_cards()}</div>
    <div class="card"><h3>التحقق والاعتماد</h3><ul><li>قراءة جميع أوراق Excel وجميع سجلات XML الرسمية.</li><li>لا يتم تفعيل قائمة تحتوي سجلات فاشلة.</li><li>يمكن تنزيل السجلات المرفوضة كملف CSV وتصحيحها ثم رفعها ودمجها مع السجلات الصالحة المحفوظة مؤقتاً.</li><li>عند نجاح المجموعة كاملة، تستبدل النسخة الفعالة بصورة ذرية.</li></ul></div>
    <div class="card" id="validation-log"><h3>سجل الرفع والتحديث</h3><div class="table-wrap"><table><thead><tr><th>#</th><th>القائمة</th><th>التاريخ</th><th>الطريقة</th><th>الملف</th><th>الإجمالي</th><th>المعتمد</th><th>المرفوض</th><th>المكرر</th><th>الحالة</th><th>التفاصيل</th></tr></thead><tbody>{''.join(log_rows) or '<tr><td colspan="11">لا توجد عمليات</td></tr>'}</tbody></table></div></div>'''
    return layout('القوائم',body,'/lists')


def _rejected_csv(log_id: int) -> bytes:
    import csv
    with db() as con:
        ensure_schema(con); log=con.execute("SELECT * FROM sanctions_import_logs WHERE id=?",(log_id,)).fetchone()
    if not log: raise ValueError('السجل غير موجود')
    try: errors=json.loads(log['error_details_json'] or '[]')
    except Exception: errors=[]
    keys=['location','row','error','full_name','id_number','registration_number','nationality','country','notes']
    out=io.StringIO(); w=csv.DictWriter(out,fieldnames=keys,extrasaction='ignore'); w.writeheader()
    for e in errors:
        raw=e.get('raw') if isinstance(e,dict) else {}
        raw=raw if isinstance(raw,dict) else {}
        normalized=normalize_import_row(raw,{'list_name':log['list_name'],'source_url':log['source_url'] or '','list_type':'TF'})
        w.writerow({'location':e.get('location',''),'row':e.get('row',''),'error':e.get('error',''),
                    'full_name':normalized.get('full_name',''),'id_number':normalized.get('id_number',''),
                    'registration_number':normalized.get('registration_number',''),'nationality':normalized.get('nationality',''),
                    'country':normalized.get('country',''),'notes':normalized.get('notes','')})
    return ('\ufeff'+out.getvalue()).encode('utf-8')


_base_get_v1045=AppHandler.do_GET
def _do_get_v1045(self: AppHandler) -> None:
    parsed=urlparse(self.path)
    if parsed.path=='/lists/rejected.csv':
        from urllib.parse import parse_qs
        q=parse_qs(parsed.query); rid=int((q.get('id') or ['0'])[0])
        try:
            data=_rejected_csv(rid); self.send_response(200); self.send_header('Content-Type','text/csv; charset=utf-8'); self.send_header('Content-Disposition',f'attachment; filename="rejected_{rid}.csv"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        except Exception as exc: return self._send(layout('خطأ',f"<div class='error'>{h(exc)}</div>"),404)
    return _base_get_v1045(self)
AppHandler.do_GET=_do_get_v1045

_base_post_v1045=AppHandler.do_POST
def _do_post_v1045(self: AppHandler) -> None:
    path=urlparse(self.path).path
    if path=='/lists/direct-update':
        init_db(); length=int(self.headers.get('Content-Length','0')); body=self.rfile.read(length); fields,files=parse_multipart({k.lower():v for k,v in self.headers.items()},body)
        try: return self._send(lists_page(direct_update_list(fields,_real_client_ip(self))))
        except Exception as exc: return self._send(lists_page(f'فشل التحديث المباشر: {exc}'),500)
    return _base_post_v1045(self)
AppHandler.do_POST=_do_post_v1045
# ===== End V10.4.5 =====


# ===== V10.5: Simplified Regulatory Gap Closure =====
_ensure_schema_pre_v105 = ensure_schema
# V10.5.6: سلسلة ensure_schema الكاملة (خمس طبقات DDL + إصلاح مسارات) كانت تنفذ عدة
# مرات في كل طلب HTTP وفي كل استدعاء دالة مساعدة. تنفذ الآن مرة واحدة لكل قاعدة بيانات
# في عمر العملية؛ وتفرغ الذاكرة عند الاسترجاع من نسخة احتياطية.
_SCHEMA_ENSURED_DBS: set = set()

def ensure_schema(con: sqlite3.Connection, force: bool = False) -> None:  # type: ignore[override]
    key = str(DB_PATH)
    if not force and key in _SCHEMA_ENSURED_DBS:
        return
    _ensure_schema_v105_body(con)
    _SCHEMA_ENSURED_DBS.add(key)

def _ensure_schema_v105_body(con: sqlite3.Connection) -> None:
    _ensure_schema_pre_v105(con)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS document_completion_policy(
        id INTEGER PRIMARY KEY CHECK(id=1),
        default_days INTEGER NOT NULL DEFAULT 30,
        max_days INTEGER NOT NULL DEFAULT 180,
        max_extensions INTEGER NOT NULL DEFAULT 3,
        unlimited_with_partner INTEGER NOT NULL DEFAULT 1,
        updated_at TEXT,
        updated_by TEXT
    );
    INSERT OR IGNORE INTO document_completion_policy(id,default_days,max_days,max_extensions,unlimited_with_partner,updated_at,updated_by)
    VALUES(1,30,180,3,1,CURRENT_TIMESTAMP,'system');
    CREATE TABLE IF NOT EXISTS outstanding_documents(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        updated_at TEXT,
        client_id INTEGER NOT NULL REFERENCES clients(id),
        matter_id INTEGER REFERENCES matters(id),
        document_name TEXT NOT NULL,
        document_category TEXT NOT NULL DEFAULT 'important',
        status TEXT NOT NULL DEFAULT 'deferred',
        reason TEXT NOT NULL,
        due_date TEXT NOT NULL,
        responsible_partner TEXT,
        partner_undertaking INTEGER NOT NULL DEFAULT 0,
        extension_count INTEGER NOT NULL DEFAULT 0,
        closed_at TEXT,
        closure_notes TEXT
    );
    CREATE TABLE IF NOT EXISTS ubo_verifications(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        client_id INTEGER NOT NULL REFERENCES clients(id),
        verified INTEGER NOT NULL DEFAULT 0,
        verification_method TEXT,
        document_path TEXT,
        document_filename TEXT,
        verification_date TEXT,
        reviewed_by TEXT,
        notes TEXT
    );
    CREATE TABLE IF NOT EXISTS pep_assessments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        client_id INTEGER NOT NULL REFERENCES clients(id),
        pep_status TEXT NOT NULL DEFAULT 'no',
        related_person_name TEXT,
        source_of_funds TEXT,
        source_of_wealth TEXT,
        partner_approval TEXT,
        notes TEXT
    );
    CREATE TABLE IF NOT EXISTS partner_decisions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        client_id INTEGER NOT NULL REFERENCES clients(id),
        matter_id INTEGER REFERENCES matters(id),
        partner_name TEXT NOT NULL,
        decision TEXT NOT NULL,
        conditions TEXT,
        notes TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS suspicion_cases(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        updated_at TEXT,
        case_number TEXT NOT NULL UNIQUE,
        client_id INTEGER REFERENCES clients(id),
        matter_id INTEGER REFERENCES matters(id),
        reported_by TEXT NOT NULL,
        facts TEXT NOT NULL,
        indicators TEXT,
        status TEXT NOT NULL DEFAULT 'new',
        compliance_decision TEXT,
        external_reported INTEGER NOT NULL DEFAULT 0,
        external_reference TEXT,
        confidential_notes TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_outstanding_client ON outstanding_documents(client_id,status,due_date);
    CREATE INDEX IF NOT EXISTS idx_ubo_client ON ubo_verifications(client_id,created_at);
    CREATE INDEX IF NOT EXISTS idx_pep_client ON pep_assessments(client_id,created_at);
    CREATE INDEX IF NOT EXISTS idx_partner_decision_client ON partner_decisions(client_id,created_at);
    CREATE INDEX IF NOT EXISTS idx_suspicion_status ON suspicion_cases(status,created_at);
    """)
    con.commit()


def _v105_clients_options(con: sqlite3.Connection) -> str:
    return ''.join(f"<option value='{r['id']}'>{h(r['legal_name'])} — {int(r['id']):06d}</option>" for r in con.execute("SELECT id,legal_name FROM clients ORDER BY legal_name").fetchall())


def _v105_partners_options(con: sqlite3.Connection) -> str:
    rows=con.execute("SELECT full_name FROM app_users WHERE role='partner' AND is_active=1 ORDER BY full_name").fetchall()
    return ''.join(f"<option>{h(r['full_name'])}</option>" for r in rows) or "<option>الشريك المسؤول</option>"


def document_obligations_page(message: str='') -> bytes:
    with db() as con:
        ensure_schema(con)
        pol=con.execute("SELECT * FROM document_completion_policy WHERE id=1").fetchone()
        clients=_v105_clients_options(con); partners=_v105_partners_options(con)
        rows=con.execute("""SELECT o.*,c.legal_name FROM outstanding_documents o JOIN clients c ON c.id=o.client_id ORDER BY CASE WHEN o.status='overdue' THEN 0 WHEN o.status='deferred' THEN 1 ELSE 2 END,o.due_date""").fetchall()
    today=dt.date.today().isoformat(); out=[]
    for r in rows:
        state=r['status']
        if state=='deferred' and r['due_date']<today: state='overdue'
        label={'deferred':'مؤجل','overdue':'متأخر','completed':'مكتمل','closed':'مغلق','rejected':'مرفوض'}.get(state,state)
        out.append(f"<tr><td>{r['id']}</td><td>{h(r['legal_name'])}</td><td>{h(r['document_name'])}</td><td>{h(r['document_category'])}</td><td>{h(label)}</td><td>{h(r['reason'])}</td><td>{h(r['due_date'])}</td><td>{h(r['responsible_partner'] or '-')}</td><td>{r['extension_count']}</td><td><form method='post' action='/document-obligations/extend' class='inline-form'><input type='hidden' name='id' value='{r['id']}'><input name='days' type='number' min='1' value='{pol['default_days']}' style='width:90px'><button class='btn warn'>تمديد</button></form><form method='post' action='/document-obligations/complete' class='inline-form'><input type='hidden' name='id' value='{r['id']}'><button class='btn'>تم الاستلام</button></form></td></tr>")
    msg=f"<div class='success'>{h(message)}</div>" if message else ''
    body=f'''<div class="card"><div class="section-title"><div><h2>استكمال المستندات والالتزامات</h2><p class="small">لا يعلق العمل بسبب المستندات غير الحساسة. المستند الإلزامي لا يقبل التأجيل.</p></div><a class="btn secondary" href="/settings#document-policy">سياسة المهل</a></div>{msg}</div>
    <div class="card"><h3>إضافة مستند مؤجل</h3><form method="post" action="/document-obligations/add"><div class="grid"><div><label>العميل</label><select name="client_id" required>{clients}</select></div><div><label>اسم المستند</label><input name="document_name" required></div><div><label>التصنيف</label><select name="document_category"><option value="important">مهم — يمكن استكماله لاحقاً</option><option value="optional">اختياري</option><option value="mandatory">إلزامي — لا يقبل التأجيل</option></select></div><div><label>سبب التأجيل</label><input name="reason" required></div><div><label>عدد أيام المهلة</label><input name="days" type="number" min="1" max="{pol['max_days']}" value="{pol['default_days']}" required></div><div><label>الشريك المسؤول</label><select name="responsible_partner">{partners}</select></div></div><label><input type="checkbox" name="partner_undertaking" value="1" required> تعهد الشريك بمتابعة توفير المستندات ضمن المهلة</label><button>حفظ الالتزام</button></form></div>
    <div class="card"><h3>سجل المستندات الناقصة</h3><div class="table-wrap"><table><thead><tr><th>#</th><th>العميل</th><th>المستند</th><th>التصنيف</th><th>الحالة</th><th>السبب</th><th>الاستحقاق</th><th>الشريك</th><th>التمديدات</th><th>الإجراء</th></tr></thead><tbody>{''.join(out) or '<tr><td colspan="10">لا توجد التزامات مفتوحة</td></tr>'}</tbody></table></div></div>'''
    return layout('استكمال المستندات',body,'/document-obligations')


def regulatory_review_page(message: str='') -> bytes:
    with db() as con:
        ensure_schema(con); clients=_v105_clients_options(con); partners=_v105_partners_options(con)
        recent=con.execute("""SELECT d.created_at,c.legal_name,d.partner_name,d.decision,d.notes FROM partner_decisions d JOIN clients c ON c.id=d.client_id ORDER BY d.id DESC LIMIT 30""").fetchall()
    msg=f"<div class='success'>{h(message)}</div>" if message else ''
    rec=''.join(f"<tr><td>{h(r['created_at'])}</td><td>{h(r['legal_name'])}</td><td>{h(r['partner_name'])}</td><td>{h(r['decision'])}</td><td>{h(r['notes'])}</td></tr>" for r in recent)
    body=f'''<div class="card"><h2>المراجعة التنظيمية المبسطة</h2>{msg}<p class="notice">نموذج واحد مبسط للتحقق من المستفيد الحقيقي، PEP وقرار الشريك.</p></div>
    <div class="card"><h3>المستفيد الحقيقي</h3><form method="post" action="/regulatory-review/ubo" enctype="multipart/form-data"><div class="grid"><div><label>العميل</label><select name="client_id" required>{clients}</select></div><div><label>طريقة التحقق</label><select name="verification_method"><option>شهادة واثق</option><option>السجل التجاري</option><option>عقد التأسيس</option><option>مستند آخر</option></select></div><div><label>تاريخ التحقق</label><input type="date" name="verification_date" value="{dt.date.today().isoformat()}"></div><div><label>المراجع</label><input name="reviewed_by"></div><div><label>المستند</label><input type="file" name="ubo_file" accept=".pdf,.png,.jpg,.jpeg,.docx"></div><div><label>ملاحظات</label><input name="notes"></div></div><label><input type="checkbox" name="verified" value="1" required> تم التحقق من المستفيد الحقيقي</label><button>حفظ التحقق</button></form></div>
    <div class="card"><h3>فحص الشخصية المعرضة سياسياً PEP</h3><form method="post" action="/regulatory-review/pep"><div class="grid"><div><label>العميل</label><select name="client_id" required>{clients}</select></div><div><label>الحالة</label><select name="pep_status"><option value="no">لا</option><option value="local">نعم — محلي</option><option value="foreign">نعم — أجنبي</option><option value="international">نعم — منظمة دولية</option></select></div><div><label>اسم الشخص إن وجد</label><input name="related_person_name"></div><div><label>مصدر الأموال</label><input name="source_of_funds"></div><div><label>مصدر الثروة</label><input name="source_of_wealth"></div><div><label>ملاحظات</label><input name="notes"></div></div><button>حفظ التقييم</button></form></div>
    <div class="card"><h3>قرار الشريك</h3><form method="post" action="/regulatory-review/partner"><div class="grid"><div><label>العميل</label><select name="client_id" required>{clients}</select></div><div><label>الشريك</label><select name="partner_name">{partners}</select></div><div><label>القرار</label><select name="decision"><option>موافقة</option><option>موافقة مشروطة</option><option>رفض</option><option>تجميد</option></select></div><div><label>الشروط إن وجدت</label><input name="conditions"></div></div><label>ملاحظات القرار</label><textarea name="notes" required></textarea><button>حفظ قرار الشريك</button></form></div>
    <div class="card"><h3>آخر قرارات الشركاء</h3><div class="table-wrap"><table><thead><tr><th>التاريخ</th><th>العميل</th><th>الشريك</th><th>القرار</th><th>الملاحظات</th></tr></thead><tbody>{rec or '<tr><td colspan="5">لا توجد قرارات</td></tr>'}</tbody></table></div></div>'''
    return layout('المراجعة التنظيمية',body,'/regulatory-review')


def suspicion_cases_page(message: str='') -> bytes:
    with db() as con:
        ensure_schema(con); clients=_v105_clients_options(con)
        rows=con.execute("""SELECT s.*,c.legal_name FROM suspicion_cases s LEFT JOIN clients c ON c.id=s.client_id ORDER BY s.id DESC""").fetchall()
    msg=f"<div class='success'>{h(message)}</div>" if message else ''
    trs=''.join(f"<tr><td>{h(r['case_number'])}</td><td>{h(r['created_at'])}</td><td>{h(r['legal_name'] or '-')}</td><td>{h(r['reported_by'])}</td><td>{h(r['status'])}</td><td>{'نعم' if r['external_reported'] else 'لا'}</td><td><details><summary>عرض مقيد</summary><b>الوقائع:</b> {h(r['facts'])}<br><b>المؤشرات:</b> {h(r['indicators'] or '')}<br><b>قرار الامتثال:</b> {h(r['compliance_decision'] or '')}</details></td></tr>" for r in rows)
    body=f'''<div class="card danger-zone"><h2>سجل الاشتباه والتصعيد — سري ومقيد</h2>{msg}<p class="small">لا يظهر في تقارير العميل العامة ولا يجوز إبلاغ العميل بوجود البلاغ.</p></div>
    <div class="card"><h3>بلاغ داخلي جديد</h3><form method="post" action="/suspicion-cases/add"><div class="grid"><div><label>العميل</label><select name="client_id"><option value="">غير محدد</option>{clients}</select></div><div><label>مقدم البلاغ</label><input name="reported_by" required></div><div><label>الحالة</label><select name="status"><option value="new">جديد</option><option value="under_review">قيد المراجعة</option><option value="escalated">مصعد</option><option value="closed">مغلق</option></select></div><div><label>تم الإبلاغ خارجياً</label><select name="external_reported"><option value="0">لا</option><option value="1">نعم</option></select></div></div><label>الوقائع</label><textarea name="facts" required></textarea><label>مؤشرات الاشتباه</label><textarea name="indicators"></textarea><label>قرار مسؤول الامتثال</label><textarea name="compliance_decision"></textarea><label>المرجع الخارجي إن وجد</label><input name="external_reference"><button>حفظ البلاغ السري</button></form></div>
    <div class="card"><h3>السجل السري</h3><div class="table-wrap"><table><thead><tr><th>الرقم</th><th>التاريخ</th><th>العميل</th><th>مقدم البلاغ</th><th>الحالة</th><th>بلاغ خارجي</th><th>التفاصيل</th></tr></thead><tbody>{trs or '<tr><td colspan="7">لا توجد بلاغات</td></tr>'}</tbody></table></div></div>'''
    return layout('الاشتباه والتصعيد',body,'/suspicion-cases')


_layout_pre_v105 = layout
def layout(title: str, body: str, active: str='') -> bytes:  # type: ignore[override]
    raw=_layout_pre_v105(title,body,active).decode('utf-8')
    raw=raw.replace('<a href="/compliance">لوحة الامتثال</a>', '<a href="/compliance">لوحة الامتثال</a><a href="/regulatory-review">المراجعة التنظيمية</a><a href="/document-obligations">استكمال المستندات</a><a href="/suspicion-cases">الاشتباه والتصعيد</a>')
    return raw.encode('utf-8')


_settings_pre_v105 = settings_page
def settings_page(message: str='') -> bytes:  # type: ignore[override]
    raw=_settings_pre_v105(message).decode('utf-8')
    with db() as con:
        ensure_schema(con); p=con.execute("SELECT * FROM document_completion_policy WHERE id=1").fetchone()
    card=f'''<div class="card" id="document-policy"><h3>سياسة استكمال المستندات</h3><form method="post" action="/settings/document-policy"><div class="grid"><div><label>المدة الافتراضية بالأيام</label><input type="number" min="1" name="default_days" value="{p['default_days']}"></div><div><label>الحد الأقصى للأيام</label><input type="number" min="1" name="max_days" value="{p['max_days']}"></div><div><label>الحد الأقصى للتمديدات</label><input type="number" min="0" name="max_extensions" value="{p['max_extensions']}"></div><div><label>تمديد إضافي بتعهد الشريك</label><select name="unlimited_with_partner"><option value="1" {'selected' if p['unlimited_with_partner'] else ''}>مسموح</option><option value="0" {'selected' if not p['unlimited_with_partner'] else ''}>غير مسموح</option></select></div></div><button>حفظ السياسة</button></form></div>'''
    return raw.replace('</main>',card+'</main>',1).encode('utf-8')


def _v105_form(fields: Dict[str,List[str]], key: str, default: str='') -> str:
    return form_value(fields,key,default).strip()


def _save_ubo_file(files: Dict[str,Tuple[str,bytes]], client_id: int) -> Tuple[str,str]:
    filename,content=files.get('ubo_file',('',b''))
    if not filename or not content: return '',''
    safe=re.sub(r'[^A-Za-z0-9._-]+','_',Path(filename).name)
    folder=DATA_DIR/'documents'/'ubo'/str(client_id); folder.mkdir(parents=True,exist_ok=True)
    path=folder/f"{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}_{safe}"; path.write_bytes(content)
    return str(path),filename


_get_pre_v105=AppHandler.do_GET
def _do_get_v105(self: AppHandler) -> None:
    path=urlparse(self.path).path
    if path=='/document-obligations': return self._send(document_obligations_page())
    if path=='/regulatory-review': return self._send(regulatory_review_page())
    if path=='/suspicion-cases': return self._send(suspicion_cases_page())
    return _get_pre_v105(self)
AppHandler.do_GET=_do_get_v105


_post_pre_v105=AppHandler.do_POST
def _do_post_v105(self: AppHandler) -> None:
    path=urlparse(self.path).path
    if path not in {'/document-obligations/add','/document-obligations/extend','/document-obligations/complete','/regulatory-review/ubo','/regulatory-review/pep','/regulatory-review/partner','/suspicion-cases/add','/settings/document-policy'}:
        return _post_pre_v105(self)
    length=int(self.headers.get('Content-Length','0')); body=self.rfile.read(length)
    ctype=self.headers.get('Content-Type','')
    if 'multipart/form-data' in ctype: fields,files=parse_multipart({k.lower():v for k,v in self.headers.items()},body)
    else: fields=parse_qs(body.decode('utf-8')); files={}
    ip=_real_client_ip(self)
    try:
        with db() as con:
            ensure_schema(con)
            if path=='/settings/document-policy':
                d=int(_v105_form(fields,'default_days','30')); m=int(_v105_form(fields,'max_days','180')); x=int(_v105_form(fields,'max_extensions','3')); u=int(_v105_form(fields,'unlimited_with_partner','1'))
                if d<1 or m<d: raise ValueError('يجب أن يكون الحد الأقصى أكبر من أو يساوي المدة الافتراضية')
                con.execute("UPDATE document_completion_policy SET default_days=?,max_days=?,max_extensions=?,unlimited_with_partner=?,updated_at=?,updated_by=? WHERE id=1",(d,m,x,u,now_iso(),'system')); audit(con,'update_document_policy','settings',1,f'{d}/{m}/{x}',ip); con.commit(); return self._send(settings_page('تم حفظ سياسة استكمال المستندات'))
            if path=='/document-obligations/add':
                cat=_v105_form(fields,'document_category','important')
                if cat=='mandatory': raise ValueError('المستند الإلزامي لا يمكن تأجيله. يجب استكماله قبل الاعتماد.')
                pol=con.execute("SELECT * FROM document_completion_policy WHERE id=1").fetchone(); days=int(_v105_form(fields,'days',str(pol['default_days'])))
                if days>pol['max_days']: raise ValueError(f"المدة تتجاوز الحد الأقصى ({pol['max_days']} يوم)")
                due=(dt.date.today()+dt.timedelta(days=days)).isoformat()
                con.execute("""INSERT INTO outstanding_documents(created_at,client_id,document_name,document_category,status,reason,due_date,responsible_partner,partner_undertaking) VALUES(?,?,?,?,?,?,?,?,?)""",(now_iso(),int(_v105_form(fields,'client_id')), _v105_form(fields,'document_name'),cat,'deferred',_v105_form(fields,'reason'),due,_v105_form(fields,'responsible_partner'),1 if _v105_form(fields,'partner_undertaking') else 0)); audit(con,'defer_document','client',int(_v105_form(fields,'client_id')),_v105_form(fields,'document_name'),ip); con.commit(); return self._send(document_obligations_page('تم تسجيل المستند المؤجل وتعهد الشريك'))
            if path=='/document-obligations/extend':
                rid=int(_v105_form(fields,'id')); days=int(_v105_form(fields,'days','1')); r=con.execute("SELECT * FROM outstanding_documents WHERE id=?",(rid,)).fetchone(); pol=con.execute("SELECT * FROM document_completion_policy WHERE id=1").fetchone()
                if not r: raise ValueError('الالتزام غير موجود')
                if r['extension_count']>=pol['max_extensions'] and not pol['unlimited_with_partner']: raise ValueError('تم بلوغ الحد الأقصى للتمديدات')
                due=(dt.date.fromisoformat(r['due_date'])+dt.timedelta(days=days)).isoformat(); con.execute("UPDATE outstanding_documents SET due_date=?,extension_count=extension_count+1,updated_at=?,status='deferred' WHERE id=?",(due,now_iso(),rid)); audit(con,'extend_document_obligation','outstanding_document',rid,f'{days} days',ip); con.commit(); return self._send(document_obligations_page('تم تمديد المهلة وتسجيل العملية'))
            if path=='/document-obligations/complete':
                rid=int(_v105_form(fields,'id')); con.execute("UPDATE outstanding_documents SET status='completed',closed_at=?,updated_at=? WHERE id=?",(now_iso(),now_iso(),rid)); audit(con,'complete_document_obligation','outstanding_document',rid,'تم الاستلام',ip); con.commit(); return self._send(document_obligations_page('تم إغلاق الالتزام'))
            if path=='/regulatory-review/ubo':
                cid=int(_v105_form(fields,'client_id')); fpath,fname=_save_ubo_file(files,cid); con.execute("""INSERT INTO ubo_verifications(created_at,client_id,verified,verification_method,document_path,document_filename,verification_date,reviewed_by,notes) VALUES(?,?,?,?,?,?,?,?,?)""",(now_iso(),cid,1 if _v105_form(fields,'verified') else 0,_v105_form(fields,'verification_method'),fpath,fname,_v105_form(fields,'verification_date'),_v105_form(fields,'reviewed_by'),_v105_form(fields,'notes'))); audit(con,'ubo_verification','client',cid,_v105_form(fields,'verification_method'),ip); con.commit(); return self._send(regulatory_review_page('تم حفظ التحقق من المستفيد الحقيقي'))
            if path=='/regulatory-review/pep':
                cid=int(_v105_form(fields,'client_id')); con.execute("""INSERT INTO pep_assessments(created_at,client_id,pep_status,related_person_name,source_of_funds,source_of_wealth,notes) VALUES(?,?,?,?,?,?,?)""",(now_iso(),cid,_v105_form(fields,'pep_status','no'),_v105_form(fields,'related_person_name'),_v105_form(fields,'source_of_funds'),_v105_form(fields,'source_of_wealth'),_v105_form(fields,'notes'))); audit(con,'pep_assessment','client',cid,_v105_form(fields,'pep_status'),ip); con.commit(); return self._send(regulatory_review_page('تم حفظ تقييم PEP'))
            if path=='/regulatory-review/partner':
                cid=int(_v105_form(fields,'client_id')); con.execute("""INSERT INTO partner_decisions(created_at,client_id,partner_name,decision,conditions,notes) VALUES(?,?,?,?,?,?)""",(now_iso(),cid,_v105_form(fields,'partner_name'),_v105_form(fields,'decision'),_v105_form(fields,'conditions'),_v105_form(fields,'notes'))); con.execute("UPDATE clients SET status=?,updated_at=? WHERE id=?",('approved' if _v105_form(fields,'decision') in {'موافقة','موافقة مشروطة'} else 'rejected',now_iso(),cid)); audit(con,'partner_decision','client',cid,_v105_form(fields,'decision'),ip); con.commit(); return self._send(regulatory_review_page('تم حفظ قرار الشريك'))
            if path=='/suspicion-cases/add':
                num='SUS-'+dt.datetime.now().strftime('%Y%m%d%H%M%S')+'-'+secrets.token_hex(2).upper(); cid=_v105_form(fields,'client_id'); con.execute("""INSERT INTO suspicion_cases(created_at,case_number,client_id,reported_by,facts,indicators,status,compliance_decision,external_reported,external_reference) VALUES(?,?,?,?,?,?,?,?,?,?)""",(now_iso(),num,int(cid) if cid.isdigit() else None,_v105_form(fields,'reported_by'),_v105_form(fields,'facts'),_v105_form(fields,'indicators'),_v105_form(fields,'status','new'),_v105_form(fields,'compliance_decision'),int(_v105_form(fields,'external_reported','0')),_v105_form(fields,'external_reference'))); audit(con,'create_suspicion_case','suspicion_case',0,num,ip); con.commit(); return self._send(suspicion_cases_page('تم حفظ البلاغ الداخلي بشكل مستقل ومقيد'))
    except Exception as exc:
        page=document_obligations_page if path.startswith('/document-obligations') else regulatory_review_page if path.startswith('/regulatory-review') else suspicion_cases_page if path.startswith('/suspicion-cases') else settings_page
        return self._send(page(f'خطأ: {exc}'),400)
AppHandler.do_POST=_do_post_v105
# ===== End V10.5 =====

# ===== V10.5.1: Controlled document catalogue, partner dashboard, backup governance =====
APP_VERSION = "V10.5.1 - Workflow, Document Catalogue & Backup Governance"

_DOCUMENT_CATALOG_SEED = [
    ("commercial_registration","السجل التجاري","mandatory",0,"company,government,charity,foreign_company"),
    ("national_id","الهوية الوطنية / الإقامة","mandatory",0,"individual"),
    ("passport","جواز السفر","mandatory",0,"individual,foreign_company"),
    ("articles_of_association","عقد التأسيس / النظام الأساسي","mandatory",0,"company,foreign_company,charity"),
    ("ubo_wathiq","شهادة المستفيد الحقيقي – واثق","mandatory",0,"company,foreign_company"),
    ("authorized_signatory_id","هوية المفوض بالتوقيع","mandatory",0,"company,government,charity,foreign_company"),
    ("national_address","العنوان الوطني","important",1,"all"),
    ("board_resolution","قرار مجلس الإدارة / قرار التفويض","important",1,"company,government,charity,foreign_company"),
    ("power_of_attorney","وكالة أو تفويض","important",1,"all"),
    ("ownership_structure","هيكل الملكية","important",1,"company,foreign_company"),
    ("source_of_funds","مستند مصدر الأموال","risk_based",1,"all"),
    ("source_of_wealth","مستند مصدر الثروة","risk_based",1,"all"),
    ("engagement_letter","خطاب التكليف / اتفاقية الأتعاب","important",1,"all"),
    ("supporting_document","مستند داعم آخر","optional",1,"all"),
]


def _v1051_ensure_schema(con: sqlite3.Connection) -> None:
    ensure_schema(con)
    for table, col, typ in [
        ("clients","managing_partner","TEXT"),("clients","executing_partner","TEXT"),
        ("matters","managing_partner","TEXT"),("matters","executing_partner","TEXT"),
    ]:
        cols={r[1] for r in con.execute(f"PRAGMA table_info({table})").fetchall()}
        if col not in cols: con.execute(f"ALTER TABLE {table} ADD COLUMN {col} {typ}")
    con.execute('''CREATE TABLE IF NOT EXISTS document_catalog(
        code TEXT PRIMARY KEY, document_name TEXT NOT NULL, category TEXT NOT NULL,
        defer_allowed INTEGER NOT NULL DEFAULT 0, client_types TEXT NOT NULL DEFAULT 'all',
        is_active INTEGER NOT NULL DEFAULT 1, updated_at TEXT, updated_by TEXT)''')
    con.execute('''CREATE TABLE IF NOT EXISTS backup_audit(
        id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, operation TEXT NOT NULL,
        backup_filename TEXT, environment TEXT NOT NULL, status TEXT NOT NULL, file_size INTEGER,
        sha256 TEXT, initiated_by TEXT, details TEXT, comparison_with TEXT)''')
    con.executemany("INSERT OR IGNORE INTO document_catalog(code,document_name,category,defer_allowed,client_types,is_active,updated_at,updated_by) VALUES(?,?,?,?,?,1,?,?)",
                    [(*r,now_iso(),'system') for r in _DOCUMENT_CATALOG_SEED])
    con.execute("CREATE INDEX IF NOT EXISTS idx_backup_audit_created ON backup_audit(created_at)")
    con.execute("CREATE INDEX IF NOT EXISTS idx_doc_catalog_active ON document_catalog(is_active,document_name)")
    con.commit()


def _category_label(cat: str) -> str:
    return {"mandatory":"إلزامي — غير قابل للتأجيل","important":"مهم — قابل للتأجيل","optional":"اختياري","risk_based":"حسب مستوى المخاطر"}.get(cat,cat)


def _partner_options(selected: str='') -> str:
    with db() as con:
        _v1051_ensure_schema(con)
        rows=con.execute("SELECT full_name FROM app_users WHERE role='partner' AND is_active=1 ORDER BY full_name").fetchall()
    opts=['<option value="">-- اختر الشريك --</option>']
    for r in rows:
        name=r['full_name']; opts.append(f'<option value="{h(name)}" {"selected" if name==selected else ""}>{h(name)}</option>')
    return ''.join(opts)


def _doc_catalog_options() -> str:
    with db() as con:
        _v1051_ensure_schema(con)
        rows=con.execute("SELECT * FROM document_catalog WHERE is_active=1 ORDER BY CASE category WHEN 'mandatory' THEN 1 WHEN 'important' THEN 2 WHEN 'risk_based' THEN 3 ELSE 4 END, document_name").fetchall()
    return ''.join(f'<option value="{h(r["code"])}" data-category="{h(r["category"])}" data-defer="{r["defer_allowed"]}">{h(r["document_name"])} — {_category_label(r["category"])}</option>' for r in rows)


_base_client_form_v1051=client_form
def client_form() -> bytes:  # type: ignore[override]
    raw=_base_client_form_v1051().decode('utf-8')
    extra=f'''<div class="card"><h3>المسؤولية عن العميل</h3><div class="grid"><div><label>الشريك المدير</label><select name="managing_partner">{_partner_options()}</select></div><div><label>الشريك المنفذ</label><select name="executing_partner">{_partner_options()}</select></div></div><p class="small">تستخدم هذه البيانات لتوجيه المهام والموافقات إلى لوحة الشريك الديناميكية.</p></div>'''
    return raw.replace('<button type="submit">حفظ العميل</button>',extra+'<button type="submit">حفظ العميل</button>',1).encode('utf-8')


_base_create_client_v1051=create_client
def create_client(fields: Dict[str,List[str]], files: Optional[Dict[str,Tuple[str,bytes]]]=None, ip: str='') -> int:  # type: ignore[override]
    cid=_base_create_client_v1051(fields,files,ip)
    with db() as con:
        _v1051_ensure_schema(con)
        con.execute("UPDATE clients SET managing_partner=?,executing_partner=? WHERE id=?",(form_value(fields,'managing_partner'),form_value(fields,'executing_partner'),cid))
        audit(con,'assign_client_partners','client',cid,f"managing={form_value(fields,'managing_partner')}; executing={form_value(fields,'executing_partner')}",ip); con.commit()
    return cid


_base_matter_form_v1051=matter_form
def matter_form(prefill_client_id: str='') -> bytes:  # type: ignore[override]
    raw=_base_matter_form_v1051(prefill_client_id).decode('utf-8')
    block=f'''<div class="card"><h3>تعيين الشركاء</h3><div class="grid"><div><label>الشريك المدير</label><select name="managing_partner" required>{_partner_options()}</select></div><div><label>الشريك المنفذ</label><select name="executing_partner" required>{_partner_options()}</select></div></div><p class="small">ستظهر الموافقات والفحوص والمستندات المرتبطة بالمشروع في لوحة كل شريك حسب دوره.</p></div>'''
    return raw.replace('<button>حفظ المشروع / القضية</button>',block+'<button>حفظ المشروع / القضية</button>',1).encode('utf-8')


_base_create_matter_v1051=create_matter
def create_matter(fields: Dict[str,List[str]], ip: str='') -> int:  # type: ignore[override]
    mid=_base_create_matter_v1051(fields,ip)
    with db() as con:
        _v1051_ensure_schema(con)
        con.execute("UPDATE matters SET managing_partner=?,executing_partner=? WHERE id=?",(form_value(fields,'managing_partner'),form_value(fields,'executing_partner'),mid))
        audit(con,'assign_matter_partners','matter',mid,f"managing={form_value(fields,'managing_partner')}; executing={form_value(fields,'executing_partner')}",ip); con.commit()
    return mid


def document_obligations_page(message: str='') -> bytes:  # type: ignore[override]
    with db() as con:
        _v1051_ensure_schema(con)
        pol=con.execute("SELECT * FROM document_completion_policy WHERE id=1").fetchone()
        clients=_v105_clients_options(con); partners=_v105_partners_options(con)
        rows=con.execute("""SELECT o.*,c.legal_name FROM outstanding_documents o JOIN clients c ON c.id=o.client_id ORDER BY CASE o.status WHEN 'deferred' THEN 1 WHEN 'overdue' THEN 2 ELSE 3 END,o.due_date""").fetchall()
    today=dt.date.today().isoformat(); out=[]
    for r in rows:
        status='متأخر' if r['status']=='deferred' and r['due_date']<today else {'deferred':'مؤجل','completed':'مكتمل','closed':'مغلق'}.get(r['status'],r['status'])
        out.append(f"<tr><td>{r['id']}</td><td>{h(r['legal_name'])}</td><td>{h(r['document_name'])}</td><td>{h(_category_label(r['document_category']))}</td><td>{h(status)}</td><td>{h(r['reason'])}</td><td>{h(r['due_date'])}</td><td>{h(r['responsible_partner'] or '-')}</td><td>{r['extension_count']}</td><td><form method='post' action='/document-obligations/extend' class='inline-form'><input type='hidden' name='id' value='{r['id']}'><input name='days' type='number' min='1' value='{pol['default_days']}' style='width:90px'><button class='btn warn'>تمديد</button></form><form method='post' action='/document-obligations/complete' class='inline-form'><input type='hidden' name='id' value='{r['id']}'><button class='btn'>تم الاستلام</button></form></td></tr>")
    msg=f"<div class='success'>{h(message)}</div>" if message else ''
    body=f'''<div class="card"><div class="section-title"><div><h2>استكمال المستندات والالتزامات</h2><p class="small">اختيار المستند من دليل موحد؛ التصنيف يظهر تلقائياً ولا يمكن تغييره. البنود الإلزامية لا تقبل التأجيل.</p></div><a class="btn secondary" href="/settings#document-policy">سياسة المهل</a></div>{msg}</div>
    <div class="card"><h3>إضافة مستند مؤجل</h3><form method="post" action="/document-obligations/add"><div class="grid"><div><label>العميل</label><select name="client_id" required>{clients}</select></div><div><label>اسم المستند</label><select id="doc_code" name="document_code" required onchange="syncDocCategory()"><option value="">-- اختر المستند --</option>{_doc_catalog_options()}</select></div><div><label>التصنيف</label><input id="doc_category_label" readonly value="يحدد تلقائياً"></div><div><label>سبب التأجيل</label><input name="reason" required></div><div><label>عدد أيام المهلة</label><input name="days" type="number" min="1" max="{pol['max_days']}" value="{pol['default_days']}" required></div><div><label>الشريك المسؤول</label><select name="responsible_partner" required>{partners}</select></div></div><input type="hidden" id="doc_category" name="document_category"><label><input type="checkbox" name="partner_undertaking" value="1" required> تعهد الشريك بمتابعة توفير المستندات ضمن المهلة</label><div id="doc_warning" class="notice" style="display:none"></div><button id="save_doc_btn">حفظ الالتزام</button></form></div>
    <div class="card"><h3>سجل المستندات الناقصة</h3><div class="table-wrap"><table><thead><tr><th>#</th><th>العميل</th><th>المستند</th><th>التصنيف</th><th>الحالة</th><th>السبب</th><th>الاستحقاق</th><th>الشريك</th><th>التمديدات</th><th>الإجراء</th></tr></thead><tbody>{''.join(out) or '<tr><td colspan="10">لا توجد التزامات مفتوحة</td></tr>'}</tbody></table></div></div>
    <script>function syncDocCategory(){{const s=document.getElementById('doc_code'),o=s.options[s.selectedIndex],cat=o?.dataset.category||'',defer=o?.dataset.defer||'0';const labels={{mandatory:'إلزامي — غير قابل للتأجيل',important:'مهم — قابل للتأجيل',optional:'اختياري',risk_based:'حسب مستوى المخاطر'}};document.getElementById('doc_category').value=cat;document.getElementById('doc_category_label').value=labels[cat]||'يحدد تلقائياً';const b=document.getElementById('save_doc_btn'),w=document.getElementById('doc_warning');if(cat==='mandatory'||defer==='0'){{b.disabled=true;w.style.display='block';w.textContent='هذا المستند إلزامي ولا يمكن تسجيله كمستند مؤجل.'}}else{{b.disabled=false;w.style.display='none'}}}}</script>'''
    return layout('استكمال المستندات',body,'/document-obligations')


def partner_dashboard_page(partner: str='') -> bytes:
    with db() as con:
        _v1051_ensure_schema(con)
        partners=con.execute("SELECT full_name FROM app_users WHERE role='partner' AND is_active=1 ORDER BY full_name").fetchall()
        if not partner and partners: partner=partners[0]['full_name']
        matters=con.execute("""SELECT m.id,m.matter_number,m.title,m.status,c.legal_name,m.managing_partner,m.executing_partner FROM matters m JOIN clients c ON c.id=m.client_id WHERE m.managing_partner=? OR m.executing_partner=? ORDER BY m.id DESC""",(partner,partner)).fetchall() if partner else []
        docs=con.execute("""SELECT o.id,o.document_name,o.due_date,o.status,c.legal_name FROM outstanding_documents o JOIN clients c ON c.id=o.client_id WHERE o.responsible_partner=? AND o.status='deferred' ORDER BY o.due_date""",(partner,)).fetchall() if partner else []
        pending=con.execute("""SELECT c.id,c.legal_name,c.status FROM clients c WHERE (c.managing_partner=? OR c.executing_partner=?) AND c.status IN ('draft','under_review') ORDER BY c.id DESC""",(partner,partner)).fetchall() if partner else []
        hits=con.execute("""SELECT s.id,s.subject_name,s.status,s.match_score,m.title,c.legal_name FROM screenings s LEFT JOIN counterparties cp ON s.subject_type='counterparty' AND cp.id=s.subject_id LEFT JOIN matters m ON m.id=cp.matter_id LEFT JOIN clients c ON c.id=m.client_id WHERE (m.managing_partner=? OR m.executing_partner=?) AND s.status IN ('potential_match','high_similarity','confirmed_match','frozen') ORDER BY s.id DESC LIMIT 100""",(partner,partner)).fetchall() if partner else []
    opts=''.join(f'<option value="{h(r["full_name"])}" {"selected" if r["full_name"]==partner else ""}>{h(r["full_name"])}</option>' for r in partners)
    matter_rows=''.join(f"<tr><td><a href='/matter?id={r['id']}'>{h(r['matter_number'])}</a></td><td>{h(r['title'])}</td><td>{h(r['legal_name'])}</td><td>{badge_status(r['status'])}</td><td>{'شريك مدير' if r['managing_partner']==partner else 'شريك منفذ'}</td></tr>" for r in matters)
    doc_rows=''.join(f"<tr><td>{h(r['legal_name'])}</td><td>{h(r['document_name'])}</td><td>{h(r['due_date'])}</td><td>{'متأخر' if r['due_date']<dt.date.today().isoformat() else 'معلق'}</td></tr>" for r in docs)
    client_rows=''.join(f"<tr><td><a href='/client?id={r['id']}'>{h(r['legal_name'])}</a></td><td>{badge_status(r['status'])}</td><td><a class='btn' href='/regulatory-review'>مراجعة واعتماد</a></td></tr>" for r in pending)
    hit_rows=''.join(f"<tr><td>{h(r['legal_name'] or '-')}</td><td>{h(r['title'] or '-')}</td><td>{h(r['subject_name'])}</td><td>{badge_status(r['status'])}</td><td>{h(r['match_score'])}</td></tr>" for r in hits)
    body=f'''<div class="card"><div class="section-title"><div><h2>لوحة مهام الشريك</h2><p class="small">لوحة ديناميكية تعرض فقط العملاء والمشروعات والفحوص والمستندات المسندة للشريك المختار.</p></div><form method="get" action="/partner-dashboard"><select name="partner" onchange="this.form.submit()">{opts}</select></form></div></div>
    <div class="grid"><div class="card kpi"><div>بانتظار المراجعة</div><div class="num">{len(pending)}</div></div><div class="card kpi"><div>المشروعات المرتبطة</div><div class="num">{len(matters)}</div></div><div class="card kpi"><div>مستندات معلقة</div><div class="num">{len(docs)}</div></div><div class="card kpi"><div>نتائج فحص تحتاج مراجعة</div><div class="num">{len(hits)}</div></div></div>
    <div class="card"><h3>الموافقات المطلوبة</h3><div class="table-wrap"><table><thead><tr><th>العميل</th><th>الحالة</th><th>الإجراء</th></tr></thead><tbody>{client_rows or '<tr><td colspan="3">لا توجد موافقات معلقة</td></tr>'}</tbody></table></div></div>
    <div class="card"><h3>مشاريعي</h3><div class="table-wrap"><table><thead><tr><th>الرقم</th><th>المشروع</th><th>العميل</th><th>الحالة</th><th>الدور</th></tr></thead><tbody>{matter_rows or '<tr><td colspan="5">لا توجد مشروعات مسندة</td></tr>'}</tbody></table></div></div>
    <div class="card"><h3>المستندات المعلقة</h3><div class="table-wrap"><table><thead><tr><th>العميل</th><th>المستند</th><th>الاستحقاق</th><th>الحالة</th></tr></thead><tbody>{doc_rows or '<tr><td colspan="4">لا توجد مستندات معلقة</td></tr>'}</tbody></table></div></div>
    <div class="card"><h3>نتائج الفحص المرتبطة بعملائي</h3><div class="table-wrap"><table><thead><tr><th>العميل</th><th>المشروع</th><th>الطرف</th><th>النتيجة</th><th>الدرجة</th></tr></thead><tbody>{hit_rows or '<tr><td colspan="5">لا توجد نتائج مفتوحة</td></tr>'}</tbody></table></div></div>'''
    return layout('لوحة مهام الشريك',body,'/partner-dashboard')


def _backup_manifest_counts(dbfile: Path) -> Dict[str,int]:
    result={}
    con=sqlite3.connect(str(dbfile))
    try:
        for t in ['clients','matters','counterparties','sanctions_entries','screenings','outstanding_documents','app_users']:
            try: result[t]=con.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]
            except sqlite3.Error: result[t]=0
    finally: con.close()
    return result


def create_backup(note: str='manual') -> str:  # type: ignore[override]
    ensure_dirs(); init_db(); stamp=dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f'); backup_path=BACKUP_DIR/f'masarat_{APP_ENV.lower()}_backup_{stamp}.zip'
    counts=_backup_manifest_counts(DB_PATH) if DB_PATH.exists() else {}
    manifest={"created_at":now_iso(),"version":APP_VERSION,"environment":APP_ENV,"note":note,"database_counts":counts,"retention_years":RETENTION_YEARS}
    with zipfile.ZipFile(backup_path,'w',zipfile.ZIP_DEFLATED) as z:
        if DB_PATH.exists(): z.write(DB_PATH,arcname='data/masarat_kyc_v10.sqlite3')
        # V10.5.7 fix: لا يوضع مفتاح التشفير داخل أرشيف النسخة الاحتياطية. كان تضمينه يجعل
        # تسريب ملف نسخة واحد يكشف البيانات والمفتاح معاً. يحفظ المفتاح ويدار بشكل منفصل.
        docs=DATA_DIR/'documents'
        if docs.exists():
            for p in docs.rglob('*'):
                if p.is_file(): z.write(p,arcname=str(Path('documents')/p.relative_to(docs)))
        z.writestr('backup_manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    sha=hashlib.sha256(backup_path.read_bytes()).hexdigest(); backup_path.with_suffix('.sha256.txt').write_text(f'{sha}  {backup_path.name}\n',encoding='utf-8')
    with db() as con:
        _v1051_ensure_schema(con); con.execute("INSERT INTO rollback_points(created_at,backup_path,notes) VALUES(?,?,?)",(now_iso(),str(backup_path),note)); con.execute("INSERT INTO backup_audit(created_at,operation,backup_filename,environment,status,file_size,sha256,initiated_by,details) VALUES(?,?,?,?,?,?,?,?,?)",(now_iso(),'create',backup_path.name,APP_ENV,'success',backup_path.stat().st_size,sha,'system',json.dumps(counts,ensure_ascii=False))); audit(con,'create_backup','backup',0,backup_path.name); con.commit()
    return str(backup_path)


def _safe_backup_file(name: str) -> Path:
    p=(BACKUP_DIR/Path(name).name).resolve(); base=BACKUP_DIR.resolve()
    if base not in p.parents or not p.exists() or p.suffix.lower()!='.zip': raise ValueError('ملف النسخة الاحتياطية غير صالح')
    return p


def _read_backup_manifest(path: Path) -> Dict[str,Any]:
    with zipfile.ZipFile(path) as z:
        if 'backup_manifest.json' not in z.namelist(): return {"created_at":"-","version":"نسخة قديمة","environment":"UNKNOWN","database_counts":{}}
        return json.loads(z.read('backup_manifest.json').decode('utf-8'))


def restore_backup(filename: str, initiated_by: str='system') -> str:
    src=_safe_backup_file(filename); manifest=_read_backup_manifest(src); env=manifest.get('environment','UNKNOWN')
    if env not in {APP_ENV,'UNKNOWN'}: raise ValueError(f'لا يمكن استعادة نسخة {env} داخل بيئة {APP_ENV}')
    sha=hashlib.sha256(src.read_bytes()).hexdigest(); side=src.with_suffix('.sha256.txt')
    if side.exists() and sha not in side.read_text(encoding='utf-8',errors='ignore'): raise ValueError('فشل التحقق من بصمة النسخة الاحتياطية')
    pre=create_backup(f'pre_restore_before_{src.name}')
    tmp=BACKUP_DIR/f'.restore_{secrets.token_hex(4)}'; tmp.mkdir(parents=True,exist_ok=False)
    try:
        with zipfile.ZipFile(src) as z: z.extractall(tmp)
        restored=tmp/'data'/'masarat_kyc_v10.sqlite3'
        if not restored.exists(): raise ValueError('النسخة لا تحتوي قاعدة بيانات')
        con=sqlite3.connect(str(restored)); ok=con.execute('PRAGMA integrity_check').fetchone()[0]; con.close()
        if ok!='ok': raise ValueError(f'قاعدة البيانات داخل النسخة غير سليمة: {ok}')
        replacement=DB_PATH.with_suffix('.restore.tmp'); shutil.copy2(restored,replacement); os.replace(replacement,DB_PATH)
        _SCHEMA_ENSURED_DBS.discard(str(DB_PATH))  # V10.5.6: إعادة فحص المخطط بعد الاستبدال بنسخة أقدم.
        _JOINT_SCHEMA_ENSURED.discard(str(DB_PATH))  # V10.6: rebuild+reseed matter_clients after restore.
        key=tmp/'keys'/'kyc_master.key'
        if key.exists(): KEY_DIR.mkdir(parents=True,exist_ok=True); shutil.copy2(key,KEY_DIR/'kyc_master.key')
        docs=tmp/'documents'
        if docs.exists():
            target=DATA_DIR/'documents'; target.mkdir(parents=True,exist_ok=True)
            for p in docs.rglob('*'):
                if p.is_file(): dest=target/p.relative_to(docs); dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dest)
        with db() as con:
            _v1051_ensure_schema(con); con.execute("INSERT INTO backup_audit(created_at,operation,backup_filename,environment,status,file_size,sha256,initiated_by,details) VALUES(?,?,?,?,?,?,?,?,?)",(now_iso(),'restore',src.name,APP_ENV,'success',src.stat().st_size,sha,initiated_by,f'pre_restore={Path(pre).name}')); audit(con,'restore_backup','backup',0,src.name); con.commit()
        return f'تمت استعادة النسخة {src.name} بنجاح، وتم إنشاء نسخة حماية قبل الاستعادة: {Path(pre).name}'
    except Exception as exc:
        with db() as con:
            _v1051_ensure_schema(con); con.execute("INSERT INTO backup_audit(created_at,operation,backup_filename,environment,status,file_size,sha256,initiated_by,details) VALUES(?,?,?,?,?,?,?,?,?)",(now_iso(),'restore',src.name,APP_ENV,'failed',src.stat().st_size,sha,initiated_by,str(exc))); con.commit()
        raise
    finally: shutil.rmtree(tmp,ignore_errors=True)


def _backup_counts(path: Path) -> Dict[str,int]:
    manifest=_read_backup_manifest(path); counts=manifest.get('database_counts') or {}
    if counts: return {k:int(v) for k,v in counts.items()}
    tmp=BACKUP_DIR/f'.compare_{secrets.token_hex(4)}'; tmp.mkdir(parents=True,exist_ok=False)
    try:
        with zipfile.ZipFile(path) as z: z.extract('data/masarat_kyc_v10.sqlite3',tmp)
        return _backup_manifest_counts(tmp/'data'/'masarat_kyc_v10.sqlite3')
    finally: shutil.rmtree(tmp,ignore_errors=True)


def backups_page(message: str='', compare_a: str='', compare_b: str='') -> bytes:
    BACKUP_DIR.mkdir(parents=True,exist_ok=True); files=sorted(BACKUP_DIR.glob('*.zip'),key=lambda p:p.stat().st_mtime,reverse=True)
    rows=[]
    for p in files:
        man=_read_backup_manifest(p); sha=hashlib.sha256(p.read_bytes()).hexdigest(); rows.append(f"<tr><td>{h(p.name)}</td><td>{h(man.get('created_at','-'))}</td><td>{h(man.get('environment','UNKNOWN'))}</td><td>{p.stat().st_size/1024/1024:.2f} MB</td><td><code>{sha[:16]}…</code></td><td><a class='btn secondary' href='/backups/download?file={h(p.name)}'>تنزيل</a><form method='post' action='/backups/restore' class='inline-form' onsubmit=\"return confirm('سيتم استبدال بيانات البيئة الحالية. هل أنت متأكد؟')\"><input type='hidden' name='file' value='{h(p.name)}'><input name='confirm_text' placeholder='اكتب RESTORE' required style='width:120px'><button class='btn danger'>استعادة</button></form></td></tr>")
    with db() as con:
        _v1051_ensure_schema(con); audits=con.execute("SELECT * FROM backup_audit ORDER BY id DESC LIMIT 200").fetchall()
    audit_rows=''.join(f"<tr><td>{r['id']}</td><td>{h(r['created_at'])}</td><td>{h(r['operation'])}</td><td>{h(r['backup_filename'])}</td><td>{h(r['environment'])}</td><td>{badge_status(r['status'])}</td><td>{h(r['initiated_by'] or '-')}</td><td>{h(r['details'] or '')}</td></tr>" for r in audits)
    comparison=''
    if compare_a and compare_b:
        try:
            a=_safe_backup_file(compare_a); b=_safe_backup_file(compare_b); ca=_backup_counts(a); cb=_backup_counts(b); keys=sorted(set(ca)|set(cb)); comp=''.join(f"<tr><td>{h(k)}</td><td>{ca.get(k,0)}</td><td>{cb.get(k,0)}</td><td>{cb.get(k,0)-ca.get(k,0):+d}</td></tr>" for k in keys); comparison=f"<div class='card'><h3>نتيجة المقارنة</h3><table><thead><tr><th>العنصر</th><th>{h(a.name)}</th><th>{h(b.name)}</th><th>الفرق</th></tr></thead><tbody>{comp}</tbody></table></div>"
        except Exception as exc: comparison=f"<div class='error'>تعذر إجراء المقارنة: {h(exc)}</div>"
    options=''.join(f'<option value="{h(p.name)}">{h(p.name)}</option>' for p in files)
    msg=f"<div class='success'>{h(message)}</div>" if message else ''
    body=f'''<div class="card"><div class="section-title"><div><h2>النسخ الاحتياطية والاستعادة</h2><p class="small">إنشاء، تحقق، استعادة آمنة، مقارنة، وسجل تدقيق مستقل لكل العمليات.</p></div><form method="post" action="/production/backup"><button>إنشاء نسخة الآن</button></form></div>{msg}</div>
    <div class="card"><h3>مقارنة نسختين</h3><form method="get" action="/backups"><div class="grid"><div><label>النسخة الأولى</label><select name="a">{options}</select></div><div><label>النسخة الثانية</label><select name="b">{options}</select></div></div><button class="btn secondary">مقارنة</button></form></div>{comparison}
    <div class="card"><h3>أرشيف النسخ</h3><div class="table-wrap"><table><thead><tr><th>الملف</th><th>الإنشاء</th><th>البيئة</th><th>الحجم</th><th>البصمة</th><th>الإجراء</th></tr></thead><tbody>{''.join(rows) or '<tr><td colspan="6">لا توجد نسخ احتياطية</td></tr>'}</tbody></table></div></div>
    <div class="card"><h3>سجل تدقيق النسخ الاحتياطية</h3><div class="table-wrap"><table><thead><tr><th>#</th><th>التاريخ</th><th>العملية</th><th>النسخة</th><th>البيئة</th><th>الحالة</th><th>المنفذ</th><th>التفاصيل</th></tr></thead><tbody>{audit_rows or '<tr><td colspan="8">لا توجد عمليات</td></tr>'}</tbody></table></div></div>'''
    return layout('النسخ الاحتياطية والاستعادة',body,'/backups')


_base_production_page_v1051=production_page
def production_page(message: str='') -> bytes:  # type: ignore[override]
    raw=_base_production_page_v1051(message).decode('utf-8')
    card='''<div class="card"><h3>إدارة النسخ الاحتياطية</h3><p>أرشيف كامل، استعادة آمنة، مقارنة، وسجل تدقيق.</p><a class="btn" href="/backups">فتح النسخ الاحتياطية والاستعادة</a></div>'''
    return raw.replace('<div class="card danger-zone">',card+'<div class="card danger-zone">',1).encode('utf-8')


_base_layout_v1051=layout
def layout(title: str, body: str, active: str='') -> bytes:  # type: ignore[override]
    raw=_base_layout_v1051(title,body,active).decode('utf-8')
    raw=raw.replace('<a href="/audit">سجل التدقيق</a>', '<a href="/partner-dashboard">لوحة مهام الشريك</a><a href="/backups">النسخ الاحتياطية والاستعادة</a><a href="/audit">سجل التدقيق</a>')
    return raw.encode('utf-8')


_get_pre_v1051=AppHandler.do_GET
def _do_get_v1051(self: AppHandler) -> None:
    parsed=urlparse(self.path); path=parsed.path; qs=parse_qs(parsed.query)
    if path=='/partner-dashboard': return self._send(partner_dashboard_page(qs.get('partner',[''])[0]))
    if path=='/backups': return self._send(backups_page(compare_a=qs.get('a',[''])[0],compare_b=qs.get('b',[''])[0]))
    if path=='/backups/download':
        try:
            p=_safe_backup_file(qs.get('file',[''])[0]); return self._send(p.read_bytes(),200,'application/zip')
        except Exception as exc: return self._send(layout('خطأ',f"<div class='error'>{h(exc)}</div>",'/backups'),404)
    return _get_pre_v1051(self)
AppHandler.do_GET=_do_get_v1051


_post_pre_v1051=AppHandler.do_POST
def _do_post_v1051(self: AppHandler) -> None:
    path=urlparse(self.path).path
    if path=='/backups/restore':
        length=int(self.headers.get('Content-Length','0')); fields=parse_qs(self.rfile.read(length).decode('utf-8')); ip=_real_client_ip(self)
        try:
            if form_value(fields,'confirm_text')!='RESTORE': raise ValueError('يجب كتابة RESTORE لتأكيد الاستعادة')
            msg=restore_backup(form_value(fields,'file'),ip); return self._send(backups_page(msg))
        except Exception as exc: return self._send(backups_page(f'فشل الاستعادة: {exc}'),400)
    if path=='/document-obligations/add':
        length=int(self.headers.get('Content-Length','0')); fields=parse_qs(self.rfile.read(length).decode('utf-8')); ip=_real_client_ip(self)
        try:
            with db() as con:
                _v1051_ensure_schema(con); code=form_value(fields,'document_code'); doc=con.execute("SELECT * FROM document_catalog WHERE code=? AND is_active=1",(code,)).fetchone()
                if not doc: raise ValueError('المستند غير موجود في الدليل المعتمد')
                if not doc['defer_allowed'] or doc['category']=='mandatory': raise ValueError('هذا المستند إلزامي ولا يمكن تأجيله')
                pol=con.execute("SELECT * FROM document_completion_policy WHERE id=1").fetchone(); days=int(form_value(fields,'days',str(pol['default_days'])))
                if days<1 or days>pol['max_days']: raise ValueError(f"المدة يجب أن تكون بين 1 و{pol['max_days']} يوماً")
                if not form_value(fields,'partner_undertaking'): raise ValueError('تعهد الشريك إلزامي لتأجيل المستند')
                due=(dt.date.today()+dt.timedelta(days=days)).isoformat(); cid=int(form_value(fields,'client_id'))
                con.execute("""INSERT INTO outstanding_documents(created_at,client_id,document_name,document_category,status,reason,due_date,responsible_partner,partner_undertaking) VALUES(?,?,?,?,?,?,?,?,?)""",(now_iso(),cid,doc['document_name'],doc['category'],'deferred',form_value(fields,'reason'),due,form_value(fields,'responsible_partner'),1))
                audit(con,'defer_document','client',cid,f"{doc['code']}|{doc['document_name']}|{doc['category']}",ip); con.commit()
            return self._send(document_obligations_page('تم تسجيل المستند المؤجل وفق دليل المستندات المعتمد'))
        except Exception as exc: return self._send(document_obligations_page(f'خطأ: {exc}'),400)
    return _post_pre_v1051(self)
AppHandler.do_POST=_do_post_v1051
# ===== End V10.5.1 =====

# ===== V10.5.2: Separate My Tasks from Administration =====
_base_layout_v1052 = layout
def layout(title: str, body: str, active: str='') -> bytes:  # type: ignore[override]
    raw = _base_layout_v1052(title, body, active).decode('utf-8')
    # Remove the partner dashboard from the Administration dropdown if it was injected by V10.5.1.
    raw = raw.replace('<a href="/partner-dashboard">لوحة مهام الشريك</a>', '')
    # Add a standalone operational navigation item immediately after Home.
    my_tasks_link = f'<a class="{"active" if active == "/partner-dashboard" else ""}" href="/partner-dashboard">مهامي</a>'
    home_pattern = r'(<nav class="main-nav"[^>]*>\s*<a class="[^"]*" href="/">الرئيسية</a>)'
    if 'href="/partner-dashboard">مهامي</a>' not in raw:
        raw = re.sub(home_pattern, r'\1' + my_tasks_link, raw, count=1, flags=re.S)
    return raw.encode('utf-8')

_base_partner_dashboard_page_v1052 = partner_dashboard_page
def partner_dashboard_page(partner: str='') -> bytes:  # type: ignore[override]
    raw = _base_partner_dashboard_page_v1052(partner).decode('utf-8')
    raw = raw.replace('<h2>لوحة مهام الشريك</h2>', '<h2>مهامي</h2>')
    raw = raw.replace('لوحة ديناميكية تعرض فقط العملاء والمشروعات والفحوص والمستندات المسندة للشريك المختار.', 'لوحة تشغيلية ديناميكية تعرض الموافقات والمشروعات والفحوص والمستندات المرتبطة بالمستخدم المختار.')
    raw = raw.replace('<title>لوحة مهام الشريك', '<title>مهامي')
    return raw
# ===== End V10.5.2 =====
# ===== V10.5.4: Authentication, User Menu, Task Filters & Searchable Report Archive =====
import secrets as _secrets
import threading as _threading
from http.cookies import SimpleCookie as _SimpleCookie

APP_VERSION = "V10.5.4 - Authentication + User Menu + Searchable Report Archive"
_AUTH_CTX = _threading.local()
_AUTH_SESSIONS: Dict[str, Dict[str, Any]] = {}

def _auth_hash(password: str, salt_hex: str = "") -> Tuple[str, str]:
    salt = bytes.fromhex(salt_hex) if salt_hex else _secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 180000)
    return salt.hex(), digest.hex()

def _auth_ensure_schema(con: sqlite3.Connection) -> None:
    ensure_schema(con)
    cols = {r[1] for r in con.execute("PRAGMA table_info(app_users)").fetchall()}
    for name, ddl in {
        "password_salt": "TEXT", "password_hash": "TEXT", "must_change_password": "INTEGER NOT NULL DEFAULT 1",
        "last_login_at": "TEXT", "failed_login_attempts": "INTEGER NOT NULL DEFAULT 0", "locked_until": "TEXT"
    }.items():
        if name not in cols:
            con.execute(f"ALTER TABLE app_users ADD COLUMN {name} {ddl}")
    con.execute("CREATE TABLE IF NOT EXISTS user_login_audit(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, user_name TEXT, event_type TEXT NOT NULL, success INTEGER NOT NULL DEFAULT 0, ip_address TEXT, details TEXT)")
    con.execute("CREATE TABLE IF NOT EXISTS report_access_audit(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, report_id INTEGER NOT NULL, user_name TEXT, action TEXT NOT NULL, ip_address TEXT, details TEXT)")
    for u in con.execute("SELECT id,user_name,password_hash FROM app_users").fetchall():
        if not (u['password_hash'] or ''):
            initial = 'Admin@123' if u['user_name']=='admin' else 'ChangeMe@123'
            salt, ph = _auth_hash(initial)
            con.execute("UPDATE app_users SET password_salt=?,password_hash=?,must_change_password=1 WHERE id=?",(salt,ph,u['id']))
    con.commit()

def _cookie_value(handler: AppHandler, key: str) -> str:
    c = _SimpleCookie()
    try: c.load(handler.headers.get('Cookie',''))
    except Exception: return ''
    return c[key].value if key in c else ''

def _session_user(handler: AppHandler) -> Optional[Dict[str, Any]]:
    token = _cookie_value(handler,'masarat_session')
    sess = _AUTH_SESSIONS.get(token)
    if not sess: return None
    if sess.get('expires',0) < dt.datetime.now().timestamp():
        _AUTH_SESSIONS.pop(token,None); return None
    sess['expires'] = dt.datetime.now().timestamp()+8*3600
    return sess.get('user')

def _auth_current_user() -> Optional[Dict[str, Any]]:
    return getattr(_AUTH_CTX,'user',None)

def _auth_send_redirect(handler: AppHandler, location: str, cookie: str='') -> None:
    handler.send_response(303); handler.send_header('Location',location)
    if cookie: handler.send_header('Set-Cookie',cookie)
    handler.end_headers()

def login_page(message: str='') -> bytes:
    msg=f"<div class='error'>{h(message)}</div>" if message else ""
    body=f"""<div class='card' style='max-width:520px;margin:40px auto'><h2>تسجيل الدخول</h2>{msg}
    <p class='notice'>استخدم بيانات الدخول التي سلّمها لك مدير النظام. يجب تغيير كلمة المرور المؤقتة عند أول دخول.</p>
    <form method='post' action='/login'><label>البريد الإلكتروني</label><input name='user_name' required autocomplete='username' placeholder='name@legaltracks.sa'>
    <label>كلمة المرور</label><input type='password' name='password' required autocomplete='current-password'>
    <button style='margin-top:14px'>دخول</button></form></div>"""
    return _base_layout_v1052('تسجيل الدخول',body,'')

def account_page(message: str='') -> bytes:
    u=_auth_current_user() or {}
    msg=f"<div class='success'>{h(message)}</div>" if message else ''
    body=f"""<div class='card'><h2>حسابي</h2>{msg}<table>
    <tr><th>الاسم</th><td>{h(u.get('full_name',''))}</td></tr><tr><th>اسم المستخدم</th><td>{h(u.get('user_name',''))}</td></tr>
    <tr><th>الدور</th><td>{h(u.get('role',''))}</td></tr><tr><th>آخر دخول</th><td>{h(u.get('last_login_at',''))}</td></tr></table></div>
    <div class='card' id='password'><h3>تغيير كلمة المرور</h3><form method='post' action='/account/change-password'>
    <div class='grid'><div><label>كلمة المرور الحالية</label><input type='password' name='current_password' required></div>
    <div><label>كلمة المرور الجديدة</label><input type='password' name='new_password' minlength='8' required></div>
    <div><label>تأكيد كلمة المرور</label><input type='password' name='confirm_password' minlength='8' required></div></div>
    <button>حفظ كلمة المرور</button></form></div>"""
    return layout('حسابي',body,'')

def _user_menu_html() -> str:
    u=_auth_current_user()
    if not u: return ''
    warn = '<span class="user-warning">تغيير كلمة المرور مطلوب</span>' if u.get('must_change_password') else ''
    return f"""<div class='user-menu dropdown'><button class='user-button'>{h(u.get('full_name'))}<small>{h(u.get('role'))}</small> ▼</button>
    <div class='dropdown-content user-dropdown'>{warn}<a href='/account'>ملفي الشخصي</a><a href='/account#password'>تغيير كلمة المرور</a>
    <a href='/audit?user={h(u.get('user_name'))}'>نشاطي</a><a href='/logout'>تسجيل الخروج</a></div></div>"""

_layout_pre_v1054 = layout
def layout(title: str, body: str, active: str='') -> bytes:  # type: ignore[override]
    raw=_layout_pre_v1054(title,body,active).decode('utf-8')
    menu=_user_menu_html()
    if menu: raw=raw.replace('</header>',menu+'</header>',1)
    extra="""<style>header{position:relative}.user-menu{position:absolute;left:18px;top:13px;z-index:1200}.user-button{background:#fff;color:#064e3b;border:1px solid #a7f3d0;border-radius:9px;padding:7px 12px;font-weight:800;min-width:170px;text-align:right}.user-button small{display:block;color:#475569}.user-dropdown{right:auto;left:0;top:48px;min-width:220px}.user-warning{display:block;background:#fef3c7;color:#92400e;padding:8px;border-radius:7px;font-size:12px}.task-filter-bar{display:flex;gap:10px;align-items:end;flex-wrap:wrap}.task-section[hidden]{display:none!important}.archive-filters{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}.archive-actions{display:flex;gap:8px;flex-wrap:wrap}</style>"""
    raw=raw.replace('</head>',extra+'</head>',1)
    return raw.encode('utf-8')

_partner_pre_v1054=partner_dashboard_page
def partner_dashboard_page(partner: str='', task_type: str='all', task_status: str='all') -> bytes:  # type: ignore[override]
    # V10.5.6 fix: حصر معاملات العرض بالقيم المعروفة - كانت قيمة task_type تدرج داخل
    # وسم <script> فتتيح XSS منعكساً عبر رابط معدل.
    if task_type not in {'all','approvals','matters','documents','screenings'}: task_type='all'
    if task_status not in {'all','open','overdue'}: task_status='all'
    u=_auth_current_user()
    if u and u.get('role')=='partner': partner=u.get('full_name','')
    _base_result=_partner_pre_v1054(partner)
    raw=_base_result.decode('utf-8') if isinstance(_base_result,(bytes,bytearray)) else str(_base_result)
    partner_selector=''
    if u and u.get('role') in ('admin','compliance'):
        with db() as con:
            _auth_ensure_schema(con); ps=con.execute("SELECT full_name FROM app_users WHERE role='partner' AND is_active=1 ORDER BY full_name").fetchall()
        po=''.join(f'<option value="{h(r[0])}" {"selected" if r[0]==partner else ""}>{h(r[0])}</option>' for r in ps)
        partner_selector=f'<div><label>المستخدم / الشريك</label><select name="partner">{po}</select></div>'
    filter_html=f"""<form class='task-filter-bar' method='get' action='/partner-dashboard'>{partner_selector}
    <div><label>عرض المهام</label><select name='task_type' onchange='this.form.submit()'>
    <option value='all' {'selected' if task_type=='all' else ''}>جميع المهام</option><option value='approvals' {'selected' if task_type=='approvals' else ''}>الموافقات</option>
    <option value='matters' {'selected' if task_type=='matters' else ''}>المشروعات</option><option value='documents' {'selected' if task_type=='documents' else ''}>المستندات المعلقة</option>
    <option value='screenings' {'selected' if task_type=='screenings' else ''}>نتائج الفحص</option></select></div>
    <div><label>الحالة</label><select name='task_status' onchange='this.form.submit()'><option value='all'>الكل</option><option value='open' {'selected' if task_status=='open' else ''}>مفتوحة</option><option value='overdue' {'selected' if task_status=='overdue' else ''}>متأخرة</option></select></div><button>تطبيق</button></form>"""
    raw=re.sub(r'<form method="get" action="/partner-dashboard">.*?</form>',filter_html,raw,count=1,flags=re.S)
    for label,typ in [('الموافقات المطلوبة','approvals'),('مشاريعي','matters'),('المستندات المعلقة','documents'),('نتائج الفحص المرتبطة بعملائي','screenings')]:
        raw=raw.replace(f'<div class="card"><h3>{label}</h3>',f'<div class="card task-section" data-task-type="{typ}"><h3>{label}</h3>')
    raw += f"<script>(function(){{const type={json.dumps(task_type)};document.querySelectorAll('.task-section').forEach(x=>{{if(type!=='all'&&x.dataset.taskType!==type)x.hidden=true;}});}})();</script>"
    return raw.encode('utf-8')

def reports_archive_page(qs: Dict[str,List[str]]) -> bytes:
    q=(qs.get('q',[''])[0] or '').strip(); status=(qs.get('status',[''])[0] or '').strip(); date_from=(qs.get('date_from',[''])[0] or '').strip(); date_to=(qs.get('date_to',[''])[0] or '').strip()
    params=[]; where=['1=1']
    if q:
        like=f'%{q}%'; where.append("(sr.report_number LIKE ? OR s.subject_name LIKE ? OR s.list_name LIKE ? OR s.matched_name LIKE ? OR c.legal_name LIKE ? OR c.client_code LIKE ? OR m.matter_number LIKE ? OR m.title LIKE ? OR EXISTS(SELECT 1 FROM matter_clients mcx JOIN clients cx ON cx.id=mcx.client_id WHERE mcx.matter_id=sr.matter_id AND (cx.legal_name LIKE ? OR cx.client_code LIKE ?)))"); params += [like]*10
    if status: where.append('sr.decision_status=?'); params.append(status)
    if date_from: where.append('date(sr.created_at)>=date(?)'); params.append(date_from)
    if date_to: where.append('date(sr.created_at)<=date(?)'); params.append(date_to)
    sql=f"""SELECT sr.*,s.subject_name,s.subject_type,s.screening_scope,s.list_name,s.matched_name,s.match_score,s.matched_entity_type AS scr_matched_type,s.status AS scr_status,
    c.legal_name client_name,c.client_code client_code,m.matter_number,m.title matter_title
    FROM screening_reports sr LEFT JOIN screenings s ON s.id=sr.screening_id
    LEFT JOIN clients c ON c.id=sr.client_id
    LEFT JOIN matters m ON m.id=sr.matter_id
    WHERE {' AND '.join(where)} ORDER BY sr.id DESC LIMIT 500"""
    with db() as con:
        _auth_ensure_schema(con); rows=con.execute(sql,params).fetchall()
    tr=[]
    for r in rows:
        tr.append(f"""<tr><td>{h(r['report_number'])}</td><td>{h(r['created_at'])}</td><td>{h(r['client_code'] or '')}</td><td>{auto_dir(r['client_name'] or '')}</td>
        <td>{h(r['matter_number'] or '')}</td><td>{auto_dir(r['matter_title'] or '')}</td><td>{auto_dir(r['subject_name'] or '')}</td><td>{auto_dir(list_display_for_screening(r['screening_scope'], r['list_name'], r['scr_matched_type'], r['scr_status']))}</td>
        <td>{badge_status(r['decision_status'])}</td><td>{h(r['match_score'] if r['match_score'] is not None else '')}</td><td class='archive-actions'><a class='btn secondary' target='_blank' href='/reports/download?id={r['id']}&print=1'>عرض / طباعة PDF</a><a class='btn' href='/reports/download?id={r['id']}&download=1'>حفظ PDF</a></td></tr>""")
    body=f"""<div class='card'><h2>أرشيف تقارير الامتثال</h2><p class='notice'>يمكن فتح التقرير للطباعة مباشرة من المتصفح أو حفظ نسخة PDF. جميع عمليات العرض والحفظ تسجل في سجل التدقيق.</p>
    <form method='get' class='archive-filters'><div><label>بحث</label><input name='q' value='{h(q)}' placeholder='اسم العميل، رقم العميل، المشروع، الطرف أو التقرير'></div>
    <div><label>حالة القرار</label><select name='status'><option value=''>الكل</option><option value='no_match' {'selected' if status=='no_match' else ''}>لا يوجد تطابق</option><option value='list_unavailable' {'selected' if status=='list_unavailable' else ''}>الفحص غير مكتمل</option><option value='potential_match' {'selected' if status=='potential_match' else ''}>تطابق محتمل</option><option value='confirmed_match' {'selected' if status=='confirmed_match' else ''}>تطابق مؤكد</option></select></div>
    <div><label>من تاريخ</label><input type='date' name='date_from' value='{h(date_from)}'></div><div><label>إلى تاريخ</label><input type='date' name='date_to' value='{h(date_to)}'></div><div><button>بحث</button></div></form></div>
    <div class='card'><h3>النتائج ({len(rows)})</h3><div class='table-wrap'><table><thead><tr><th>رقم التقرير</th><th>التاريخ</th><th>رقم العميل</th><th>العميل</th><th>رقم المشروع</th><th>المشروع</th><th>المفحوص</th><th>القائمة</th><th>النتيجة</th><th>الدرجة</th><th>PDF</th></tr></thead><tbody>{''.join(tr) or '<tr><td colspan="11">لا توجد نتائج مطابقة</td></tr>'}</tbody></table></div></div>"""
    return layout('أرشيف تقارير الامتثال',body,'/reports')


_get_pre_v1054=AppHandler.do_GET
def _do_get_v1054(self: AppHandler) -> None:
    parsed=urlparse(self.path); path=parsed.path; qs=parse_qs(parsed.query)
    if path=='/login': return self._send(login_page())
    if path=='/logout':
        token=_cookie_value(self,'masarat_session'); _AUTH_SESSIONS.pop(token,None)
        return _auth_send_redirect(self,'/login','masarat_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict')
    user=_session_user(self)
    if not user: return _auth_send_redirect(self,'/login')
    _AUTH_CTX.user=user
    if user.get('must_change_password') and path not in {'/account','/logout'}:
        return _auth_send_redirect(self,'/account')
    if (path.startswith('/settings') or path.startswith('/production') or path.startswith('/backups')) and user.get('role')!='admin':
        return self._send(layout('غير مصرح','<div class="error">ليس لديك صلاحية للوصول إلى هذه الصفحة.</div>'),403)
    if path=='/account': return self._send(account_page())
    if path=='/partner-dashboard': return self._send(partner_dashboard_page(qs.get('partner',[''])[0],qs.get('task_type',['all'])[0],qs.get('task_status',['all'])[0]))
    if path=='/reports': return self._send(reports_archive_page(qs))
    if path=='/reports/download':
        rid=int(qs.get('id',['0'])[0]); pdf_path, report_number=get_report_file(rid)
        if not pdf_path or not pdf_path.exists(): return self._send(layout('غير موجود','<div class="error">تقرير PDF غير موجود</div>','/reports'),404)
        with db() as con:
            _auth_ensure_schema(con); con.execute("INSERT INTO report_access_audit(created_at,report_id,user_name,action,ip_address,details) VALUES(?,?,?,?,?,?)",(now_iso(),rid,user.get('user_name'),'download' if qs.get('download') else 'view',_real_client_ip(self),report_number)); audit(con,'access_report','screening_report',rid,f"{user.get('user_name')}|{report_number}",_real_client_ip(self)); con.commit()
        return self._send(pdf_path.read_bytes(),200,'application/pdf')
    return _get_pre_v1054(self)
AppHandler.do_GET=_do_get_v1054

_post_pre_v1054=AppHandler.do_POST
def _do_post_v1054(self: AppHandler) -> None:
    path=urlparse(self.path).path
    length=int(self.headers.get('Content-Length','0')); raw=self.rfile.read(length); fields=parse_qs(raw.decode('utf-8',errors='replace'))
    if path=='/login':
        user_name=form_value(fields,'user_name'); password=form_value(fields,'password'); ip=_real_client_ip(self)
        with db() as con:
            _auth_ensure_schema(con); row=con.execute("SELECT * FROM app_users WHERE lower(user_name)=lower(?) AND is_active=1",(user_name,)).fetchone(); ok=False  # V10.5.9: case-insensitive email login
            if row:
                locked_until = row['locked_until'] or ''
                if locked_until:
                    try:
                        if dt.datetime.fromisoformat(locked_until) > dt.datetime.now():
                            con.execute("INSERT INTO user_login_audit(created_at,user_name,event_type,success,ip_address,details) VALUES(?,?,?,?,?,?)",(now_iso(),user_name,'login',0,ip,'account locked'))
                            con.commit()
                            return self._send(login_page('تم قفل الحساب مؤقتاً بسبب تكرار محاولات الدخول غير الصحيحة'),423)
                    except ValueError:
                        pass
                _,ph=_auth_hash(password,row['password_salt'] or '')
                ok=secrets.compare_digest(ph,(row['password_hash'] or ''))
            con.execute("INSERT INTO user_login_audit(created_at,user_name,event_type,success,ip_address,details) VALUES(?,?,?,?,?,?)",(now_iso(),user_name,'login',1 if ok else 0,ip,'successful' if ok else 'invalid credentials'))
            if ok:
                con.execute("UPDATE app_users SET last_login_at=?,failed_login_attempts=0,locked_until=NULL WHERE id=?",(now_iso(),row['id'])); con.commit()
                token=_secrets.token_urlsafe(32); user=dict(row); user['last_login_at']=now_iso(); user['failed_login_attempts']=0; user['locked_until']=None
                _AUTH_SESSIONS[token]={'user':user,'expires':dt.datetime.now().timestamp()+8*3600}
                return _auth_send_redirect(self,'/account' if row['must_change_password'] else ('/partner-dashboard' if row['role']=='partner' else '/'),'masarat_session='+token+'; Path=/; HttpOnly; SameSite=Strict'+_cookie_flags(self))
            if row:
                attempts=int(row['failed_login_attempts'] or 0)+1
                lock_until=(dt.datetime.now()+dt.timedelta(minutes=15)).replace(microsecond=0).isoformat() if attempts>=5 else None
                con.execute("UPDATE app_users SET failed_login_attempts=?,locked_until=? WHERE id=?",(attempts,lock_until,row['id']))
            con.commit()
        return self._send(login_page('اسم المستخدم أو كلمة المرور غير صحيحة'),401)
    user=_session_user(self)
    if not user: return _auth_send_redirect(self,'/login')
    _AUTH_CTX.user=user
    if user.get('must_change_password') and path!='/account/change-password':
        return _auth_send_redirect(self,'/account')
    if (path.startswith('/settings') or path.startswith('/production') or path.startswith('/backups')) and user.get('role')!='admin':
        return self._send(layout('غير مصرح','<div class="error">ليس لديك صلاحية لتنفيذ هذا الإجراء.</div>'),403)
    if path=='/account/change-password':
        cur=form_value(fields,'current_password'); new=form_value(fields,'new_password'); conf=form_value(fields,'confirm_password')
        if new!=conf or len(new)<8: return self._send(account_page('كلمة المرور الجديدة غير متطابقة أو أقل من 8 أحرف'),400)
        with db() as con:
            _auth_ensure_schema(con); row=con.execute("SELECT * FROM app_users WHERE id=?",(user['id'],)).fetchone(); _,curh=_auth_hash(cur,row['password_salt'])
            # V10.5.6 fix: مقارنة ثابتة الزمن كما في تسجيل الدخول.
            if not secrets.compare_digest(curh,(row['password_hash'] or '')): return self._send(account_page('كلمة المرور الحالية غير صحيحة'),400)
            salt,ph=_auth_hash(new); con.execute("UPDATE app_users SET password_salt=?,password_hash=?,must_change_password=0,failed_login_attempts=0,locked_until=NULL WHERE id=?",(salt,ph,user['id'])); audit(con,'change_password','app_user',user['id'],'password changed',_real_client_ip(self)); con.commit(); user['must_change_password']=0
            current_token=_cookie_value(self,'masarat_session')
            for token,sess in list(_AUTH_SESSIONS.items()):
                if token!=current_token and (sess.get('user') or {}).get('id')==user['id']:
                    _AUTH_SESSIONS.pop(token,None)
        return self._send(account_page('تم تغيير كلمة المرور بنجاح'))
    from io import BytesIO as _BytesIO
    self.rfile=_BytesIO(raw)
    return _post_pre_v1054(self)
AppHandler.do_POST=_do_post_v1054
# ===== End V10.5.4 =====



# ---------------------------------------------------------------------------
# V10.5.5 - Identifier-first screening, multi-token name controls,
# printable/savable PDF responses, and readable Excel sanctions export.
# ---------------------------------------------------------------------------
APP_VERSION = "V10.5.5 - Identifier & Multi-Token Screening + Excel Export"


def build_sanctions_export_xlsx(list_name: str = "") -> Tuple[bytes, int]:
    try:
        from openpyxl import Workbook  # type: ignore
        from openpyxl.styles import Alignment, Font, PatternFill, Border, Side  # type: ignore
        from openpyxl.worksheet.table import Table, TableStyleInfo  # type: ignore
    except Exception as exc:
        raise RuntimeError("تصدير Excel يتطلب تثبيت openpyxl من ملف requirements.txt") from exc
    with db() as con:
        ensure_schema(con)
        params: List[Any] = []
        where = "WHERE active=1"
        if list_name:
            where += " AND list_name=?"; params.append(list_name)
        rows = con.execute(f"""SELECT id, created_at, list_name, list_type, full_name, id_number,
            registration_number, nationality, country, source_url, notes, active
            FROM sanctions_entries {where} ORDER BY list_name, full_name, id""", params).fetchall()
        summary = con.execute(f"SELECT list_name, COUNT(*) c FROM sanctions_entries {where} GROUP BY list_name ORDER BY list_name", params).fetchall()

    wb = Workbook()
    ws = wb.active; ws.title = "القوائم النشطة"; ws.sheet_view.rightToLeft = True
    headers = ["التسلسل", "اسم القائمة", "نوع القائمة", "الاسم الكامل", "رقم الهوية/الجواز", "رقم السجل/الكيان", "الجنسية", "الدولة", "رابط المصدر", "الملاحظات", "تاريخ الإدخال", "الحالة"]
    ws.append(headers)
    for i, r in enumerate(rows, 1):
        ws.append([i, r["list_name"], r["list_type"], r["full_name"], r["id_number"] or "", r["registration_number"] or "", r["nationality"] or "", r["country"] or "", r["source_url"] or "", r["notes"] or "", r["created_at"], "نشط" if r["active"] else "غير نشط"])
    header_fill = PatternFill("solid", fgColor="0F766E")
    header_font = Font(color="FFFFFF", bold=True)
    thin = Side(style="thin", color="94A3B8")
    for cell in ws[1]:
        cell.fill = header_fill; cell.font = header_font; cell.alignment = Alignment(horizontal="center", vertical="center"); cell.border = Border(bottom=thin)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(horizontal="right", vertical="top", wrap_text=True)
    ws.freeze_panes = "A2"; ws.auto_filter.ref = ws.dimensions
    widths = [10, 24, 14, 36, 22, 22, 18, 18, 42, 48, 20, 12]
    for col, width in enumerate(widths, 1): ws.column_dimensions[chr(64+col)].width = width
    if rows:
        tab = Table(displayName="ActiveSanctionsTable", ref=f"A1:L{len(rows)+1}")
        tab.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True, showColumnStripes=False)
        ws.add_table(tab)

    sm = wb.create_sheet("ملخص"); sm.sheet_view.rightToLeft = True
    sm.append(["اسم القائمة", "عدد السجلات النشطة"])
    for r in summary: sm.append([r["list_name"], r["c"]])
    sm.append([]); sm.append(["تاريخ التصدير", now_iso()]); sm.append(["معيار البحث", "قائمة محددة" if list_name else "جميع القوائم النشطة"]); sm.append(["اسم القائمة المحددة", list_name or "الكل"])
    for cell in sm[1]: cell.fill=header_fill; cell.font=header_font; cell.alignment=Alignment(horizontal="center")
    sm.column_dimensions["A"].width=34; sm.column_dimensions["B"].width=22; sm.freeze_panes="A2"
    out = io.BytesIO(); wb.save(out)
    return out.getvalue(), len(rows)


_lists_page_pre_v1055 = lists_page
def lists_page(message: str = "") -> bytes:  # type: ignore[override]
    raw = _lists_page_pre_v1055(message).decode("utf-8")
    export_card = '<div class="card"><div class="section-title"><div><h3>تصدير القوائم للبحث اليدوي</h3><p class="small">ينشئ ملف Excel مقروءاً يحتوي جميع السجلات النشطة، الأرقام المميزة، اسم القائمة، المصدر، والملاحظات، مع فلاتر وتجميد صف العناوين.</p></div><a class="btn" href="/lists/export.xlsx">تصدير جميع القوائم إلى Excel</a></div></div>'
    marker = '<div class="card"><div class="section-title"><h3>المصادر الرسمية</h3>'
    raw = raw.replace(marker, export_card + marker, 1)
    return raw.encode("utf-8")


_official_list_cards_pre_v1055 = official_list_cards
def official_list_cards() -> str:  # type: ignore[override]
    raw = _official_list_cards_pre_v1055()
    # يضاف زر تصدير بجانب كل كود قائمة دون تغيير وظائف الرفع/التحديث.
    for src in OFFICIAL_LIST_SOURCES:
        needle = f'<span><b>الكود:</b> <span dir="ltr">{h(src["code"])}</span></span>'
        replacement = needle + f'<span><a class="btn secondary" href="/lists/export.xlsx?list_name={h(src["code"])}">Excel</a></span>'
        raw = raw.replace(needle, replacement, 1)
    return raw


def _send_binary_with_disposition(handler: AppHandler, data: bytes, content_type: str, filename: str, disposition: str = "attachment") -> None:
    from urllib.parse import quote
    ascii_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", filename) or "download.bin"
    handler.send_response(200)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Content-Disposition", f"{disposition}; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(filename)}")
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.send_header("Cache-Control", "private, no-store")
    handler.end_headers(); handler.wfile.write(data)


_get_pre_v1055 = AppHandler.do_GET
def _do_get_v1055(self: AppHandler) -> None:
    parsed = urlparse(self.path); path = parsed.path; qs = parse_qs(parsed.query)
    if path not in {"/lists/export.xlsx", "/reports/download"}:
        return _get_pre_v1055(self)
    user = _session_user(self)
    if not user: return _auth_send_redirect(self, "/login")
    _AUTH_CTX.user = user
    if user.get("must_change_password"): return _auth_send_redirect(self, "/account")
    if path == "/lists/export.xlsx":
        list_name = (qs.get("list_name", [""])[0] or "").strip()
        try:
            content, count = build_sanctions_export_xlsx(list_name)
        except Exception as exc:
            return self._send(layout("خطأ التصدير", f"<div class='error'>{h(exc)}</div>", "/lists"), 500)
        with db() as con:
            audit(con, "export_sanctions_excel", "sanctions_list", 0, f"list={list_name or 'ALL'}; rows={count}; user={user.get('user_name')}", _real_client_ip(self)); con.commit()
        name = f"sanctions_{list_name or 'all_active'}_{dt.datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
        return _send_binary_with_disposition(self, content, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", name, "attachment")
    rid = int(qs.get("id", ["0"])[0]); pdf_path, report_number = get_report_file(rid)
    if not pdf_path or not pdf_path.exists():
        return self._send(layout("غير موجود", "<div class='error'>تقرير PDF غير موجود</div>", "/reports"), 404)
    action = "download" if qs.get("download") else "print_view" if qs.get("print") else "view"
    with db() as con:
        _auth_ensure_schema(con)
        con.execute("INSERT INTO report_access_audit(created_at,report_id,user_name,action,ip_address,details) VALUES(?,?,?,?,?,?)", (now_iso(),rid,user.get("user_name"),action,_real_client_ip(self),report_number))
        audit(con,"access_report","screening_report",rid,f"{user.get('user_name')}|{report_number}|{action}",_real_client_ip(self)); con.commit()
    disposition = "attachment" if qs.get("download") else "inline"
    return _send_binary_with_disposition(self, pdf_path.read_bytes(), "application/pdf", f"{report_number}.pdf", disposition)

AppHandler.do_GET = _do_get_v1055

# ---------------------------------------------------------------------------
# V10.5.6 - Bulk candidate screening (الفحص الجماعي), access-control hardening,
# session freshness, request-size limits, and safer audit access.
# ---------------------------------------------------------------------------
APP_VERSION = "V10.5.6 - Bulk Screening + Coherence Hardening"

BULK_MAX_ROWS = 2000
BULK_MAX_MATCHES_PER_ROW = 15
MAX_REQUEST_BYTES = 50 * 1024 * 1024


def _v1056_ensure_schema(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS bulk_screening_runs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        created_by TEXT DEFAULT '',
        source TEXT DEFAULT 'paste',
        source_filename TEXT DEFAULT '',
        file_sha256 TEXT DEFAULT '',
        screening_mode TEXT DEFAULT 'both',
        total_rows INTEGER DEFAULT 0,
        screened_rows INTEGER DEFAULT 0,
        error_rows INTEGER DEFAULT 0,
        hit_rows INTEGER DEFAULT 0,
        red_rows INTEGER DEFAULT 0,
        yellow_rows INTEGER DEFAULT 0,
        green_rows INTEGER DEFAULT 0,
        lists_available INTEGER DEFAULT 1,
        active_entries INTEGER DEFAULT 0,
        active_lists INTEGER DEFAULT 0,
        notes TEXT DEFAULT '')""")
    con.execute("""CREATE TABLE IF NOT EXISTS bulk_screening_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id INTEGER NOT NULL,
        row_number INTEGER DEFAULT 0,
        subject_name TEXT NOT NULL,
        id_number TEXT DEFAULT '',
        registration_number TEXT DEFAULT '',
        entity_category TEXT DEFAULT '',
        country TEXT DEFAULT '',
        nationality TEXT DEFAULT '',
        reference TEXT DEFAULT '',
        top_score INTEGER DEFAULT 0,
        result_status TEXT DEFAULT 'no_match',
        visual TEXT DEFAULT 'أخضر',
        required_action TEXT DEFAULT '',
        match_count INTEGER DEFAULT 0,
        matches_json TEXT DEFAULT '[]',
        row_error TEXT DEFAULT '',
        FOREIGN KEY(run_id) REFERENCES bulk_screening_runs(id))""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_bulk_items_run ON bulk_screening_items(run_id)")
    con.commit()


_BULK_FIELD_ALIASES = {
    "subject_name": ["الاسم", "الاسم الكامل", "اسم العميل", "اسم الطرف", "اسم الشخص", "اسم الكيان",
                     "full name", "full_name", "name", "subject name", "legal name", "legal_name", "client name"],
    "id_number": ["رقم الهوية", "رقم الإقامة", "رقم الاقامة", "رقم الجواز", "رقم جواز السفر",
                  "رقم الهوية/الإقامة/الجواز", "رقم الهوية الإقامة الجواز", "id number", "id_number",
                  "national id", "passport", "passport number", "iqama"],
    "registration_number": ["السجل التجاري", "رقم السجل التجاري", "رقم السجل", "رقم الكيان",
                            "السجل التجاري/الكيان", "رقم السجل التجاري/الكيان", "registration number",
                            "registration_number", "cr number", "cr", "entity number", "commercial registration"],
    "entity_category": ["النوع", "نوع الكيان", "نوع الشخص", "نوع الشخص/الكيان", "التصنيف", "الفئة",
                        "category", "entity category", "type", "entity type"],
    "country": ["الدولة", "البلد", "country"],
    "nationality": ["الجنسية", "nationality"],
    "reference": ["المرجع", "مرجع", "ملاحظات", "reference", "notes", "ref"],
}
_BULK_HEADER_MAP = {}
for _canon, _aliases in _BULK_FIELD_ALIASES.items():
    for _a in _aliases:
        _BULK_HEADER_MAP[_normalize_header(_a)] = _canon


def _bulk_category_code(value: Any) -> str:
    v = normalize_name(str(value or ""))
    if not v:
        return ""
    if v in {"individual", "فرد", "شخص", "فردي", "person"} or "فرد" in v or "شخص" in v or "individual" in v or "person" in v:
        return "individual"
    if "حكوم" in v or "government" in v:
        return "government"
    if ("شرك" in v or "مؤسس" in v or "كيان" in v or "company" in v or "entity" in v or "corp" in v
            or "establishment" in v or "organisation" in v or "organization" in v):
        return "company"
    return "other"


def _bulk_subject_from_cells(cells: List[str], row_number: int) -> Dict[str, Any]:
    def cell(i: int) -> str:
        return cells[i].strip() if i < len(cells) and cells[i] is not None else ""
    return {
        "row_number": row_number,
        "subject_name": cell(0),
        "id_number": cell(1),
        "registration_number": cell(2),
        "entity_category": _bulk_category_code(cell(3)),
        "country": cell(4),
        "nationality": cell(5),
        "reference": cell(6),
    }


def parse_bulk_paste(text: str) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """كل سطر: الاسم، رقم الهوية، رقم السجل، النوع، الدولة، الجنسية، المرجع - بفاصلة أو Tab أو |."""
    subjects: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    for n, line in enumerate(str(text or "").splitlines(), start=1):
        line = line.strip()
        if not line:
            continue
        delim = "\t" if "\t" in line else ("|" if "|" in line else (";" if ";" in line else ","))
        cells = [c.strip() for c in line.split(delim)]
        if n == 1 and cells and _BULK_HEADER_MAP.get(_normalize_header(cells[0])) == "subject_name":
            continue  # سطر عناوين منسوخ من القالب
        sub = _bulk_subject_from_cells(cells, n)
        if not sub["subject_name"]:
            errors.append({"row": n, "error": "الاسم مطلوب في بداية السطر"})
            continue
        subjects.append(sub)
    return subjects, errors


def parse_bulk_file(filename: str, content: bytes) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    raw_rows = _read_tabular(filename, content)
    subjects: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    for n, raw in enumerate(raw_rows, start=2):
        mapped: Dict[str, str] = {}
        unmapped_values: List[str] = []
        for k, v in raw.items():
            canon = _BULK_HEADER_MAP.get(_normalize_header(k))
            val = str(v if v is not None else "").strip()
            if canon and val and not mapped.get(canon):
                mapped[canon] = val
            elif not canon and val:
                unmapped_values.append(val)
        if not mapped.get("subject_name") and unmapped_values:
            # ملف بدون رؤوس معروفة: أول عمود غير فارغ يعامل كاسم.
            mapped.setdefault("subject_name", unmapped_values[0])
        if not mapped.get("subject_name"):
            errors.append({"row": n, "error": "تعذر تحديد عمود الاسم؛ استخدم القالب الرسمي"})
            continue
        subjects.append({
            "row_number": n,
            "subject_name": mapped.get("subject_name", ""),
            "id_number": mapped.get("id_number", ""),
            "registration_number": mapped.get("registration_number", ""),
            "entity_category": _bulk_category_code(mapped.get("entity_category", "")),
            "country": mapped.get("country", ""),
            "nationality": mapped.get("nationality", ""),
            "reference": mapped.get("reference", ""),
        })
    return subjects, errors


def _bulk_match_subject(subject: Dict[str, Any], internal_entities: List[Dict[str, Any]],
                        sanctions_rows: List[sqlite3.Row], screening_mode: str) -> List[Dict[str, Any]]:
    matches: List[Dict[str, Any]] = []
    if screening_mode in {"internal", "both"}:
        for ent in internal_entities:
            score, reason = match_score(
                subject["subject_name"], ent["matched_name"], subject.get("id_number", ""), ent.get("id_number", ""),
                subject.get("registration_number", ""), ent.get("registration_number", ""),
                subject.get("entity_category", ""), ent.get("entity_category", ""))
            if score >= 75:
                matches.append({"scope": "internal", "list_name": "INTERNAL_REGISTRY",
                                "matched_name": ent["matched_name"], "matched_entity_type": ent["matched_entity_type"],
                                "matched_entity_id": ent["matched_entity_id"], "score": score, "reason": reason,
                                "status": status_for_score(score, reason)})
    if screening_mode in {"sanctions", "both"}:
        for se in sanctions_rows:
            cat = "company" if se["registration_number"] else ""
            score, reason = match_score(
                subject["subject_name"], se["full_name"], subject.get("id_number", ""), se["id_number"] or "",
                subject.get("registration_number", ""), se["registration_number"] or "",
                subject.get("entity_category", ""), cat)
            if score >= 75:
                matches.append({"scope": "sanctions", "list_name": se["list_name"],
                                "matched_name": se["full_name"], "matched_entity_type": "sanctions_entry",
                                "matched_entity_id": se["id"], "score": score, "reason": reason,
                                "status": status_for_score(score, reason)})
    matches.sort(key=lambda m: int(m.get("score") or 0), reverse=True)
    return matches


def _bulk_row_status(matches: List[Dict[str, Any]], lists_available: bool, screening_mode: str) -> Tuple[int, str]:
    max_score = int(matches[0]["score"]) if matches else 0
    if matches:
        if any(m["status"] == "confirmed_match" for m in matches):
            return max_score, "confirmed_match"
        if max_score >= 90:
            return max_score, "high_similarity"
        return max_score, "potential_match"
    if screening_mode in {"sanctions", "both"} and not lists_available:
        return 0, "list_unavailable"
    return 0, "no_match"


def run_bulk_screening(subjects: List[Dict[str, Any]], parse_errors: List[Dict[str, Any]], *,
                       source: str, source_filename: str = "", file_sha256: str = "",
                       screening_mode: str = "both", created_by: str = "", ip: str = "") -> int:
    if not subjects:
        raise ValueError("لا توجد أسماء صالحة للفحص؛ أضف الأسماء بالصيغة الموضحة أو استخدم القالب")
    if len(subjects) > BULK_MAX_ROWS:
        raise ValueError(f"الحد الأقصى للفحص الجماعي في العملية الواحدة {BULK_MAX_ROWS} صفاً؛ قسّم الملف على دفعات")
    if screening_mode not in {"both", "sanctions", "internal"}:
        screening_mode = "both"
    with db() as con:
        ensure_schema(con)
        _v1056_ensure_schema(con)
        internal_entities = all_internal_entities(con) if screening_mode in {"internal", "both"} else []
        sanctions_rows = (con.execute("SELECT * FROM sanctions_entries WHERE active=1 ORDER BY list_name, id").fetchall()
                          if screening_mode in {"sanctions", "both"} else [])
        active_lists = len({str(r["list_name"] or "") for r in sanctions_rows})
        lists_available = bool(sanctions_rows)
        cur = con.execute("""INSERT INTO bulk_screening_runs(created_at,created_by,source,source_filename,file_sha256,
            screening_mode,total_rows,screened_rows,error_rows,lists_available,active_entries,active_lists,notes)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (now_iso(), created_by, source, source_filename, file_sha256, screening_mode,
             len(subjects) + len(parse_errors), 0, len(parse_errors), 1 if lists_available else 0,
             len(sanctions_rows), active_lists,
             json.dumps({"parse_errors": parse_errors[:200]}, ensure_ascii=False) if parse_errors else ""))
        run_id = int(cur.lastrowid)
        hit_rows = red_rows = yellow_rows = green_rows = 0
        for sub in subjects:
            matches = _bulk_match_subject(sub, internal_entities, sanctions_rows, screening_mode)
            top_score, status = _bulk_row_status(matches, lists_available, screening_mode)
            _, visual, required_action = risk_visual_for_screening(status, top_score)
            if matches:
                hit_rows += 1
            if visual == "أحمر":
                red_rows += 1
            elif visual == "أصفر":
                yellow_rows += 1
            else:
                green_rows += 1
            kept = matches[:BULK_MAX_MATCHES_PER_ROW]
            con.execute("""INSERT INTO bulk_screening_items(run_id,row_number,subject_name,id_number,registration_number,
                entity_category,country,nationality,reference,top_score,result_status,visual,required_action,
                match_count,matches_json,row_error) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (run_id, sub.get("row_number", 0), sub["subject_name"], sub.get("id_number", ""),
                 sub.get("registration_number", ""), sub.get("entity_category", ""), sub.get("country", ""),
                 sub.get("nationality", ""), sub.get("reference", ""), top_score, status, visual, required_action,
                 len(matches), json.dumps(kept, ensure_ascii=False), ""))
        for err in parse_errors[:500]:
            con.execute("""INSERT INTO bulk_screening_items(run_id,row_number,subject_name,top_score,result_status,
                visual,required_action,match_count,matches_json,row_error) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (run_id, int(err.get("row") or 0), str(err.get("name") or "-"), 0, "failed", "أحمر",
                 "صحح الصف وأعد الفحص", 0, "[]", str(err.get("error") or "")[:300]))
        con.execute("""UPDATE bulk_screening_runs SET screened_rows=?, hit_rows=?, red_rows=?, yellow_rows=?, green_rows=?
            WHERE id=?""", (len(subjects), hit_rows, red_rows, yellow_rows, green_rows, run_id))
        audit(con, "bulk_screening", "screening", run_id,
              f"source={source}; rows={len(subjects)}; errors={len(parse_errors)}; hits={hit_rows}; "
              f"red={red_rows}; yellow={yellow_rows}; lists_available={lists_available}; user={created_by}", ip)
        con.commit()
    return run_id


def _bulk_scope_label(scope: str) -> str:
    return "السجل الداخلي" if scope == "internal" else "قوائم العقوبات"


def _bulk_mode_label(mode: str) -> str:
    return {"both": "القوائم والسجل الداخلي", "sanctions": "قوائم العقوبات فقط", "internal": "السجل الداخلي فقط"}.get(mode, mode)


def bulk_screen_page(message: str = "", is_error: bool = False) -> bytes:
    with db() as con:
        ensure_schema(con)
        _v1056_ensure_schema(con)
        runs = con.execute("SELECT * FROM bulk_screening_runs ORDER BY id DESC LIMIT 30").fetchall()
        active_n = con.execute("SELECT COUNT(*) FROM sanctions_entries WHERE active=1").fetchone()[0]
    msg = ""
    if message:
        cls = "error" if is_error else "success"
        msg = f"<div class='{cls}'>{h(message)}</div>"
    lists_note = "" if active_n else "<div class='error'>لا توجد قوائم نشطة حالياً: أي فحص جماعي الآن سيصدر بحالة \"الفحص غير مكتمل\" وفق الضابط الرقابي. ارفع القوائم الرسمية أولاً من صفحة القوائم.</div>"
    rows = ""
    for r in runs:
        rows += (f"<tr><td>{r['id']}</td><td>{h(r['created_at'])}</td><td>{auto_dir(r['created_by'] or '-')}</td>"
                 f"<td>{h({'paste': 'لصق مباشر', 'file': 'ملف', 'quick': 'فحص سريع'}.get(r['source'], r['source']))}</td>"
                 f"<td dir='auto'>{h(r['source_filename'] or '-')}</td><td>{h(_bulk_mode_label(r['screening_mode']))}</td>"
                 f"<td>{r['screened_rows']}</td><td>{r['hit_rows']}</td>"
                 f"<td><span class='badge danger'>{r['red_rows']}</span> <span class='badge warn'>{r['yellow_rows']}</span> <span class='badge ok'>{r['green_rows']}</span></td>"
                 f"<td>{'نعم' if r['lists_available'] else '<b>لا</b>'}</td>"
                 f"<td class='archive-actions'><a class='btn secondary' href='/bulk_screen/results?id={r['id']}'>النتائج</a>"
                 f"<a class='btn' href='/bulk_screen/export.xlsx?id={r['id']}'>Excel</a></td></tr>")
    body = f"""
<div class="card"><h2>الفحص الجماعي (دفعة واحدة)</h2>{msg}{lists_note}
<p class="notice">يفحص عدة أسماء دفعة واحدة ضد القوائم النشطة والسجل الداخلي بنفس معايير V10.5.5: الأرقام المميزة أولاً بعد توحيد الأرقام العربية واللاتينية وإزالة المسافات والشرطات، ثم قاعدة المقطعين المتصلين لأسماء الأشخاص، واستبعاد الصفة القانونية العامة لأسماء الكيانات. تحفظ كل عملية بسجل قابل للتصدير Excel وسجل تدقيق. الحد الأقصى {BULK_MAX_ROWS} صف في العملية الواحدة.</p>
<div class="grid">
<section class="card"><h3>الخيار 1: رفع ملف Excel أو CSV</h3>
<form method="post" action="/bulk_screen/run" enctype="multipart/form-data">
<label>ملف الأسماء (CSV / XLSX)</label><input required type="file" name="bulk_file" accept=".csv,.xlsx,.xlsm">
<label>نطاق الفحص</label><select name="screening_mode"><option value="both">القوائم والسجل الداخلي</option><option value="sanctions">قوائم العقوبات فقط</option><option value="internal">السجل الداخلي فقط</option></select>
<button>تشغيل الفحص الجماعي من الملف</button></form>
<p class="small"><a class="btn secondary" href="/bulk_screen/template.xlsx">تنزيل قالب Excel الرسمي</a></p>
<p class="small">الأعمدة المدعومة: الاسم الكامل (إلزامي)، رقم الهوية/الإقامة/الجواز، رقم السجل التجاري/الكيان، نوع الكيان، الدولة، الجنسية، المرجع.</p></section>
<section class="card"><h3>الخيار 2: لصق الأسماء مباشرة</h3>
<form method="post" action="/bulk_screen/run">
<label>سطر لكل اسم: الاسم، رقم الهوية، رقم السجل، النوع، الدولة، الجنسية، المرجع</label>
<textarea name="bulk_text" rows="8" placeholder="محمد أحمد العتيبي, 1077889911\nشركة النور للتجارة,,4030112233, شركة\nJohn Smith, A1234567,, فرد"></textarea>
<label>نطاق الفحص</label><select name="screening_mode"><option value="both">القوائم والسجل الداخلي</option><option value="sanctions">قوائم العقوبات فقط</option><option value="internal">السجل الداخلي فقط</option></select>
<button>تشغيل الفحص الجماعي من النص</button></form>
<p class="small">يكفي الاسم وحده؛ الحقول الأخرى اختيارية وتفصل بفاصلة أو Tab أو |. تتجاهل المعالجة سطر العناوين إذا نسخته من القالب.</p></section>
</div></div>
<div class="card"><h3>سجل عمليات الفحص الجماعي</h3><div class="table-wrap"><table><thead>
<tr><th>#</th><th>التاريخ</th><th>المستخدم</th><th>المصدر</th><th>الملف</th><th>النطاق</th><th>المفحوص</th><th>صفوف بتطابق</th><th>أحمر/أصفر/أخضر</th><th>القوائم نشطة؟</th><th>إجراءات</th></tr></thead>
<tbody>{rows or '<tr><td colspan="11">لا توجد عمليات فحص جماعي بعد</td></tr>'}</tbody></table></div></div>"""
    return layout("الفحص الجماعي", body, "/bulk_screen")


def bulk_run_results_page(run_id: int) -> bytes:
    with db() as con:
        ensure_schema(con)
        _v1056_ensure_schema(con)
        run = con.execute("SELECT * FROM bulk_screening_runs WHERE id=?", (run_id,)).fetchone()
        if not run:
            return layout("غير موجود", "<div class='error'>عملية الفحص الجماعي غير موجودة</div>", "/bulk_screen")
        items = con.execute("SELECT * FROM bulk_screening_items WHERE run_id=? ORDER BY CASE visual WHEN 'أحمر' THEN 0 WHEN 'أصفر' THEN 1 ELSE 2 END, top_score DESC, row_number", (run_id,)).fetchall()
    warn_banner = "" if run["lists_available"] else "<div class='error'>تنفيذ رقابي: لم تكن هناك قوائم نشطة وقت الفحص، لذلك لا يجوز اعتماد أي نتيجة \"لا يوجد تطابق\" من هذه العملية. الحالة الصادرة: الفحص غير مكتمل. ارفع القوائم الرسمية وأعد الفحص.</div>"
    rows = ""
    for it in items:
        match_html = "-"
        if it["row_error"]:
            match_html = f"<span class='badge danger'>خطأ صف</span> {h(it['row_error'])}"
        elif it["match_count"]:
            try:
                matches = json.loads(it["matches_json"] or "[]")
            except Exception:
                matches = []
            inner = "".join(
                f"<tr><td>{h(_bulk_scope_label(m.get('scope', '')))}</td><td>{auto_dir(m.get('list_name') or '-')}</td>"
                f"<td>{auto_dir(m.get('matched_name') or '-')}</td><td>{int(m.get('score') or 0)}</td>"
                f"<td>{h(m.get('reason') or '')}</td><td>{badge_status(m.get('status') or '')}</td></tr>"
                for m in matches)
            extra = f"<p class='small'>عرضت أعلى {len(matches)} من أصل {it['match_count']} تطابقاً؛ التفاصيل الكاملة في ملف Excel.</p>" if it["match_count"] > len(matches) else ""
            match_html = (f"<details><summary>{it['match_count']} تطابق - اعرض التفاصيل</summary>"
                          f"<table><thead><tr><th>النطاق</th><th>القائمة</th><th>الاسم المطابق</th><th>الدرجة</th><th>السبب</th><th>الحالة</th></tr></thead>"
                          f"<tbody>{inner}</tbody></table>{extra}</details>")
        rows += (f"<tr class='status-{ {'أحمر': 'red', 'أصفر': 'yellow'}.get(it['visual'], 'green') }'>"
                 f"<td>{it['row_number'] or '-'}</td><td>{auto_dir(it['subject_name'])}</td>"
                 f"<td dir='ltr'>{h(it['id_number'] or '')}</td><td dir='ltr'>{h(it['registration_number'] or '')}</td>"
                 f"<td>{h(client_type_label(it['entity_category']) if it['entity_category'] else '-')}</td>"
                 f"<td>{it['top_score']}</td><td>{badge_status(it['result_status'])}</td>"
                 f"<td>{badge_status(it['visual'])}</td><td>{h(it['required_action'])}</td><td>{match_html}</td></tr>")
    body = f"""
<div class="card"><div class="section-title"><div><h2>نتائج الفحص الجماعي رقم {run['id']}</h2>
<p class="small">التاريخ: {h(run['created_at'])} | المستخدم: {h(run['created_by'] or '-')} | النطاق: {h(_bulk_mode_label(run['screening_mode']))} | المصدر: {h(run['source_filename'] or run['source'])}</p></div>
<div class="archive-actions"><a class="btn" href="/bulk_screen/export.xlsx?id={run['id']}">تصدير النتائج Excel</a><a class="btn secondary" href="/bulk_screen">فحص جماعي جديد</a></div></div>
{warn_banner}
<div class="grid">
<div class="card kpi"><div class="num">{run['screened_rows']}</div><div>صفوف مفحوصة</div></div>
<div class="card kpi"><div class="num">{run['red_rows']}</div><div>أحمر: تطابق مؤكد</div></div>
<div class="card kpi"><div class="num">{run['yellow_rows']}</div><div>أصفر: يتطلب مراجعة</div></div>
<div class="card kpi"><div class="num">{run['green_rows']}</div><div>أخضر: لا تطابق مؤثر</div></div>
<div class="card kpi"><div class="num">{run['error_rows']}</div><div>صفوف مرفوضة</div></div>
</div>
<p class="notice">فحصت هذه العملية ضد {run['active_entries']} سجلاً نشطاً في {run['active_lists']} قائمة. الصفوف الحمراء تعرض أولاً ثم الصفراء. القرار النهائي لأي تطابق يبقى لمسؤول الامتثال.</p>
<div class="table-wrap"><table><thead><tr><th>الصف</th><th>الاسم</th><th>رقم الهوية</th><th>رقم السجل</th><th>النوع</th><th>أعلى درجة</th><th>الحالة</th><th>المؤشر</th><th>الإجراء المطلوب</th><th>التطابقات</th></tr></thead>
<tbody>{rows or '<tr><td colspan="10">لا توجد صفوف</td></tr>'}</tbody></table></div></div>"""
    return layout(f"نتائج الفحص الجماعي {run['id']}", body, "/bulk_screen")


def build_bulk_results_xlsx(run_id: int) -> Tuple[bytes, str]:
    try:
        from openpyxl import Workbook  # type: ignore
        from openpyxl.styles import Alignment, Font, PatternFill, Side, Border  # type: ignore
    except Exception as exc:
        raise RuntimeError("تصدير Excel يتطلب تثبيت openpyxl من ملف requirements.txt") from exc
    with db() as con:
        ensure_schema(con)
        _v1056_ensure_schema(con)
        run = con.execute("SELECT * FROM bulk_screening_runs WHERE id=?", (run_id,)).fetchone()
        if not run:
            raise ValueError("عملية الفحص الجماعي غير موجودة")
        items = con.execute("SELECT * FROM bulk_screening_items WHERE run_id=? ORDER BY CASE visual WHEN 'أحمر' THEN 0 WHEN 'أصفر' THEN 1 ELSE 2 END, top_score DESC, row_number", (run_id,)).fetchall()
    wb = Workbook()
    header_fill = PatternFill("solid", fgColor="0F766E")
    header_font = Font(color="FFFFFF", bold=True)
    fills = {"أحمر": PatternFill("solid", fgColor="FEE2E2"), "أصفر": PatternFill("solid", fgColor="FEF3C7"),
             "أخضر": PatternFill("solid", fgColor="DCFCE7")}
    thin = Side(style="thin", color="94A3B8")

    ws = wb.active
    ws.title = "النتائج"
    ws.sheet_view.rightToLeft = True
    headers = ["الصف", "الاسم", "رقم الهوية/الجواز", "رقم السجل/الكيان", "النوع", "الدولة", "الجنسية", "المرجع",
               "أعلى درجة", "الحالة", "المؤشر", "الإجراء المطلوب", "عدد التطابقات", "أهم تطابق", "قائمة أهم تطابق", "سبب أهم تطابق", "خطأ الصف"]
    ws.append(headers)
    for it in items:
        try:
            top = (json.loads(it["matches_json"] or "[]") or [{}])[0]
        except Exception:
            top = {}
        ws.append([it["row_number"], it["subject_name"], it["id_number"] or "", it["registration_number"] or "",
                   status_text_ar(it["entity_category"]) if False else (it["entity_category"] or ""), it["country"] or "",
                   it["nationality"] or "", it["reference"] or "", it["top_score"], status_text_ar(it["result_status"]),
                   it["visual"], it["required_action"], it["match_count"], top.get("matched_name", ""),
                   top.get("list_name", ""), top.get("reason", ""), it["row_error"] or ""])
        fill = fills.get(it["visual"])
        if fill:
            for cell in ws[ws.max_row]:
                cell.fill = fill
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = Border(bottom=thin)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(horizontal="right", vertical="top", wrap_text=True)
    widths = [8, 34, 20, 20, 12, 14, 14, 16, 12, 22, 10, 40, 12, 32, 20, 46, 28]
    for col, width in enumerate(widths, 1):
        ws.column_dimensions[ws.cell(row=1, column=col).column_letter].width = width
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    wm = wb.create_sheet("كل التطابقات")
    wm.sheet_view.rightToLeft = True
    wm.append(["الصف", "الاسم المفحوص", "النطاق", "القائمة", "الاسم المطابق", "الدرجة", "السبب", "الحالة"])
    for it in items:
        try:
            matches = json.loads(it["matches_json"] or "[]")
        except Exception:
            matches = []
        for m in matches:
            wm.append([it["row_number"], it["subject_name"], _bulk_scope_label(m.get("scope", "")),
                       m.get("list_name", ""), m.get("matched_name", ""), int(m.get("score") or 0),
                       m.get("reason", ""), status_text_ar(m.get("status", ""))])
    for cell in wm[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
    for row in wm.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(horizontal="right", vertical="top", wrap_text=True)
    for col, width in enumerate([8, 30, 14, 22, 34, 10, 50, 20], 1):
        wm.column_dimensions[wm.cell(row=1, column=col).column_letter].width = width
    wm.freeze_panes = "A2"
    if wm.max_row > 1:
        wm.auto_filter.ref = wm.dimensions

    si = wb.create_sheet("معلومات العملية")
    si.sheet_view.rightToLeft = True
    for k, v in [("رقم العملية", run["id"]), ("التاريخ", run["created_at"]), ("المستخدم", run["created_by"] or "-"),
                 ("المصدر", run["source"]), ("الملف", run["source_filename"] or "-"),
                 ("بصمة الملف SHA-256", run["file_sha256"] or "-"), ("نطاق الفحص", _bulk_mode_label(run["screening_mode"])),
                 ("إجمالي الصفوف", run["total_rows"]), ("الصفوف المفحوصة", run["screened_rows"]),
                 ("الصفوف المرفوضة", run["error_rows"]), ("صفوف بتطابق", run["hit_rows"]),
                 ("أحمر", run["red_rows"]), ("أصفر", run["yellow_rows"]), ("أخضر", run["green_rows"]),
                 ("القوائم نشطة وقت الفحص", "نعم" if run["lists_available"] else "لا - الفحص غير مكتمل"),
                 ("عدد السجلات النشطة", run["active_entries"]), ("عدد القوائم النشطة", run["active_lists"]),
                 ("تاريخ التصدير", now_iso())]:
        si.append([k, v])
    si.column_dimensions["A"].width = 30
    si.column_dimensions["B"].width = 44
    for row in si.iter_rows():
        row[0].font = Font(bold=True)
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue(), f"bulk_screening_run_{run['id']}_{dt.datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"


def build_bulk_template_xlsx() -> bytes:
    from openpyxl import Workbook  # type: ignore
    from openpyxl.styles import Alignment, Font, PatternFill  # type: ignore
    wb = Workbook()
    ws = wb.active
    ws.title = "الأسماء"
    ws.sheet_view.rightToLeft = True
    ws.append(["الاسم الكامل", "رقم الهوية/الإقامة/الجواز", "رقم السجل التجاري/الكيان", "نوع الكيان", "الدولة", "الجنسية", "المرجع"])
    ws.append(["محمد أحمد العتيبي", "1077889911", "", "فرد", "السعودية", "سعودي", "مثال - احذف هذا الصف"])
    ws.append(["شركة النور للتجارة المحدودة", "", "4030112233", "شركة", "السعودية", "", "مثال - احذف هذا الصف"])
    header_fill = PatternFill("solid", fgColor="0F766E")
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center")
    for col, width in enumerate([36, 24, 24, 14, 14, 14, 22], 1):
        ws.column_dimensions[ws.cell(row=1, column=col).column_letter].width = width
    ws.freeze_panes = "A2"
    notes = wb.create_sheet("التعليمات")
    notes.sheet_view.rightToLeft = True
    for line in ["الاسم الكامل إلزامي؛ بقية الأعمدة اختيارية وترفع دقة المطابقة.",
                 "الأرقام تقبل بالصيغتين العربية والإنجليزية ومع أو بدون مسافات وشرطات.",
                 "نوع الكيان: فرد أو شركة أو جهة حكومية أو أخرى.",
                 "احذف صفوف الأمثلة قبل الرفع.",
                 f"الحد الأقصى {BULK_MAX_ROWS} صف في العملية الواحدة.",
                 "لا تغيّر أسماء الأعمدة في الصف الأول."]:
        notes.append([line])
    notes.column_dimensions["A"].width = 80
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


# --- تقوية جلسات المستخدمين: تحديث حي من قاعدة البيانات وتنظيف الجلسات المنتهية ---
_session_user_pre_v1056 = _session_user
def _session_user(handler: AppHandler) -> Optional[Dict[str, Any]]:  # type: ignore[override]
    user = _session_user_pre_v1056(handler)
    if not user:
        return None
    now_ts = dt.datetime.now().timestamp()
    if len(_AUTH_SESSIONS) > 64:
        for t, s in list(_AUTH_SESSIONS.items()):
            if s.get("expires", 0) < now_ts:
                _AUTH_SESSIONS.pop(t, None)
    try:
        with db() as con:
            row = con.execute("SELECT * FROM app_users WHERE id=? AND is_active=1", (user.get("id"),)).fetchone()
    except Exception:
        return user
    if not row:
        _AUTH_SESSIONS.pop(_cookie_value(handler, "masarat_session"), None)
        return None
    fresh = dict(row)
    sess = _AUTH_SESSIONS.get(_cookie_value(handler, "masarat_session"))
    if sess:
        sess["user"] = fresh
    return fresh


# --- سجل التدقيق: مسؤول الامتثال والإدارة يريان الكل؛ بقية الأدوار ترى نشاطها فقط ---
def audit_page_v1056(qs: Dict[str, List[str]], user: Dict[str, Any]) -> bytes:
    requested_user = (qs.get("user", [""])[0] or "").strip()
    privileged = user.get("role") in {"admin", "compliance"}
    effective_user = requested_user if privileged else str(user.get("user_name") or "")
    where = ""
    params: List[Any] = []
    if effective_user:
        where = "WHERE details LIKE ? OR ip_address LIKE ?"
        like = f"%{effective_user}%"
        params = [like, like]
    with db() as con:
        ensure_schema(con)
        rows = con.execute(f"SELECT * FROM audit_events {where} ORDER BY id DESC LIMIT 300", params).fetchall()
    scope_note = "جميع الأحداث" if (privileged and not effective_user) else f"أحداث المستخدم: {effective_user}"
    body_rows = "".join(
        f"<tr><td>{r['id']}</td><td>{h(r['created_at'])}</td><td>{h(r['action'])}</td><td>{h(r['entity_type'])}"
        f"</td><td>{r['entity_id']}</td><td>{auto_dir(r['details'])}</td><td>{h(r['ip_address'])}</td></tr>"
        for r in rows)
    body = f"""<div class="card"><h2>سجل التدقيق</h2>
<p class="notice">سجل غير قابل للحذف من داخل الواجهة. النطاق المعروض: {h(scope_note)} (أحدث 300 حدث).</p>
<table><thead><tr><th>#</th><th>الوقت</th><th>الإجراء</th><th>الكيان</th><th>المعرف</th><th>التفاصيل</th><th>IP</th></tr></thead>
<tbody>{body_rows or '<tr><td colspan="7">لا توجد أحداث</td></tr>'}</tbody></table></div>"""
    return layout("سجل التدقيق", body, "/audit")


# --- ربط الفحص السريع بالفحص الجماعي (ملاحظة إرشادية فقط دون تغيير سلوكه) ---
_quick_screen_form_pre_v1056 = quick_screen_form
def quick_screen_form(message: str = "") -> bytes:  # type: ignore[override]
    raw = _quick_screen_form_pre_v1056(message).decode("utf-8")
    tip = "<p class='small'>لفحص عدة أسماء دفعة واحدة مع حفظ النتائج وتصديرها Excel استخدم <a href='/bulk_screen'>الفحص الجماعي</a>.</p></div>"
    raw = raw.replace("</form></div>", "</form>" + tip, 1)
    return raw.encode("utf-8")


_layout_pre_v1056 = layout
def layout(title: str, body: str, active: str = "") -> bytes:  # type: ignore[override]
    raw = _layout_pre_v1056(title, body, active).decode("utf-8")
    cls = "active" if active == "/bulk_screen" else ""
    needle = 'href="/quick_screen">الفحص السريع</a>'
    raw = raw.replace(needle, needle + f'<a class="{cls}" href="/bulk_screen">الفحص الجماعي</a>', 1)
    return raw.encode("utf-8")


def _qs_int(qs: Dict[str, List[str]], key: str, default: int = 0) -> int:
    try:
        return int((qs.get(key, [str(default)])[0] or default))
    except (TypeError, ValueError):
        return default


_V1056_GATED_GET = {"/audit", "/data-import"}
_V1056_GATED_POST = {"/lists/upload", "/lists/direct-update", "/data-import"}
_V1056_BULK_GET = {"/bulk_screen", "/bulk_screen/results", "/bulk_screen/export.xlsx", "/bulk_screen/template.xlsx"}

_get_pre_v1056 = AppHandler.do_GET
def _do_get_v1056(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    path = parsed.path
    qs = parse_qs(parsed.query)
    if path not in _V1056_BULK_GET and path not in _V1056_GATED_GET:
        try:
            return _get_pre_v1056(self)
        except (ValueError, KeyError) as exc:
            return self._send(layout("طلب غير صالح", f"<div class='error'>طلب غير صالح: {h(exc)}</div>"), 400)
    user = _session_user(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    _AUTH_CTX.user = user
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    try:
        if path == "/audit":
            return self._send(audit_page_v1056(qs, user))
        if path == "/data-import":
            if user.get("role") not in {"admin", "compliance"}:
                return self._send(layout("غير مصرح", "<div class='error'>استيراد البيانات متاح لأدوار الامتثال والإدارة فقط.</div>"), 403)
            return _get_pre_v1056(self)
        if path == "/bulk_screen":
            return self._send(bulk_screen_page())
        if path == "/bulk_screen/results":
            rid = _qs_int(qs, "id")
            return self._send(bulk_run_results_page(rid))
        if path == "/bulk_screen/template.xlsx":
            return _send_binary_with_disposition(self, build_bulk_template_xlsx(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "bulk_screening_template.xlsx")
        if path == "/bulk_screen/export.xlsx":
            rid = _qs_int(qs, "id")
            content, fname = build_bulk_results_xlsx(rid)
            with db() as con:
                audit(con, "export_bulk_screening_excel", "screening", rid, f"user={user.get('user_name')}", _real_client_ip(self))
                con.commit()
            return _send_binary_with_disposition(self, content,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fname)
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>حدث خطأ: {h(exc)}</div>", "/bulk_screen"), 500)

AppHandler.do_GET = _do_get_v1056

_post_pre_v1056 = AppHandler.do_POST
def _do_post_v1056(self: AppHandler) -> None:
    path = urlparse(self.path).path
    try:
        length = int(self.headers.get("Content-Length", "0") or 0)
    except ValueError:
        length = 0
    if length > MAX_REQUEST_BYTES:
        return self._send(layout("الطلب كبير جداً", "<div class='error'>حجم الطلب يتجاوز الحد المسموح (50 MB).</div>"), 413)
    if path != "/bulk_screen/run" and path not in _V1056_GATED_POST:
        try:
            return _post_pre_v1056(self)
        except (ValueError, KeyError) as exc:
            return self._send(layout("طلب غير صالح", f"<div class='error'>طلب غير صالح: {h(exc)}</div>"), 400)
    user = _session_user(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    _AUTH_CTX.user = user
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    if path in _V1056_GATED_POST:
        if user.get("role") not in {"admin", "compliance"}:
            return self._send(layout("غير مصرح", "<div class='error'>هذا الإجراء متاح لأدوار الامتثال والإدارة فقط.</div>"), 403)
        return _post_pre_v1056(self)
    try:
        fields, files, ip = _parse_request_fields(self)
        screening_mode = form_value(fields, "screening_mode", "both")
        filename, content = files.get("bulk_file", ("", b""))
        if filename and content:
            subjects, errors = parse_bulk_file(filename, content)
            source = "file"
            file_sha = hashlib.sha256(content).hexdigest()
        else:
            subjects, errors = parse_bulk_paste(form_value(fields, "bulk_text"))
            source = "paste"
            filename = ""
            file_sha = ""
        run_id = run_bulk_screening(subjects, errors, source=source, source_filename=filename,
                                    file_sha256=file_sha, screening_mode=screening_mode,
                                    created_by=str(user.get("user_name") or ""), ip=ip)
        return send_redirect(self, f"/bulk_screen/results?id={run_id}")
    except ValueError as exc:
        return self._send(bulk_screen_page(str(exc), is_error=True), 400)
    except Exception as exc:
        return self._send(bulk_screen_page(f"تعذر تنفيذ الفحص الجماعي: {exc}", is_error=True), 500)

AppHandler.do_POST = _do_post_v1056
# ===== End V10.5.6 =====


# ---------------------------------------------------------------------------
# V10.5.7 - Security hardening (proxy-aware audit IP, Secure session cookie,
# SQLite busy_timeout, master key excluded from backups) and the Legal Tracks
# (مسارات قانونية) trademark branding.
# ---------------------------------------------------------------------------
APP_VERSION = "V10.5.7 - Security Hardening + Legal Tracks Branding"
BRAND_EN = "Legal Tracks"
BRAND_AR = "مسارات الامتثال"  # V10.8: اسم الواجهة العربية (المظلة: مسارات قانونية / Legal Tracks)


def _real_client_ip(handler: Any) -> str:
    """V10.5.7: the genuine client IP for the audit trail. Behind the on-host TLS reverse
    proxy (IIS ARR) and the Entra Application Proxy connector, the socket peer is always
    loopback, so the real client IP lives in X-Forwarded-For. Trust XFF ONLY when the direct
    peer is a trusted loopback proxy; otherwise fall back to the socket peer to prevent
    header spoofing from a direct (non-proxied) connection."""
    peer = ""
    try:
        peer = handler.client_address[0]
    except Exception:
        peer = ""
    try:
        headers = getattr(handler, "headers", None)
        if peer in TRUSTED_PROXY_PEERS and headers is not None:
            xff = headers.get("X-Forwarded-For", "") or ""
            parts = [p.strip() for p in xff.split(",") if p.strip()]
            if parts:
                # leftmost = original client when the proxy overwrites XFF; rightmost = the hop
                # the trusted proxy itself recorded when it appends (config-dependent, see constant).
                return parts[-1] if XFF_CLIENT_POSITION == "rightmost" else parts[0]
    except Exception:
        pass
    return peer or "-"


def _cookie_flags(handler: Any = None) -> str:
    """V10.5.7: append '; Secure' to the session cookie when the app is served over TLS
    (production default, or any request forwarded with X-Forwarded-Proto=https)."""
    secure = COOKIE_SECURE
    if not secure and handler is not None:
        try:
            secure = (handler.headers.get("X-Forwarded-Proto", "").lower() == "https")
        except Exception:
            secure = False
    return "; Secure" if secure else ""


# ---------------------------------------------------------------------------
# V10.5.8 - Audit hardening: attribute every action to the acting user, capture
# the device/browser (user-agent) and a session id, and provide an append-only,
# integrity-stamped export of the audit trail.
# ---------------------------------------------------------------------------
APP_VERSION = "V10.5.8 - Audit Hardening (attribution, device capture, append-only export)"

# Extra audit_events columns are added idempotently, once per DB per process.
_V1058_AUDIT_COLS = {"user_name": "TEXT", "user_agent": "TEXT", "session_id": "TEXT"}
_V1058_ENSURED: set = set()
_ensure_schema_pre_v1058 = ensure_schema


def ensure_schema(con: sqlite3.Connection, force: bool = False) -> None:  # type: ignore[override]
    _ensure_schema_pre_v1058(con, force)
    key = str(DB_PATH)
    if force or key not in _V1058_ENSURED:
        for name, ddl in _V1058_AUDIT_COLS.items():
            try:
                _ensure_column(con, "audit_events", name, ddl)
            except Exception:
                pass
        con.commit()
        _V1058_ENSURED.add(key)


def _audit_actor() -> Tuple[str, str, str]:
    """Current acting user, device/user-agent and session id for the request in flight."""
    u = _auth_current_user() or {}
    user_name = str(u.get("user_name") or "")
    ua = str(getattr(_AUTH_CTX, "user_agent", "") or "")[:400]
    sid = str(getattr(_AUTH_CTX, "session_id", "") or "")
    return user_name, ua, sid


def audit(con: sqlite3.Connection, action: str, entity_type: str = "system", entity_id: int = 0, details: str = "", ip: str = "") -> None:  # type: ignore[override]
    """V10.5.8: every audited action is now stamped with the acting user, the device
    (user-agent) and the session id, in addition to the action/entity/IP/time. Falls
    back gracefully if the extra columns are somehow absent (e.g. an old restored DB)."""
    user_name, ua, sid = _audit_actor()
    if not ip:
        ip = str(getattr(_AUTH_CTX, "ip", "") or "")
    params = (now_iso(), action, entity_type, int(entity_id or 0), str(details or "")[:2000], ip, user_name, ua, sid)
    sql = ("INSERT INTO audit_events(created_at, action, entity_type, entity_id, details, ip_address, "
           "user_name, user_agent, session_id) VALUES(?,?,?,?,?,?,?,?,?)")
    try:
        con.execute(sql, params)
    except sqlite3.OperationalError:
        for name, ddl in _V1058_AUDIT_COLS.items():
            try:
                _ensure_column(con, "audit_events", name, ddl)
            except Exception:
                pass
        try:
            con.execute(sql, params)
        except Exception:
            con.execute("INSERT INTO audit_events(created_at, action, entity_type, entity_id, details, ip_address) VALUES(?,?,?,?,?,?)",
                        (now_iso(), action, entity_type, int(entity_id or 0), str(details or "")[:2000], ip))


def build_audit_export(since_id: int = 0) -> Tuple[bytes, str, int]:
    """Append-only NDJSON export of the audit trail with a SHA-256 integrity trailer.
    Line 1 = manifest; then one line per record tagged with its source table; final line
    = integrity record whose sha256_of_body covers everything above it. Pass since_id to
    export only audit_events newer than a previously exported id (true append-only shipping)."""
    with db() as con:
        ensure_schema(con)
        ae = con.execute("SELECT * FROM audit_events WHERE id > ? ORDER BY id", (int(since_id or 0),)).fetchall()
        others: Dict[str, List[Any]] = {}
        for tb in ("user_login_audit", "report_access_audit", "backup_audit"):
            try:
                others[tb] = con.execute(f"SELECT * FROM {tb} ORDER BY id").fetchall()
            except Exception:
                others[tb] = []
    counts = {"audit_events": len(ae)}
    counts.update({k: len(v) for k, v in others.items()})
    max_id = ae[-1]["id"] if ae else int(since_id or 0)
    lines = [json.dumps({"_type": "legal_tracks_audit_export", "brand": "Compliance Tracks / مسارات الامتثال (Legal Tracks)",
                         "app_version": APP_VERSION, "exported_at": now_iso(), "since_id": int(since_id or 0),
                         "max_audit_id": max_id, "counts": counts}, ensure_ascii=False)]
    for r in ae:
        d = {k: r[k] for k in r.keys()}; d["_table"] = "audit_events"; lines.append(json.dumps(d, ensure_ascii=False))
    for tb, rows in others.items():
        for r in rows:
            d = {k: r[k] for k in r.keys()}; d["_table"] = tb; lines.append(json.dumps(d, ensure_ascii=False))
    body = ("\n".join(lines) + "\n").encode("utf-8")
    sha = hashlib.sha256(body).hexdigest()
    trailer = (json.dumps({"_type": "integrity", "sha256_of_body": sha, "rows": sum(counts.values())}, ensure_ascii=False) + "\n").encode("utf-8")
    fname = f"legaltracks_audit_export_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.ndjson"
    return body + trailer, fname, max_id


def _handle_audit_export(handler: AppHandler) -> None:
    user = _session_user(handler)
    if not user:
        return _auth_send_redirect(handler, "/login")
    _AUTH_CTX.user = user
    if user.get("must_change_password"):
        return _auth_send_redirect(handler, "/account")
    if user.get("role") not in {"admin", "compliance"}:
        return handler._send(layout("غير مصرح", "<div class='error'>تصدير سجل التدقيق متاح لأدوار الامتثال والإدارة فقط.</div>"), 403)
    parsed = urlparse(handler.path); qs = parse_qs(parsed.query)
    try:
        since = int((qs.get("since", ["0"])[0] or 0))
    except (TypeError, ValueError):
        since = 0
    try:
        content, fname, max_id = build_audit_export(since)
    except Exception as exc:
        return handler._send(layout("خطأ التصدير", f"<div class='error'>{h(exc)}</div>", "/audit"), 500)
    with db() as con:
        audit(con, "export_audit_log", "audit", max_id, f"since={since}; file={fname}; bytes={len(content)}", _real_client_ip(handler))
        con.commit()
    return _send_binary_with_disposition(handler, content, "application/x-ndjson", fname)


# --- Audit page upgraded: show the acting user + device, and an export button ---
def audit_page_v1056(qs: Dict[str, List[str]], user: Dict[str, Any]) -> bytes:  # type: ignore[override]
    requested_user = (qs.get("user", [""])[0] or "").strip()
    privileged = user.get("role") in {"admin", "compliance"}
    effective_user = requested_user if privileged else str(user.get("user_name") or "")
    where = ""
    params: List[Any] = []
    if effective_user:
        where = "WHERE user_name = ? OR details LIKE ? OR ip_address LIKE ?"
        like = f"%{effective_user}%"
        params = [effective_user, like, like]
    with db() as con:
        ensure_schema(con)
        rows = con.execute(f"SELECT * FROM audit_events {where} ORDER BY id DESC LIMIT 300", params).fetchall()
    scope_note = "جميع الأحداث" if (privileged and not effective_user) else f"أحداث المستخدم: {effective_user}"

    def _cell_user(r: sqlite3.Row) -> str:
        keys = r.keys()
        return h(r["user_name"]) if ("user_name" in keys and r["user_name"]) else "<span class='small'>غير منسوب</span>"

    def _cell_device(r: sqlite3.Row) -> str:
        keys = r.keys()
        ua = (r["user_agent"] if "user_agent" in keys else "") or ""
        if not ua:
            return "-"
        short = (ua[:38] + "…") if len(ua) > 40 else ua
        return f"<span title=\"{h(ua)}\">{h(short)}</span>"

    body_rows = "".join(
        f"<tr><td>{r['id']}</td><td>{h(r['created_at'])}</td><td>{_cell_user(r)}</td><td>{h(r['action'])}</td>"
        f"<td>{h(r['entity_type'])}</td><td>{r['entity_id']}</td><td>{auto_dir(r['details'])}</td>"
        f"<td dir='ltr'>{h(r['ip_address'])}</td><td>{_cell_device(r)}</td></tr>"
        for r in rows)
    export_btn = ("<a class='btn' href='/audit/export'>تصدير سجل التدقيق (NDJSON موقّع)</a>"
                  if privileged else "")
    body = f"""<div class="card"><div class="section-title"><div><h2>سجل التدقيق</h2>
<p class="notice">سجل غير قابل للحذف من داخل الواجهة، ويقيد الآن المستخدم المنفذ والجهاز/المتصفح لكل إجراء. النطاق المعروض: {h(scope_note)} (أحدث 300 حدث). للحفظ طويل الأمد صدّر السجل ورحّله إلى مخزن غير قابل للتعديل (WORM) أو Microsoft Sentinel.</p></div>{export_btn}</div>
<div class="table-wrap"><table><thead><tr><th>#</th><th>الوقت</th><th>المستخدم</th><th>الإجراء</th><th>الكيان</th><th>المعرف</th><th>التفاصيل</th><th>IP الجهاز</th><th>الجهاز/المتصفح</th></tr></thead>
<tbody>{body_rows or '<tr><td colspan="9">لا توجد أحداث</td></tr>'}</tbody></table></div></div>"""
    return layout("سجل التدقيق", body, "/audit")


# --- Per-request audit context: capture device + IP + session, reset user each request ---
_get_pre_v1058 = AppHandler.do_GET
def _do_get_v1058(self: AppHandler) -> None:
    try:
        _AUTH_CTX.user = None
        _AUTH_CTX.user_agent = (self.headers.get("User-Agent", "") or "")[:400]
        _AUTH_CTX.ip = _real_client_ip(self)
        tok = _cookie_value(self, "masarat_session")
        _AUTH_CTX.session_id = hashlib.sha256(tok.encode("utf-8")).hexdigest()[:16] if tok else ""
    except Exception:
        pass
    if urlparse(self.path).path == "/audit/export":
        return _handle_audit_export(self)
    return _get_pre_v1058(self)
AppHandler.do_GET = _do_get_v1058

_post_pre_v1058 = AppHandler.do_POST
def _do_post_v1058(self: AppHandler) -> None:
    try:
        _AUTH_CTX.user = None
        _AUTH_CTX.user_agent = (self.headers.get("User-Agent", "") or "")[:400]
        _AUTH_CTX.ip = _real_client_ip(self)
        tok = _cookie_value(self, "masarat_session")
        _AUTH_CTX.session_id = hashlib.sha256(tok.encode("utf-8")).hexdigest()[:16] if tok else ""
    except Exception:
        pass
    return _post_pre_v1058(self)
AppHandler.do_POST = _do_post_v1058
# ===== End V10.5.8 =====


# ---------------------------------------------------------------------------
# V10.5.9 - Restrict application accounts to the firm's email domain.
# New user accounts must be a firm email (name@legaltracks.sa by default); the local
# 'admin' stays exempt as a break-glass account. Domains are configurable and logins
# are case-insensitive. Forward-compatible with Entra sign-in (username == firm email).
# ---------------------------------------------------------------------------
APP_VERSION = "V10.5.9 - Firm-Domain Accounts (email logins on legaltracks.sa)"

# Allowed domains for user accounts (comma-separated), and whether enforcement is on.
ALLOWED_USER_DOMAINS = {d.strip().lower() for d in os.environ.get("MASARAT_ALLOWED_USER_DOMAINS", "legaltracks.sa").split(",") if d.strip()}
ENFORCE_USER_DOMAIN = os.environ.get("MASARAT_ENFORCE_USER_DOMAIN", "1") == "1"
# Local accounts exempt from the email-domain rule (break-glass; never lock yourself out).
RESERVED_LOCAL_ACCOUNTS = {"admin"}
_USER_EMAIL_RE = re.compile(r"^[a-z0-9._%+\-]+@([a-z0-9.\-]+\.[a-z]{2,})$")


def _normalize_user_name(u: Any) -> str:
    return str(u or "").strip().lower()


def _user_domain_ok(u: Any) -> Tuple[bool, str, str]:
    """Returns (ok, normalized_username, error_message). Reserved local accounts and the
    disabled/empty-domain case pass through; otherwise the username must be a valid email
    on one of the allowed domains."""
    n = _normalize_user_name(u)
    if n in RESERVED_LOCAL_ACCOUNTS:
        return True, n, ""
    if not (ENFORCE_USER_DOMAIN and ALLOWED_USER_DOMAINS):
        return True, n, ""
    m = _USER_EMAIL_RE.match(n)
    if not m:
        return False, n, "اسم المستخدم يجب أن يكون بريداً إلكترونياً على نطاق الشركة، مثل name@legaltracks.sa"
    if m.group(1) not in ALLOWED_USER_DOMAINS:
        return False, n, "يسمح فقط بإنشاء حسابات على النطاق: " + ", ".join(sorted(ALLOWED_USER_DOMAINS))
    return True, n, ""


_add_app_user_pre_v1059 = add_app_user
def add_app_user(fields: Dict[str, List[str]], ip: str = "") -> str:  # type: ignore[override]
    """V10.5.9: enforce the firm email domain on new accounts, normalise to lowercase,
    then defer to the existing duplicate/role checks."""
    ok, norm, err = _user_domain_ok(form_value(fields, "user_name"))
    if not ok:
        return err
    normalized_fields = dict(fields)
    normalized_fields["user_name"] = [norm]
    return _add_app_user_pre_v1059(normalized_fields, ip)
# ===== End V10.5.9 =====


# ---------------------------------------------------------------------------
# V10.5.10 - User management: edit (name/role), deactivate/reactivate, and reset
# password for existing accounts (V10.5.9 could only ADD users). Admin-only, with
# guards that prevent locking out the last active administrator. Deactivation and role
# changes take effect immediately via the live session refresh (V10.5.6).
# ---------------------------------------------------------------------------
APP_VERSION = "V10.5.10 - User Management (edit, deactivate, reset password)"

_APP_ROLES = {"admin": "مدير نظام", "compliance": "امتثال", "partner": "شريك", "user": "مستخدم"}


def _generate_temp_password() -> str:
    # Meets the >=8-char change-password rule; user is forced to change it on first login.
    return "Lt" + secrets.token_urlsafe(9)


def _role_options(selected: str = "") -> str:
    return "".join(f"<option value='{code}' {'selected' if code == selected else ''}>{h(label)}</option>"
                   for code, label in _APP_ROLES.items())


def _last_active_admin_blocker(con: sqlite3.Connection, uid: int) -> bool:
    """True if uid is the ONLY remaining active admin (so demoting/deactivating it is blocked)."""
    others = con.execute("SELECT COUNT(*) FROM app_users WHERE role='admin' AND is_active=1 AND id<>?", (uid,)).fetchone()[0]
    return others == 0


def update_app_user(fields: Dict[str, List[str]], ip: str = "") -> str:
    uid = int(form_value(fields, "user_id", "0") or 0)
    full_name = form_value(fields, "full_name")
    role = form_value(fields, "role")
    if role and role not in _APP_ROLES:
        return "دور غير معتمد"
    with db() as con:
        ensure_schema(con)
        row = con.execute("SELECT * FROM app_users WHERE id=?", (uid,)).fetchone()
        if not row:
            return "المستخدم غير موجود"
        if role and role != "admin" and row["role"] == "admin" and row["is_active"] and _last_active_admin_blocker(con, uid):
            return "لا يمكن تغيير دور آخر مدير نظام نشط؛ عيّن مديراً آخر أولاً."
        sets, params = [], []
        if full_name:
            sets.append("full_name=?"); params.append(full_name)
        if role:
            sets.append("role=?"); params.append(role)
        if not sets:
            return "لا توجد تغييرات لحفظها."
        params.append(uid)
        con.execute(f"UPDATE app_users SET {', '.join(sets)} WHERE id=?", params)
        audit(con, "update_user", "app_user", uid, f"full_name={full_name}; role={role}; user={row['user_name']}", ip)
        con.commit()
    return f"تم تحديث بيانات المستخدم {row['user_name']}."


def toggle_app_user(fields: Dict[str, List[str]], ip: str = "") -> str:
    uid = int(form_value(fields, "user_id", "0") or 0)
    with db() as con:
        ensure_schema(con)
        row = con.execute("SELECT * FROM app_users WHERE id=?", (uid,)).fetchone()
        if not row:
            return "المستخدم غير موجود"
        new_active = 0 if row["is_active"] else 1
        if new_active == 0 and row["role"] == "admin" and _last_active_admin_blocker(con, uid):
            return "لا يمكن تعطيل آخر مدير نظام نشط؛ أبقِ مديراً واحداً على الأقل."
        con.execute("UPDATE app_users SET is_active=? WHERE id=?", (new_active, uid))
        if new_active == 0:
            # Immediately end any live sessions for the deactivated user.
            for tok, sess in list(_AUTH_SESSIONS.items()):
                if (sess.get("user") or {}).get("id") == uid:
                    _AUTH_SESSIONS.pop(tok, None)
        audit(con, "toggle_user_active", "app_user", uid, f"is_active={new_active}; user={row['user_name']}", ip)
        con.commit()
    return (f"تم تفعيل المستخدم {row['user_name']}." if new_active
            else f"تم تعطيل المستخدم {row['user_name']} — لن يتمكن من الدخول وأُنهيت جلساته.")


def reset_app_user_password(fields: Dict[str, List[str]], ip: str = "") -> str:
    uid = int(form_value(fields, "user_id", "0") or 0)
    with db() as con:
        ensure_schema(con)
        row = con.execute("SELECT * FROM app_users WHERE id=?", (uid,)).fetchone()
        if not row:
            return "المستخدم غير موجود"
        temp = _generate_temp_password()
        salt, ph = _auth_hash(temp)
        con.execute("UPDATE app_users SET password_salt=?, password_hash=?, must_change_password=1, failed_login_attempts=0, locked_until=NULL WHERE id=?",
                    (salt, ph, uid))
        for tok, sess in list(_AUTH_SESSIONS.items()):
            if (sess.get("user") or {}).get("id") == uid:
                _AUTH_SESSIONS.pop(tok, None)
        audit(con, "reset_user_password", "app_user", uid, f"user={row['user_name']}", ip)
        con.commit()
    return (f"تم تعيين كلمة مرور مؤقتة للمستخدم {row['user_name']}: {temp} — سلّمها للمستخدم؛ "
            f"سيُطلب تغييرها عند أول دخول. (لا تظهر هذه الكلمة مرة أخرى)")


def _build_user_mgmt_card() -> str:
    with db() as con:
        ensure_schema(con)
        users = con.execute("SELECT id, full_name, user_name, role, is_active FROM app_users ORDER BY is_active DESC, role, user_name").fetchall()
    rows = []
    for u in users:
        uid = u["id"]
        active = bool(u["is_active"])
        status = "<span class='badge ok'>نشط</span>" if active else "<span class='badge warn'>موقوف</span>"
        edit_form = (f"<form method='post' action='/settings/update_user' style='display:flex;gap:6px;flex-wrap:wrap;align-items:center'>"
                     f"<input type='hidden' name='user_id' value='{uid}'>"
                     f"<input name='full_name' value='{h(u['full_name'] or '')}' style='max-width:150px' title='الاسم'>"
                     f"<select name='role' style='max-width:130px'>{_role_options(u['role'] or 'user')}</select>"
                     f"<button class='btn secondary'>حفظ</button></form>")
        toggle_label = "تعطيل" if active else "تفعيل"
        toggle_cls = "warn" if active else "ok"
        toggle_form = (f"<form method='post' action='/settings/toggle_user' style='display:inline'>"
                       f"<input type='hidden' name='user_id' value='{uid}'>"
                       f"<button class='btn {toggle_cls}'>{toggle_label}</button></form>")
        reset_form = (f"<form method='post' action='/settings/reset_user_password' style='display:inline'>"
                      f"<input type='hidden' name='user_id' value='{uid}'>"
                      f"<button class='btn'>إعادة تعيين كلمة المرور</button></form>")
        rows.append(f"<tr><td>{uid}</td><td dir='ltr'>{h(u['user_name'])}</td><td>{edit_form}</td>"
                    f"<td>{status}</td><td style='white-space:nowrap'>{toggle_form} {reset_form}</td></tr>")
    body = "".join(rows) or "<tr><td colspan='5'>لا يوجد مستخدمون</td></tr>"
    return (f"<div class=\"card\" id=\"users-manage\"><h3>إدارة المستخدمين</h3>"
            f"<p class=\"notice\">تعديل الاسم/الدور، تعطيل أو تفعيل الحساب، وإعادة تعيين كلمة المرور. "
            f"التعطيل يمنع الدخول فوراً ويُنهي الجلسات. لا يمكن تعطيل أو خفض دور آخر مدير نظام نشط.</p>"
            f"<div class=\"table-wrap\"><table><thead><tr><th>#</th><th>البريد الإلكتروني</th><th>الاسم والدور (قابل للتعديل)</th><th>الحالة</th><th>إجراءات</th></tr></thead>"
            f"<tbody>{body}</tbody></table></div></div>")


_settings_page_pre_v1510 = settings_page
def settings_page(message: str = "") -> bytes:  # type: ignore[override]
    raw = _settings_page_pre_v1510(message).decode("utf-8")
    try:
        card = _build_user_mgmt_card()
        raw = raw.replace('<div class="card" id="users">', card + '<div class="card" id="users">', 1)
    except Exception:
        pass
    return raw.encode("utf-8")


_USER_MGMT_ROUTES = {"/settings/update_user", "/settings/toggle_user", "/settings/reset_user_password"}
_post_pre_v1510 = AppHandler.do_POST
def _do_post_v1510(self: AppHandler) -> None:
    try:
        _AUTH_CTX.user = None
        _AUTH_CTX.user_agent = (self.headers.get("User-Agent", "") or "")[:400]
        _AUTH_CTX.ip = _real_client_ip(self)
        tok = _cookie_value(self, "masarat_session")
        _AUTH_CTX.session_id = hashlib.sha256(tok.encode("utf-8")).hexdigest()[:16] if tok else ""
    except Exception:
        pass
    path = urlparse(self.path).path
    if path not in _USER_MGMT_ROUTES:
        return _post_pre_v1510(self)
    user = _session_user(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    _AUTH_CTX.user = user
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    if user.get("role") != "admin":
        return self._send(layout("غير مصرح", "<div class='error'>إدارة المستخدمين متاحة لمدير النظام فقط.</div>"), 403)
    try:
        fields, files, ip = _parse_request_fields(self)
        if path == "/settings/update_user":
            msg = update_app_user(fields, ip)
        elif path == "/settings/toggle_user":
            msg = toggle_app_user(fields, ip)
        else:
            msg = reset_app_user_password(fields, ip)
        return self._send(settings_page(msg))
    except Exception as exc:
        return self._send(settings_page(f"تعذر تنفيذ العملية: {exc}"), 500)
AppHandler.do_POST = _do_post_v1510
# ===== End V10.5.10 =====


# ---------------------------------------------------------------------------
# V10.5.11 - Suspicion detail & traceability. For every screening result you can now
# see EXACTLY which list, the exact matched record (with its identifiers/source), and
# for an internal conflict which client number/entity caused it — in the register and
# in a dedicated per-result detail page.
# ---------------------------------------------------------------------------
APP_VERSION = "V10.5.11 - Suspicion Detail & Traceability"


def _resolve_sanctions_match(con: sqlite3.Connection, mid: Any) -> Dict[str, Any]:
    r = con.execute("SELECT * FROM sanctions_entries WHERE id=?", (int(mid or 0),)).fetchone()
    return {k: r[k] for k in r.keys()} if r else {}


def _resolve_internal_match(con: sqlite3.Connection, mtype: str, mid: Any) -> Dict[str, Any]:
    """Resolve an internal matched entity to a human reference: the conflicting client
    number/name, matter, identifiers, and a link to the record."""
    mtype = mtype or ""
    mid = int(mid or 0)
    out = {"found": False, "kind_label": "", "name": "", "client_code": "", "matter_number": "",
           "id_number": "", "registration_number": "", "link": ""}
    if not mid:
        return out
    if mtype == "client":
        r = con.execute("SELECT legal_name,client_code,id_number,registration_number FROM clients WHERE id=?", (mid,)).fetchone()
        if r:
            out.update(found=True, kind_label="عميل", name=r["legal_name"] or "", client_code=r["client_code"] or "",
                       id_number=r["id_number"] or "", registration_number=r["registration_number"] or "", link=f"/client?id={mid}")
    elif mtype == "counterparty":
        r = con.execute("""SELECT cp.full_name,cp.id_number,cp.registration_number,m.matter_number,c.client_code
            FROM counterparties cp LEFT JOIN matters m ON m.id=cp.matter_id LEFT JOIN clients c ON c.id=m.client_id WHERE cp.id=?""", (mid,)).fetchone()
        if r:
            out.update(found=True, kind_label="طرف مقابل", name=r["full_name"] or "", client_code=r["client_code"] or "",
                       matter_number=r["matter_number"] or "", id_number=r["id_number"] or "", registration_number=r["registration_number"] or "", link=f"/counterparty?id={mid}")
    elif mtype == "client_related_party":
        r = con.execute("""SELECT rp.full_name,rp.id_number,rp.registration_number,rp.parent_id,c.client_code
            FROM related_parties rp LEFT JOIN clients c ON c.id=rp.parent_id WHERE rp.id=? AND rp.parent_type='client'""", (mid,)).fetchone()
        if r:
            out.update(found=True, kind_label="طرف مرتبط بعميل (مجلس/مدير/مستفيد)", name=r["full_name"] or "", client_code=r["client_code"] or "",
                       id_number=r["id_number"] or "", registration_number=r["registration_number"] or "", link=f"/client?id={r['parent_id']}")
    elif mtype == "counterparty_related_party":
        r = con.execute("""SELECT rp.full_name,rp.id_number,rp.registration_number,rp.parent_id,m.matter_number,c.client_code
            FROM related_parties rp LEFT JOIN counterparties cp ON cp.id=rp.parent_id
            LEFT JOIN matters m ON m.id=cp.matter_id LEFT JOIN clients c ON c.id=m.client_id
            WHERE rp.id=? AND rp.parent_type='counterparty'""", (mid,)).fetchone()
        if r:
            out.update(found=True, kind_label="طرف مرتبط بطرف مقابل", name=r["full_name"] or "", client_code=r["client_code"] or "",
                       matter_number=r["matter_number"] or "", id_number=r["id_number"] or "", registration_number=r["registration_number"] or "", link=f"/counterparty?id={r['parent_id']}")
    return out


def _internal_match_short(con: sqlite3.Connection, r: sqlite3.Row) -> str:
    """Compact one-line internal-conflict label for register cells (client number + name)."""
    info = _resolve_internal_match(con, r["matched_entity_type"], r["matched_entity_id"])
    if not info["found"]:
        return ""
    bits = [info["kind_label"]]
    if info["client_code"]:
        bits.append(f"عميل رقم {info['client_code']}")
    if info["matter_number"]:
        bits.append(f"مشروع {info['matter_number']}")
    return " · ".join(b for b in bits if b)


_DECISION_FORM = ("<form method='post' action='/screening/update'><input type='hidden' name='screening_id' value='{sid}'>"
                  "<select name='status'><option value='under_review'>قيد المراجعة</option><option value='false_positive'>False Positive موثق</option>"
                  "<option value='confirmed_match'>تطابق مؤكد</option><option value='frozen'>تجميد/حظر تعامل</option>"
                  "<option value='reported'>تم الإبلاغ</option><option value='closed'>إغلاق</option></select>"
                  "<input name='decision_reason' placeholder='سبب القرار - إلزامي تشغيليًا'><button>تحديث وتسجيل حالة امتثال</button></form>")
_PDF_FORM = ("<form method='post' action='/screening/report'><input type='hidden' name='screening_id' value='{sid}'>"
             "<select name='report_language'><option value='ar'>تقرير عربي</option><option value='en'>English Report</option></select>"
             "<button class='btn secondary'>إصدار PDF</button></form>")


def screening_detail_page(sid: int) -> bytes:
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT * FROM screenings WHERE id=?", (int(sid or 0),)).fetchone()
        if not r:
            return layout("غير موجود", "<div class='error'>نتيجة الفحص غير موجودة</div>", "/screenings")
        subj = screening_report_details(con, r)
        scope = r["screening_scope"]
        matched_type = r["matched_entity_type"] or ""
        sanc = _resolve_sanctions_match(con, r["matched_entity_id"]) if matched_type == "sanctions_entry" else {}
        internal = _resolve_internal_match(con, matched_type, r["matched_entity_id"]) if scope == "internal" else {"found": False}
        try:
            audit(con, "view_screening_detail", "screening", int(sid), f"scope={scope}", getattr(_AUTH_CTX, "ip", "") or "")
            con.commit()
        except Exception:
            pass
    risk_level, visual, action = risk_visual_for_screening(r["status"], int(r["match_score"] or 0))
    row_cls = "status-red" if visual == "أحمر" else "status-yellow" if visual == "أصفر" else "status-green"

    # --- subject block ---
    subj_ref = []
    if subj.get("client_code"):
        subj_ref.append(f"عميل رقم <b>{h(subj['client_code'])}</b>")
    if subj.get("client_name"):
        subj_ref.append(auto_dir(subj["client_name"]))
    if subj.get("matter_number"):
        subj_ref.append(f"مشروع {h(subj['matter_number'])}")
    subject_html = f"""<table>
<tr><th>الاسم المفحوص</th><td>{auto_dir(r['subject_name'])}</td><th>نوع المفحوص</th><td>{h(report_value_for_language('subject_type', r['subject_type'], 'ar'))}</td></tr>
<tr><th>العميل / المشروع</th><td colspan='3'>{' · '.join(subj_ref) or '-'}</td></tr>
<tr><th>رقم هوية/جواز المفحوص</th><td dir='ltr'>{h(subj.get('subject_id_number') or '-')}</td><th>رقم سجل/كيان المفحوص</th><td dir='ltr'>{h(subj.get('subject_registration_number') or '-')}</td></tr>
</table>"""

    # --- match block ---
    if scope == "sanctions" and sanc:
        match_html = f"""<p class='notice'>نطاق الفحص: قوائم العقوبات — القائمة: <b>{auto_dir(r['list_name'] or sanc.get('list_name') or '-')}</b>
{('· نوع القائمة: ' + h(sanc.get('list_type'))) if sanc.get('list_type') else ''}</p>
<table>
<tr><th>الاسم في القائمة</th><td>{auto_dir(sanc.get('full_name') or r['matched_name'])}</td><th>رقم السجل في القائمة</th><td dir='ltr'>{h(r['matched_entity_id'])}</td></tr>
<tr><th>رقم الهوية/الجواز</th><td dir='ltr'>{h(sanc.get('id_number') or '-')}</td><th>رقم السجل/الكيان</th><td dir='ltr'>{h(sanc.get('registration_number') or '-')}</td></tr>
<tr><th>الجنسية</th><td>{auto_dir(sanc.get('nationality') or '-')}</td><th>الدولة</th><td>{auto_dir(sanc.get('country') or '-')}</td></tr>
<tr><th>المصدر</th><td colspan='3' dir='ltr'>{h(sanc.get('source_url') or '-')}</td></tr>
<tr><th>ملاحظات القائمة</th><td colspan='3'>{auto_dir(sanc.get('notes') or '-')}</td></tr>
</table>"""
    elif scope == "internal" and internal.get("found"):
        match_html = f"""<p class='notice'>نطاق الفحص: السجل الداخلي — نوع التعارض: <b>{h(internal['kind_label'])}</b></p>
<table>
<tr><th>رقم العميل الداخلي المتعارض</th><td><b>{h(internal.get('client_code') or '-')}</b></td><th>الاسم الداخلي المطابق</th><td>{auto_dir(internal.get('name') or r['matched_name'])}</td></tr>
<tr><th>رقم المشروع</th><td>{h(internal.get('matter_number') or '-')}</td><th>رقم هوية/سجل المطابق</th><td dir='ltr'>{h(internal.get('id_number') or internal.get('registration_number') or '-')}</td></tr>
<tr><th>فتح السجل الداخلي</th><td colspan='3'>{('<a class=\"btn secondary\" href=\"'+internal['link']+'\">فتح السجل الداخلي المتعارض</a>') if internal.get('link') else '-'}</td></tr>
</table>"""
    else:
        # no-match / warning / exemption rows
        match_html = f"""<p class='notice'>النطاق: {h(report_value_for_language('scope', scope, 'ar'))} — القائمة/الحالة: <b>{auto_dir(r['list_name'] or '-')}</b>. لا يوجد سجل مطابق محدد لهذه النتيجة (نتيجة "لا يوجد تطابق" أو تحذير أو استثناء موثق).</p>"""

    body = f"""
<div class="card {row_cls}"><div class="section-title"><div><h2>تفاصيل نتيجة الفحص رقم {r['id']}</h2>
<p class="small">التاريخ: {h(r['created_at'])} · النطاق: {h(report_value_for_language('scope', scope, 'ar'))}</p></div>
<div>{badge_status(r['status'])} {badge_status(visual)}</div></div>
<p class="notice"><b>الإجراء المطلوب:</b> {h(action)}</p>
<p><a class="btn secondary" href="/screenings">العودة إلى سجل الفحص والتطابقات</a></p></div>

<div class="card"><h3>المفحوص</h3>{subject_html}</div>
<div class="card"><h3>السجل / القائمة المطابقة</h3>{match_html}
<table style="margin-top:10px"><tr><th>درجة التشابه</th><td>{r['match_score']}</td><th>حالة النتيجة</th><td>{badge_status(r['status'])}</td></tr>
<tr><th>سبب النتيجة</th><td colspan='3'>{auto_dir(r['match_reason'] or '-')}</td></tr>
{("<tr><th>سبب القرار المسجل</th><td colspan='3'>"+auto_dir(r['decision_reason'])+"</td></tr>") if r['decision_reason'] else ''}</table></div>

<div class="card"><h3>قرار الامتثال</h3><p class="small">سجّل القرار مع سببه؛ يُقيَّد في لوحة الامتثال وسجل التدقيق.</p>{_DECISION_FORM.format(sid=r['id'])}</div>
<div class="card"><h3>تقرير PDF</h3>{_PDF_FORM.format(sid=r['id'])}</div>
"""
    return layout(f"تفاصيل الفحص {r['id']}", body, "/screenings")


# --- Register enriched: internal client number in the match cell + a detail link per row ---
def screenings_page(message: str = "") -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        rows_ = con.execute("SELECT * FROM screenings ORDER BY id DESC LIMIT 400").fetchall()
        enrich = {}
        for r in rows_:
            if r["screening_scope"] == "internal":
                enrich[r["id"]] = _internal_match_short(con, r)
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    parts = []
    for r in rows_:
        risk_level, visual_status, required_action = risk_visual_for_screening(r['status'], int(r['match_score'] or 0))
        row_cls = "status-red" if visual_status == "أحمر" else "status-yellow" if visual_status == "أصفر" else "status-green"
        matched_cell = auto_dir(r['matched_name'])
        extra = enrich.get(r["id"])
        if extra:
            matched_cell += f"<br><span class='small'>{h(extra)}</span>"
        parts.append(
            f"<tr class='{row_cls}'><td><a href='/screening?id={r['id']}'>{r['id']}</a></td>"
            f"<td>{h(report_value_for_language('subject_type', r['subject_type'], 'ar'))}</td><td>{auto_dir(r['subject_name'])}</td>"
            f"<td>{h(report_value_for_language('scope', r['screening_scope'], 'ar'))}</td><td>{auto_dir(r['list_name'])}</td>"
            f"<td>{matched_cell}</td><td>{r['match_score']}</td><td>{auto_dir(r['match_reason'])}</td>"
            f"<td>{badge_status(r['status'])}</td><td>{badge_status(visual_status)}<br><span class='small'>{h(required_action)}</span></td>"
            f"<td><a class='btn secondary' href='/screening?id={r['id']}'>تفاصيل</a></td>"
            f"<td>{_DECISION_FORM.format(sid=r['id'])}</td>"
            f"<td>{_PDF_FORM.format(sid=r['id'])}</td></tr>")
    body = f"""
<div class="card"><h2>الفحص والتطابقات</h2>{msg}<p class="notice">لكل نتيجة زر "تفاصيل" يوضح القائمة بالتحديد والسجل المطابق بأرقامه ومصدره، ورقم العميل الداخلي المتعارض في حالة التعارض الداخلي. التقارير تقبل العربية والإنجليزية.</p></div>
<div class="card"><div class="table-wrap"><table><thead><tr><th>#</th><th>نوع المفحوص</th><th>الاسم</th><th>النطاق</th><th>القائمة</th><th>التطابق (والعميل الداخلي)</th><th>النسبة</th><th>السبب</th><th>الحالة</th><th>المؤشر البصري</th><th>تفاصيل</th><th>قرار الامتثال</th><th>تقرير PDF</th></tr></thead><tbody>{''.join(parts) or '<tr><td colspan="13">لا توجد نتائج</td></tr>'}</tbody></table></div></div>
"""
    return layout("الفحص", body, "/screenings")


# --- Pointers from client/matter detail pages to the full suspicion detail ---
_client_detail_pre_v1511 = client_detail
def client_detail(client_id: int) -> bytes:  # type: ignore[override]
    raw = _client_detail_pre_v1511(client_id).decode("utf-8")
    note = "<h3>آخر نتائج الفحص</h3><p class='small'>لتفاصيل أي تطابق (القائمة بالتحديد، السجل المطابق بأرقامه، ورقم العميل الداخلي المتعارض) افتح <a href='/screenings'>الفحص والتطابقات</a> واضغط \"تفاصيل\".</p>"
    return raw.replace("<h3>آخر نتائج الفحص</h3>", note, 1).encode("utf-8")


_matter_detail_pre_v1511 = matter_detail
def matter_detail(matter_id: int) -> bytes:  # type: ignore[override]
    raw = _matter_detail_pre_v1511(matter_id).decode("utf-8")
    note = "<h3>آخر نتائج الفحص للمشروع / القضية</h3><p class='small'>لتفاصيل أي تطابق (القائمة، السجل المطابق، ورقم العميل الداخلي المتعارض) افتح <a href='/screenings'>الفحص والتطابقات</a> واضغط \"تفاصيل\".</p>"
    return raw.replace("<h3>آخر نتائج الفحص للمشروع / القضية</h3>", note, 1).encode("utf-8")


# --- Guarantee every client gets a client number at creation (schema caching means the
#     backfill runs only once per process, so a client created mid-session could be blank). ---
_create_client_pre_v1511 = create_client
def create_client(fields: Dict[str, List[str]], files: Optional[Dict[str, Tuple[str, bytes]]] = None, ip: str = "") -> int:  # type: ignore[override]
    cid = _create_client_pre_v1511(fields, files, ip)
    try:
        with db() as con:
            row = con.execute("SELECT client_code FROM clients WHERE id=?", (cid,)).fetchone()
            if row is not None and not (row["client_code"] or ""):
                con.execute("UPDATE clients SET client_code=? WHERE id=?", (f"{cid:06d}", cid))
                con.commit()
    except Exception:
        pass
    return cid


# --- Route the detail page ---
_get_pre_v1511 = AppHandler.do_GET
def _do_get_v1511(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    if parsed.path != "/screening":
        return _get_pre_v1511(self)
    try:
        _AUTH_CTX.user = None
        _AUTH_CTX.user_agent = (self.headers.get("User-Agent", "") or "")[:400]
        _AUTH_CTX.ip = _real_client_ip(self)
        tok = _cookie_value(self, "masarat_session")
        _AUTH_CTX.session_id = hashlib.sha256(tok.encode("utf-8")).hexdigest()[:16] if tok else ""
    except Exception:
        pass
    user = _session_user(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    _AUTH_CTX.user = user
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    try:
        sid = int((parse_qs(parsed.query).get("id", ["0"])[0] or 0))
    except (TypeError, ValueError):
        sid = 0
    try:
        return self._send(screening_detail_page(sid))
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر عرض التفاصيل: {h(exc)}</div>", "/screenings"), 500)
AppHandler.do_GET = _do_get_v1511
# ===== End V10.5.11 =====


# ---------------------------------------------------------------------------
# V10.5.12 - Readable screenings register (compact; actions on the detail page),
# Arabic name-connector exclusion (بن/ابن/بنت — handled in match_score), and full
# record management: edit names & capacities of clients, projects (matters),
# counterparties, and related parties.
# ---------------------------------------------------------------------------
APP_VERSION = "V10.5.12 - Readable Register + Name Connectors + Full Record Editing"

_PARTY_ROLES = {"board_member": "عضو مجلس إدارة", "manager": "عضو هيئة مديرين", "ubo": "مستفيد حقيقي",
                "authorized_signatory": "مفوض بالتوقيع", "controller": "مسيطر فعلي"}
_CP_TYPES = {"company": "شركة", "individual": "فرد", "government": "جهة حكومية", "charity": "جمعية خيرية", "other": "أخرى"}


def _opts(mapping: Dict[str, str], sel: str) -> str:
    return "".join(f"<option value='{h(k)}' {'selected' if k == sel else ''}>{h(v)}</option>" for k, v in mapping.items())


def _pct_val(fields: Dict[str, List[str]]) -> Optional[float]:
    v = form_value(fields, "ownership_percent")
    if not v:
        return None
    try:
        return float(v.replace("٪", "").replace("%", "").strip())
    except ValueError:
        raise ValueError("نسبة الملكية يجب أن تكون رقماً مثل 25 أو 12.5")


# ----------------------------- update functions -----------------------------
def update_client(fields: Dict[str, List[str]], ip: str = "") -> int:
    cid = int(form_value(fields, "client_id", "0") or 0)
    with db() as con:
        ensure_schema(con)
        c = con.execute("SELECT * FROM clients WHERE id=?", (cid,)).fetchone()
        if not c:
            raise ValueError("العميل غير موجود")
        legal_name = form_value(fields, "legal_name") or c["legal_name"]
        client_type = form_value(fields, "client_type") or c["client_type"]
        listed = int(client_type == "company" and form_value(fields, "listed_saudi_market", "0") == "1")
        con.execute("""UPDATE clients SET legal_name=?, client_type=?, id_number=?, registration_number=?, country=?,
            nationality=?, listed_saudi_market=?, source_of_funds=?, source_of_wealth=?, source_notes=?, notes=?, updated_at=? WHERE id=?""",
            (legal_name, client_type, form_value(fields, "id_number"), form_value(fields, "registration_number"),
             form_value(fields, "country"), form_value(fields, "nationality"), listed,
             form_value(fields, "source_of_funds"), form_value(fields, "source_of_wealth"),
             form_value(fields, "source_notes"), form_value(fields, "notes"), now_iso(), cid))
        try:
            evaluate_client_risk(con, cid)
        except Exception:
            pass
        audit(con, "update_client", "client", cid, f"name={legal_name}; type={client_type}", ip)
        con.commit()
    return cid


def update_matter(fields: Dict[str, List[str]], ip: str = "") -> int:
    mid = int(form_value(fields, "matter_id", "0") or 0)
    with db() as con:
        ensure_schema(con)
        m = con.execute("SELECT * FROM matters WHERE id=?", (mid,)).fetchone()
        if not m:
            raise ValueError("المشروع / القضية غير موجود")
        title = form_value(fields, "title") or m["title"]
        con.execute("UPDATE matters SET title=?, service_type=?, description=?, updated_at=? WHERE id=?",
                    (title, form_value(fields, "service_type"), form_value(fields, "description"), now_iso(), mid))
        mp = form_value(fields, "managing_partner"); ep = form_value(fields, "executing_partner")
        if mp or ep:
            # V10.8: تعديل الشريك المدير/المنفذ في المراحل اللاحقة (تغير الشريك المنفذ وارد)
            con.execute("UPDATE matters SET managing_partner=COALESCE(NULLIF(?,''),managing_partner), executing_partner=COALESCE(NULLIF(?,''),executing_partner) WHERE id=?", (mp, ep, mid))
            audit(con, "update_matter_partners", "matter", mid, f"managing={mp}; executing={ep}", ip)
        try:
            evaluate_matter_risk(con, mid)
        except Exception:
            pass
        audit(con, "update_matter", "matter", mid, f"title={title}", ip)
        con.commit()
    return mid


def update_counterparty(fields: Dict[str, List[str]], ip: str = "") -> int:
    cpid = int(form_value(fields, "counterparty_id", "0") or 0)
    with db() as con:
        ensure_schema(con)
        cp = con.execute("SELECT * FROM counterparties WHERE id=?", (cpid,)).fetchone()
        if not cp:
            raise ValueError("الطرف المقابل غير موجود")
        full_name = form_value(fields, "full_name") or cp["full_name"]
        party_type = form_value(fields, "party_type") or cp["party_type"]
        con.execute("""UPDATE counterparties SET full_name=?, party_type=?, id_number=?, registration_number=?,
            nationality=?, country=?, role_in_matter=?, notes=? WHERE id=?""",
            (full_name, party_type, form_value(fields, "id_number"), form_value(fields, "registration_number"),
             form_value(fields, "nationality"), form_value(fields, "country"), form_value(fields, "role_in_matter"),
             form_value(fields, "notes"), cpid))
        try:
            evaluate_counterparty_risk(con, cpid)
        except Exception:
            pass
        audit(con, "update_counterparty", "counterparty", cpid, f"name={full_name}; type={party_type}", ip)
        con.commit()
    return cpid


def update_related_party(fields: Dict[str, List[str]], ip: str = "") -> Tuple[str, int]:
    pid = int(form_value(fields, "party_id", "0") or 0)
    pct = _pct_val(fields)
    with db() as con:
        ensure_schema(con)
        rp = con.execute("SELECT * FROM related_parties WHERE id=?", (pid,)).fetchone()
        if not rp:
            raise ValueError("الطرف المرتبط غير موجود")
        full_name = form_value(fields, "full_name") or rp["full_name"]
        party_role = form_value(fields, "party_role") or rp["party_role"]
        con.execute("""UPDATE related_parties SET full_name=?, party_role=?, id_number=?, registration_number=?,
            nationality=?, country=?, ownership_percent=?, notes=? WHERE id=?""",
            (full_name, party_role, form_value(fields, "id_number"), form_value(fields, "registration_number"),
             form_value(fields, "nationality"), form_value(fields, "country"), pct, form_value(fields, "notes"), pid))
        parent_type, parent_id = rp["parent_type"], int(rp["parent_id"])
        try:
            if parent_type == "client":
                evaluate_client_risk(con, parent_id)
            elif parent_type == "counterparty":
                evaluate_counterparty_risk(con, parent_id)
        except Exception:
            pass
        audit(con, "update_related_party", parent_type, parent_id, f"party={full_name}; role={party_role}", ip)
        con.commit()
    return parent_type, parent_id


# ----------------------------- edit pages -----------------------------
def _related_party_edit_rows(con: sqlite3.Connection, parent_type: str, parent_id: int, show_pct: bool) -> str:
    rows = con.execute("SELECT * FROM related_parties WHERE parent_type=? AND parent_id=? ORDER BY id", (parent_type, parent_id)).fetchall()
    if not rows:
        return "<p class='small'>لا توجد أطراف مرتبطة.</p>"
    out = []
    for p in rows:
        pct = "" if p["ownership_percent"] is None else p["ownership_percent"]
        pct_field = (f"<input name='ownership_percent' type='number' step='0.01' value='{h(pct)}' placeholder='نسبة %' style='max-width:90px'>" if show_pct else "")
        out.append(
            f"<form method='post' action='/party/update' style='display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:6px 0;border-bottom:1px solid var(--line);padding-bottom:6px'>"
            f"<input type='hidden' name='party_id' value='{p['id']}'>"
            f"<input name='full_name' value='{h(p['full_name'] or '')}' title='الاسم' style='max-width:170px'>"
            f"<select name='party_role' title='الصفة' style='max-width:150px'>{_opts(_PARTY_ROLES, p['party_role'] or 'board_member')}</select>"
            f"<input name='id_number' value='{h(p['id_number'] or '')}' placeholder='هوية' style='max-width:120px'>"
            f"<input name='registration_number' value='{h(p['registration_number'] or '')}' placeholder='سجل' style='max-width:120px'>"
            f"{pct_field}"
            f"<button class='btn secondary'>حفظ الطرف</button></form>")
    return "".join(out)


def client_edit_page(cid: int, message: str = "") -> bytes:
    with db() as con:
        ensure_schema(con)
        c = con.execute("SELECT * FROM clients WHERE id=?", (cid,)).fetchone()
        if not c:
            return layout("غير موجود", "<div class='error'>العميل غير موجود</div>", "/clients")
        rp_rows = _related_party_edit_rows(con, "client", cid, show_pct=True)
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    body = f"""
<div class="card"><h2>تعديل بيانات العميل — رقم {h(c['client_code'] or cid)}</h2>{msg}
<p class="notice">عدّل الاسم والصفة والأرقام المميزة. بعد تغيير الاسم أو الأرقام يُنصح بإعادة الفحص من صفحة العميل.</p>
<form method="post" action="/client/update"><input type="hidden" name="client_id" value="{cid}"><div class="grid">
<div><label>الاسم القانوني</label><input required name="legal_name" value="{h(c['legal_name'] or '')}"></div>
<div><label>نوع العميل / الصفة</label><select name="client_type">{client_type_options(c['client_type'] or '')}</select></div>
<div><label>رقم الهوية/الإقامة/الجواز</label><input name="id_number" value="{h(c['id_number'] or '')}"></div>
<div><label>رقم السجل التجاري/الكيان</label><input name="registration_number" value="{h(c['registration_number'] or '')}"></div>
<div><label>الرقم الموحد للمنشأة (700)</label><input name="unified_number" value="{h(c['unified_number'] or '')}" placeholder="7xxxxxxxxx (اتركه فارغاً للمسح)"><input type="hidden" name="unified_number_present" value="1"></div>
<div><label>الدولة</label><input name="country" value="{h(c['country'] or '')}"></div>
<div><label>الجنسية</label><input name="nationality" value="{h(c['nationality'] or '')}"></div>
<div><label>مدرجة في السوق المالية السعودية</label><select name="listed_saudi_market"><option value="0" {'selected' if not c['listed_saudi_market'] else ''}>لا</option><option value="1" {'selected' if c['listed_saudi_market'] else ''}>نعم</option></select></div>
<div><label>مصدر المال</label><input name="source_of_funds" value="{h(c['source_of_funds'] or '')}"></div>
<div><label>مصدر الثروة</label><input name="source_of_wealth" value="{h(c['source_of_wealth'] or '')}"></div>
</div><label>سبب تجاوز مصدر المال/الثروة</label><input name="source_notes" value="{h(c['source_notes'] or '')}">
<label>ملاحظات</label><textarea name="notes">{h(c['notes'] or '')}</textarea>
<button>حفظ تعديلات العميل</button> <a class="btn secondary" href="/client?id={cid}">رجوع لصفحة العميل</a></form></div>

<div class="card"><h3>تعديل الأطراف المرتبطة (مجلس/مديرون/مستفيدون) — الاسم والصفة</h3>
<p class="small">عدّل الاسم أو الصفة أو الأرقام لكل طرف ثم اضغط "حفظ الطرف".</p>{rp_rows}</div>
"""
    return layout("تعديل العميل", body, "/clients")


def matter_edit_page(mid: int, message: str = "") -> bytes:
    with db() as con:
        ensure_schema(con)
        m = con.execute("SELECT m.*, c.legal_name FROM matters m LEFT JOIN clients c ON c.id=m.client_id WHERE m.id=?", (mid,)).fetchone()
        if not m:
            return layout("غير موجود", "<div class='error'>المشروع / القضية غير موجود</div>", "/matters")
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    body = f"""
<div class="card"><h2>تعديل المشروع / القضية — {h(m['matter_number'])}</h2>{msg}
<p class="small">العميل: {auto_dir(m['legal_name'] or '')}</p>
<form method="post" action="/matter/update"><input type="hidden" name="matter_id" value="{mid}"><div class="grid">
<div><label>اسم العقد / المشروع / القضية</label><input required name="title" value="{h(m['title'] or '')}"></div>
<div><label>نوع الخدمة</label><select name="service_type">{service_type_options(m['service_type'] or '')}</select></div>
<div><label>الشريك المدير</label><select name="managing_partner">{_partner_options(m['managing_partner'] or '')}</select></div>
<div><label>الشريك المنفذ</label><select name="executing_partner">{_partner_options(m['executing_partner'] or '')}</select></div>
</div><label>الوصف</label><textarea name="description">{h(m['description'] or '')}</textarea>
<button>حفظ تعديلات المشروع</button> <a class="btn secondary" href="/matter?id={mid}">رجوع للمشروع</a></form></div>
"""
    return layout("تعديل المشروع", body, "/matters")


def counterparty_edit_page(cpid: int, message: str = "") -> bytes:
    with db() as con:
        ensure_schema(con)
        cp = con.execute("SELECT * FROM counterparties WHERE id=?", (cpid,)).fetchone()
        if not cp:
            return layout("غير موجود", "<div class='error'>الطرف المقابل غير موجود</div>", "/matters")
        rp_rows = _related_party_edit_rows(con, "counterparty", cpid, show_pct=True)
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    body = f"""
<div class="card"><h2>تعديل الطرف المقابل</h2>{msg}
<p class="notice">عدّل اسم الطرف وصفته وأرقامه المميزة. بعد التعديل يُنصح بإعادة فحص المشروع.</p>
<form method="post" action="/counterparty/update"><input type="hidden" name="counterparty_id" value="{cpid}"><div class="grid">
<div><label>اسم الطرف</label><input required name="full_name" value="{h(cp['full_name'] or '')}"></div>
<div><label>نوع الطرف / الصفة</label><select name="party_type">{_opts(_CP_TYPES, cp['party_type'] or 'company')}</select></div>
<div><label>رقم الهوية</label><input name="id_number" value="{h(cp['id_number'] or '')}"></div>
<div><label>رقم السجل</label><input name="registration_number" value="{h(cp['registration_number'] or '')}"></div>
<div><label>الجنسية</label><input name="nationality" value="{h(cp['nationality'] or '')}"></div>
<div><label>الدولة</label><input name="country" value="{h(cp['country'] or '')}"></div>
<div><label>صفة الطرف في المشروع / القضية</label><input name="role_in_matter" value="{h(cp['role_in_matter'] or '')}"></div>
</div><label>ملاحظات</label><textarea name="notes">{h(cp['notes'] or '')}</textarea>
<button>حفظ تعديلات الطرف المقابل</button> <a class="btn secondary" href="/counterparty?id={cpid}">رجوع للطرف</a></form></div>

<div class="card"><h3>تعديل أعضاء مجلس/مديرين/مستفيدين لهذا الطرف — الاسم والصفة</h3>{rp_rows}</div>
"""
    return layout("تعديل الطرف المقابل", body, "/matters")


# ----------------------------- compact register -----------------------------
def screenings_page(message: str = "") -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        rows_ = con.execute("SELECT * FROM screenings ORDER BY id DESC LIMIT 400").fetchall()
        enrich = {}
        for r in rows_:
            if r["screening_scope"] == "internal":
                enrich[r["id"]] = _internal_match_short(con, r)
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    parts = []
    for r in rows_:
        risk_level, visual_status, required_action = risk_visual_for_screening(r['status'], int(r['match_score'] or 0))
        row_cls = "status-red" if visual_status == "أحمر" else "status-yellow" if visual_status == "أصفر" else "status-green"
        matched_cell = auto_dir(r['matched_name'])
        extra = enrich.get(r["id"])
        if extra:
            matched_cell += f"<br><span class='small'>{h(extra)}</span>"
        subj = f"{auto_dir(r['subject_name'])}<br><span class='small'>{h(report_value_for_language('subject_type', r['subject_type'], 'ar'))}</span>"
        parts.append(
            f"<tr class='{row_cls}'><td><a href='/screening?id={r['id']}'>{r['id']}</a></td>"
            f"<td>{subj}</td>"
            f"<td>{h(report_value_for_language('scope', r['screening_scope'], 'ar'))}</td>"
            f"<td>{auto_dir(r['list_name'])}</td><td>{matched_cell}</td><td>{r['match_score']}</td>"
            f"<td>{badge_status(r['status'])}</td><td>{badge_status(visual_status)}</td>"
            f"<td><a class='btn secondary' href='/screening?id={r['id']}'>تفاصيل</a></td></tr>")
    body = f"""
<div class="card"><h2>الفحص والتطابقات</h2>{msg}<p class="notice">جدول مختصر لسهولة القراءة. اضغط "تفاصيل" لأي نتيجة لعرض القائمة بالتحديد والسجل المطابق بأرقامه ومصدره ورقم العميل الداخلي المتعارض، ولاتخاذ قرار الامتثال وإصدار تقرير PDF.</p></div>
<div class="card"><div class="table-wrap"><table><thead><tr><th>#</th><th>المفحوص</th><th>النطاق</th><th>القائمة</th><th>التطابق (والعميل الداخلي)</th><th>النسبة</th><th>الحالة</th><th>المؤشر</th><th>التفاصيل والقرار</th></tr></thead><tbody>{''.join(parts) or '<tr><td colspan="9">لا توجد نتائج</td></tr>'}</tbody></table></div></div>
"""
    return layout("الفحص", body, "/screenings")


# ----------------------------- inject edit links on detail pages -----------------------------
_client_detail_pre_v1512 = client_detail
def client_detail(client_id: int) -> bytes:  # type: ignore[override]
    raw = _client_detail_pre_v1512(client_id).decode("utf-8")
    link = f" <a class='btn secondary' href='/client/edit?id={client_id}'>تعديل البيانات والأطراف</a>"
    return raw.replace("</h2>", "</h2>" + link, 1).encode("utf-8")


_matter_detail_pre_v1512 = matter_detail
def matter_detail(matter_id: int) -> bytes:  # type: ignore[override]
    raw = _matter_detail_pre_v1512(matter_id).decode("utf-8")
    link = f" <a class='btn secondary' href='/matter/edit?id={matter_id}'>تعديل المشروع</a>"
    return raw.replace("</h2>", "</h2>" + link, 1).encode("utf-8")


_counterparty_detail_pre_v1512 = counterparty_detail
def counterparty_detail(cp_id: int) -> bytes:  # type: ignore[override]
    raw = _counterparty_detail_pre_v1512(cp_id).decode("utf-8")
    link = f" <a class='btn secondary' href='/counterparty/edit?id={cp_id}'>تعديل الطرف والأطراف المرتبطة</a>"
    return raw.replace("</h2>", "</h2>" + link, 1).encode("utf-8")


# ----------------------------- routes -----------------------------
def _v1512_ctx(handler: AppHandler) -> Optional[Dict[str, Any]]:
    try:
        _AUTH_CTX.user = None
        _AUTH_CTX.user_agent = (handler.headers.get("User-Agent", "") or "")[:400]
        _AUTH_CTX.ip = _real_client_ip(handler)
        tok = _cookie_value(handler, "masarat_session")
        _AUTH_CTX.session_id = hashlib.sha256(tok.encode("utf-8")).hexdigest()[:16] if tok else ""
    except Exception:
        pass
    user = _session_user(handler)
    if user:
        _AUTH_CTX.user = user
    return user


_EDIT_GET_ROUTES = {"/client/edit", "/matter/edit", "/counterparty/edit"}
_get_pre_v1512 = AppHandler.do_GET
def _do_get_v1512(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    if parsed.path not in _EDIT_GET_ROUTES:
        return _get_pre_v1512(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    try:
        rid = int((parse_qs(parsed.query).get("id", ["0"])[0] or 0))
    except (TypeError, ValueError):
        rid = 0
    try:
        if parsed.path == "/client/edit":
            return self._send(client_edit_page(rid))
        if parsed.path == "/matter/edit":
            return self._send(matter_edit_page(rid))
        return self._send(counterparty_edit_page(rid))
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر فتح صفحة التعديل: {h(exc)}</div>"), 500)
AppHandler.do_GET = _do_get_v1512


_EDIT_POST_ROUTES = {"/client/update", "/matter/update", "/counterparty/update", "/party/update"}
_post_pre_v1512 = AppHandler.do_POST
def _do_post_v1512(self: AppHandler) -> None:
    path = urlparse(self.path).path
    if path not in _EDIT_POST_ROUTES:
        return _post_pre_v1512(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    try:
        fields, files, ip = _parse_request_fields(self)
        if path == "/client/update":
            cid = update_client(fields, ip); return send_redirect(self, f"/client?id={cid}")
        if path == "/matter/update":
            mid = update_matter(fields, ip); return send_redirect(self, f"/matter?id={mid}")
        if path == "/counterparty/update":
            cpid = update_counterparty(fields, ip); return send_redirect(self, f"/counterparty?id={cpid}")
        ptype, pid = update_related_party(fields, ip)
        return send_redirect(self, f"/client?id={pid}" if ptype == "client" else f"/counterparty?id={pid}")
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر حفظ التعديل: {h(exc)}</div>"), 500)
AppHandler.do_POST = _do_post_v1512
# ===== End V10.5.12 =====


# ---------------------------------------------------------------------------
# V10.5.13 - Triage register. Addresses the layout question (slim wins over
# wide+wrap+bidirectional-scroll for an RTL triage list that already has a
# detail page) AND two correctness gaps the design review surfaced:
#   * the register showed only the 400 MOST RECENT screenings (ORDER BY id DESC
#     LIMIT 400), so an old UNRESOLVED red/sanctions hit could silently vanish;
#   * it was chronologically ordered with no risk sort and no "open items" filter.
# Now: default view = OPEN matches (anything not closed/false-positive), sorted
# by severity then score so no red/yellow ever hides; paginated; columns
# reordered so the risk signals LEAD (rightmost in RTL) and never scroll off;
# identity columns wrap (never ellipsis-clip a sanctioned name) while the short
# columns stay single-line; score shown as a right-aligned %.  No JavaScript.
# ---------------------------------------------------------------------------
APP_VERSION = "V10.5.13 - Triage Register (risk-sort + open-items filter + RTL-safe columns)"

# Statuses that count as RESOLVED (hidden from the default "open" view). Anything
# else — including confirmed_match / frozen / reported / blocked / under_review /
# list_unavailable — stays visible so no live risk is ever hidden by the filter.
_RESOLVED_SCREEN_STATUSES = {"no_match", "false_positive", "closed", "exempted_listed_company", "exempted_government", "known_relationship"}
_SCREEN_PAGE_SIZE = 200
_VIS_RANK = {"أحمر": 0, "أصفر": 1, "أخضر": 2}
_IND_LABEL = {"أحمر": "خطر مرتفع", "أصفر": "للمراجعة", "أخضر": "سليم"}
_IND_CLS = {"أحمر": "danger", "أصفر": "warn", "أخضر": "ok"}

_REG_CSS = (
    "<style>"
    ".filterbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:6px}"
    "table.reg th,table.reg td{white-space:nowrap;vertical-align:middle}"
    "table.reg td.idcell,table.reg th.idcell{white-space:normal;overflow-wrap:anywhere;max-width:26ch}"
    "table.reg td.numcell,table.reg th.numcell{text-align:right;font-variant-numeric:tabular-nums}"
    "@media(max-width:760px){table.reg .col-t2{display:none}}"
    "</style>"
)


def screenings_page(message: str = "", flt: str = "open", page: int = 1, scope: str = "") -> bytes:  # type: ignore[override]
    flt = "all" if flt == "all" else "open"
    scope = scope if scope in ("internal", "sanctions") else ""
    try:
        page = int(page)
    except (TypeError, ValueError):
        page = 1
    with db() as con:
        ensure_schema(con)
        all_rows = con.execute("SELECT * FROM screenings").fetchall()
        total_all = len(all_rows)
        decorated = []
        open_count = 0
        for r in all_rows:
            if scope and (r["screening_scope"] or "") != scope:
                continue
            _rl, visual_status, _ra = risk_visual_for_screening(r["status"], int(r["match_score"] or 0))
            is_open = (r["status"] or "") not in _RESOLVED_SCREEN_STATUSES
            if is_open:
                open_count += 1
            if flt == "open" and not is_open:
                continue
            # sort: severity (red<yellow<green) -> score desc -> newest id first
            decorated.append((_VIS_RANK.get(visual_status, 3), -(int(r["match_score"] or 0)), -int(r["id"]), r["id"], r, visual_status))
        decorated.sort(key=lambda t: (t[0], t[1], t[2]))
        shown_total = len(decorated)
        pages = max(1, (shown_total + _SCREEN_PAGE_SIZE - 1) // _SCREEN_PAGE_SIZE)
        page = max(1, min(page, pages))
        start = (page - 1) * _SCREEN_PAGE_SIZE
        page_rows = decorated[start:start + _SCREEN_PAGE_SIZE]
        enrich = {}
        for _rk, _ns, _ni, _id, r, _vs in page_rows:
            if r["screening_scope"] == "internal":
                enrich[r["id"]] = _internal_match_short(con, r)
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    parts = []
    for _rk, _ns, _ni, _id, r, visual_status in page_rows:
        row_cls = "status-red" if visual_status == "أحمر" else "status-yellow" if visual_status == "أصفر" else "status-green"
        ind = f"<span class='badge {_IND_CLS.get(visual_status, 'ok')}'>{h(_IND_LABEL.get(visual_status, ''))}</span>"
        score = int(r["match_score"] or 0)
        matched_cell = auto_dir(r["matched_name"])
        extra = enrich.get(r["id"])
        if extra:
            matched_cell += f"<br><span class='small'>{h(extra)}</span>"
        subj = f"{auto_dir(r['subject_name'])}<br><span class='small'>{h(report_value_for_language('subject_type', r['subject_type'], 'ar'))}</span>"
        parts.append(
            f"<tr class='{row_cls}'>"
            f"<td>{ind}</td>"
            f"<td>{badge_status(r['status'])}</td>"
            f"<td class='numcell'>{score}%</td>"
            f"<td>{h(report_value_for_language('scope', r['screening_scope'], 'ar'))}</td>"
            f"<td class='idcell'>{subj}</td>"
            f"<td class='idcell'>{matched_cell}</td>"
            f"<td class='col-t2'>{auto_dir(list_display_for_screening(r['screening_scope'], r['list_name'], r['matched_entity_type'], r['status']))}</td>"
            f"<td><a class='btn secondary' href='/screening?id={r['id']}'>تفاصيل #{r['id']}</a></td>"
            f"</tr>")
    open_cls = "ok" if flt == "open" else "secondary"
    all_cls = "ok" if flt == "all" else "secondary"
    scope_q = f"&scope={scope}" if scope else ""
    scope_chip = {"internal": " — التعارض الداخلي فقط", "sanctions": " — تطابقات القوائم فقط"}.get(scope, "")
    filterbar = (
        f"<div class='filterbar'>"
        f"<a class='btn {open_cls}' href='/screenings?filter=open{scope_q}'>المطابقات المفتوحة ({open_count}){scope_chip}</a>"
        f"<a class='btn {all_cls}' href='/screenings?filter=all{scope_q}'>عرض الكل ({total_all})</a>"
        + (f"<a class='btn secondary' href='/screenings?filter={flt}'>إلغاء تخصيص النطاق</a>" if scope else "")
        + "</div>")
    pager = ""
    if pages > 1:
        nxt = f"<a class='btn secondary' href='/screenings?filter={flt}&page={page + 1}{scope_q}'>التالي ←</a>" if page < pages else ""
        prev = f"<a class='btn secondary' href='/screenings?filter={flt}&page={page - 1}{scope_q}'>→ السابق</a>" if page > 1 else ""
        pager = f"<div class='filterbar'>{nxt}<span class='small'>صفحة {page} من {pages} — {shown_total} نتيجة</span>{prev}</div>"
    head = ("<thead><tr><th>المؤشر</th><th>الحالة</th><th class='numcell'>النسبة</th><th>النطاق</th>"
            "<th class='idcell'>المفحوص</th><th class='idcell'>التطابق (والعميل الداخلي)</th>"
            "<th class='col-t2'>القائمة</th><th>التفاصيل والقرار</th></tr></thead>")
    body = f"""
{_REG_CSS}
<div class="card"><h2>الفحص والتطابقات</h2>{msg}
<p class="notice">العرض الافتراضي يُظهر <b>المطابقات المفتوحة</b> (كل نتيجة لم تُغلَق أو تُوثَّق كـ False Positive) مرتَّبةً حسب الخطورة ثم النسبة، فلا تختفي أي مطابقة حمراء أو صفراء مهما قدُم تاريخها. اضغط "تفاصيل" لأي نتيجة لعرض القائمة بالتحديد والسجل المطابق بأرقامه ومصدره ورقم العميل الداخلي المتعارض، ولاتخاذ قرار الامتثال وإصدار تقرير PDF.</p>
{filterbar}</div>
<div class="card"><div class="table-wrap"><table class="reg">{head}<tbody>{''.join(parts) or '<tr><td colspan="8">لا توجد نتائج</td></tr>'}</tbody></table></div>{pager}</div>
"""
    return layout("الفحص", body, "/screenings")


# Route /screenings with filter + page (mirrors the auth gate of the detail route).
_get_pre_v1513 = AppHandler.do_GET
def _do_get_v1513(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    if parsed.path != "/screenings":
        return _get_pre_v1513(self)
    try:
        _AUTH_CTX.user = None
        _AUTH_CTX.user_agent = (self.headers.get("User-Agent", "") or "")[:400]
        _AUTH_CTX.ip = _real_client_ip(self)
        tok = _cookie_value(self, "masarat_session")
        _AUTH_CTX.session_id = hashlib.sha256(tok.encode("utf-8")).hexdigest()[:16] if tok else ""
    except Exception:
        pass
    user = _session_user(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    _AUTH_CTX.user = user
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    q = parse_qs(parsed.query)
    flt = (q.get("filter", ["open"])[0] or "open")
    scope = (q.get("scope", [""])[0] or "")
    try:
        page = int(q.get("page", ["1"])[0] or 1)
    except (TypeError, ValueError):
        page = 1
    try:
        return self._send(screenings_page("", flt, page, scope))
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر عرض السجل: {h(exc)}</div>", "/screenings"), 500)
AppHandler.do_GET = _do_get_v1513
# ===== End V10.5.13 =====


# ===========================================================================
# V10.6.0 - Joint Instructions (co-clients per matter)
# ---------------------------------------------------------------------------
# A matter/engagement may be instructed by MULTIPLE clients (co-clients), each a
# full KYC client record with a role: 'lead' (the primary, kept in matters.client_id
# for full backward-compatibility) or 'joint'. Everything additive; existing
# single-client matters are migrated to exactly one 'lead' row and behave identically.
# Stage 1: schema + idempotent seed + shared read/rollup helpers.
# ===========================================================================
APP_VERSION = "V10.6.0 - Joint Instructions (co-clients per matter)"

_JOINT_SCHEMA_ENSURED: set = set()

_JOINT_SCHEMA_DDL = """
CREATE TABLE IF NOT EXISTS matter_clients (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT    NOT NULL,
    matter_id  INTEGER NOT NULL REFERENCES matters(id),
    client_id  INTEGER NOT NULL REFERENCES clients(id),
    role       TEXT    NOT NULL DEFAULT 'joint' CHECK(role IN ('lead','joint')),
    UNIQUE(matter_id, client_id)
);
CREATE INDEX IF NOT EXISTS idx_matter_clients_client ON matter_clients(client_id);
CREATE UNIQUE INDEX IF NOT EXISTS ux_matter_clients_one_lead ON matter_clients(matter_id) WHERE role='lead';
"""

# Triple-guarded, orphan/FK-safe seed: one 'lead' row per existing matter.
_JOINT_SEED_SQL = """
INSERT OR IGNORE INTO matter_clients(created_at, matter_id, client_id, role)
  SELECT ?, m.id, m.client_id, 'lead'
    FROM matters m
   WHERE m.client_id IS NOT NULL
     AND EXISTS     (SELECT 1 FROM clients c        WHERE c.id = m.client_id)
     AND NOT EXISTS (SELECT 1 FROM matter_clients mc WHERE mc.matter_id = m.id AND mc.role = 'lead')
"""

# Backstop: if a matter has a 'joint' row for its own owner but no 'lead' row
# (e.g. odd insert order), promote it so "every matter has exactly one lead" holds.
_JOINT_SEED_FIX_SQL = """
UPDATE matter_clients SET role='lead'
 WHERE role='joint'
   AND client_id IN (SELECT client_id FROM matters WHERE id = matter_clients.matter_id)
   AND NOT EXISTS (SELECT 1 FROM matter_clients mc2 WHERE mc2.matter_id = matter_clients.matter_id AND mc2.role='lead')
"""

_ensure_schema_pre_joint = ensure_schema


def ensure_schema(con: sqlite3.Connection, force: bool = False) -> None:  # type: ignore[override]
    _ensure_schema_pre_joint(con, force)
    key = str(DB_PATH)
    if not force and key in _JOINT_SCHEMA_ENSURED:
        return
    con.executescript(_JOINT_SCHEMA_DDL)
    con.execute(_JOINT_SEED_SQL, (now_iso(),))
    con.execute(_JOINT_SEED_FIX_SQL)
    con.execute("INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES('V10.6.0-joint-instructions', ?)", (now_iso(),))
    con.commit()
    _JOINT_SCHEMA_ENSURED.add(key)


def matter_instructing_clients(con: sqlite3.Connection, matter_id: int) -> List[Dict[str, Any]]:
    """All clients instructing a matter (lead first). Falls back to matters.client_id
    if the junction has no row yet (defensive; pre/around backfill)."""
    rows = con.execute(
        "SELECT mc.role AS role, c.id AS client_id, c.legal_name AS legal_name, c.client_code AS client_code, "
        "c.status AS status, c.risk_level AS risk_level "
        "FROM matter_clients mc JOIN clients c ON c.id = mc.client_id "
        "WHERE mc.matter_id = ? ORDER BY CASE mc.role WHEN 'lead' THEN 0 ELSE 1 END, c.legal_name",
        (matter_id,)).fetchall()
    if rows:
        return [dict(r) for r in rows]
    m = con.execute("SELECT client_id FROM matters WHERE id=?", (matter_id,)).fetchone()
    if m and m["client_id"]:
        c = con.execute("SELECT id AS client_id, legal_name, client_code, status, risk_level FROM clients WHERE id=?", (m["client_id"],)).fetchone()
        if c:
            return [{"role": "lead", **dict(c)}]
    return []


def _matters_for_client(con: sqlite3.Connection, client_id: int) -> List[int]:
    """Every matter this client instructs (as lead via matters.client_id OR as any junction role)."""
    ids = {r[0] for r in con.execute("SELECT id FROM matters WHERE client_id=?", (client_id,)).fetchall()}
    ids |= {r[0] for r in con.execute("SELECT matter_id FROM matter_clients WHERE client_id=?", (client_id,)).fetchall()}
    return sorted(ids)


def _effective_client_risk(con: sqlite3.Connection, client_id: int) -> str:
    """A client's effective risk = max(stored risk_level, highest current risk_flag severity).
    Lets an association flag raise the rollup without mutating clients.risk_level."""
    c = con.execute("SELECT risk_level FROM clients WHERE id=?", (client_id,)).fetchone()
    best = (c["risk_level"] if c else "") or "normal"
    best_rank = _severity_rank(best)
    for f in con.execute("SELECT severity FROM risk_flags WHERE entity_type='client' AND entity_id=?", (client_id,)).fetchall():
        if _severity_rank(f["severity"]) > best_rank:
            best, best_rank = (f["severity"] or best), _severity_rank(f["severity"])
    return best


_SEVERITY_BY_RANK = {0: "normal", 1: "low", 2: "medium", 3: "high", 4: "critical"}


# ---- V10.6 Stage 2: write paths + creation form ----
def _autoscreen_client(client_id: int, ip: str = "") -> None:
    """Auto-screen a client when attached as a co-client (best-effort; never blocks the write)."""
    try:
        run_client_screening(int(client_id), ip)
    except Exception:
        pass


def _write_instructing_clients(con: sqlite3.Connection, matter_id: int, lead_id: int, joint_ids: List[int]) -> List[int]:
    """Write the lead + joint junction rows for a matter (idempotent). Returns joint ids added."""
    if lead_id:
        con.execute("INSERT OR IGNORE INTO matter_clients(created_at, matter_id, client_id, role) VALUES(?,?,?, 'lead')", (now_iso(), matter_id, lead_id))
    added: List[int] = []
    for jid in joint_ids:
        if jid and jid != lead_id:
            con.execute("INSERT OR IGNORE INTO matter_clients(created_at, matter_id, client_id, role) VALUES(?,?,?, 'joint')", (now_iso(), matter_id, jid))
            added.append(jid)
    return added


def _joint_ids_from_fields(fields: Dict[str, List[str]]) -> List[int]:
    out: List[int] = []
    for r in (fields.get("joint_client_id", []) if isinstance(fields, dict) else []):
        try:
            v = int(r or 0)
        except (TypeError, ValueError):
            continue
        if v:
            out.append(v)
    return out


_base_create_matter_v106 = create_matter
def create_matter(fields: Dict[str, List[str]], ip: str = "") -> int:  # type: ignore[override]
    mid = _base_create_matter_v106(fields, ip)
    lead = int(form_value(fields, "client_id", "0") or 0)
    joint_ids = _joint_ids_from_fields(fields)
    with db() as con:
        ensure_schema(con)
        added = _write_instructing_clients(con, mid, lead, joint_ids)
        if added:
            audit(con, "matter_set_instructing_clients", "matter", mid, f"lead={lead}; joint={added}", ip)
        con.commit()
    for jid in {j for j in joint_ids if j and j != lead}:
        _autoscreen_client(jid, ip)  # auto-screen co-clients on add
    return mid


_base_matter_form_v106 = matter_form
def matter_form(prefill_client_id: str = "") -> bytes:  # type: ignore[override]
    raw = _base_matter_form_v106(prefill_client_id).decode("utf-8")
    with db() as con:
        ensure_schema(con)
        opts = _v105_clients_options(con)
    card = ("<div class=\"card\"><h3>العملاء المشاركون (تعليمات مشتركة)</h3>"
            "<p class=\"small\">اختياري: أضِف عملاء آخرين يوكِّلون في هذا المشروع/القضية مع العميل الرئيسي. "
            "كل عميل مشارك سِجلّ عميل كامل ويُفحَص تلقائياً عند الإضافة. (استخدم Ctrl/⌘ للاختيار المتعدد)</p>"
            f"<label>عملاء مشاركون</label><select name=\"joint_client_id\" multiple size=\"6\">{opts}</select></div>")
    return raw.replace("<button>حفظ المشروع / القضية</button>", card + "<button>حفظ المشروع / القضية</button>", 1).encode("utf-8")


# ---- V10.6 Stage 3: detail/edit UI + add/remove/promote handlers + routes ----
def _mc_role_badge(role: str) -> str:
    return "<span class='badge danger'>عميل رئيسي</span>" if role == "lead" else "<span class='badge'>عميل مشارك</span>"


_matter_detail_pre_v106 = matter_detail
def matter_detail(matter_id: int) -> bytes:  # type: ignore[override]
    raw = _matter_detail_pre_v106(matter_id).decode("utf-8")
    with db() as con:
        ensure_schema(con)
        ic = matter_instructing_clients(con, matter_id)
    if not ic:
        return raw.encode("utf-8")
    trs = []
    for d in ic:
        code = d.get("client_code") or ("%06d" % int(d["client_id"]))
        trs.append(
            "<tr><td><a href='/client?id=%d'>%s</a></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (
                int(d["client_id"]), h(d["legal_name"]), h(code), _mc_role_badge(d["role"]),
                badge_status(d.get("status") or ""), h(d.get("risk_level") or "")))
    card = ("<div class=\"card\"><h3>العملاء المُوكِّلون (تعليمات مشتركة)</h3>"
            "<table><thead><tr><th>العميل</th><th>الرقم</th><th>الصفة</th><th>الحالة</th><th>المخاطر</th></tr></thead><tbody>"
            + "".join(trs)
            + "</tbody></table><p class=\"small\"><a class=\"btn secondary\" href=\"/matter/edit?id=%d\">إدارة العملاء المشاركين</a></p></div>" % matter_id)
    anchor = "<div class=\"card\"><h3>إضافة طرف مقابل جديد</h3>"
    raw = raw.replace(anchor, card + anchor, 1) if anchor in raw else raw + card
    return raw.encode("utf-8")


_matter_edit_page_pre_v106 = matter_edit_page
def matter_edit_page(mid: int, message: str = "") -> bytes:  # type: ignore[override]
    raw = _matter_edit_page_pre_v106(mid, message).decode("utf-8")
    with db() as con:
        ensure_schema(con)
        ic = matter_instructing_clients(con, mid)
        opts = _v105_clients_options(con)
    rows = []
    for d in ic:
        cid = int(d["client_id"]); name = h(d["legal_name"])
        if d["role"] == "lead":
            rows.append("<tr><td>%s</td><td>%s</td><td class='small'>العميل الرئيسي — لا يُزال (عيّن عميلاً رئيسياً آخر لاستبداله)</td></tr>" % (name, _mc_role_badge("lead")))
        else:
            actions = (
                "<form method='post' action='/matter/remove_client' style='display:inline'>"
                "<input type='hidden' name='matter_id' value='%d'><input type='hidden' name='client_id' value='%d'>"
                "<button class='btn danger'>إزالة</button></form> "
                "<form method='post' action='/matter/add_client' style='display:inline'>"
                "<input type='hidden' name='matter_id' value='%d'><input type='hidden' name='client_id' value='%d'>"
                "<input type='hidden' name='set_lead' value='1'><button class='btn secondary'>تعيين كعميل رئيسي</button></form>"
            ) % (mid, cid, mid, cid)
            rows.append("<tr><td>%s</td><td>%s</td><td>%s</td></tr>" % (name, _mc_role_badge("joint"), actions))
    add_form = (
        "<form method='post' action='/matter/add_client'><input type='hidden' name='matter_id' value='%d'>"
        "<div class='grid'><div><label>إضافة عميل مشارك</label><select name='client_id' required>%s</select></div></div>"
        "<label><input type='checkbox' name='set_lead' value='1'> تعيينه عميلاً رئيسياً (يستبدل الحالي)</label>"
        "<button>إضافة العميل للمشروع</button></form>"
    ) % (mid, opts)
    card = ("<div class=\"card\"><h3>العملاء المُوكِّلون (تعليمات مشتركة)</h3>"
            "<p class=\"small\">العميل المشارك سِجلّ عميل كامل ويُفحَص تلقائياً عند إضافته. لا يمكن إزالة العميل الرئيسي إلا بتعيين عميل رئيسي آخر أولاً.</p>"
            "<table><thead><tr><th>العميل</th><th>الصفة</th><th>الإجراء</th></tr></thead><tbody>"
            + "".join(rows) + "</tbody></table>" + add_form + "</div>")
    anchor = "رجوع للمشروع</a></form></div>"
    raw = raw.replace(anchor, anchor + card, 1) if anchor in raw else raw + card
    return raw.encode("utf-8")


def matter_add_client(fields: Dict[str, List[str]], ip: str = "") -> int:
    mid = int(form_value(fields, "matter_id", "0") or 0)
    cid = int(form_value(fields, "client_id", "0") or 0)
    set_lead = form_value(fields, "set_lead", "0") == "1"
    if not mid or not cid:
        raise ValueError("بيانات غير مكتملة")
    with db() as con:
        ensure_schema(con)
        m = con.execute("SELECT client_id FROM matters WHERE id=?", (mid,)).fetchone()
        if not m:
            raise ValueError("المشروع / القضية غير موجود")
        if not con.execute("SELECT 1 FROM clients WHERE id=?", (cid,)).fetchone():
            raise ValueError("العميل غير موجود")
        if set_lead:
            # demote the current lead FIRST (partial unique lead index), then promote, then sync matters.client_id
            con.execute("UPDATE matter_clients SET role='joint' WHERE matter_id=? AND role='lead'", (mid,))
            con.execute("INSERT OR IGNORE INTO matter_clients(created_at,matter_id,client_id,role) VALUES(?,?,?, 'lead')", (now_iso(), mid, cid))
            con.execute("UPDATE matter_clients SET role='lead' WHERE matter_id=? AND client_id=?", (mid, cid))
            con.execute("UPDATE matters SET client_id=?, updated_at=? WHERE id=?", (cid, now_iso(), mid))
            audit(con, "matter_set_lead_client", "matter", mid, f"lead={cid}", ip)
        else:
            con.execute("INSERT OR IGNORE INTO matter_clients(created_at,matter_id,client_id,role) VALUES(?,?,?, 'joint')", (now_iso(), mid, cid))
            audit(con, "matter_add_client", "matter", mid, f"joint={cid}", ip)
        con.commit()
    _autoscreen_client(cid, ip)  # auto-screen on add
    with db() as con:
        ensure_schema(con)
        try:
            evaluate_matter_risk(con, mid); con.commit()
        except Exception:
            pass
    return mid


def matter_remove_client(fields: Dict[str, List[str]], ip: str = "") -> int:
    mid = int(form_value(fields, "matter_id", "0") or 0)
    cid = int(form_value(fields, "client_id", "0") or 0)
    with db() as con:
        ensure_schema(con)
        m = con.execute("SELECT client_id FROM matters WHERE id=?", (mid,)).fetchone()
        if not m:
            raise ValueError("المشروع / القضية غير موجود")
        if cid == int(m["client_id"] or 0):
            raise ValueError("لا يمكن إزالة العميل الرئيسي؛ عيّن عميلاً رئيسياً آخر أولاً")
        con.execute("DELETE FROM matter_clients WHERE matter_id=? AND client_id=? AND role='joint'", (mid, cid))
        audit(con, "matter_remove_client", "matter", mid, f"removed={cid}", ip)
        try:
            evaluate_matter_risk(con, mid)
        except Exception:
            pass
        con.commit()
    return mid


_MATTER_CLIENT_ROUTES = {"/matter/add_client", "/matter/remove_client"}
_post_pre_v106 = AppHandler.do_POST
def _do_post_v106(self: AppHandler) -> None:
    path = urlparse(self.path).path
    if path not in _MATTER_CLIENT_ROUTES:
        return _post_pre_v106(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    try:
        fields, files, ip = _parse_request_fields(self)
        mid = matter_add_client(fields, ip) if path == "/matter/add_client" else matter_remove_client(fields, ip)
        return send_redirect(self, f"/matter/edit?id={mid}")
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر تحديث العملاء المشاركين: {h(exc)}</div>", "/matters"), 500)
AppHandler.do_POST = _do_post_v106


# ---- V10.6 Stage 4: screening covers joint co-clients + most-conservative risk rollup ----
_evaluate_matter_risk_pre_v106 = evaluate_matter_risk
def evaluate_matter_risk(con: sqlite3.Connection, matter_id: int) -> None:  # type: ignore[override]
    _evaluate_matter_risk_pre_v106(con, matter_id)  # base keyword risk -> sets matters.risk_level
    m = con.execute("SELECT risk_level FROM matters WHERE id=?", (matter_id,)).fetchone()
    if not m:
        return
    rank = _severity_rank(m["risk_level"] or "normal")
    for cp in con.execute("SELECT risk_level FROM counterparties WHERE matter_id=?", (matter_id,)).fetchall():
        rank = max(rank, _severity_rank(cp["risk_level"] or "normal"))
    for d in matter_instructing_clients(con, matter_id):
        rank = max(rank, _severity_rank(_effective_client_risk(con, int(d["client_id"]))))
    sev = _SEVERITY_BY_RANK.get(rank, "normal")
    if sev == "low":
        sev = "normal"  # matters use normal/medium/high/critical
    con.execute("UPDATE matters SET risk_level=? WHERE id=?", (sev, matter_id))


_run_matter_screening_pre_v106 = run_matter_screening
def run_matter_screening(matter_id: int, ip: str = "", screening_mode: str = "both") -> Dict[str, int]:  # type: ignore[override]
    base = _run_matter_screening_pre_v106(matter_id, ip, screening_mode)
    with db() as con:
        ensure_schema(con)
        ics = matter_instructing_clients(con, matter_id)
    joint_ids = [int(d["client_id"]) for d in ics if d["role"] == "joint"]
    for jid in joint_ids:  # auto-screen the joint co-clients (lead keeps its own client-page flow)
        try:
            run_client_screening(jid, ip, screening_mode)
        except Exception:
            pass
    # recompute matter status from the COMBINED subject set (so a co-client-only matter isn't stuck)
    base_dirty = bool(base.get("hits", 0)) or (base.get("warnings", 0) and base.get("created", 0) > 0)
    with db() as con:
        ensure_schema(con)
        statuses = []
        for d in ics:
            r = con.execute("SELECT status FROM clients WHERE id=?", (int(d["client_id"]),)).fetchone()
            statuses.append((r["status"] if r else "") or "")
        dirty = base_dirty or any(s in ("under_review", "blocked", "frozen") for s in statuses)
        if dirty:
            con.execute("UPDATE matters SET status='under_review', updated_at=? WHERE id=? AND status NOT IN ('blocked','frozen')", (now_iso(), matter_id))
        elif screening_mode == "both":
            con.execute("UPDATE matters SET status='active', updated_at=? WHERE id=? AND status NOT IN ('blocked','frozen')", (now_iso(), matter_id))
        try:
            evaluate_matter_risk(con, matter_id)
        except Exception:
            pass
        con.commit()
    return base


# Re-aggregation triggers: refresh matter risk when an instructing client's risk changes.
_update_client_pre_v106 = update_client
def update_client(fields: Dict[str, List[str]], ip: str = "") -> int:  # type: ignore[override]
    cid = _update_client_pre_v106(fields, ip)
    try:
        with db() as con:
            ensure_schema(con)
            for mid in _matters_for_client(con, cid):
                try:
                    evaluate_matter_risk(con, mid)
                except Exception:
                    pass
            con.commit()
    except Exception:
        pass
    return cid


_add_related_party_pre_v106 = add_related_party
def add_related_party(fields: Dict[str, List[str]], parent_type: str, parent_id_key: str, ip: str = "") -> int:  # type: ignore[override]
    pid = _add_related_party_pre_v106(fields, parent_type, parent_id_key, ip)
    try:
        parent_id = int(form_value(fields, parent_id_key, "0") or 0)
        with db() as con:
            ensure_schema(con)
            if parent_type == "client":
                for mid in _matters_for_client(con, parent_id):
                    try:
                        evaluate_matter_risk(con, mid)
                    except Exception:
                        pass
            elif parent_type == "counterparty":
                r = con.execute("SELECT matter_id FROM counterparties WHERE id=?", (parent_id,)).fetchone()
                if r and r["matter_id"]:
                    try:
                        evaluate_matter_risk(con, int(r["matter_id"]))
                    except Exception:
                        pass
            con.commit()
    except Exception:
        pass
    return pid


# ---- V10.6 Stage 5: compliance cascade — association risk for instructing co-clients ----
# Policy (client decision): a CONFIRMED match blocks the MATCHED entity + the matter, but the
# instructing co-clients are NOT hard-blocked — they are labelled "high risk by association"
# (a self-healing derived risk flag) and set to under-review. When the match is closed as a
# documented false positive, the association clears and the co-clients reactivate automatically.
_ASSOC_FLAG = "ASSOC_CONFIRMED_MATCH"
_CONFIRMED_STATES = ("confirmed_match", "frozen", "reported")
_OPEN_STATES = ("confirmed_match", "high_similarity", "potential_match", "frozen", "reported")


def _client_direct_confirmed_hit(con: sqlite3.Connection, client_id: int, exclude_sid: int = 0) -> bool:
    ph = ",".join("?" for _ in _CONFIRMED_STATES)
    return con.execute(
        f"SELECT COUNT(*) FROM screenings s WHERE s.id<>? AND s.status IN ({ph}) AND "
        "((s.subject_type='client' AND s.subject_id=?) OR (s.subject_type='client_related_party' "
        "AND s.subject_id IN (SELECT id FROM related_parties WHERE parent_type='client' AND parent_id=?)))",
        (int(exclude_sid), *_CONFIRMED_STATES, int(client_id), int(client_id))).fetchone()[0] > 0


def _client_open_hit(con: sqlite3.Connection, client_id: int) -> bool:
    ph = ",".join("?" for _ in _OPEN_STATES)
    return con.execute(
        f"SELECT COUNT(*) FROM screenings s WHERE s.status IN ({ph}) AND "
        "((s.subject_type='client' AND s.subject_id=?) OR (s.subject_type='client_related_party' "
        "AND s.subject_id IN (SELECT id FROM related_parties WHERE parent_type='client' AND parent_id=?)))",
        (*_OPEN_STATES, int(client_id), int(client_id))).fetchone()[0] > 0


def _client_association_reason(con: sqlite3.Connection, client_id: int) -> str:
    """Non-empty if the client instructs a matter carrying an ACTIVE confirmed match attributable to
    a DIFFERENT subject (a counterparty of the matter, or another instructing co-client)."""
    ph = ",".join("?" for _ in _CONFIRMED_STATES)
    reasons: List[str] = []
    for mid in _matters_for_client(con, int(client_id)):
        cp_hit = con.execute(
            f"SELECT COUNT(*) FROM screenings s WHERE s.status IN ({ph}) AND "
            "((s.subject_type='counterparty' AND s.subject_id IN (SELECT id FROM counterparties WHERE matter_id=?)) "
            "OR (s.subject_type='counterparty_related_party' AND s.subject_id IN "
            "(SELECT id FROM related_parties WHERE parent_type='counterparty' AND parent_id IN "
            "(SELECT id FROM counterparties WHERE matter_id=?))))",
            (*_CONFIRMED_STATES, mid, mid)).fetchone()[0]
        oc_hit = 0
        for d in matter_instructing_clients(con, mid):
            oc = int(d["client_id"])
            if oc == int(client_id):
                continue
            oc_hit += con.execute(
                f"SELECT COUNT(*) FROM screenings s WHERE s.status IN ({ph}) AND "
                "((s.subject_type='client' AND s.subject_id=?) OR (s.subject_type='client_related_party' "
                "AND s.subject_id IN (SELECT id FROM related_parties WHERE parent_type='client' AND parent_id=?)))",
                (*_CONFIRMED_STATES, oc, oc)).fetchone()[0]
        if cp_hit or oc_hit:
            mrow = con.execute("SELECT matter_number FROM matters WHERE id=?", (mid,)).fetchone()
            reasons.append("مطابقة مؤكدة مرتبطة بالمشروع %s" % ((mrow["matter_number"] if mrow and mrow["matter_number"] else mid)))
    return "؛ ".join(reasons)


_evaluate_client_risk_pre_v106 = evaluate_client_risk
def evaluate_client_risk(con: sqlite3.Connection, client_id: int) -> None:  # type: ignore[override]
    _evaluate_client_risk_pre_v106(con, client_id)
    con.execute("DELETE FROM risk_flags WHERE entity_type='client' AND entity_id=? AND flag_code=?", (int(client_id), _ASSOC_FLAG))
    reason = _client_association_reason(con, int(client_id))
    if reason:
        _add_risk_flag(con, "client", int(client_id), _ASSOC_FLAG,
                       "مخاطر عالية بالارتباط بمطابقة مؤكدة على مشروع/قضية مشتركة", "high", reason)


_case_for_screening_pre_v106 = _case_for_screening
def _case_for_screening(con: sqlite3.Connection, screening_id: int, status: str, reason: str, ip: str = "") -> None:  # type: ignore[override]
    r = con.execute("SELECT * FROM screenings WHERE id=?", (screening_id,)).fetchone()
    _case_for_screening_pre_v106(con, screening_id, status, reason, ip)
    if not r:
        return
    client_id, matter_id, counterparty_id = report_context_for_screening(con, r)
    subject_is_client = r["subject_type"] in ("client", "client_related_party")

    # A non-client (counterparty) confirmed match must NOT hard-block the instructing lead client;
    # relax the base block to under-review (unless the client has its OWN direct confirmed hit).
    if matter_id and not subject_is_client and status in _CONFIRMED_STATES and client_id:
        if not _client_direct_confirmed_hit(con, int(client_id), exclude_sid=int(screening_id)):
            con.execute("UPDATE clients SET status='under_review', updated_at=? WHERE id=? AND status='blocked'", (now_iso(), int(client_id)))

    # Affected matters: the matter of a counterparty hit, or all matters of a hit client.
    affected = []
    if matter_id:
        affected = [int(matter_id)]
    elif subject_is_client and client_id:
        affected = _matters_for_client(con, int(client_id))

    seen = set()
    for mid in affected:
        for d in matter_instructing_clients(con, mid):
            cid = int(d["client_id"])
            if cid in seen:
                continue
            seen.add(cid)
            evaluate_client_risk(con, cid)  # (re)derive the association flag — self-healing on close
            has_assoc = con.execute("SELECT 1 FROM risk_flags WHERE entity_type='client' AND entity_id=? AND flag_code=?", (cid, _ASSOC_FLAG)).fetchone()
            if has_assoc:
                con.execute("UPDATE clients SET status='under_review', updated_at=? WHERE id=? AND status NOT IN ('blocked','frozen')", (now_iso(), cid))
            elif not _client_open_hit(con, cid):
                con.execute("UPDATE clients SET status='active', updated_at=? WHERE id=? AND status='under_review'", (now_iso(), cid))
        try:
            evaluate_matter_risk(con, mid)
        except Exception:
            pass


# ---- V10.6 Stage 6: name co-clients in compliance records (detail page, report details, archive) ----
def _matter_co_client_label(con: sqlite3.Connection, matter_id: int, exclude_client_id: Optional[int] = None) -> str:
    parts = []
    for d in matter_instructing_clients(con, int(matter_id)):
        cid = int(d["client_id"])
        if exclude_client_id and cid == int(exclude_client_id):
            continue
        code = d.get("client_code") or ("%06d" % cid)
        role = "رئيسي" if d["role"] == "lead" else "مشارك"
        parts.append("%s (%s، %s)" % (d["legal_name"], code, role))
    return "، ".join(parts)


def _matter_id_for_screening(con: sqlite3.Connection, r: sqlite3.Row) -> Optional[int]:
    st = r["subject_type"]
    sid = int(r["subject_id"] or 0)
    if st == "counterparty":
        row = con.execute("SELECT matter_id FROM counterparties WHERE id=?", (sid,)).fetchone()
        return int(row["matter_id"]) if row and row["matter_id"] else None
    if st == "counterparty_related_party":
        row = con.execute("SELECT cp.matter_id FROM related_parties rp LEFT JOIN counterparties cp ON cp.id=rp.parent_id WHERE rp.id=?", (sid,)).fetchone()
        return int(row["matter_id"]) if row and row["matter_id"] else None
    return None


_screening_report_details_pre_v106 = screening_report_details
def screening_report_details(con: sqlite3.Connection, r: sqlite3.Row) -> Dict[str, Any]:  # type: ignore[override]
    details = _screening_report_details_pre_v106(con, r)
    try:
        mid = _matter_id_for_screening(con, r)
        details["co_client_names"] = _matter_co_client_label(con, mid) if mid else ""
    except Exception:
        details.setdefault("co_client_names", "")
    return details


_screening_detail_page_pre_v106 = screening_detail_page
def screening_detail_page(sid: int) -> bytes:  # type: ignore[override]
    raw = _screening_detail_page_pre_v106(sid).decode("utf-8")
    try:
        with db() as con:
            ensure_schema(con)
            r = con.execute("SELECT * FROM screenings WHERE id=?", (int(sid or 0),)).fetchone()
            mid = _matter_id_for_screening(con, r) if r else None
            ics = matter_instructing_clients(con, mid) if mid else []
            label = _matter_co_client_label(con, mid) if mid else ""
        if mid and len(ics) >= 2 and label:  # only when the matter is genuinely jointly-instructed
            note = f"<p class='notice'><b>العملاء المُوكِّلون (تعليمات مشتركة):</b> {h(label)} — أي مطابقة مؤكدة على هذا المشروع/القضية تُوسم كمخاطر عالية بالارتباط على العملاء المشاركين.</p>"
            anchor = '<p class="notice"><b>الإجراء المطلوب:</b>'
            if anchor in raw:
                raw = raw.replace(anchor, note + anchor, 1)
            else:
                raw = raw + note
    except Exception:
        pass
    return raw.encode("utf-8")


# ===========================================================================
# V10.6.1 - Joint-instructions aggregation on the partner dashboard & compliance
# page. Additive cards computed directly from matter_clients (no row surgery on
# the existing screens), so co-clients and association alerts surface where
# partners and compliance actually look. Display-only; no schema change.
# ===========================================================================
APP_VERSION = "V10.6.1 - Joint Instructions dashboard aggregation"


def _instructing_clients_cell(con: sqlite3.Connection, matter_id: int) -> str:
    parts = []
    for d in matter_instructing_clients(con, int(matter_id)):
        cid = int(d["client_id"])
        eff = _effective_client_risk(con, cid)
        assoc = con.execute("SELECT 1 FROM risk_flags WHERE entity_type='client' AND entity_id=? AND flag_code=?", (cid, _ASSOC_FLAG)).fetchone()
        tag = " <span class='badge danger'>ارتباط بمطابقة مؤكدة</span>" if assoc else ""
        role = "عميل رئيسي" if d["role"] == "lead" else "عميل مشارك"
        parts.append("<div style='margin:3px 0'><a href='/client?id=%d'>%s</a> — %s · %s · مخاطر: %s%s</div>" % (
            cid, h(d["legal_name"]), role, badge_status(d.get("status") or ""), h(eff), tag))
    return "".join(parts)


def _joint_matters_card(con: sqlite3.Connection, partner: str = "", title: str = "التعليمات المشتركة على مشاريعي") -> str:
    if partner:
        ms = con.execute(
            "SELECT m.id, m.matter_number, m.title FROM matters m WHERE (m.managing_partner=? OR m.executing_partner=?) "
            "AND (SELECT COUNT(*) FROM matter_clients mc WHERE mc.matter_id=m.id) >= 2 ORDER BY m.id DESC LIMIT 200",
            (partner, partner)).fetchall()
    else:
        ms = con.execute(
            "SELECT m.id, m.matter_number, m.title FROM matters m WHERE "
            "(SELECT COUNT(*) FROM matter_clients mc WHERE mc.matter_id=m.id) >= 2 ORDER BY m.id DESC LIMIT 200").fetchall()
    if not ms:
        return ""
    rows = "".join(
        "<tr><td><a href='/matter?id=%d'>%s</a></td><td>%s</td><td>%s</td></tr>" % (
            int(m["id"]), h(m["matter_number"] or m["id"]), auto_dir(m["title"] or ""), _instructing_clients_cell(con, int(m["id"])))
        for m in ms)
    return ("<div class=\"card\"><h3>%s</h3>"
            "<p class=\"small\">المشاريع/القضايا ذات العملاء المشاركين، مع صفة كل عميل وحالته ومخاطره، ووسم مَن وُسِم بالارتباط بمطابقة مؤكدة.</p>"
            "<div class=\"table-wrap\"><table><thead><tr><th>المشروع/القضية</th><th>العنوان</th><th>العملاء المُوكِّلون</th></tr></thead><tbody>%s</tbody></table></div></div>" % (title, rows))


def _association_alerts_card(con: sqlite3.Connection) -> str:
    rows = con.execute(
        "SELECT rf.entity_id AS cid, c.legal_name AS name, c.client_code AS code, c.status AS status, rf.notes AS notes "
        "FROM risk_flags rf JOIN clients c ON c.id=rf.entity_id "
        "WHERE rf.entity_type='client' AND rf.flag_code=? ORDER BY rf.id DESC LIMIT 200", (_ASSOC_FLAG,)).fetchall()
    if not rows:
        return ""
    trs = "".join(
        "<tr><td><a href='/client?id=%d'>%s</a></td><td>%s</td><td>%s</td><td>%s</td></tr>" % (
            int(r["cid"]), h(r["name"]), h(r["code"] or ("%06d" % int(r["cid"]))), badge_status(r["status"] or ""), auto_dir(r["notes"] or ""))
        for r in rows)
    return ("<div class=\"card\"><h3>تنبيهات الارتباط في التعليمات المشتركة</h3>"
            "<p class=\"notice\">عملاء مشاركون وُسِموا كمخاطر عالية بالارتباط بمطابقة مؤكدة على مشروع/قضية مشتركة (دون حظرهم). يُزال الوسم تلقائياً عند إغلاق المطابقة كإيجابية كاذبة موثقة.</p>"
            "<div class=\"table-wrap\"><table><thead><tr><th>العميل</th><th>الرقم</th><th>الحالة</th><th>سبب الارتباط</th></tr></thead><tbody>%s</tbody></table></div></div>" % trs)


_partner_dashboard_pre_v1061 = partner_dashboard_page
def partner_dashboard_page(partner: str = '', task_type: str = 'all', task_status: str = 'all') -> bytes:  # type: ignore[override]
    raw = _partner_dashboard_pre_v1061(partner, task_type, task_status).decode('utf-8')
    try:
        u = _auth_current_user()
        eff_partner = u.get('full_name', '') if (u and u.get('role') == 'partner') else partner
        with db() as con:
            ensure_schema(con)
            card = _joint_matters_card(con, eff_partner)
        if card and "</main>" in raw:
            raw = raw.replace("</main>", card + "</main>", 1)
    except Exception:
        pass
    return raw.encode('utf-8')


_compliance_page_pre_v1061 = compliance_page
def compliance_page(message: str = "") -> bytes:  # type: ignore[override]
    raw = _compliance_page_pre_v1061(message).decode('utf-8')
    try:
        with db() as con:
            ensure_schema(con)
            card = _association_alerts_card(con) + _joint_matters_card(con, "", "المشاريع ذات التعليمات المشتركة")
        if card and "</main>" in raw:
            raw = raw.replace("</main>", card + "</main>", 1)
    except Exception:
        pass
    return raw.encode('utf-8')


# ===========================================================================
# V10.7.0 - Relationship-aware internal screening + inspection readiness
# ---------------------------------------------------------------------------
# Pilot feedback fixes (screening semantics — INTERNAL scope only; sanctions
# matching keeps full sensitivity):
#  (1) Same-file matches (a client's own circle: the client + its related
#      parties, or a counterparty + its own related parties) are NOT conflicts —
#      the UBO/owner or a duplicated role row no longer produces a red hit.
#  (2) Same-matter matches (the matter's counterparty side vs its own
#      instructing clients — e.g. partners suing their company) are recorded as
#      an informational green "known relationship" result, not a conflict.
#  (3) Person NAME-only similarity (family chains: father/sons sharing 3-4
#      name segments) is capped at "potential match" (review) — it can never
#      reach high-similarity/red without an identifier match or exact equality.
# ===========================================================================
APP_VERSION = "V10.7.1 - Relationship-Aware Screening + Inspection Readiness (report coverage fix)"

_KNOWN_REL_STATUS = "known_relationship"


def _internal_context_maps(con: sqlite3.Connection) -> Tuple[Dict[int, Tuple[str, int]], Dict[int, Optional[int]], Dict[int, set]]:
    rp: Dict[int, Tuple[str, int]] = {}
    for r in con.execute("SELECT id, parent_type, parent_id FROM related_parties").fetchall():
        rp[int(r["id"])] = (r["parent_type"], int(r["parent_id"]))
    cpm: Dict[int, Optional[int]] = {}
    for r in con.execute("SELECT id, matter_id FROM counterparties").fetchall():
        cpm[int(r["id"])] = int(r["matter_id"]) if r["matter_id"] else None
    instr: Dict[int, set] = {}
    for r in con.execute("SELECT id, client_id FROM matters").fetchall():
        instr.setdefault(int(r["id"]), set())
        if r["client_id"]:
            instr[int(r["id"])].add(int(r["client_id"]))
    try:
        for r in con.execute("SELECT matter_id, client_id FROM matter_clients").fetchall():
            instr.setdefault(int(r["matter_id"]), set()).add(int(r["client_id"]))
    except sqlite3.OperationalError:
        pass
    return rp, cpm, instr


def _relation_ctx(etype: str, eid: int, rp: Dict[int, Tuple[str, int]], cpm: Dict[int, Optional[int]]) -> Tuple[Optional[int], Optional[int], Optional[int]]:
    """(client_id, matter_id, counterparty_id) an entity belongs to, else Nones."""
    if etype == "client":
        return int(eid), None, None
    if etype == "client_related_party":
        p = rp.get(int(eid))
        return (int(p[1]), None, None) if p and p[0] == "client" else (None, None, None)
    if etype == "counterparty":
        return None, cpm.get(int(eid)), int(eid)
    if etype == "counterparty_related_party":
        p = rp.get(int(eid))
        if p and p[0] == "counterparty":
            return None, cpm.get(int(p[1])), int(p[1])
    return None, None, None


def _classify_internal_relation(sub_ctx, ent_ctx, instr: Dict[int, set]) -> str:
    (sc, sm, scp), (ec, em, ecp) = sub_ctx, ent_ctx
    if sc and ec and sc == ec:
        return "same_file"
    if scp and ecp and scp == ecp:
        return "same_file"
    if sm and em and sm == em:
        return "same_matter"
    if sm and ec and ec in instr.get(sm, set()):
        return "same_matter"
    if em and sc and sc in instr.get(em, set()):
        return "same_matter"
    return "other"


_PERSONISH = {"individual", ""}


def _cap_internal_person_similarity(score: int, reason: str, sub_cat: str, ent_cat: str) -> Tuple[int, str]:
    """Internal scope only: a 90-99 NAME-similarity between two persons is capped at 89
    (potential_match) with a family note. Identifier matches and exact equality (100) untouched."""
    if score < 90 or score >= 100:
        return score, reason
    if (sub_cat or "") not in _PERSONISH or (ent_cat or "") not in _PERSONISH:
        return score, reason
    return 89, reason + " — تشابه أسماء دون رقم مميز؛ قد يكون تشابه أسماء شائعاً أو قرابة عائلية (أب/أبناء/أقارب)؛ لا يُعتمد كتشابه مرتفع دون رقم مميز"


def screen_subjects(con: sqlite3.Connection, subjects: List[Dict[str, Any]], skip_sanctions: bool = False, ip: str = "", screening_mode: str = "both") -> Dict[str, int]:  # type: ignore[override]
    created = 0
    hits = 0
    warnings = 0
    suppressed = 0
    internal_entities = all_internal_entities(con) if screening_mode in {"internal", "both"} else []
    sanctions = con.execute("SELECT * FROM sanctions_entries WHERE active=1 ORDER BY list_name, id").fetchall() if screening_mode in {"sanctions", "both"} else []
    if internal_entities:
        rp_map, cp_map, instr_map = _internal_context_maps(con)
        ent_ctx_list = [(ent, _relation_ctx(ent["matched_entity_type"], int(ent["matched_entity_id"]), rp_map, cp_map)) for ent in internal_entities]
    else:
        rp_map, cp_map, instr_map = {}, {}, {}
        ent_ctx_list = []
    # V10.15 (بعد مراجعة عدائية): خريطة الأزواج الداخلية المبتوتة نهائياً = التي لها إغلاق موثق
    # (false_positive/closed) و«لا يوجد لها أي صف مفتوح». استبعاد الأزواج ذات صف مفتوح يعالج
    # عيب إعادة الفتح: تغيير حالة أي صف إلى قيد المراجعة يُخرج الزوج من الكبت فوراً فيعود للظهور.
    # تُكبت فقط potential_match الداخلية (تشابه أسماء ضعيف)؛ لا القوائم ولا التطابق المؤكد.
    _dismissed_internal: Dict[Tuple[str, int, str, int], int] = {}
    if internal_entities:
        _open_states = ("potential_match", "high_similarity", "confirmed_match", "under_review", "frozen", "reported")
        _open_pairs: set = set()
        for r in con.execute(
            "SELECT subject_type, subject_id, matched_entity_type, matched_entity_id, status, match_score "
            "FROM screenings WHERE screening_scope='internal'").fetchall():
            try:
                pk = (r[0], int(r[1]), r[2], int(r[3]))
            except Exception:
                continue
            if r[4] in ("false_positive", "closed"):
                _dismissed_internal[pk] = max(_dismissed_internal.get(pk, 0), int(r[5] or 0))
            elif r[4] in _open_states:
                _open_pairs.add(pk)
        # أي زوج له صف مفتوح لا يُكبت (يشمل من أُعيد فتحه للمراجعة)
        for pk in _open_pairs:
            _dismissed_internal.pop(pk, None)

    for sub in subjects:
        if screening_mode in {"internal", "both"}:
            sub_ctx = _relation_ctx(sub["subject_type"], int(sub["subject_id"]), rp_map, cp_map)
            internal_rows = 0
            internal_hits = 0
            internal_suppressed = 0
            for ent, ent_ctx in ent_ctx_list:
                if ent["matched_entity_type"] == sub["subject_type"] and ent["matched_entity_id"] == sub["subject_id"]:
                    continue
                relation = _classify_internal_relation(sub_ctx, ent_ctx, instr_map)
                if relation == "same_file":
                    # V10.7: نفس ملف العميل/الطرف (المالك، المستفيد الحقيقي، صف دور مكرر) — ليس تعارضاً.
                    continue
                # V10.8.0-fix: الرقم الموحد (700) رقم مميز مستقل بمساره واسمه الصحيح في السبب —
                # لا يُمرَّر عبر خانة السجل التجاري ولا يدخل في مقارنات قوائم العقوبات.
                _us = normalize_identifier(str(sub.get("unified_number") or ""))
                _ue = normalize_identifier(str(ent.get("unified_number") or ""))
                if _us and _ue and len(_us) >= 4 and _us == _ue:
                    score, reason = 100, "تطابق مؤكد في الرقم الموحد للمنشأة (700) بعد توحيد الصيغة"
                else:
                    score, reason = match_score(
                        sub["subject_name"], ent["matched_name"], sub["id_number"], ent.get("id_number", ""),
                        sub["registration_number"], ent.get("registration_number", ""),
                        sub.get("entity_category", ""), ent.get("entity_category", ""),
                    )
                if score < 75:
                    continue
                if relation == "same_matter":
                    # V10.7.0-fix (مراجعة عدائية): تطابق 100 مباشر بين "طرف مقابل" و"عميل" في القضية
                    # نفسها يعني أن الكيان نفسه يجلس على الجانبين (المكتب يعمل ضد عميله أو خطأ إدخال) —
                    # هذا تعارض يجب حسمه ولا يجوز توثيقه علاقةً معروفة. جسور الأطراف المرتبطة
                    # (الشريك المُدرج عضواً لدى الطرف المقابل) تبقى علاقة معروفة كما هو مقصود.
                    direct_pair = {sub["subject_type"], ent["matched_entity_type"]} == {"counterparty", "client"}
                    if direct_pair and score >= 100:
                        status = status_for_score(score, reason)
                        insert_screening(con, sub, "internal", ent, score,
                                         "الكيان نفسه يظهر موكِّلاً وطرفاً مقابلاً في المشروع/القضية نفسها — تعارض يجب حسمه: " + reason,
                                         status)
                        created += 1; hits += 1; internal_hits += 1; internal_rows += 1
                        continue
                    # V10.7: علاقة معروفة داخل القضية نفسها (خصومة الشركاء مع شركتهم ونحوها) —
                    # تُوثق كنتيجة معلوماتية خضراء ولا تُعد تعارض مصالح.
                    insert_screening(con, sub, "internal", ent, score,
                                     "علاقة معروفة داخل نفس المشروع/القضية (طرفا القضية نفسها) — " + reason,
                                     _KNOWN_REL_STATUS)
                    created += 1
                    internal_rows += 1
                    continue
                score, reason = _cap_internal_person_similarity(score, reason, sub.get("entity_category", ""), ent.get("entity_category", ""))
                # V10.18: تصنيف واعٍ بالمقعد للأزواج عابرة الملفات — «التعارض» الحقيقي هو تقاطع
                # جهة الموكِّل مع جهة الطرف المقابل؛ أما الشخص نفسه في مقعد العميل بملفين
                # (مباشرة أو كطرف مرتبط) بهوية مؤكدة فهو ارتباط داخلي موثق لا تعارض خصومة.
                # التشابه الاسمي بلا هوية مؤكدة يبقى تنبيهاً كما هو (قد يكون شخصين مختلفين).
                _sub_seat = "client" if sub_ctx[0] else ("cp" if sub_ctx[2] else None)
                _ent_seat = "client" if ent_ctx[0] else ("cp" if ent_ctx[2] else None)
                # شرطان معاً للتخفيض: هوية مؤكدة + اتساق الاسمين. هوية متطابقة باسم مختلف تماماً
                # = خلل بيانات أو انتحال محتمل — تبقى تنبيهاً مؤكداً (حارس V10.7/V10.8 القائم).
                if (score >= 100 and _sub_seat == "client" and _ent_seat == "client"
                        and _internal_ids_confirmed(sub, ent)
                        and _internal_names_consistent(sub["subject_name"], ent["matched_name"],
                                                       sub.get("entity_category", ""), ent.get("entity_category", ""))):
                    insert_screening(con, sub, "internal", ent, score,
                                     "الشخص/الكيان نفسه يظهر في أكثر من ملف عميل (مقعد العميل في الجانبين، بهوية مؤكدة واسم متسق) — "
                                     "ارتباط داخلي موثق وليس تعارض خصومة. يُنصح بتوحيد السجلات إن كانا سجلين مزدوجين: " + reason,
                                     _KNOWN_REL_STATUS)
                    created += 1
                    internal_rows += 1
                    continue
                if _sub_seat and _ent_seat and _sub_seat != _ent_seat:
                    reason = "تقاطع مقعدين عبر الملفات (جهة موكِّل × جهة طرف مقابل) — أولوية مراجعة تعارض المصالح: " + reason
                status = status_for_score(score, reason)
                # V10.15: كبت إعادة إثارة تعارض داخلي ضعيف (potential_match) لزوج سبق إغلاقه موثقاً
                # بدرجة مساوية أو أعلى — الإغلاق يبقى دائماً. التصعيد (تشابه عالٍ/تطابق مؤكد أو درجة
                # أعلى) لا يُكبت أبداً فيظل يظهر للمراجعة.
                if status == "potential_match":
                    _pk = (sub["subject_type"], int(sub["subject_id"]), ent["matched_entity_type"], int(ent["matched_entity_id"]))
                    if _dismissed_internal.get(_pk, -1) >= score:
                        suppressed += 1
                        internal_suppressed += 1
                        continue
                insert_screening(con, sub, "internal", ent, score, reason, status)
                created += 1; hits += 1; internal_hits += 1; internal_rows += 1
            if internal_rows == 0:
                # V10.15 (مراجعة عدائية): لا تُصرّح «لا يوجد تطابق» إن كان هناك تعارض مطابق
                # مكبوت بقرار إغلاق سابق — هذا يضلّل المفتش. سجّل الحقيقة: لا جديد، وتعارضات
                # سابقة مطابقة مغلقة بقرار موثق ({suppressed}).
                if internal_suppressed:
                    _nm_reason = f"تم فحص السجل الداخلي؛ لا تعارضات جديدة. توجد تعارضات مطابقة سابقة مغلقة بقرار موثق (عدد {internal_suppressed}) — راجعها في أرشيف الفحص."
                else:
                    _nm_reason = "تم فحص السجل الداخلي بالأرقام المميزة والأسماء متعددة المقاطع (مع استبعاد أطراف الملف نفسه) ولم يوجد تطابق مؤثر"
                insert_screening(con, sub, "internal", {
                    "list_name": "INTERNAL_REGISTRY", "matched_entity_type": "none", "matched_entity_id": 0, "matched_name": "-"
                }, 0, _nm_reason, "no_match")
                created += 1

        if screening_mode not in {"sanctions", "both"}:
            continue

        applicable = list(sanctions)
        if skip_sanctions and sub.get("subject_type") == "client":
            national_ids = {se["id"] for se in applicable if str(se["list_type"] or "").upper() == "NATIONAL" or "1373" in str(se["list_name"] or "")}
            if national_ids:
                applicable = [se for se in applicable if se["id"] not in national_ids]
                insert_screening(con, sub, "sanctions", {
                    "list_name": "NATIONAL_1373", "matched_entity_type": "listed_company_exemption", "matched_entity_id": 0,
                    "matched_name": "استثناء القائمة الوطنية للشركة المدرجة"
                }, 0, "استثناء موثق للقائمة الوطنية 1373 فقط؛ استمر فحص قوائم الأمم المتحدة", "exempted_listed_company")
                created += 1

        # V10.8: الجهات الحكومية (الوزارات والهيئات) — استثناء موثق ضيق مماثل للشركات المدرجة:
        # تُستثنى القائمة الوطنية 1373 فقط للجهة نفسها، وتستمر القوائم الدولية كاملة
        # (جهات حكومية أجنبية مدرجة فعلاً على قوائم مجلس الأمن) وفحص الأطراف المرتبطة.
        if sub.get("entity_category") == "government" and sub.get("subject_type") == "client" and _is_domestic_gov_subject(sub):
            # V10.8.0-fix (مراجعة عدائية): الاستثناء لعملاء المكتب فقط (لا يمتد لطرف مقابل أدخل نوعه
            # من قائمة حرة)، ويشترط أن تكون الجهة سعودية موثقة الدولة/الجنسية — جهة حكومية أجنبية
            # قد تكون مدرجة على القائمة الوطنية نفسها فتُفحص كاملة.
            gov_national = {se["id"] for se in applicable if str(se["list_type"] or "").upper() == "NATIONAL" or "1373" in str(se["list_name"] or "")}
            if gov_national:
                applicable = [se for se in applicable if se["id"] not in gov_national]
                insert_screening(con, sub, "sanctions", {
                    "list_name": "NATIONAL_1373", "matched_entity_type": "government_exemption", "matched_entity_id": 0,
                    "matched_name": "استثناء القائمة الوطنية لجهة حكومية"
                }, 0, "استثناء موثق لجهة حكومية: القائمة الوطنية 1373 فقط؛ استمر فحص القوائم الدولية والفحص الداخلي", "exempted_government")
                created += 1

        if not applicable:
            insert_screening(con, sub, "sanctions", {
                "list_name": "NO_ACTIVE_LISTS", "matched_entity_type": "system_warning", "matched_entity_id": 0, "matched_name": "-"
            }, 0, "تعذر إصدار نتيجة سليمة: لا توجد قوائم عقوبات نشطة قابلة للفحص ضمن النطاق المطلوب", "list_unavailable")
            created += 1; warnings += 1
            continue

        sanctions_hits = 0
        screened_lists = set()
        for se in applicable:
            screened_lists.add(str(se["list_name"] or ""))
            ent = {"list_name": se["list_name"], "matched_entity_type": "sanctions_entry", "matched_entity_id": se["id"], "matched_name": se["full_name"], "id_number": se["id_number"] or "", "registration_number": se["registration_number"] or "", "entity_category": "company" if se["registration_number"] else ""}
            score, reason = match_score(
                sub["subject_name"], se["full_name"], sub["id_number"], se["id_number"] or "",
                sub["registration_number"], se["registration_number"] or "",
                sub.get("entity_category", ""), ent.get("entity_category", ""),
            )
            if score >= 75:
                status = status_for_score(score, reason)
                insert_screening(con, sub, "sanctions", ent, score, reason, status)
                created += 1; hits += 1; sanctions_hits += 1
        if sanctions_hits == 0:
            list_label = ", ".join(sorted(x for x in screened_lists if x))[:500] or "ALL_ACTIVE_LISTS"
            insert_screening(con, sub, "sanctions", {
                "list_name": list_label, "matched_entity_type": "none", "matched_entity_id": 0, "matched_name": "-"
            }, 0, f"تم فحص {len(applicable)} سجل نشط في {len(screened_lists)} قائمة بالأرقام المميزة والأسماء متعددة المقاطع ولم يوجد تطابق مؤثر", "no_match")
            created += 1

    audit(con, "run_screening", "screening", 0, f"تم إنشاء {created} نتيجة؛ تطابقات={hits}؛ تحذيرات={warnings}", ip)
    return {"created": created, "hits": hits, "warnings": warnings}


# --- status plumbing for known_relationship (green, informational, resolved) ---
_badge_status_pre_v107 = badge_status
def badge_status(status: str) -> str:  # type: ignore[override]
    if status == _KNOWN_REL_STATUS:
        return '<span class="badge ok" role="status">علاقة معروفة موثقة</span>'
    return _badge_status_pre_v107(status)


_risk_visual_pre_v107 = risk_visual_for_screening
def risk_visual_for_screening(status: str, score: int) -> Tuple[str, str, str]:  # type: ignore[override]
    if status == _KNOWN_REL_STATUS:
        return "green", "أخضر", "علاقة معروفة داخل نفس الملف/القضية — موثقة للمعلومية ولا تتطلب إجراء"
    return _risk_visual_pre_v107(status, score)


# ---- V10.7 Stage B: descriptive القائمة column for register + reports archive ----
_INTERNAL_KIND_AR = {
    "client": "تعارض مع عميل قائم",
    "counterparty": "تعارض مع طرف مقابل",
    "client_related_party": "تعارض مع طرف مرتبط بعميل",
    "counterparty_related_party": "تعارض مع طرف مرتبط بطرف مقابل",
}


def _sanctions_list_kind(list_name: str) -> str:
    up = (list_name or "").upper()
    if "NATIONAL" in up or "1373" in up or "محلي" in (list_name or ""):
        return "محلية"
    if up.startswith("UN") or "UNSC" in up or "1267" in up or "2253" in up or "أمم" in (list_name or "") or "دولي" in (list_name or ""):
        return "دولية"
    return ""


def list_display_for_screening(scope: str, list_name: str, matched_entity_type: str = "", status: str = "") -> str:
    """Human description for the القائمة column: exact conflict type for internal results,
    and the list name tagged محلية/دولية for sanctions results."""
    if scope == "internal":
        if status == _KNOWN_REL_STATUS:
            return "فحص داخلي — علاقة معروفة موثقة"
        kind = _INTERNAL_KIND_AR.get(matched_entity_type or "")
        if kind:
            return f"تعارض مصالح داخلي — {kind}"
        # V10.7.0-fix: hit rows with an unrecognized matched type must not read as "no match".
        if (status or "") not in ("", "no_match") and (matched_entity_type or "") not in ("", "none"):
            return "تعارض مصالح داخلي"
        return "فحص داخلي — لا تطابق"
    ln = (list_name or "").strip()
    if not ln or ln in ("ALL_ACTIVE_LISTS",):
        return "قوائم العقوبات — كل القوائم النشطة"
    if ln == "NO_ACTIVE_LISTS":
        return "لا توجد قوائم نشطة"
    # V10.7.1: صفوف "لا تطابق" الموجزة تحمل أسماء كل القوائم المفحوصة مضمومة بفواصل — كان أول اسم
    # (NATIONAL) يوسم النص كله "قائمة محلية" ويُقتطع الباقي فيبدو أن القوائم الدولية لم تُفحص.
    if "," in ln:
        parts = [p.strip() for p in ln.split(",") if p.strip()]
        loc = sum(1 for p in parts if _sanctions_list_kind(p) == "محلية")
        intl = sum(1 for p in parts if _sanctions_list_kind(p) == "دولية")
        other = len(parts) - loc - intl
        bits = []
        if loc:
            bits.append(f"{loc} محلية")
        if intl:
            bits.append(f"{intl} دولية")
        if other:
            bits.append(f"{other} أخرى")
        return f"فُحصت {len(parts)} قوائم ({' + '.join(bits)}): {'، '.join(parts)}"
    if ln == "NATIONAL_1373" and status == "exempted_listed_company":
        return "القائمة المحلية 1373 — استثناء موثق (استمر فحص القوائم الدولية)"
    if ln == "NATIONAL_1373" and status == "exempted_government":
        return "القائمة المحلية 1373 — استثناء جهة حكومية (استمرت القوائم الدولية)"
    kind = _sanctions_list_kind(ln)
    return f"قائمة {kind}: {ln}" if kind else f"قائمة: {ln}"


# ---- V10.7 Stages C+D: nested ownership for compound entities + editable layers/documents ----
_V107_SCHEMA_ENSURED: set = set()
_ensure_schema_pre_v107 = ensure_schema


def ensure_schema(con: sqlite3.Connection, force: bool = False) -> None:  # type: ignore[override]
    _ensure_schema_pre_v107(con, force)
    key = str(DB_PATH)
    if not force and key in _V107_SCHEMA_ENSURED:
        return
    for col, ddl in (("doc_status", "TEXT NOT NULL DEFAULT 'active'"), ("superseded_by", "INTEGER")):
        try:
            _ensure_column(con, "entity_documents", col, ddl)
        except Exception:
            pass
    con.execute("""CREATE TABLE IF NOT EXISTS inspection_checklist(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        updated_at TEXT,
        section_no INTEGER NOT NULL,
        section_title TEXT NOT NULL,
        item_no INTEGER NOT NULL,
        question TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        evidence TEXT,
        updated_by TEXT,
        UNIQUE(section_no, item_no)
    )""")
    con.commit()
    _V107_SCHEMA_ENSURED.add(key)


# ----------------------------- ownership layers -----------------------------
def ownership_trace_table(con: sqlite3.Connection, client_id: int) -> str:  # type: ignore[override]
    rows = con.execute("SELECT * FROM ownership_tracing WHERE client_id=? ORDER BY sequence_no, id", (client_id,)).fetchall()
    out = []
    for r in rows:
        plus = ""
        if (r["owner_type"] or "company") != "individual":
            js_arg = h(json.dumps(r["owner_name"] or "", ensure_ascii=False))
            plus = (f"<button type='button' class='btn ok' style='padding:6px 10px;margin:0' "
                    f"onclick='pfOwn({js_arg},{int(r['sequence_no'] or 1) + 1})' "
                    f"title='إضافة ملاك هذا الكيان كطبقة تالية'>+ ملاك الكيان</button> ")
        actions = (
            f"{plus}<a class='btn secondary' style='padding:6px 10px;margin:0' href='/ownership/edit?id={r['id']}'>تعديل</a> "
            f"<form method='post' action='/ownership/delete' style='display:inline'>"
            f"<input type='hidden' name='trace_id' value='{r['id']}'>"
            f"<button class='btn danger' style='padding:6px 10px;margin:0' onclick=\"return confirm('حذف طبقة الملكية هذه؟')\">حذف</button></form>")
        out.append(
            f"<tr><td>{r['sequence_no']}</td><td>{auto_dir(r['owner_name'])}</td><td>{h(r['owner_type'])}</td>"
            f"<td>{h(r['registration_number'] or r['id_number'])}</td><td>{h(r['country'])}</td><td>{h(r['ownership_percent'])}</td>"
            f"<td>{auto_dir(r['parent_owner'])}</td><td>{auto_dir(r['control_description'])}</td><td>{actions}</td></tr>")
    return "".join(out) or "<tr><td colspan='9'>لا يوجد تتبع ملكية</td></tr>"


_OWN_PREFILL_JS = ("<script>function pfOwn(n,s){var p=document.getElementsByName('parent_owner')[0],"
                   "q=document.getElementsByName('sequence_no')[0];if(q){q.value=s}if(p){p.value=n;"
                   "p.scrollIntoView({behavior:'smooth',block:'center'});p.style.outline='3px solid #facc15';"
                   "var o=document.getElementsByName('owner_name')[0];if(o){o.focus()}}}</script>")

_client_detail_pre_v107 = client_detail
def client_detail(client_id: int) -> bytes:  # type: ignore[override]
    raw = _client_detail_pre_v107(client_id).decode("utf-8")
    if "pfOwn" in raw and "</main>" in raw:
        raw = raw.replace("</main>", _OWN_PREFILL_JS + "</main>", 1)
    return raw.encode("utf-8")


def update_ownership_trace(fields: Dict[str, List[str]], ip: str = "") -> int:
    tid = int(form_value(fields, "trace_id", "0") or 0)
    pct_raw = form_value(fields, "ownership_percent")
    pct = float(pct_raw) if pct_raw else None
    with db() as con:
        ensure_schema(con)
        row = con.execute("SELECT * FROM ownership_tracing WHERE id=?", (tid,)).fetchone()
        if not row:
            raise ValueError("طبقة الملكية غير موجودة")
        con.execute("""UPDATE ownership_tracing SET sequence_no=?, owner_name=?, owner_type=?, id_number=?,
            registration_number=?, country=?, ownership_percent=?, parent_owner=?, control_description=?, notes=? WHERE id=?""",
            (int(form_value(fields, "sequence_no", str(row["sequence_no"])) or row["sequence_no"]),
             form_value(fields, "owner_name") or row["owner_name"], form_value(fields, "owner_type", row["owner_type"]),
             form_value(fields, "id_number"), form_value(fields, "registration_number"), form_value(fields, "country"),
             pct, form_value(fields, "parent_owner"), form_value(fields, "control_description"), form_value(fields, "notes"), tid))
        cid = int(row["client_id"])
        try:
            evaluate_client_risk(con, cid)
        except Exception:
            pass
        audit(con, "update_ownership_trace", "client", cid, f"trace={tid}; owner={form_value(fields, 'owner_name') or row['owner_name']}", ip)
        con.commit()
    return cid


def delete_ownership_trace(fields: Dict[str, List[str]], ip: str = "") -> int:
    tid = int(form_value(fields, "trace_id", "0") or 0)
    with db() as con:
        ensure_schema(con)
        row = con.execute("SELECT * FROM ownership_tracing WHERE id=?", (tid,)).fetchone()
        if not row:
            raise ValueError("طبقة الملكية غير موجودة")
        con.execute("DELETE FROM ownership_tracing WHERE id=?", (tid,))
        cid = int(row["client_id"])
        try:
            evaluate_client_risk(con, cid)
        except Exception:
            pass
        audit(con, "delete_ownership_trace", "client", cid, f"trace={tid}; owner={row['owner_name']}", ip)
        con.commit()
    return cid


def ownership_edit_page(tid: int, message: str = "") -> bytes:
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT o.*, c.legal_name FROM ownership_tracing o LEFT JOIN clients c ON c.id=o.client_id WHERE o.id=?", (tid,)).fetchone()
        if not r:
            return layout("غير موجود", "<div class='error'>طبقة الملكية غير موجودة</div>", "/clients")
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    types = {"company": "شركة", "individual": "فرد", "trust": "ترتيب قانوني / صندوق", "government": "جهة حكومية", "other": "أخرى"}
    opts = "".join(f"<option value='{k}' {'selected' if k == (r['owner_type'] or 'company') else ''}>{v}</option>" for k, v in types.items())
    body = f"""
<div class="card"><h2>تعديل طبقة ملكية — للعميل {auto_dir(r['legal_name'] or '')}</h2>{msg}
<p class="notice">لتصحيح الأخطاء الإملائية أو تجويد بيانات الهيكل. بعد الحفظ يُعاد تقييم مؤشرات المخاطر تلقائياً.</p>
<form method="post" action="/ownership/update"><input type="hidden" name="trace_id" value="{tid}"><div class="grid">
<div><label>ترتيب الطبقة</label><input type="number" name="sequence_no" value="{h(r['sequence_no'])}"></div>
<div><label>اسم المالك / الكيان</label><input required name="owner_name" value="{h(r['owner_name'] or '')}"></div>
<div><label>نوع المالك</label><select name="owner_type">{opts}</select></div>
<div><label>رقم الهوية</label><input name="id_number" value="{h(r['id_number'] or '')}"></div>
<div><label>رقم السجل</label><input name="registration_number" value="{h(r['registration_number'] or '')}"></div>
<div><label>الدولة</label><input name="country" value="{h(r['country'] or '')}"></div>
<div><label>نسبة الملكية</label><input type="number" step="0.01" name="ownership_percent" value="{h(r['ownership_percent'] if r['ownership_percent'] is not None else '')}"></div>
<div><label>المالك الأعلى / التابع له</label><input name="parent_owner" value="{h(r['parent_owner'] or '')}"></div>
</div><label>وصف السيطرة الفعلية</label><textarea name="control_description">{h(r['control_description'] or '')}</textarea>
<label>ملاحظات</label><textarea name="notes">{h(r['notes'] or '')}</textarea>
<button>حفظ التعديلات</button> <a class="btn secondary" href="/client?id={r['client_id']}">رجوع للعميل</a></form></div>
"""
    return layout("تعديل طبقة ملكية", body, "/clients")


# ----------------------------- documents -----------------------------
def documents_table(con: sqlite3.Connection, entity_type: str, entity_id: int) -> str:  # type: ignore[override]
    rows = con.execute("SELECT * FROM entity_documents WHERE entity_type=? AND entity_id=? ORDER BY id DESC", (entity_type, entity_id)).fetchall()
    out = []
    for r in rows:
        keys = set(r.keys())
        superseded = (r["doc_status"] if "doc_status" in keys else "active") == "superseded"
        state = "<span class='badge warn'>نسخة سابقة</span> " if superseded else ""
        actions = f"<a class='btn secondary' style='padding:6px 10px;margin:0' href='/documents/download?id={r['id']}'>فتح</a>"
        if not superseded:
            actions += f" <a class='btn' style='padding:6px 10px;margin:0' href='/document/edit?id={r['id']}'>تعديل / استبدال</a>"
        out.append(
            f"<tr><td>{r['id']}</td><td>{h(doc_type_label(r['document_type']))}</td><td>{state}{auto_dir(r['document_title'])}</td>"
            f"<td>{h(r['original_filename'])}</td><td>{h((r['file_sha256'] or '')[:16])}...</td><td>{actions}</td></tr>")
    return "".join(out) or "<tr><td colspan='6'>لا توجد وثائق محفوظة</td></tr>"


def update_entity_document(fields: Dict[str, List[str]], ip: str = "") -> Tuple[str, int]:
    did = int(form_value(fields, "document_id", "0") or 0)
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT * FROM entity_documents WHERE id=?", (did,)).fetchone()
        if not r:
            raise ValueError("الوثيقة غير موجودة")
        con.execute("UPDATE entity_documents SET document_type=?, document_title=?, notes=? WHERE id=?",
                    (form_value(fields, "document_type", r["document_type"]),
                     form_value(fields, "document_title") or r["document_title"],
                     form_value(fields, "notes"), did))
        audit(con, "update_entity_document", r["entity_type"], int(r["entity_id"]), f"doc={did}; title={form_value(fields, 'document_title') or r['document_title']}", ip)
        con.commit()
        return r["entity_type"], int(r["entity_id"])


def replace_entity_document(fields: Dict[str, List[str]], files: Dict[str, Tuple[str, bytes]], ip: str = "") -> Tuple[str, int]:
    """Compliance-safe replacement: the new scan becomes a NEW row; the old row is kept and
    marked superseded (never destroyed) so the audit chain stays intact."""
    did = int(form_value(fields, "document_id", "0") or 0)
    with db() as con:
        ensure_schema(con)
        old = con.execute("SELECT * FROM entity_documents WHERE id=?", (did,)).fetchone()
    if not old:
        raise ValueError("الوثيقة غير موجودة")
    fields = dict(fields)
    fields.setdefault("entity_type", [old["entity_type"]])
    fields.setdefault("entity_id", [str(old["entity_id"])])
    if not form_value(fields, "document_type"):
        fields["document_type"] = [old["document_type"] or "other"]
    if not form_value(fields, "document_title"):
        fields["document_title"] = [old["document_title"] or ""]
    if not form_value(fields, "notes"):
        fields["notes"] = [old["notes"] or ""]
    new_id = save_entity_document(fields, files, ip)
    with db() as con:
        ensure_schema(con)
        con.execute("UPDATE entity_documents SET doc_status='superseded', superseded_by=? WHERE id=?", (new_id, did))
        audit(con, "replace_entity_document", old["entity_type"], int(old["entity_id"]), f"old={did}; new={new_id}", ip)
        con.commit()
    return old["entity_type"], int(old["entity_id"])


def document_edit_page(did: int, message: str = "") -> bytes:
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT * FROM entity_documents WHERE id=?", (did,)).fetchone()
        if not r:
            return layout("غير موجود", "<div class='error'>الوثيقة غير موجودة</div>", "/clients")
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    back = f"/{r['entity_type']}?id={r['entity_id']}" if r["entity_type"] in {"client", "matter", "counterparty"} else "/"
    body = f"""
<div class="card"><h2>تعديل / استبدال وثيقة رقم {did}</h2>{msg}
<p class="notice">تعديل البيانات الوصفية أو رفع نسخة جديدة. النسخة القديمة تبقى محفوظة وتُوسم "نسخة سابقة" حفاظاً على سلسلة التدقيق.</p>
<form method="post" action="/document/update"><input type="hidden" name="document_id" value="{did}"><div class="grid">
<div><label>نوع الوثيقة</label><input name="document_type" value="{h(r['document_type'] or '')}"></div>
<div><label>عنوان الوثيقة</label><input name="document_title" value="{h(r['document_title'] or '')}"></div>
</div><label>ملاحظات</label><textarea name="notes">{h(r['notes'] or '')}</textarea>
<button>حفظ البيانات الوصفية</button> <a class="btn secondary" href="{back}">رجوع</a></form></div>
<div class="card"><h3>استبدال النسخة الممسوحة</h3>
<form method="post" action="/document/replace" enctype="multipart/form-data"><input type="hidden" name="document_id" value="{did}">
<label>النسخة الجديدة</label><input type="file" name="document_file" required>
<button class="btn warn">رفع النسخة الجديدة (تُوسم القديمة نسخة سابقة)</button></form></div>
"""
    return layout("تعديل وثيقة", body, "/clients")


# ----------------------------- routes (C+D) -----------------------------
_V107_GET_ROUTES = {"/ownership/edit", "/document/edit"}
_get_pre_v107 = AppHandler.do_GET
def _do_get_v107(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    if parsed.path not in _V107_GET_ROUTES:
        return _get_pre_v107(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    try:
        rid = int((parse_qs(parsed.query).get("id", ["0"])[0] or 0))
    except (TypeError, ValueError):
        rid = 0
    try:
        page = ownership_edit_page(rid) if parsed.path == "/ownership/edit" else document_edit_page(rid)
        return self._send(page)
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر فتح الصفحة: {h(exc)}</div>"), 500)
AppHandler.do_GET = _do_get_v107


_V107_POST_ROUTES = {"/ownership/update", "/ownership/delete", "/document/update", "/document/replace"}
_post_pre_v107 = AppHandler.do_POST
def _do_post_v107(self: AppHandler) -> None:
    path = urlparse(self.path).path
    if path not in _V107_POST_ROUTES:
        return _post_pre_v107(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    try:
        fields, files, ip = _parse_request_fields(self)
        if path == "/ownership/update":
            cid = update_ownership_trace(fields, ip); return send_redirect(self, f"/client?id={cid}")
        if path == "/ownership/delete":
            cid = delete_ownership_trace(fields, ip); return send_redirect(self, f"/client?id={cid}")
        if path == "/document/update":
            et, eid = update_entity_document(fields, ip)
        else:
            et, eid = replace_entity_document(fields, files, ip)
        return send_redirect(self, f"/{et}?id={eid}" if et in {"client", "matter", "counterparty"} else "/")
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر تنفيذ العملية: {h(exc)}</div>"), 500)
AppHandler.do_POST = _do_post_v107


# ---- V10.7 Stage E: batch reports (clients-vs-lists + internal conflicts) in XLSX + PDF ----
_SEV_ORDER = {"confirmed_match": 0, "frozen": 0, "reported": 0, "high_similarity": 1, "potential_match": 2,
              "under_review": 2, "list_unavailable": 3, "exempted_listed_company": 4, "exempted_government": 4, "known_relationship": 5,
              "false_positive": 6, "closed": 6, "no_match": 7}


def _xlsx_bytes(sheet_name: str, headers: List[str], rows: List[List[Any]]) -> bytes:
    """Minimal valid .xlsx (SpreadsheetML) via stdlib zipfile — RTL sheet, inline strings."""
    import io
    import zipfile as _zf

    def esc(t: Any) -> str:
        # V10.7.0-fix: strip XML-illegal control chars (Word pastes \x0b etc.) — they cannot be
        # entity-escaped and would silently corrupt the workbook; escape quotes for attribute use.
        s = (str(t) if t is not None else "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
        return re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F]", "", s)

    def row_xml(idx: int, vals: List[Any]) -> str:
        cells = []
        for v in vals:
            if isinstance(v, bool):
                v = "نعم" if v else "لا"
            if isinstance(v, (int, float)):
                cells.append(f'<c t="n"><v>{v}</v></c>')
            else:
                cells.append(f'<c t="inlineStr"><is><t xml:space="preserve">{esc(v)}</t></is></c>')
        return f'<row r="{idx}">{"".join(cells)}</row>'

    body = "".join([row_xml(1, headers)] + [row_xml(i + 2, r) for i, r in enumerate(rows)])
    sheet = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
             '<sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews>'
             f'<sheetData>{body}</sheetData></worksheet>')
    safe_name = re.sub(r"[\\/?*\[\]:]", "_", str(sheet_name or ""))[:31] or "Report"
    wb = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
          f'<sheets><sheet name="{esc(safe_name)}" sheetId="1" r:id="rId1"/></sheets></workbook>')
    wb_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
               '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
    root_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                 '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
    ctypes = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
              '<Default Extension="xml" ContentType="application/xml"/>'
              '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
              '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
    buf = io.BytesIO()
    with _zf.ZipFile(buf, "w", _zf.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ctypes)
        z.writestr("_rels/.rels", root_rels)
        z.writestr("xl/workbook.xml", wb)
        z.writestr("xl/_rels/workbook.xml.rels", wb_rels)
        z.writestr("xl/worksheets/sheet1.xml", sheet)
    return buf.getvalue()


def _batch_pdf_bytes(title: str, headers: List[str], rows: List[List[Any]], col_weights: Optional[List[int]] = None) -> bytes:
    """Landscape A4 table PDF with Arabic shaping, paginated."""
    import io
    from reportlab.lib.pagesizes import A4, landscape  # type: ignore
    from reportlab.pdfbase import pdfmetrics  # type: ignore
    from reportlab.pdfbase.ttfonts import TTFont  # type: ignore
    from reportlab.pdfgen import canvas as _canvas  # type: ignore
    font_path = find_pdf_font()
    font_name = "Helvetica"
    if font_path:
        try:
            pdfmetrics.registerFont(TTFont("LTArabic", font_path))
            font_name = "LTArabic"
        except Exception:
            pass
    buf = io.BytesIO()
    page_w, page_h = landscape(A4)
    c = _canvas.Canvas(buf, pagesize=(page_w, page_h))
    margin = 24
    weights = col_weights or [1] * len(headers)
    total_w = page_w - 2 * margin
    widths = [total_w * w / sum(weights) for w in weights]

    def draw_header(y: float) -> float:
        c.setFont(font_name, 13)
        c.drawRightString(page_w - margin, y, pdf_value(title))
        c.setFont(font_name, 8)
        c.drawRightString(page_w - margin, y - 14, pdf_value(f"مسارات الامتثال — Compliance Tracks (Legal Tracks) — {APP_VERSION} — تاريخ الإصدار: {now_iso()}"))
        y -= 30
        x = page_w - margin
        c.setFont(font_name, 8.5)
        for i, hd in enumerate(headers):
            c.drawRightString(x - 2, y, pdf_value(str(hd)[:40]))
            x -= widths[i]
        c.line(margin, y - 3, page_w - margin, y - 3)
        return y - 14

    y = draw_header(page_h - margin - 6)
    c.setFont(font_name, 8)
    for row in rows:
        if y < margin + 14:
            c.showPage()
            y = draw_header(page_h - margin - 6)
            c.setFont(font_name, 8)
        x = page_w - margin
        for i, val in enumerate(row):
            # V10.7.0-fix: truncate the LOGICAL string BEFORE shaping/bidi, so long Arabic names
            # lose their tail (least identifying part), not their beginning.
            raw_txt = str(val if val is not None else "").strip()
            max_chars = max(6, int(widths[i] / 4.3))
            if len(raw_txt) > max_chars:
                raw_txt = raw_txt[:max_chars - 1] + "…"
            c.drawRightString(x - 2, y, pdf_value(raw_txt).strip())
            x -= widths[i]
        y -= 12
    c.showPage()
    c.save()
    return buf.getvalue()


def _clients_sanctions_report_rows(con: sqlite3.Connection) -> Tuple[List[str], List[List[Any]]]:
    """Regulatory report: every client + related party vs the local/international lists —
    the most severe current sanctions result per subject, with the exact list."""
    headers = ["رقم العميل", "العميل", "المفحوص", "نوع المفحوص", "هوية/سجل", "آخر فحص", "القوائم المفحوصة / التطابق", "النتيجة", "النسبة %", "سبب القرار"]
    rows: List[List[Any]] = []
    subjects: List[Tuple[str, int, str, str, str, int]] = []  # (stype, sid, subj_name, ids, client_name, client_no_int)
    for cl in con.execute("SELECT * FROM clients ORDER BY id").fetchall():
        code = cl["client_code"] or ("%06d" % int(cl["id"]))
        subjects.append(("client", int(cl["id"]), cl["legal_name"] or "", cl["id_number"] or cl["registration_number"] or "", cl["legal_name"] or "", code))
        for rp in con.execute("SELECT * FROM related_parties WHERE parent_type='client' AND parent_id=? ORDER BY id", (cl["id"],)).fetchall():
            subjects.append(("client_related_party", int(rp["id"]), rp["full_name"] or "", rp["id_number"] or rp["registration_number"] or "", cl["legal_name"] or "", code))
    # V10.7.0-fix (مراجعة عدائية): اختيار أشد نتيجة عبر كل السجل (بدون نافذة LIMIT قد تُسقط تطابقاً
    # مؤكداً قديماً غير محسوم بعد عشرات الفحوص الدورية)، وعمود "آخر فحص" يعرض تاريخ آخر فحص فعلي.
    sev_case = ("CASE status WHEN 'confirmed_match' THEN 0 WHEN 'frozen' THEN 0 WHEN 'reported' THEN 0 "
                "WHEN 'high_similarity' THEN 1 WHEN 'potential_match' THEN 2 WHEN 'under_review' THEN 2 "
                "WHEN 'list_unavailable' THEN 3 WHEN 'exempted_listed_company' THEN 4 WHEN 'exempted_government' THEN 4 WHEN 'known_relationship' THEN 5 "
                "WHEN 'false_positive' THEN 6 WHEN 'closed' THEN 6 ELSE 7 END")
    for stype, sid, sname, ids, cname, code in subjects:
        best = con.execute(
            f"SELECT * FROM screenings WHERE subject_type=? AND subject_id=? AND screening_scope='sanctions' ORDER BY {sev_case}, id DESC LIMIT 1",
            (stype, sid)).fetchone()
        if not best:
            rows.append([code, cname, sname, report_value_for_language("subject_type", stype, "ar"), ids, "لم يُفحص بعد", "-", "لم يُفحص", "", ""])
            continue
        last = con.execute("SELECT MAX(created_at) FROM screenings WHERE subject_type=? AND subject_id=? AND screening_scope='sanctions'", (stype, sid)).fetchone()[0]
        # V10.7.1: عمود القوائم يعرض التغطية الكاملة للمفحوص (كم قائمة محلية ودولية فُحصت فعلاً)
        # بدل اسم قائمة السطر الأشد وحده الذي كان يوحي بأن القوائم الدولية لم تُفحص.
        lists_screened = set()
        for r2 in con.execute("SELECT DISTINCT list_name FROM screenings WHERE subject_type=? AND subject_id=? AND screening_scope='sanctions' AND status NOT IN ('exempted_listed_company','exempted_government')", (stype, sid)).fetchall():
            for part in (r2[0] or "").split(","):
                p = part.strip()
                if p and p not in ("ALL_ACTIVE_LISTS", "NO_ACTIVE_LISTS"):
                    lists_screened.add(p)
        _exempted_n = con.execute("SELECT COUNT(*) FROM screenings WHERE subject_type=? AND subject_id=? AND status IN ('exempted_listed_company','exempted_government')", (stype, sid)).fetchone()[0]
        loc = sum(1 for p in lists_screened if _sanctions_list_kind(p) == "محلية")
        intl = sum(1 for p in lists_screened if _sanctions_list_kind(p) == "دولية")
        other = len(lists_screened) - loc - intl
        cover = f"فُحصت {len(lists_screened)} قوائم: {loc} محلية + {intl} دولية" + (f" + {other} أخرى" if other else "") if lists_screened else "-"
        if _exempted_n:
            cover += " (القائمة المحلية مستثناة بتوثيق ولم تُفحص)"
        if best["status"] in ("confirmed_match", "frozen", "reported", "high_similarity", "potential_match", "under_review"):
            list_cell = list_display_for_screening("sanctions", best["list_name"], best["matched_entity_type"], best["status"]) + " — من أصل: " + cover
        else:
            list_cell = cover
        rows.append([code, cname, sname, report_value_for_language("subject_type", stype, "ar"), ids,
                     (last or "")[:19], list_cell,
                     status_text_ar(best["status"]), int(best["match_score"] or 0), best["decision_reason"] or ""])
    return headers, rows


def _internal_conflicts_report_rows(con: sqlite3.Connection) -> Tuple[List[str], List[List[Any]]]:
    """Internal report: every internal-scope result that matched something (conflicts, decided
    outcomes, and documented known relationships)."""
    headers = ["#", "التاريخ", "المفحوص", "نوع المفحوص", "نوع التعارض", "السجل المطابق", "رقم العميل المتعارض", "النسبة %", "الحالة", "سبب القرار"]
    rows: List[List[Any]] = []
    scr = con.execute("SELECT * FROM screenings WHERE screening_scope='internal' AND status<>'no_match' ORDER BY id DESC LIMIT 2000").fetchall()
    for r in scr:
        info = {}
        try:
            info = _resolve_internal_match(con, r["matched_entity_type"], r["matched_entity_id"])
        except Exception:
            info = {"found": False}
        rows.append([int(r["id"]), (r["created_at"] or "")[:19], r["subject_name"] or "",
                     report_value_for_language("subject_type", r["subject_type"], "ar"),
                     list_display_for_screening("internal", r["list_name"], r["matched_entity_type"], r["status"]),
                     r["matched_name"] or "", (info.get("client_code") or "") if info.get("found") else "",
                     int(r["match_score"] or 0), status_text_ar(r["status"]), r["decision_reason"] or ""])
    return headers, rows


_BATCH_REPORTS = {
    "clients-sanctions": ("تقرير فحص العملاء مقابل القوائم المحلية والدولية", _clients_sanctions_report_rows,
                          [5, 12, 12, 7, 8, 9, 14, 8, 5, 12]),
    "internal-conflicts": ("تقرير فحص التعارض الداخلي", _internal_conflicts_report_rows,
                           [3, 9, 12, 8, 14, 12, 7, 5, 8, 12]),
}


def _serve_batch_report(handler: AppHandler, key: str, fmt: str) -> None:
    title, fn, weights = _BATCH_REPORTS[key]
    with db() as con:
        ensure_schema(con)
        headers, rows = fn(con)
        audit(con, "generate_batch_report", "report", 0, f"{key}.{fmt}; rows={len(rows)}", _real_client_ip(handler))
        con.commit()
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M")
    if fmt == "xlsx":
        data = _xlsx_bytes(title, headers, rows)
        ctype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        fname = f"{key}_{stamp}.xlsx"
    else:
        data = _batch_pdf_bytes(title, headers, rows, weights)
        ctype = "application/pdf"
        fname = f"{key}_{stamp}.pdf"
    handler.send_response(200)
    handler.send_header("Content-Type", ctype)
    handler.send_header("Content-Disposition", f'attachment; filename="{fname}"')
    handler.send_header("Content-Length", str(len(data)))
    handler.end_headers()
    handler.wfile.write(data)


_BATCH_ROUTE_RE = re.compile(r"^/reports/batch/(clients-sanctions|internal-conflicts)\.(xlsx|pdf)$")
_get_pre_v107e = AppHandler.do_GET
def _do_get_v107e(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    m = _BATCH_ROUTE_RE.match(parsed.path)
    if not m:
        return _get_pre_v107e(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    try:
        return _serve_batch_report(self, m.group(1), m.group(2))
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر توليد التقرير: {h(exc)}</div>", "/reports"), 500)
AppHandler.do_GET = _do_get_v107e


_reports_page_pre_v107 = reports_page
def reports_page() -> bytes:  # type: ignore[override]
    raw = _reports_page_pre_v107().decode("utf-8")
    card = (
        "<div class=\"card\"><h3>التقارير الدورية (Excel / PDF)</h3>"
        "<p class=\"small\">تقريران جاهزان للتحميل: فحص العملاء مقابل القوائم المحلية والدولية (للأغراض الرقابية)، "
        "وفحص التعارض الداخلي (للأغراض الداخلية). كل توليد يُقيَّد في سجل التدقيق.</p>"
        "<div class=\"workflow\">"
        "<a class=\"btn\" href=\"/reports/batch/clients-sanctions.xlsx\">فحص العملاء مقابل القوائم — Excel</a>"
        "<a class=\"btn secondary\" href=\"/reports/batch/clients-sanctions.pdf\">فحص العملاء مقابل القوائم — PDF</a>"
        "<a class=\"btn\" href=\"/reports/batch/internal-conflicts.xlsx\">التعارض الداخلي — Excel</a>"
        "<a class=\"btn secondary\" href=\"/reports/batch/internal-conflicts.pdf\">التعارض الداخلي — PDF</a>"
        "</div></div>")
    if "</main>" in raw:
        raw = raw.replace("</main>", card + "</main>", 1)
    else:
        raw += card
    return raw.encode("utf-8")


# ---- V10.7 Stage F: inspection-readiness dashboard (استمارة تفتيش الإدارة العامة للمحاماة) ----
# The 13 sections of the MoJ AML/CTF inspection form for law firms, kept as a live,
# fill-and-print checklist backed by auto-evidence computed from the system itself.
_INSPECTION_FORM: List[Tuple[int, str, List[str]]] = [
    (1, "السياسات والإجراءات", [
        "هل لدى المنشأة سياسات وإجراءات مكتملة وموثقة في مجال مكافحة غسل الأموال وتمويل الإرهاب وانتشار التسلح؟",
        "هل السياسات متوافقة مع الأنظمة ذات الصلة بمكافحة غسل الأموال وتمويل الإرهاب وانتشار التسلح؟",
        "هل تجري تحديث أو مراجعة لهذه السياسات بشكل دوري؟",
        "هل صيغت السياسات بما يتناسب مع طبيعة وحجم ومخاطر وتعقيد المنشأة؟",
        "هل يتم تقديم تقارير منتظمة عن مكافحة غسل الأموال وتمويل الإرهاب إلى المجلس والإدارة العليا؟",
        "كيف يتم إبلاغ الموظفين بالتحديثات؟",
        "هل توجد آلية رسمية لاعتماد السياسات الجديدة أو المعدلة؟"]),
    (2, "الحوكمة", [
        "هل تتوفر محاضر مجلس الإدارة التي تثبت مناقشات مكافحة غسل الأموال وتمويل الإرهاب؟",
        "هل تشرف الإدارة العليا على امتثال مكافحة غسل الأموال وتمويل الإرهاب بشكل فعال؟",
        "هل يقدم مسؤول الامتثال تقاريره إلى السلطة المناسبة في الشركة؟",
        "هل يتم تقديم تقارير منتظمة إلى المجلس والإدارة العليا؟",
        "هل تغطي هذه التقارير جميع المخاطر والنتائج الرئيسية ذات العلاقة؟"]),
    (3, "مسؤول الامتثال والموارد", [
        "هل تم تعيين مسؤول امتثال رسمياً وتسجيله إذا طُلب ذلك؟",
        "هل مسؤول الامتثال مستقل وملائم لذلك؟",
        "هل لدى مسؤول الامتثال السلطة والموارد والدعم الكافيين؟",
        "هل يشارك مسؤول الامتثال في القرارات الرئيسية المتعلقة بمكافحة غسل الأموال وتقييم المخاطر؟"]),
    (4, "تقييم مخاطر الأعمال", [
        "هل هناك تقييم موثق لمخاطر غسل الأموال وتمويل الإرهاب ومنع انتشار التسلح على مستوى الأعمال؟",
        "هل تم تحديث تقييم المخاطر خلال الـ12-18 شهراً الماضية؟",
        "هل أُخذت جميع عوامل المخاطر ذات الصلة (المنتجات، العملاء، الجغرافيا، قنوات التوزيع) في الاعتبار؟",
        "هل تقوم الإدارة العليا بمراجعة واعتماد تقييم المخاطر؟",
        "هل تُستخدم النتائج لتخصيص سياسات وضوابط المكافحة؟"]),
    (5, "تقييم مخاطر العملاء", [
        "هل يتم تعيين تصنيف مخاطر لكل عميل (منخفض/متوسط/مرتفع)؟",
        "هل تستند ملفات تعريف مخاطر العملاء إلى عوامل مخاطر موضوعية؟",
        "هل يتم مراجعة وتحديث ملفات تعريف المخاطر بشكل دوري؟",
        "هل يُؤخذ تصنيف مخاطر العملاء في الاعتبار عند تطبيق تدابير العناية الواجبة؟"]),
    (6, "العناية الواجبة بالعملاء", [
        "هل يتم الحصول على معلومات الهوية والتحقق منها قبل البدء بتقديم الخدمة؟",
        "هل يتم تحديد المالكين والمستفيدين الحقيقيين والتحقق منهم؟",
        "هل تم تحديد الغرض والهدف من الخدمة؟",
        "هل يتم تطبيق تدابير العناية الواجبة على أساس حساس للمخاطر؟"]),
    (7, "العناية الواجبة المعززة", [
        "هل يتم تطبيق العناية الواجبة المعززة على العملاء ذوي المخاطر العالية؟",
        "هل تم الحصول على مصادر الأموال ومصدر الثروة للعلاقات عالية المخاطر؟",
        "هل يتطلب الأمر موافقة الإدارة العليا للعملاء ذوي المخاطر العالية؟",
        "هل تخضع العلاقات مع الشخصيات العامة (PEP) لمراقبة خاصة متزايدة؟"]),
    (8, "المراقبة المستمرة", [
        "هل يتم مراقبة معاملات العملاء والتغييرات على أساس المخاطر؟",
        "هل يتم تصعيد الأنماط غير العادية للمراجعة؟",
        "هل يخضع العملاء ذوو المخاطر العالية لمراقبة مستمرة معززة؟",
        "هل يمكن مراجعة العلاقات والمعاملات بشكل دوري وتوثيقها؟"]),
    (9, "الامتثال للعقوبات المالية المستهدفة", [
        "هل تدرك المنشأة مخاطر تمويل الإرهاب؟",
        "هل تدرك المنشأة مخاطر تمويل انتشار الأسلحة؟",
        "ما مدى وعي المنشأة بتصنيفات الأمم المتحدة والمملكة العربية السعودية؟",
        "هل تعتمد المنشأة على أداة فحص؟ قيِّم كفاية هذه الأداة، وهل يُجرى اختبار ضمان على أداة الفحص؟",
        "إذا لم يتم الاعتماد على أداة فحص، فكيف يتم إجراء الفحص لضمان تلبية متطلبات العقوبات المالية المستهدفة؟",
        "هل يتم إجراء فحص العقوبات عند الانضمام وخلال تقديم الخدمة؟",
        "هل يُحدَّث نظام الفحص بأحدث قوائم العقوبات؟",
        "هل تُراجع التنبيهات بسرعة ودقة؟",
        "هل تُجمَّد الأصول/الموارد ويُبلغ عنها إذا تحددت تطابقات إيجابية؟",
        "هل تطبق المنشأة إجراءات العناية الواجبة المعززة على مواطني الدول عالية المخاطر؟",
        "هل يشمل التدريب المقدم للموظفين مخاطر تمويل الإرهاب؟",
        "هل يشمل التدريب المقدم للموظفين مخاطر تمويل انتشار الأسلحة؟"]),
    (10, "الإبلاغ عن المعاملات المشبوهة (STR)", [
        "هل لدى المنشأة عملية مراقبة مستمرة وقائمة؟",
        "هل لدى المنشأة إجراء مراقبة مستمرة يُعمل به؟",
        "هل تُراقب المعاملات يدوياً أم يُعتمد على أداة تلقائية؟",
        "هل لدى المنشأة قائمة بعلامات التحذير والسيناريوهات المتعلقة بغسل الأموال/تمويل الإرهاب/تمويل انتشار الأسلحة؟",
        "هل هناك عملية تصعيد داخلية للمعاملات المشبوهة؟",
        "هل لديكم آلية لتطبيق قرارات مجلس الأمن ذات الصلة بمكافحة جرائم الإرهاب وتمويله المبلغة بتعميم الوزارة رقم (13/ت/7744) في 24/7/1440هـ؟",
        "هل لديكم آلية لتطبيق قرارات مجلس الأمن المتعلقة بمنع انتشار أسلحة الدمار الشامل المبلغة بتعميم الوزارة رقم (13/ت/7745) في 26/7/1440هـ؟",
        "هل لديكم آلية الالتزام بالعقوبات المالية المستهدفة الوطنية والأممية ذات الصلة والقرارات الأخرى لمجلس الأمن وفق تعميم الوزارة رقم (476226920) في 20/5/1447هـ؟",
        "هل تُقدَّم بلاغات المعاملات المشبوهة في الوقت المناسب إلى الإدارة العامة للتحريات المالية على منظومة (تقصّي) عند الحاجة؟",
        "هل تُوثَّق أسباب تقديم أو عدم تقديم بلاغات المعاملات المشبوهة على نحو صحيح؟",
        "هل يُدرَّب الموظفون على كيفية التعرف على الأنشطة المشبوهة والإبلاغ عنها؟"]),
    (11, "حفظ السجلات", [
        "هل يُحتفظ بسجلات العناية الواجبة لمدة لا تقل عن الحد الأدنى المطلوب نظاماً؟",
        "هل يُحتفظ بسجلات المعاملات بشكل كافٍ للسماح بإعادة البناء عند الحاجة؟",
        "هل يُتحكم في الوصول إلى السجلات ويُراقب جيداً؟",
        "هل يمكن استرجاع السجلات بسهولة لطلبات الجهات التنظيمية أو إنفاذ النظام؟"]),
    (12, "التدقيق الداخلي والاختبار المستقل", [
        "هل توجد وظيفة تدقيق داخلي مستقلة تغطي الامتثال لأحكام أنظمة مكافحة غسل الأموال/تمويل الإرهاب/تمويل انتشار الأسلحة؟",
        "هل تُجرى تدقيقات المكافحة بشكل دوري استناداً إلى المخاطر؟",
        "هل تُبلَّغ نتائج التدقيق إلى الإدارة العليا ومجلس الإدارة؟",
        "هل يتم تتبع الإجراءات التصحيحية وتنفيذها؟"]),
    (13, "تدريب الموظفين", [
        "هل التدريب على المكافحة إلزامي لجميع الموظفين المعنيين؟",
        "هل يُحدَّث التدريب بانتظام ليعكس المخاطر الناشئة والتغييرات التنظيمية؟",
        "هل يُوفر تدريب متخصص للوظائف ذات المخاطر العالية؟",
        "هل تُجمع سجلات الحضور والتعليقات ويُحافظ عليها؟"]),
]

_INSPECTION_STATUSES = {"pending": "لم يُقيَّم", "available": "متوفر", "partial": "جزئي", "missing": "غير متوفر", "na": "لا ينطبق"}


def _seed_inspection_checklist(con: sqlite3.Connection) -> None:
    for sec_no, sec_title, items in _INSPECTION_FORM:
        for i, q in enumerate(items, 1):
            con.execute("INSERT OR IGNORE INTO inspection_checklist(created_at, section_no, section_title, item_no, question) VALUES(?,?,?,?,?)",
                        (now_iso(), sec_no, sec_title, i, q))


def _inspection_auto_evidence(con: sqlite3.Connection) -> str:
    total = con.execute("SELECT COUNT(*) FROM screenings").fetchone()[0]
    sanc = con.execute("SELECT COUNT(*) FROM screenings WHERE screening_scope='sanctions'").fetchone()[0]
    internal = con.execute("SELECT COUNT(*) FROM screenings WHERE screening_scope='internal'").fetchone()[0]
    open_alerts = con.execute("SELECT COUNT(*) FROM screenings WHERE status IN ('potential_match','high_similarity','confirmed_match','frozen','under_review')").fetchone()[0]
    decided = con.execute("SELECT COUNT(*) FROM screenings WHERE status IN ('false_positive','closed','reported') OR (decision_reason IS NOT NULL AND decision_reason<>'')").fetchone()[0]
    blocked = con.execute("SELECT COUNT(*) FROM clients WHERE status IN ('blocked','frozen')").fetchone()[0]
    lists_active = con.execute("SELECT COUNT(DISTINCT list_name) FROM sanctions_entries WHERE active=1").fetchone()[0]
    last_import = con.execute("SELECT created_at FROM sanctions_import_logs WHERE status IN ('success','partial_success') ORDER BY id DESC LIMIT 1").fetchone()
    risk_dist = con.execute("SELECT risk_level, COUNT(*) c FROM clients GROUP BY risk_level").fetchall()
    high_clients = con.execute("SELECT COUNT(*) FROM clients WHERE risk_level IN ('high','critical')").fetchone()[0]
    high_doc = con.execute("SELECT COUNT(*) FROM clients WHERE risk_level IN ('high','critical') AND (COALESCE(source_of_funds,'')<>'' OR COALESCE(source_of_wealth,'')<>'' OR COALESCE(source_notes,'')<>'')").fetchone()[0]
    runs = con.execute("SELECT COUNT(*) FROM continuous_screening_runs").fetchone()
    last_run = con.execute("SELECT created_at FROM continuous_screening_runs ORDER BY id DESC LIMIT 1").fetchone()
    audits = con.execute("SELECT COUNT(*) FROM audit_events").fetchone()[0]
    gov = con.execute("SELECT COUNT(*) FROM compliance_governance").fetchone()[0]
    dist = "، ".join(f"{h(r['risk_level'] or 'normal')}: {r['c']}" for r in risk_dist) or "-"
    pct = f"{(100 * high_doc // high_clients)}%" if high_clients else "—"
    return f"""
<div class="card"><h3>الأدلة الآلية من النظام (لأسئلة الأداة والفحص والسجلات)</h3>
<div class="grid">
<div class="card kpi"><div>نتائج الفحص الكلية (أداة الفحص قيد الاستخدام)</div><div class="num">{total}</div><span class="small">قوائم: {sanc} · داخلي: {internal}</span></div>
<div class="card kpi"><div>القوائم النشطة المحملة</div><div class="num">{lists_active}</div><span class="small">آخر تحديث للقوائم: {h((last_import[0] if last_import else 'لم يتم')[:19])}</span></div>
<div class="card kpi"><div>تنبيهات قيد المراجعة</div><div class="num">{open_alerts}</div><span class="small">قرارات موثقة: {decided}</span></div>
<div class="card kpi status-red"><div>عملاء محظورون/مجمدون</div><div class="num">{blocked}</div><span class="small">يجمَّد ويُبلَّغ عند التطابق الموجب</span></div>
<div class="card kpi"><div>توزيع تصنيف مخاطر العملاء</div><div class="num" style="font-size:18px">{dist}</div></div>
<div class="card kpi"><div>توثيق مصادر الأموال/الثروة للعملاء مرتفعي المخاطر</div><div class="num">{pct}</div><span class="small">{high_doc} من {high_clients}</span></div>
<div class="card kpi"><div>دورات الفحص المستمر/اليومي</div><div class="num">{runs[0] if runs else 0}</div><span class="small">آخر دورة: {h((last_run[0] if last_run else '-')[:19])}</span></div>
<div class="card kpi"><div>سجل التدقيق (من فعل ماذا ومتى وبأي جهاز)</div><div class="num">{audits}</div><span class="small">الاحتفاظ بالسجلات: {RETENTION_YEARS} سنوات على الأقل</span></div>
</div>
<p class="small">أداة الفحص: هذا النظام نفسه؛ اختبارات الضمان موثقة ضمن حزمة كل إصدار (docs/*_TEST_RESULTS.txt) وتشمل فحص المطابقة بالأرقام والأسماء متعددة المقاطع. عناصر الحوكمة والتدريب المسجلة: {gov}.</p></div>
"""


def inspection_page(message: str = "") -> bytes:
    with db() as con:
        ensure_schema(con)
        _seed_inspection_checklist(con)
        con.commit()
        items = con.execute("SELECT * FROM inspection_checklist ORDER BY section_no, item_no").fetchall()
        auto = _inspection_auto_evidence(con)
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    total = len(items)
    done = sum(1 for r in items if r["status"] in ("available", "na"))
    partial = sum(1 for r in items if r["status"] == "partial")
    missing = sum(1 for r in items if r["status"] == "missing")
    sections: Dict[int, List[sqlite3.Row]] = {}
    for r in items:
        sections.setdefault(int(r["section_no"]), []).append(r)
    parts = []
    for sec_no in sorted(sections):
        rows = sections[sec_no]
        trs = []
        for r in rows:
            opts = "".join(f"<option value='{k}' {'selected' if r['status'] == k else ''}>{v}</option>" for k, v in _INSPECTION_STATUSES.items())
            badge_cls = {"available": "ok", "na": "ok", "partial": "warn", "missing": "danger"}.get(r["status"], "warn")
            trs.append(
                f"<tr><td>{r['item_no']}</td><td>{h(r['question'])}</td>"
                f"<td><span class='badge {badge_cls}'>{h(_INSPECTION_STATUSES.get(r['status'], r['status']))}</span></td>"
                f"<td><form method='post' action='/inspection/update' style='display:flex;gap:6px;flex-wrap:wrap;align-items:center'>"
                f"<input type='hidden' name='item_id' value='{r['id']}'>"
                f"<select name='status' style='max-width:130px'>{opts}</select>"
                f"<input name='evidence' value='{h(r['evidence'] or '')}' placeholder='الدليل / المرفق / الملاحظة' style='max-width:260px'>"
                f"<button class='btn secondary' style='margin:0;padding:8px 12px'>حفظ</button></form>"
                f"<span class='small'>{h(r['updated_by'] or '')} {h((r['updated_at'] or '')[:16])}</span></td></tr>")
        parts.append(
            f"<div class=\"card\"><h3>المطلب {sec_no}: {h(rows[0]['section_title'])}</h3>"
            f"<div class=\"table-wrap\"><table><thead><tr><th>#</th><th>البند</th><th>الحالة</th><th>التقييم والدليل</th></tr></thead>"
            f"<tbody>{''.join(trs)}</tbody></table></div></div>")
    body = f"""
<div class="card"><div class="section-title"><div><h2>جاهزية التفتيش — استمارة تفتيش الإدارة العامة للمحاماة (مكافحة غسل الأموال وتمويل الإرهاب)</h2>
<p class="small">قيِّم كل بند وأرفق الدليل؛ يظهر التقييم والمقيِّم وتاريخه. اطبع الصفحة عند الزيارة.</p></div>
<button class="btn secondary" onclick="window.print()">طباعة</button></div>{msg}
<div class="grid"><div class="card kpi status-green"><div>متوفر / لا ينطبق</div><div class="num">{done}</div></div>
<div class="card kpi status-yellow"><div>جزئي</div><div class="num">{partial}</div></div>
<div class="card kpi status-red"><div>غير متوفر</div><div class="num">{missing}</div></div>
<div class="card kpi"><div>إجمالي البنود</div><div class="num">{total}</div></div></div>
{auto}
{''.join(parts)}
"""
    return layout("جاهزية التفتيش", body, "/compliance")


def inspection_update(fields: Dict[str, List[str]], ip: str = "") -> None:
    item_id = int(form_value(fields, "item_id", "0") or 0)
    status = form_value(fields, "status", "pending")
    if status not in _INSPECTION_STATUSES:
        status = "pending"
    user = _auth_current_user() or {}
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT * FROM inspection_checklist WHERE id=?", (item_id,)).fetchone()
        if not r:
            raise ValueError("البند غير موجود")
        con.execute("UPDATE inspection_checklist SET status=?, evidence=?, updated_at=?, updated_by=? WHERE id=?",
                    (status, form_value(fields, "evidence"), now_iso(), str(user.get("user_name") or ""), item_id))
        audit(con, "inspection_item_update", "inspection", item_id, f"المطلب {r['section_no']} بند {r['item_no']}: {status}", ip)
        con.commit()


_get_pre_v107f = AppHandler.do_GET
def _do_get_v107f(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    if parsed.path != "/inspection":
        return _get_pre_v107f(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    try:
        return self._send(inspection_page())
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر عرض الصفحة: {h(exc)}</div>", "/compliance"), 500)
AppHandler.do_GET = _do_get_v107f


_post_pre_v107f = AppHandler.do_POST
def _do_post_v107f(self: AppHandler) -> None:
    if urlparse(self.path).path != "/inspection/update":
        return _post_pre_v107f(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    # V10.9 صدق/تفويض: تعديل تقييم بند التفتيش يمس دليلاً يُعرض على المفتش — يقتصر على مدير/مسؤول امتثال
    if (user.get("role") or "") not in ("admin", "compliance"):
        return self._send(layout("غير مصرح", "<div class='error'>تعديل بنود التفتيش يتطلب دور مدير أو مسؤول امتثال.</div>", "/compliance"), 403)
    try:
        fields, files, ip = _parse_request_fields(self)
        inspection_update(fields, ip)
        return send_redirect(self, "/inspection")
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر حفظ البند: {h(exc)}</div>", "/compliance"), 500)
AppHandler.do_POST = _do_post_v107f


_compliance_page_pre_v107 = compliance_page
def compliance_page(message: str = "") -> bytes:  # type: ignore[override]
    raw = _compliance_page_pre_v107(message).decode("utf-8")
    link = ("<div class=\"card\"><h3>جاهزية التفتيش</h3><p class=\"small\">استمارة تفتيش الإدارة العامة للمحاماة "
            "لمتطلبات مكافحة غسل الأموال وتمويل الإرهاب — تقييم البنود الثلاثة عشر مع الأدلة الآلية من النظام.</p>"
            "<a class=\"btn\" href=\"/inspection\">فتح لوحة جاهزية التفتيش</a></div>")
    raw = raw.replace("</main>", link + "</main>", 1) if "</main>" in raw else raw + link
    return raw.encode("utf-8")


# ---- V10.7.0-fix layer (adversarial-review findings) ----
# The /reports route is served by reports_archive_page (V10.5.4+), so the batch-report card
# must be injected THERE — the reports_page override alone was unreachable in the live UI.
_BATCH_REPORT_CARD = (
    "<div class=\"card\"><h3>التقارير الدورية (Excel / PDF)</h3>"
    "<p class=\"small\">تقريران جاهزان للتحميل: فحص العملاء مقابل القوائم المحلية والدولية (للأغراض الرقابية)، "
    "وفحص التعارض الداخلي (للأغراض الداخلية). كل توليد يُقيَّد في سجل التدقيق.</p>"
    "<div class=\"workflow\">"
    "<a class=\"btn\" href=\"/reports/batch/clients-sanctions.xlsx\">فحص العملاء مقابل القوائم — Excel</a>"
    "<a class=\"btn secondary\" href=\"/reports/batch/clients-sanctions.pdf\">فحص العملاء مقابل القوائم — PDF</a>"
    "<a class=\"btn\" href=\"/reports/batch/internal-conflicts.xlsx\">التعارض الداخلي — Excel</a>"
    "<a class=\"btn secondary\" href=\"/reports/batch/internal-conflicts.pdf\">التعارض الداخلي — PDF</a>"
    "</div></div>")

_reports_archive_pre_v107fix = reports_archive_page
def reports_archive_page(qs: Dict[str, List[str]]) -> bytes:  # type: ignore[override]
    raw = _reports_archive_pre_v107fix(qs).decode("utf-8")
    raw = raw.replace("</main>", _BATCH_REPORT_CARD + "</main>", 1) if "</main>" in raw else raw + _BATCH_REPORT_CARD
    return raw.encode("utf-8")


# known_relationship must read correctly in report text surfaces (batch xlsx/pdf, single-report PDF).
_status_text_ar_pre_v107 = status_text_ar
def status_text_ar(status: str) -> str:  # type: ignore[override]
    if status == _KNOWN_REL_STATUS:
        return "علاقة معروفة موثقة"
    return _status_text_ar_pre_v107(status)


_status_text_en_pre_v107 = status_text_en
def status_text_en(status: str) -> str:  # type: ignore[override]
    if status == _KNOWN_REL_STATUS:
        return "Documented Known Relationship"
    return _status_text_en_pre_v107(status)


# ===========================================================================
# V10.8.0 - Team feedback wave 2:
#  (1) documented narrow exemption for GOVERNMENT entities (national list only —
#      applied inside screen_subjects; status plumbing here);
#  (2) per-client PDF reports (detailed internal conflicts + lists screening);
#  (3) BACKGROUND screening jobs so the app never hangs + full re-scan;
#  (4) managing/executing partner editable later (in-place in matter edit);
#  (5) clients page: search + matters count + pending/outstanding notes;
#  (6) unified establishment number (700) captured and used as an internal identifier;
#  (7) home dashboard: clickable red/yellow/green boxes with pulse alert.
# ===========================================================================
import queue as _bgqueue
import threading as _bgthreading
import time as _bgtime

APP_VERSION = "V10.8.0 - Team Feedback Wave 2 (gov exemption, client reports, background screening)"

_GOV_EXEMPT_STATUS = "exempted_government"


# --------------------- schema: unified number ---------------------
_V108_SCHEMA_ENSURED: set = set()
_ensure_schema_pre_v108 = ensure_schema


def ensure_schema(con: sqlite3.Connection, force: bool = False) -> None:  # type: ignore[override]
    _ensure_schema_pre_v108(con, force)
    key = str(DB_PATH)
    if not force and key in _V108_SCHEMA_ENSURED:
        return
    try:
        _ensure_column(con, "clients", "unified_number", "TEXT")
    except Exception:
        pass
    con.commit()
    _V108_SCHEMA_ENSURED.add(key)


# --------------------- status plumbing: exempted_government ---------------------
_badge_status_pre_v108 = badge_status
def badge_status(status: str) -> str:  # type: ignore[override]
    if status == _GOV_EXEMPT_STATUS:
        return '<span class="badge ok" role="status">استثناء موثق - جهة حكومية</span>'
    return _badge_status_pre_v108(status)


_risk_visual_pre_v108 = risk_visual_for_screening
def risk_visual_for_screening(status: str, score: int) -> Tuple[str, str, str]:  # type: ignore[override]
    if status == _GOV_EXEMPT_STATUS:
        return "green", "أخضر", "جهة حكومية: استثناء موثق للقائمة الوطنية فقط مع استمرار القوائم الدولية والفحص الداخلي"
    return _risk_visual_pre_v108(status, score)


_status_text_ar_pre_v108 = status_text_ar
def status_text_ar(status: str) -> str:  # type: ignore[override]
    if status == _GOV_EXEMPT_STATUS:
        return "استثناء موثق - جهة حكومية"
    return _status_text_ar_pre_v108(status)


_status_text_en_pre_v108 = status_text_en
def status_text_en(status: str) -> str:  # type: ignore[override]
    if status == _GOV_EXEMPT_STATUS:
        return "Documented Government Exemption"
    return _status_text_en_pre_v108(status)


# --------------------- unified number (700) as internal identifier ---------------------
_subject_tuple_pre_v108 = subject_tuple
def subject_tuple(entity_type: str, row: sqlite3.Row, subject_type: str) -> Dict[str, Any]:  # type: ignore[override]
    d = _subject_tuple_pre_v108(entity_type, row, subject_type)
    try:
        keys = set(row.keys())
        # V10.8.0-fix: الرقم الموحد في مفتاحه المستقل (لا يُحشر في خانة السجل التجاري)،
        # ولفئات الكيانات المعتمدة فقط (allowlist) حتى لا ينقلب اسم شخص إلى نمط مطابقة الكيانات.
        if (d.get("entity_category") or "") in ENTITY_CATEGORY_VALUES \
                and "unified_number" in keys and (row["unified_number"] or "").strip():
            d["unified_number"] = row["unified_number"].strip()
    except Exception:
        pass
    return d


_all_internal_entities_pre_v108 = all_internal_entities
def all_internal_entities(con: sqlite3.Connection) -> List[Dict[str, Any]]:  # type: ignore[override]
    ents = _all_internal_entities_pre_v108(con)
    try:
        uni = {int(r["id"]): (r["unified_number"] or "").strip()
               for r in con.execute("SELECT id, unified_number FROM clients WHERE COALESCE(unified_number,'')<>''").fetchall()}
        if uni:
            for e in ents:
                if e["matched_entity_type"] == "client" and (e.get("entity_category") or "") in ENTITY_CATEGORY_VALUES:
                    u = uni.get(int(e["matched_entity_id"]))
                    if u:
                        e["unified_number"] = u
    except Exception:
        pass
    return ents


def _validate_unified(u: str) -> str:
    """V10.8.0-fix: الرقم الموحد 10 أرقام يبدأ بـ7 (بعد توحيد الأرقام العربية/اللاتينية)."""
    u = normalize_identifier(str(u or ""))
    if u and not re.fullmatch(r"7\d{9}", u):
        raise ValueError("الرقم الموحد للمنشأة يجب أن يكون 10 أرقام ويبدأ بالرقم 7")
    return u


_create_client_pre_v108 = create_client
def create_client(fields: Dict[str, List[str]], files: Optional[Dict[str, Tuple[str, bytes]]] = None, ip: str = "") -> int:  # type: ignore[override]
    u = _validate_unified(form_value(fields, "unified_number"))
    cid = _create_client_pre_v108(fields, files, ip)
    if u:
        with db() as con:
            ensure_schema(con)
            con.execute("UPDATE clients SET unified_number=? WHERE id=?", (u, cid))
            con.commit()
    return cid


_update_client_pre_v108 = update_client
def update_client(fields: Dict[str, List[str]], ip: str = "") -> int:  # type: ignore[override]
    # V10.8.0-fix (غسل الحالة): تحويل نوع العميل إلى "جهة حكومية" أو تعديل علم الإدراج
    # إجراء مقيد بالامتثال/الإدارة ويقيد بتدقيق مستقل.
    target_cid = int(form_value(fields, "client_id", "0") or 0)
    new_type = form_value(fields, "client_type")
    new_listed = form_value(fields, "listed_saudi_market")
    if target_cid:
        with db() as con:
            ensure_schema(con)
            cur = con.execute("SELECT client_type, listed_saudi_market FROM clients WHERE id=?", (target_cid,)).fetchone()
        if cur:
            u_ctx = _auth_current_user() or {}
            gov_flip = new_type and new_type != (cur["client_type"] or "") and new_type == "government"
            listed_flip = new_listed != "" and int(new_listed or 0) != int(cur["listed_saudi_market"] or 0)
            if (gov_flip or listed_flip) and u_ctx and u_ctx.get("role") not in ("admin", "compliance"):
                raise ValueError("تغيير نوع العميل إلى جهة حكومية أو تعديل علم الإدراج مقصور على الامتثال أو مدير النظام")
            if gov_flip or listed_flip:
                with db() as con:
                    ensure_schema(con)
                    audit(con, "client_screening_flag_change", "client", target_cid,
                          f"type:{cur['client_type']}->{new_type}; listed:{cur['listed_saudi_market']}->{new_listed}", ip)
                    con.commit()
    uni_present = ("unified_number_present" in fields) or ("unified_number" in fields)
    u = _validate_unified(form_value(fields, "unified_number")) if uni_present else None
    cid = _update_client_pre_v108(fields, ip)
    if uni_present:
        with db() as con:
            ensure_schema(con)
            con.execute("UPDATE clients SET unified_number=? WHERE id=?", (u or "", cid))
            con.commit()
    return cid


# --------------------- background job runner (item 3) ---------------------
_JOBS: Dict[str, Dict[str, Any]] = {}
_JOB_LOCK = _bgthreading.Lock()
_JOB_Q: "_bgqueue.Queue" = _bgqueue.Queue()
_JOB_SEQ = [0]
_JOB_WORKER_STARTED = [False]


def _job_worker() -> None:
    while True:
        jid = _JOB_Q.get()
        job = _JOBS.get(jid)
        if not job:
            continue
        job["status"] = "running"
        job["started_at"] = now_iso()
        # V10.8.0-fix: إعادة تثبيت هوية المنفذ داخل خيط العامل حتى تُنسب كل قيود التدقيق
        # الناتجة عن الفحص الخلفي إلى صاحب الأمر وجهازه وجلسته (كما في التنفيذ المتزامن).
        try:
            _AUTH_CTX.user = job.get("actor_user")
            _AUTH_CTX.user_agent = (job.get("actor_ua") or "") + f" (مهمة خلفية {jid})"
            _AUTH_CTX.session_id = job.get("actor_sid") or ""
            _AUTH_CTX.ip = job.get("actor_ip") or ""
        except Exception:
            pass
        try:
            res = job["fn"]()
            job["summary"] = str(res)[:200] if res is not None else ""
            job["status"] = "done"
        except Exception as exc:
            job["status"] = "failed"
            job["summary"] = str(exc)[:300]
            try:
                import traceback as _tb
                LOGS_DIR.mkdir(parents=True, exist_ok=True)
                with open(LOGS_DIR / "background_jobs.log", "a", encoding="utf-8") as fh:
                    fh.write(f"{now_iso()} {jid} FAILED {job.get('label')}\n{_tb.format_exc()}\n")
            except Exception:
                pass
        finally:
            job["finished_epoch"] = _bgtime.time()
            job["finished_at"] = now_iso()
            # V10.8.0-fix: نتيجة المهمة تُقيَّد قيداً دائماً في سجل التدقيق (نجاحاً أو فشلاً)
            try:
                with db() as con:
                    ensure_schema(con)
                    audit(con, "background_job_done" if job["status"] == "done" else "background_job_failed",
                          "job", 0, f"{jid}: {job.get('label')} :: {job.get('summary')}"[:2000], job.get("actor_ip") or "")
                    con.commit()
            except Exception:
                pass
            try:
                _AUTH_CTX.user = None
                _AUTH_CTX.user_agent = ""
                _AUTH_CTX.session_id = ""
                _AUTH_CTX.ip = ""
            except Exception:
                pass


def enqueue_job(label: str, fn, user_name: str = "", ip: str = "") -> str:
    with _JOB_LOCK:
        if not _JOB_WORKER_STARTED[0]:
            t = _bgthreading.Thread(target=_job_worker, daemon=True, name="lt-job-worker")
            t.start()
            _JOB_WORKER_STARTED[0] = True
        # V10.8.0-fix: منع تكرار المهمة نفسها وهي منتظرة/جارية + سقف 5 مهام معلقة لكل مستخدم
        for j in _JOBS.values():
            if j["status"] in ("queued", "running") and j["label"] == label:
                return j["id"]
        pending_mine = sum(1 for j in _JOBS.values() if j["status"] in ("queued", "running") and j.get("user") == user_name)
        if pending_mine >= 5:
            raise ValueError("لديك 5 مهام خلفية معلقة؛ انتظر اكتمالها قبل إضافة المزيد")
        _JOB_SEQ[0] += 1
        jid = f"J{_JOB_SEQ[0]:05d}"
        actor_user = None
        actor_ua = ""
        actor_sid = ""
        try:
            actor_user = getattr(_AUTH_CTX, "user", None)
            actor_ua = getattr(_AUTH_CTX, "user_agent", "") or ""
            actor_sid = getattr(_AUTH_CTX, "session_id", "") or ""
        except Exception:
            pass
        _JOBS[jid] = {"id": jid, "seq": _JOB_SEQ[0], "label": label, "fn": fn, "status": "queued", "queued_at": now_iso(),
                      "user": user_name, "finished_epoch": 0.0, "summary": "",
                      "actor_user": actor_user, "actor_ua": actor_ua, "actor_sid": actor_sid, "actor_ip": ip}
        # keep the registry bounded (numeric seq order; terminal jobs only)
        if len(_JOBS) > 60:
            for k, _v in sorted(_JOBS.items(), key=lambda kv: kv[1].get("seq", 0))[: len(_JOBS) - 60]:
                if _JOBS[k]["status"] in ("done", "failed"):
                    _JOBS.pop(k, None)
    try:
        with db() as con:
            ensure_schema(con)
            audit(con, "background_job_enqueued", "job", 0, f"{jid}: {label}", ip)
            con.commit()
    except Exception:
        pass
    _JOB_Q.put(jid)
    return jid


_JOB_STATUS_AR = {"queued": "في الانتظار", "running": "قيد التنفيذ", "done": "اكتمل", "failed": "فشل"}


def _jobs_banner_html() -> str:
    # V10.8.0-fix: الشريط لصاحب المهام وللامتثال/الإدارة فقط (عناوين المهام تحمل أرقام عملاء)،
    # ولا يظهر لجلسة لم تكمل تغيير كلمة المرور.
    try:
        viewer = _auth_current_user() or {}
    except Exception:
        viewer = {}
    if not viewer or viewer.get("must_change_password"):
        return ""
    with _JOB_LOCK:
        jobs = list(_JOBS.values())
    if viewer.get("role") not in ("admin", "compliance"):
        me = str(viewer.get("user_name") or "")
        jobs = [j for j in jobs if (j.get("user") or "") == me]
    active_all = [j for j in jobs if j["status"] in ("queued", "running")]
    more = max(0, len(active_all) - 3)
    active = active_all[:3]
    recent = [j for j in jobs if j["status"] in ("done", "failed") and (_bgtime.time() - (j.get("finished_epoch") or 0)) < 600]
    if not active and not recent:
        return ""
    bits = []
    for j in active:
        bits.append(f"⏳ {h(j['label'])} — {_JOB_STATUS_AR.get(j['status'], j['status'])}")
    for j in sorted(recent, key=lambda x: -(x.get("finished_epoch") or 0))[:2]:
        icon = "✅" if j["status"] == "done" else "⚠️"
        bits.append(f"{icon} {h(j['label'])} — {_JOB_STATUS_AR.get(j['status'], j['status'])}")
    if more:
        bits.append(f"و{more} مهمة أخرى في الانتظار")
    cls = "notice" if active else "success"
    hint = " · الفحص يعمل في الخلفية ويمكنك متابعة العمل؛ حدّث الصفحة لمتابعة الحالة." if active else ""
    return f"<div class='{cls}' style='margin-bottom:12px'><b>المهام الخلفية:</b> " + " | ".join(bits) + hint + "</div>"


_layout_pre_v108 = layout
def layout(title: str, body: str, active: str = "") -> bytes:  # type: ignore[override]
    banner = _jobs_banner_html()
    if banner:
        body = banner + body
    return _layout_pre_v108(title, body, active)


# --------------------- per-client PDF reports (item 2) ---------------------
def _client_subject_set(con: sqlite3.Connection, cid: int) -> List[Tuple[str, int, str]]:
    subs = [("client", int(cid), "")]
    for rp in con.execute("SELECT id, full_name FROM related_parties WHERE parent_type='client' AND parent_id=?", (cid,)).fetchall():
        subs.append(("client_related_party", int(rp["id"]), rp["full_name"] or ""))
    return subs


def client_internal_report_rows(con: sqlite3.Connection, cid: int) -> Tuple[List[str], List[List[Any]]]:
    headers = ["#", "التاريخ", "المفحوص", "نوع المفحوص", "نوع التعارض", "السجل المطابق", "رقم العميل المتعارض", "النسبة %", "الحالة", "سبب القرار"]
    rows: List[List[Any]] = []
    for stype, sid, _nm in _client_subject_set(con, cid):
        for r in con.execute("SELECT * FROM screenings WHERE subject_type=? AND subject_id=? AND screening_scope='internal' AND status<>'no_match' ORDER BY id DESC LIMIT 500", (stype, sid)).fetchall():
            info = {}
            try:
                info = _resolve_internal_match(con, r["matched_entity_type"], r["matched_entity_id"])
            except Exception:
                info = {"found": False}
            rows.append([int(r["id"]), (r["created_at"] or "")[:19], r["subject_name"] or "",
                         report_value_for_language("subject_type", r["subject_type"], "ar"),
                         list_display_for_screening("internal", r["list_name"], r["matched_entity_type"], r["status"]),
                         r["matched_name"] or "", (info.get("client_code") or "") if info.get("found") else "",
                         int(r["match_score"] or 0), status_text_ar(r["status"]), r["decision_reason"] or ""])
    if not rows:
        rows.append(["-", "-", "-", "-", "لا توجد نتائج تعارض داخلي مسجلة لهذا العميل", "-", "-", 0, "-", "-"])
    return headers, rows


def client_sanctions_report_rows(con: sqlite3.Connection, cid: int) -> Tuple[List[str], List[List[Any]]]:
    headers = ["المفحوص", "نوع المفحوص", "آخر فحص", "القوائم المفحوصة", "أشد نتيجة", "قائمة التطابق", "السجل المطابق", "النسبة %", "سبب القرار"]
    rows: List[List[Any]] = []
    sev_case = ("CASE status WHEN 'confirmed_match' THEN 0 WHEN 'frozen' THEN 0 WHEN 'reported' THEN 0 "
                "WHEN 'high_similarity' THEN 1 WHEN 'potential_match' THEN 2 WHEN 'under_review' THEN 2 "
                "WHEN 'list_unavailable' THEN 3 WHEN 'exempted_listed_company' THEN 4 WHEN 'exempted_government' THEN 4 "
                "WHEN 'known_relationship' THEN 5 WHEN 'false_positive' THEN 6 WHEN 'closed' THEN 6 ELSE 7 END")
    for stype, sid, _nm in _client_subject_set(con, cid):
        best = con.execute(f"SELECT * FROM screenings WHERE subject_type=? AND subject_id=? AND screening_scope='sanctions' ORDER BY {sev_case}, id DESC LIMIT 1", (stype, sid)).fetchone()
        subj_name = _nm
        if stype == "client":
            c = con.execute("SELECT legal_name FROM clients WHERE id=?", (sid,)).fetchone()
            subj_name = (c["legal_name"] if c else "") or ""
        if not best:
            rows.append([subj_name, report_value_for_language("subject_type", stype, "ar"), "لم يُفحص بعد", "-", "لم يُفحص", "-", "-", 0, ""])
            continue
        last = con.execute("SELECT MAX(created_at) FROM screenings WHERE subject_type=? AND subject_id=? AND screening_scope='sanctions'", (stype, sid)).fetchone()[0]
        lists_screened = set()
        for r2 in con.execute("SELECT DISTINCT list_name FROM screenings WHERE subject_type=? AND subject_id=? AND screening_scope='sanctions' AND status NOT IN ('exempted_listed_company','exempted_government')", (stype, sid)).fetchall():
            for part in (r2[0] or "").split(","):
                p = part.strip()
                if p and p not in ("ALL_ACTIVE_LISTS", "NO_ACTIVE_LISTS"):
                    lists_screened.add(p)
        exempted = con.execute("SELECT COUNT(*) FROM screenings WHERE subject_type=? AND subject_id=? AND status IN ('exempted_listed_company','exempted_government')", (stype, sid)).fetchone()[0]
        loc = sum(1 for p in lists_screened if _sanctions_list_kind(p) == "محلية")
        intl = sum(1 for p in lists_screened if _sanctions_list_kind(p) == "دولية")
        cover = f"فُحصت {len(lists_screened)} قوائم: {loc} محلية + {intl} دولية" if lists_screened else "-"
        if exempted:
            cover += " (القائمة المحلية مستثناة بتوثيق ولم تُفحص)"
        rows.append([subj_name, report_value_for_language("subject_type", stype, "ar"), (last or "")[:19], cover,
                     status_text_ar(best["status"]),
                     list_display_for_screening("sanctions", best["list_name"], best["matched_entity_type"], best["status"]),
                     best["matched_name"] or "-", int(best["match_score"] or 0), best["decision_reason"] or ""])
        # detailed hit rows (all open/decided matches, beyond the single most-severe line)
        for hit in con.execute("SELECT * FROM screenings WHERE subject_type=? AND subject_id=? AND screening_scope='sanctions' AND status IN ('confirmed_match','frozen','reported','high_similarity','potential_match','under_review','false_positive') ORDER BY id DESC LIMIT 100", (stype, sid)).fetchall():
            rows.append(["  ↳ تطابق", "", (hit["created_at"] or "")[:19], "",
                         status_text_ar(hit["status"]),
                         list_display_for_screening("sanctions", hit["list_name"], hit["matched_entity_type"], hit["status"]),
                         hit["matched_name"] or "-", int(hit["match_score"] or 0), hit["decision_reason"] or ""])
    return headers, rows


_CLIENT_REPORT_KINDS = {
    "internal": ("تقرير التعارض الداخلي التفصيلي", client_internal_report_rows, [3, 8, 12, 8, 14, 12, 7, 5, 8, 12]),
    "sanctions": ("تقرير فحص القوائم المحلية والدولية", client_sanctions_report_rows, [12, 7, 9, 12, 8, 14, 12, 5, 10]),
}


def _serve_client_report(handler: AppHandler, cid: int, kind: str) -> None:
    title_base, fn, weights = _CLIENT_REPORT_KINDS[kind]
    with db() as con:
        ensure_schema(con)
        c = con.execute("SELECT legal_name, client_code FROM clients WHERE id=?", (cid,)).fetchone()
        if not c:
            handler._send(layout("غير موجود", "<div class='error'>العميل غير موجود</div>", "/clients"), 404)
            return
        headers, rows = fn(con, cid)
        title = f"{title_base} — العميل {c['client_code'] or cid}: {c['legal_name']}"
        audit(con, "generate_client_report", "client", cid, f"{kind}.pdf; rows={len(rows)}", _real_client_ip(handler))
        con.commit()
    data = _batch_pdf_bytes(title, headers, rows, weights)
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M")
    fname = f"client_{cid}_{kind}_{stamp}.pdf"
    handler.send_response(200)
    handler.send_header("Content-Type", "application/pdf")
    handler.send_header("Content-Disposition", f'attachment; filename="{fname}"')
    handler.send_header("Content-Length", str(len(data)))
    handler.end_headers()
    handler.wfile.write(data)


# --------------------- clients page: search + matters count + pending notes (item 5) ---------------------
def clients_list(q: str = "") -> bytes:  # type: ignore[override]
    q = (q or "").strip()
    with db() as con:
        ensure_schema(con)
        if q:
            q_esc = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            like = f"%{q_esc}%"
            rows = con.execute(
                "SELECT * FROM clients WHERE legal_name LIKE ? ESCAPE '\\' OR COALESCE(client_code,'') LIKE ? ESCAPE '\\' OR COALESCE(registration_number,'') LIKE ? ESCAPE '\\' "
                "OR COALESCE(id_number,'') LIKE ? ESCAPE '\\' OR COALESCE(unified_number,'') LIKE ? ESCAPE '\\' ORDER BY id DESC LIMIT 300",
                (like, like, like, like, like)).fetchall()
        else:
            rows = con.execute("SELECT * FROM clients ORDER BY id DESC LIMIT 300").fetchall()
        lead_counts = {r["client_id"]: r["n"] for r in con.execute("SELECT client_id, COUNT(*) n FROM matters GROUP BY client_id").fetchall()}
        joint_counts: Dict[int, int] = {}
        try:
            for r in con.execute("SELECT mc.client_id AS cid, COUNT(*) n FROM matter_clients mc JOIN matters m ON m.id=mc.matter_id WHERE mc.role='joint' GROUP BY mc.client_id").fetchall():
                joint_counts[int(r["cid"])] = int(r["n"])
        except sqlite3.OperationalError:
            pass
        docs_open = {r["client_id"]: r["n"] for r in con.execute("SELECT client_id, COUNT(*) n FROM outstanding_documents WHERE status IN ('deferred','overdue') GROUP BY client_id").fetchall()}
        mnotes: Dict[int, List[str]] = {}
        for r in con.execute("SELECT client_id, matter_number, COALESCE(description,'') AS d FROM matters WHERE COALESCE(description,'')<>''").fetchall():
            mnotes.setdefault(int(r["client_id"]), []).append(f"{r['matter_number']}: {r['d']}")
    trs = []
    for r in rows:
        cid = int(r["id"])
        mcount = int(lead_counts.get(cid, 0)) + int(joint_counts.get(cid, 0))
        matters_cell = f"<a class='btn secondary' style='padding:5px 10px;margin:0' href='/client?id={cid}'>{mcount} مشروع</a>" if mcount else "<span class='small'>0</span>"
        notes_bits = []
        nd = int(docs_open.get(cid, 0))
        if nd:
            notes_bits.append(f"<span class='badge warn'>مستندات معلقة: {nd}</span>")
        cn = (r["notes"] or "").strip()
        if cn:
            notes_bits.append(auto_dir(cn[:90] + ("…" if len(cn) > 90 else "")))
        for mn in mnotes.get(cid, [])[:2]:
            notes_bits.append("<span class='small'>" + auto_dir(mn[:80] + ("…" if len(mn) > 80 else "")) + "</span>")
        notes_cell = "<br>".join(notes_bits) or "<span class='small'>-</span>"
        keys = set(r.keys())
        uni = (r["unified_number"] if "unified_number" in keys else "") or ""
        trs.append(
            f"<tr><td>{h(r['client_code'] or cid)}</td>"
            f"<td><a href='/client?id={cid}'>{auto_dir(r['legal_name'])}</a></td>"
            f"<td>{h(client_type_label(r['client_type']))}</td>"
            f"<td dir='ltr'>{h(r['registration_number'] or r['id_number'] or '')}</td>"
            f"<td dir='ltr'>{h(uni)}</td>"
            f"<td>{matters_cell}</td>"
            f"<td>{notes_cell}</td>"
            f"<td>{'نعم' if r['listed_saudi_market'] else 'لا'}</td>"
            f"<td>{badge_status(r['status'])}</td></tr>")
    found = f"<p class='small'>نتائج البحث عن: {h(q)} — {len(rows)} عميل</p>" if q else ""
    body = f"""
<div class="card"><h2>العملاء</h2>
<form method="get" action="/clients" class="filterbar" style="display:flex;gap:8px;flex-wrap:wrap;align-items:end">
<div style="flex:1;min-width:240px"><label>بحث بالاسم / الرقم / السجل / الرقم الموحد</label><input name="q" value="{h(q)}" placeholder="اكتب اسم العميل أو أي رقم مميز"></div>
<button>بحث</button> {'<a class="btn secondary" href="/clients">إلغاء البحث</a>' if q else ''}
<a class="btn" href="/clients/new">إضافة عميل جديد</a></form>{found}</div>
<div class="card"><div class="table-wrap"><table><thead><tr><th>رقم العميل</th><th>اسم العميل</th><th>النوع</th><th>هوية/سجل</th><th>الرقم الموحد</th><th>المشاريع</th><th>ملاحظات معلقة / مطلوب استكمالها</th><th>مدرجة؟</th><th>الحالة</th></tr></thead><tbody>{''.join(trs) or '<tr><td colspan="9">لا توجد بيانات مطابقة</td></tr>'}</tbody></table></div></div>
"""
    return layout("العملاء", body, "/clients")


# --------------------- dashboard boxes (item 7) ---------------------
_dashboard_pre_v108 = dashboard
def dashboard() -> bytes:  # type: ignore[override]
    raw = _dashboard_pre_v108().decode("utf-8")
    try:
        with db() as con:
            ensure_schema(con)
            open_states = ("potential_match", "high_similarity", "confirmed_match", "frozen", "under_review")
            ph = ",".join("?" for _ in open_states)
            red = con.execute(f"SELECT COUNT(*) FROM screenings WHERE screening_scope='sanctions' AND status IN ({ph})", open_states).fetchone()[0]
            yellow = con.execute(f"SELECT COUNT(*) FROM screenings WHERE screening_scope='internal' AND status IN ({ph})", open_states).fetchone()[0]
            green = con.execute("SELECT COUNT(*) FROM screenings WHERE status IN ('no_match','false_positive','closed','known_relationship','exempted_listed_company','exempted_government')").fetchone()[0]
        pulse_css = ("<style>@keyframes ltpulse{0%{box-shadow:0 0 0 0 rgba(127,29,29,.55)}70%{box-shadow:0 0 0 16px rgba(127,29,29,0)}"
                     "100%{box-shadow:0 0 0 0 rgba(127,29,29,0)}}.lt-pulse{animation:ltpulse 1.5s infinite}"
                     "a.lt-kpi{text-decoration:none;display:block}a.lt-kpi .card{cursor:pointer}a.lt-kpi:hover .card{filter:brightness(1.05)}</style>")
        red_pulse = " lt-pulse" if red else ""
        cards = (pulse_css +
                 "<div class=\"grid\">"
                 f"<a class=\"lt-kpi\" href=\"/screenings?filter=open&scope=sanctions\"><div class=\"card kpi status-red{red_pulse}\"><div>تطابقات القوائم المحلية والدولية — قيد المعالجة</div><div class=\"num\">{red}</div><span class=\"small\">اضغط للانتقال إلى السجل واتخاذ الإجراء</span></div></a>"
                 f"<a class=\"lt-kpi\" href=\"/screenings?filter=open&scope=internal\"><div class=\"card kpi status-yellow\"><div>التعارض الداخلي — قيد المعالجة</div><div class=\"num\">{yellow}</div><span class=\"small\">اضغط لمراجعة حالات التعارض</span></div></a>"
                 f"<a class=\"lt-kpi\" href=\"/screenings?filter=all\"><div class=\"card kpi status-green\"><div>نتائج سليمة / محسومة (Passed)</div><div class=\"num\">{green}</div><span class=\"small\">اضغط لعرض السجل الكامل</span></div></a>"
                 "</div>")
        anchor = '<div class="card">\n<h2>خريطة العمل المختصرة</h2>'
        raw = raw.replace(anchor, cards + anchor, 1) if anchor in raw else raw.replace("</main>", cards + "</main>", 1)
    except Exception:
        pass
    return raw.encode("utf-8")


# --------------------- client page: unified display + report buttons ---------------------
_client_detail_pre_v108 = client_detail
def client_detail(client_id: int) -> bytes:  # type: ignore[override]
    raw = _client_detail_pre_v108(client_id).decode("utf-8")
    try:
        with db() as con:
            ensure_schema(con)
            c = con.execute("SELECT unified_number FROM clients WHERE id=?", (client_id,)).fetchone()
        uni = (c["unified_number"] if c else "") or ""
        anchor = "<tr><th>هوية/سجل</th>"
        pos = raw.find(anchor)
        if pos != -1:
            end = raw.find("</tr>", pos)
            if end != -1:
                uni_row = f"<tr><th>الرقم الموحد للمنشأة (700)</th><td dir='ltr'>{h(uni or 'غير مضاف')}</td><th></th><td></td></tr>"
                raw = raw[:end + 5] + uni_row + raw[end + 5:]
        card = (f"<div class=\"card\"><h3>تقارير العميل (PDF)</h3>"
                f"<p class=\"small\">تقريران تفصيليان على مستوى هذا العميل وأطرافه المرتبطة؛ كل توليد يُقيَّد في سجل التدقيق.</p>"
                f"<a class=\"btn\" href=\"/client/report?id={client_id}&kind=internal\">تقرير التعارض الداخلي التفصيلي — PDF</a> "
                f"<a class=\"btn secondary\" href=\"/client/report?id={client_id}&kind=sanctions\">تقرير فحص القوائم المحلية والدولية — PDF</a></div>")
        raw = raw.replace("</main>", card + "</main>", 1) if "</main>" in raw else raw + card
    except Exception:
        pass
    return raw.encode("utf-8")


# --------------------- register: full background re-scan button ---------------------
_screenings_page_pre_v108 = screenings_page
def screenings_page(message: str = "", flt: str = "open", page: int = 1, scope: str = "") -> bytes:  # type: ignore[override]
    raw = _screenings_page_pre_v108(message, flt, page, scope).decode("utf-8")
    btn = ("<div class='card'><form method='post' action='/screening/full_rescan' "
           "onsubmit=\"return confirm('تشغيل إعادة الفحص الشامل في الخلفية؟ يعاد فحص كل السجل على القواعد الحالية دون تعليق التطبيق.')\">"
           "<button class='btn warn'>إعادة الفحص الشامل بالخلفية (كل السجل)</button> "
           "<span class='small'>للامتثال والإدارة — يعمل بالخلفية ويحدّث النتائج وفق قواعد الإصدار الحالي.</span></form></div>")
    raw = raw.replace("</main>", btn + "</main>", 1) if "</main>" in raw else raw + btn
    return raw.encode("utf-8")


# --------------------- routes: background screening + client reports + clients search ---------------------
_BG_POST_ROUTES = {"/client/run_internal_screening", "/client/run_sanctions_screening", "/matter/run_screening", "/screening/full_rescan"}
_post_pre_v108 = AppHandler.do_POST
def _do_post_v108(self: AppHandler) -> None:
    path = urlparse(self.path).path
    if path not in _BG_POST_ROUTES:
        return _post_pre_v108(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    try:
        fields, files, ip = _parse_request_fields(self)
        uname = str(user.get("user_name") or "")
        if path == "/screening/full_rescan":
            if user.get("role") not in {"admin", "compliance"}:
                return self._send(layout("غير مصرح", "<div class='error'>هذه العملية لمسؤول الامتثال أو مدير النظام.</div>", "/screenings"), 403)
            enqueue_job("إعادة الفحص الشامل لكل السجل", lambda: run_daily_screening(), uname, ip)
            return send_redirect(self, "/screenings")
        if path == "/matter/run_screening":
            mid = int(form_value(fields, "matter_id", "0") or 0)
            enqueue_job(f"فحص المشروع رقم {mid} (داخلي + قوائم)", lambda m=mid, i=ip: run_matter_screening(m, i, "both"), uname, ip)
            return send_redirect(self, f"/matter?id={mid}")
        cid = int(form_value(fields, "client_id", "0") or 0)
        mode = "internal" if path.endswith("run_internal_screening") else "sanctions"
        label = f"الفحص {'الداخلي' if mode == 'internal' else 'مع القوائم'} للعميل رقم {cid}"
        enqueue_job(label, lambda c=cid, i=ip, md=mode: run_client_screening(c, i, md), uname, ip)
        return send_redirect(self, f"/client?id={cid}")
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر بدء المهمة الخلفية: {h(exc)}</div>"), 500)
AppHandler.do_POST = _do_post_v108


_get_pre_v108 = AppHandler.do_GET
def _do_get_v108(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    if parsed.path not in ("/client/report", "/clients"):
        return _get_pre_v108(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    q = parse_qs(parsed.query)
    try:
        if parsed.path == "/clients":
            return self._send(clients_list((q.get("q", [""])[0] or "")))
        try:
            cid = int((q.get("id", ["0"])[0] or 0))
        except (TypeError, ValueError):
            cid = 0
        kind = (q.get("kind", ["internal"])[0] or "internal")
        if kind not in _CLIENT_REPORT_KINDS:
            kind = "internal"
        return _serve_client_report(self, cid, kind)
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر تنفيذ الطلب: {h(exc)}</div>", "/clients"), 500)
AppHandler.do_GET = _do_get_v108
# ===== End V10.8.0 =====


# ---- V10.8.0-fix layer (adversarial-review must-fix items) ----
_SAUDI_TOKENS = {"السعودية", "المملكة العربية السعودية", "سعودي", "سعودية", "saudi", "saudi arabia", "ksa", "kingdom of saudi arabia"}


def _is_domestic_gov_subject(sub: Dict[str, Any]) -> bool:
    """الاستثناء الحكومي للجهات السعودية الموثقة فقط: يشترط أن تكون الدولة أو الجنسية
    سعودية صراحةً — الحقل الفارغ لا يكفي (تشدد مقصود؛ جهة أجنبية قد تكون مدرجة محلياً)."""
    vals = [str(sub.get("country") or "").strip().lower(), str(sub.get("nationality") or "").strip().lower()]
    return any(v and any(t in v for t in _SAUDI_TOKENS) for v in vals)


def _client_type_allowed(con: sqlite3.Connection, code: str) -> bool:
    if code in ("company", "individual", "government", "charity", "other", ""):
        return True
    try:
        return con.execute("SELECT 1 FROM ref_client_types WHERE code=?", (code,)).fetchone() is not None
    except sqlite3.OperationalError:
        return True


_create_client_pre_v108fix = create_client
def create_client(fields: Dict[str, List[str]], files: Optional[Dict[str, Tuple[str, bytes]]] = None, ip: str = "") -> int:  # type: ignore[override]
    ct = form_value(fields, "client_type")
    if ct:
        with db() as con:
            ensure_schema(con)
            if not _client_type_allowed(con, ct):
                raise ValueError("نوع العميل غير معتمد؛ استخدم الأنواع المعرفة في الإعدادات")
    return _create_client_pre_v108fix(fields, files, ip)


_update_client_pre_v108fix = update_client
def update_client(fields: Dict[str, List[str]], ip: str = "") -> int:  # type: ignore[override]
    ct = form_value(fields, "client_type")
    if ct:
        with db() as con:
            ensure_schema(con)
            if not _client_type_allowed(con, ct):
                raise ValueError("نوع العميل غير معتمد؛ استخدم الأنواع المعرفة في الإعدادات")
    return _update_client_pre_v108fix(fields, ip)


_create_counterparty_pre_v108 = create_counterparty
def create_counterparty(fields: Dict[str, List[str]], ip: str = "") -> int:  # type: ignore[override]
    pt = form_value(fields, "party_type")
    if pt and pt not in _CP_TYPES:
        raise ValueError("نوع الطرف المقابل غير معتمد")
    return _create_counterparty_pre_v108(fields, ip)


_update_counterparty_pre_v108 = update_counterparty
def update_counterparty(fields: Dict[str, List[str]], ip: str = "") -> int:  # type: ignore[override]
    pt = form_value(fields, "party_type")
    if pt and pt not in _CP_TYPES:
        raise ValueError("نوع الطرف المقابل غير معتمد")
    return _update_counterparty_pre_v108(fields, ip)


# --- MF3a: غسل الحالة — الفحص لا يعيد "نشط" لعميل لديه نتائج مؤكدة/مرتفعة غير محسومة ---
_OPEN_HARD_STATES = ("confirmed_match", "high_similarity", "frozen", "reported")
_run_client_screening_pre_v108 = run_client_screening
def run_client_screening(client_id: int, ip: str = "", screening_mode: str = "both") -> Dict[str, int]:  # type: ignore[override]
    result = _run_client_screening_pre_v108(client_id, ip, screening_mode)
    try:
        with db() as con:
            ensure_schema(con)
            ph = ",".join("?" for _ in _OPEN_HARD_STATES)
            open_hard = con.execute(
                f"SELECT COUNT(*) FROM screenings WHERE status IN ({ph}) AND ((subject_type='client' AND subject_id=?) "
                "OR (subject_type='client_related_party' AND subject_id IN (SELECT id FROM related_parties WHERE parent_type='client' AND parent_id=?)))",
                (*_OPEN_HARD_STATES, int(client_id), int(client_id))).fetchone()[0]
            if open_hard:
                con.execute("UPDATE clients SET status='under_review', updated_at=? WHERE id=? AND status NOT IN ('blocked','frozen')",
                            (now_iso(), int(client_id)))
                con.commit()
    except Exception:
        pass
    return result


# --- MF5: مهام غير منتهية عند إغلاق العملية تُقيَّد كمهام متروكة ---
import atexit as _bgatexit


def _audit_abandoned_jobs() -> None:
    try:
        pending = [j for j in _JOBS.values() if j.get("status") in ("queued", "running")]
        if not pending:
            return
        with db() as con:
            ensure_schema(con)
            for j in pending:
                audit(con, "background_job_abandoned", "job", 0, f"{j['id']}: {j.get('label')} — أُغلق النظام قبل الاكتمال", j.get("actor_ip") or "")
            con.commit()
    except Exception:
        pass


_bgatexit.register(_audit_abandoned_jobs)
# ===== End V10.8.0-fix =====


# ---- V10.8.0 Brand Skin: هوية Legal Tracks الرسمية (من tokens.css في مشروع التصميم) ----
# الأخضر المعتمد 244037# بدرجاته، الذهبي الشمبانيا E3CCAD#، الورقي الدافئ، وألوان الوظائف
# (نجاح 2E8C73# / تحذير FDB614# / خطر F15722#) وفق دليل الهوية — تُحقن كطبقة CSS أخيرة
# فوق التنسيق القائم دون أي تغيير في بنية الصفحات (آمنة وقابلة للرجوع).
_LT_BRAND_CSS = """
<style id="lt-brand-skin">
/* V10.8: خطوط الهوية مضمنة داخل التطبيق وتُقدم من /brand/fonts — تظهر للجميع دون تثبيت */
@font-face{font-family:"Tajawal";src:url("/brand/fonts/Tajawal-Regular.ttf") format("truetype");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:"Tajawal";src:url("/brand/fonts/Tajawal-Medium.ttf") format("truetype");font-weight:500;font-style:normal;font-display:swap}
@font-face{font-family:"Tajawal";src:url("/brand/fonts/Tajawal-Bold.ttf") format("truetype");font-weight:700;font-style:normal;font-display:swap}
@font-face{font-family:"Tajawal";src:url("/brand/fonts/Tajawal-ExtraBold.ttf") format("truetype");font-weight:800 900;font-style:normal;font-display:swap}
@font-face{font-family:"Hacen Liner";src:url("/brand/fonts/HacenLinerXL.ttf") format("truetype");font-weight:400 900;font-style:normal;font-display:swap}
:root{
 --ltb-g900:#14251F;--ltb-g800:#1A3129;--ltb-g700:#244037;--ltb-g600:#335248;--ltb-g500:#4A6A5E;
 --ltb-g100:#D8E0DC;--ltb-g050:#EEF2F0;
 --ltb-gold700:#B49670;--ltb-gold500:#E3CCAD;--ltb-gold100:#F5EADB;--ltb-gold050:#FBF5EB;
 --ltb-paper:#FAF7F1;--ltb-ink:#1A1A1A;--ltb-ink500:#6B6B6B;
 --ltb-teal:#2E8C73;--ltb-yellow:#FDB614;--ltb-red:#F15722;--ltb-blue:#265871;
}
body{background:var(--ltb-paper)!important;color:var(--ltb-ink)!important;
 font-family:"Tajawal","Loew Next Arabic","Hacen Liner","Segoe UI",Tahoma,Arial,sans-serif!important}
header{background:linear-gradient(105deg,var(--ltb-g900),var(--ltb-g700))!important;
 border-bottom:3px solid var(--ltb-gold500)!important;color:#fff!important}
header h1{color:#fff!important;letter-spacing:.3px}
header small{color:var(--ltb-gold500)!important}
nav a{color:var(--ltb-g700)!important;border:1.5px solid var(--ltb-g700)!important;background:#fff!important;border-radius:8px!important;font-weight:800!important}
nav a.active,nav a:hover,nav a:focus{background:var(--ltb-g700)!important;color:#fff!important;outline:3px solid var(--ltb-gold500)!important}
.main-nav{background:var(--ltb-paper)!important;box-shadow:0 1px 2px rgba(20,37,31,.08)!important}
.dropdown-content{border:1.5px solid var(--ltb-g100)!important;border-radius:8px!important;box-shadow:0 6px 20px rgba(20,37,31,.10)!important}
.card{background:#fff!important;border:1.5px solid var(--ltb-g100)!important;border-radius:8px!important;box-shadow:0 1px 2px rgba(20,37,31,.08)!important}
.kpi{border-right:3px solid var(--ltb-gold500)!important}
.kpi .num{color:var(--ltb-g700)!important}
h1,h2,h3{font-family:"Hacen Liner","Tajawal","Segoe UI",Tahoma,Arial,sans-serif!important}
h2,h3{color:var(--ltb-g700)!important}
th{background:var(--ltb-g700)!important;color:#fff!important;border:1px solid var(--ltb-g600)!important;font-weight:800!important}
td{border:1px solid var(--ltb-g100)!important}
table{border-collapse:collapse!important}
tbody tr:nth-child(even) td{background:var(--ltb-g050)}
button,.btn{background:var(--ltb-g700)!important;color:#fff!important;border-radius:6px!important;box-shadow:0 1px 2px rgba(20,37,31,.14)!important;font-weight:800!important}
button:hover,.btn:hover{background:var(--ltb-g600)!important;filter:none!important}
.btn.secondary{background:#fff!important;color:var(--ltb-g700)!important;border:1.5px solid var(--ltb-g700)!important}
.btn.secondary:hover{background:var(--ltb-g050)!important}
.btn.warn{background:var(--ltb-gold700)!important;color:#fff!important}
.btn.danger{background:var(--ltb-red)!important;color:#fff!important}
.btn.ok{background:var(--ltb-teal)!important;color:#fff!important}
input,select,textarea{border:1.5px solid var(--ltb-g100)!important;border-radius:6px!important;background:#fff!important;color:var(--ltb-ink)!important}
input:focus,select:focus,textarea:focus{outline:3px solid var(--ltb-gold500)!important;border-color:var(--ltb-g700)!important}
label{color:var(--ltb-g800)!important}
.badge{border-radius:999px!important;border:1.5px solid currentColor!important;font-weight:800!important}
.badge.ok{background:var(--ltb-g050)!important;color:var(--ltb-g700)!important}
.badge.warn{background:#FEF3D6!important;color:#8A6200!important}
.badge.danger{background:#FDE6DC!important;color:#B23A12!important}
.notice{background:var(--ltb-gold050)!important;border-right:5px solid var(--ltb-gold700)!important;color:var(--ltb-ink)!important;border-radius:6px!important}
.success{background:#E7F3EF!important;border-right:5px solid var(--ltb-teal)!important;border-radius:6px!important}
.error{background:#FDE6DC!important;border-right:5px solid var(--ltb-red)!important;border-radius:6px!important}
.status-red{border-right:6px solid var(--ltb-red)!important;background:#FDF1EB!important}
.status-yellow{border-right:6px solid var(--ltb-yellow)!important;background:#FEF9EC!important}
.status-green{border-right:6px solid var(--ltb-teal)!important;background:var(--ltb-g050)!important}
.workflow .step{border:2px solid var(--ltb-g700)!important;border-radius:8px!important;background:#fff!important;color:var(--ltb-g800)!important}
.workflow .arrow{color:var(--ltb-gold700)!important}
.small{color:var(--ltb-ink500)!important}
hr{border-top:1.5px solid var(--ltb-g100)!important}
.env-banner{border-bottom:2px solid var(--ltb-gold700)!important}
.env-banner.env-uat{background:var(--ltb-gold100)!important;color:var(--ltb-g900)!important}
.filterbar .btn{margin-top:4px!important}
a{color:var(--ltb-blue)}
@keyframes ltpulse{0%{box-shadow:0 0 0 0 rgba(241,87,34,.45)}70%{box-shadow:0 0 0 16px rgba(241,87,34,0)}100%{box-shadow:0 0 0 0 rgba(241,87,34,0)}}
</style>
"""

_layout_pre_brand = layout
def layout(title: str, body: str, active: str = "") -> bytes:  # type: ignore[override]
    raw = _layout_pre_brand(title, body, active).decode("utf-8")
    if 'id="lt-brand-skin"' not in raw and "</head>" in raw:
        raw = raw.replace("</head>", _LT_BRAND_CSS + "</head>", 1)
    return raw.encode("utf-8")


# صفحة الدخول تستخدم نسخة مجمدة من القالب القديم — تُمنح القشرة نفسها (CSS فقط، لا شريط مهام).
_login_page_pre_brand = login_page
def login_page(message: str = "") -> bytes:  # type: ignore[override]
    raw = _login_page_pre_brand(message).decode("utf-8")
    if 'id="lt-brand-skin"' not in raw and "</head>" in raw:
        raw = raw.replace("</head>", _LT_BRAND_CSS + "</head>", 1)
    return raw.encode("utf-8")


# ---- V10.8: تقديم خطوط الهوية المضمنة (مسار عام آمن بقائمة أسماء مغلقة) ----
_BRAND_FONT_FILES = {"Tajawal-Regular.ttf", "Tajawal-Medium.ttf", "Tajawal-Bold.ttf", "Tajawal-ExtraBold.ttf", "HacenLinerXL.ttf"}
_BRAND_FONT_CACHE: Dict[str, bytes] = {}
_get_pre_fonts = AppHandler.do_GET
def _do_get_fonts(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    if not parsed.path.startswith("/brand/fonts/"):
        return _get_pre_fonts(self)
    name = parsed.path.rsplit("/", 1)[-1]
    if name not in _BRAND_FONT_FILES:
        self.send_response(404); self.end_headers(); return
    data = _BRAND_FONT_CACHE.get(name)
    if data is None:
        p = BASE_DIR / "assets" / "fonts" / name
        if not p.exists():
            self.send_response(404); self.end_headers(); return
        data = p.read_bytes()
        _BRAND_FONT_CACHE[name] = data
    self.send_response(200)
    self.send_header("Content-Type", "font/ttf")
    self.send_header("Cache-Control", "public, max-age=604800")
    self.send_header("Content-Length", str(len(data)))
    self.end_headers()
    self.wfile.write(data)
AppHandler.do_GET = _do_get_fonts


APP_VERSION = "V10.9.0 - Inspection Auto-Assessment + Najiz Readiness"

# =====================================================================
# V10.9 Stage 1 — Governance facts + live metrics + auto-assessment engine
# للبنود الـ72 في استمارة التفتيش: تقييم آلي مباشر من بيانات النظام حيثما أمكن،
# وما يحتاج مدخلات تنظيمية (اعتماد/تدريب/مراجع مستقل) يُدخل مرة واحدة في
# «مدخلات الحوكمة» فتنقلب بنوده إلى تقييم آلي أيضاً. التقييم الآلي لا يكتب فوق
# أي تقييم يدوي — يُطبق فقط على البنود التي لم تُقيَّم (pending).
# =====================================================================

_ensure_schema_pre_v109 = ensure_schema

def ensure_schema(con: sqlite3.Connection, force: bool = False) -> None:  # type: ignore[override]
    _ensure_schema_pre_v109(con, force)
    con.execute("""CREATE TABLE IF NOT EXISTS governance_facts(
        fact_key TEXT PRIMARY KEY,
        fact_value TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL DEFAULT ''
    )""")
    # V10.9: مصدر تقييم بند التفتيش — 'auto' يُعاد حسابه حياً؛ 'manual' لا يُمس
    cols = {r[1] for r in con.execute("PRAGMA table_info(inspection_checklist)").fetchall()}
    if cols and "provenance" not in cols:  # الجدول موجود (تُنشئه طبقة سابقة) بلا العمود
        try:
            con.execute("ALTER TABLE inspection_checklist ADD COLUMN provenance TEXT NOT NULL DEFAULT 'manual'")
        except sqlite3.OperationalError:
            pass


# (key, label, hint) — كل ما يحتاجه التقييم الآلي ولوحة ناجز من مدخلات تنظيمية
_GOV_FACTS: List[Tuple[str, str, str]] = [
    ("policies_approved_date", "تاريخ جلسة اعتماد الوثائق المنقحة", "مثال: 2026-08-03"),
    ("board_last_meeting_date", "تاريخ آخر اجتماع حوكمة/مجلس", "مثال: 2026-07-01"),
    ("co_appointment_decision_ref", "قرار تعيين مسؤول الامتثال الموقع (التاريخ ورقم القرار)", "مثال: 2026-07-21 / قرار 4"),
    ("co_notification_sent", "إخطار الإدارة العامة بتعيين مسؤول الامتثال (التاريخ ورقم الصادر)", "مثال: 2026-08-04 / صادر 123"),
    ("co_report_last_date", "تاريخ آخر تقرير دوري لمسؤول الامتثال", "مثال: 2026-08-05"),
    ("independent_reviewer", "المراجع المستقل المكلف (الاسم ورقم قرار التكليف)", "يُترك فارغاً إن لم يُكلف بعد"),
    ("independent_review_date", "تاريخ/موعد أول مراجعة مستقلة", "مثال: 2026-09-15"),
    ("training_last_date", "تاريخ آخر تدريب منفذ", "مثال: 2026-08-02"),
    ("training_covers_tf_pf", "هل شمل التدريب تمويل الإرهاب وانتشار التسلح؟ (نعم/لا)", "نعم أو لا"),
    ("training_ack_count", "عدد إقرارات حضور التدريب الموقعة", "رقم"),
    ("circular_ack_count", "عدد إقرارات الاطلاع على التعميم الداخلي الموقعة", "رقم"),
    ("staff_total", "إجمالي منسوبي الشركة المعنيين", "رقم"),
    ("bra_approved_date", "تاريخ اعتماد تقييم مخاطر المنشأة", "مثال: 2026-08-03"),
    ("najiz_lawyers_count", "ناجز: عدد المحامين المرخصين", "مثال: 17"),
    ("najiz_consultants_count", "ناجز: عدد المستشارين", "رقم"),
    ("najiz_admins_count", "ناجز: عدد الإداريين", "مثال: 9"),
    ("najiz_trainees_count", "ناجز: عدد المتدربين السعوديين", "مثال: 10"),
    ("najiz_income_range", "ناجز: نطاق إجمالي الدخل", "كما في قائمة ناجز"),
    ("najiz_assets_range", "ناجز: نطاق إجمالي الأصول", "كما في قائمة ناجز"),
    ("najiz_ops50k_count", "ناجز: عدد العمليات ≥ 50,000 ريال", "رقم"),
    ("najiz_ops50k_total", "ناجز: إجمالي قيمة العمليات ≥ 50,000 ريال", "ريال"),
    ("najiz_cash_fees_count", "ناجز: عدد عمليات الأتعاب النقدية", "رقم"),
    ("najiz_cash_fees_total", "ناجز: إجمالي الأتعاب النقدية", "ريال"),
    ("matters_funds_mgmt", "عدد مسائل إدارة أموال العملاء", "من واقع الملفات (الحراسة القضائية: 1)"),
    ("matters_realestate", "عدد مسائل العقارات ضمن النطاق", "من واقع الملفات"),
    ("matters_entity_formation", "عدد مسائل تأسيس/إدارة الكيانات", "من واقع الملفات"),
    ("matters_company_sale", "عدد مسائل بيع/شراء الشركات", "من واقع الملفات"),
]
_GOV_FACT_KEYS = {k for k, _, _ in _GOV_FACTS}
_GOV_FACT_LABELS = {k: l for k, l, _ in _GOV_FACTS}
# V10.9 صدق: تصنيف المدخلات لتحقق نوعي — «موجود» يجب أن يعني «إثبات صالح».
# تواريخ أحداث ماضية: يجب أن تكون صالحة وغير مستقبلية (إثبات وقوع)
_GOV_DATE_KEYS = {"policies_approved_date", "board_last_meeting_date", "co_report_last_date",
                  "training_last_date", "bra_approved_date"}
# تواريخ تخطيطية: صالحة بأي اتجاه (خطة مستقبلية مقبولة)
_GOV_PLAN_DATE_KEYS = {"independent_review_date"}
_GOV_COUNT_KEYS = {"training_ack_count", "circular_ack_count", "staff_total",
                   "najiz_lawyers_count", "najiz_consultants_count", "najiz_admins_count",
                   "najiz_trainees_count", "najiz_ops50k_count", "najiz_cash_fees_count",
                   "matters_funds_mgmt", "matters_realestate", "matters_entity_formation",
                   "matters_company_sale"}
# مدخلات فعل مُهيكل: يجب أن تتضمن تاريخاً صالحاً + رقماً (صادر/قرار) لتُعد إثباتاً
_GOV_ACTION_KEYS = {"co_appointment_decision_ref", "co_notification_sent"}


def _gov_facts(con: sqlite3.Connection) -> Dict[str, str]:
    ensure_schema(con)
    return {r["fact_key"]: (r["fact_value"] or "").strip()
            for r in con.execute("SELECT fact_key, fact_value FROM governance_facts").fetchall()}


def _save_gov_facts(fields: Dict[str, List[str]], ip: str = "") -> int:
    user = _auth_current_user() or {}
    saved = 0
    with db() as con:
        ensure_schema(con)
        for key in _GOV_FACT_KEYS:
            if key not in fields:
                continue
            val = form_value(fields, key, "").strip()[:300]
            con.execute(
                "INSERT INTO governance_facts(fact_key, fact_value, updated_at, updated_by) VALUES(?,?,?,?) "
                "ON CONFLICT(fact_key) DO UPDATE SET fact_value=excluded.fact_value, updated_at=excluded.updated_at, updated_by=excluded.updated_by",
                (key, val, now_iso(), str(user.get("user_name") or "")))
            saved += 1
        audit(con, "governance_facts_update", "governance", 0, f"تحديث مدخلات الحوكمة ({saved} حقلاً)", ip)
        con.commit()
    return saved


def _v109_days_since(datestr: str) -> Optional[int]:
    """أيام منذ تاريخ صالح غير مستقبلي يبدأ بـ YYYY-MM-DD؛ None إن تعذر التحليل أو كان مستقبلياً.
    V10.9 صدق: التاريخ المستقبلي (عمر سالب) بيانات غير صالحة، لا سند حداثة."""
    import datetime as _dt
    s = (datestr or "").strip()[:10]
    try:
        d = _dt.date.fromisoformat(s)
    except Exception:
        return None
    age = (_dt.date.today() - d).days
    return age if age >= 0 else None


def _v109_valid_date(s: str) -> bool:
    """تاريخ صالح غير مستقبلي (يبدأ بـ YYYY-MM-DD)."""
    return _v109_days_since(s) is not None


def _v109_pos_int(s: str) -> Optional[int]:
    """عدد صحيح موجب من نص قد يبدأ برقم؛ None إن لم يكن كذلك."""
    import re as _re
    m = _re.match(r"\s*(\d+)", (s or ""))
    if not m:
        return None
    n = int(m.group(1))
    return n if n > 0 else None


def _v109_metrics(con: sqlite3.Connection) -> Dict[str, object]:
    """قراءة واحدة لكل المقاييس الحية التي تستهلكها قواعد التقييم الآلي ولوحة ناجز."""
    M: Dict[str, object] = {}
    one = lambda q, *a: con.execute(q, a).fetchone()[0]
    M["clients_total"] = one("SELECT COUNT(*) FROM clients")
    M["clients_by_type"] = {r[0] or "?": r[1] for r in con.execute("SELECT client_type, COUNT(*) FROM clients GROUP BY client_type")}
    # التصنيف الفعلي = الأعلى بين المخزن وأشد علم مخاطر (نفس منطق _effective_client_risk لكن دفعة واحدة)
    flags_by_client: Dict[int, List[sqlite3.Row]] = {}
    for f in con.execute("SELECT entity_id, flag_code, flag_label, severity FROM risk_flags WHERE entity_type='client'").fetchall():
        flags_by_client.setdefault(int(f["entity_id"]), []).append(f)
    eff_dist: Dict[str, int] = {}
    high_ids: List[int] = []
    for c in con.execute("SELECT id, risk_level FROM clients").fetchall():
        best = _severity_rank((c["risk_level"] or "normal"))
        for f in flags_by_client.get(int(c["id"]), []):
            best = max(best, _severity_rank(f["severity"] or "normal"))
        lvl = _SEVERITY_BY_RANK.get(best, "normal")
        eff_dist[lvl] = eff_dist.get(lvl, 0) + 1
        if lvl in ("high", "critical"):
            high_ids.append(int(c["id"]))
    M["eff_dist"] = eff_dist
    M["high_ids"] = high_ids
    M["high_eff"] = len(high_ids)
    M["hrc_flag_count"] = one("SELECT COUNT(DISTINCT entity_id) FROM risk_flags WHERE entity_type='client' AND flag_code='HIGH_RISK_COUNTRY'")
    if high_ids:
        ph = ",".join("?" * len(high_ids))
        M["high_sof_ok"] = one(f"SELECT COUNT(*) FROM clients WHERE id IN ({ph}) AND (COALESCE(source_of_funds,'')<>'' OR COALESCE(source_of_wealth,'')<>'' OR COALESCE(source_notes,'')<>'')", *high_ids)
    else:
        M["high_sof_ok"] = 0
    # اكتمال ملفات KYC
    M["identity_pct"] = int(100 * one("SELECT COUNT(*) FROM clients WHERE COALESCE(id_number,'')<>'' OR COALESCE(registration_number,'')<>''") / max(1, M["clients_total"]))
    companies = one("SELECT COUNT(*) FROM clients WHERE client_type='company'")
    ubo_ok = one("SELECT COUNT(*) FROM clients c WHERE client_type='company' AND (EXISTS(SELECT 1 FROM ownership_tracing o WHERE o.client_id=c.id) OR EXISTS(SELECT 1 FROM related_parties rp WHERE rp.parent_type='client' AND rp.parent_id=c.id))")
    M["ubo_pct"] = int(100 * ubo_ok / max(1, companies))
    M["matters_total"] = one("SELECT COUNT(*) FROM matters")
    M["purpose_pct"] = int(100 * one("SELECT COUNT(*) FROM matters WHERE COALESCE(service_type,'')<>'' AND COALESCE(title,'')<>''") / max(1, M["matters_total"]))
    M["matter_types"] = {r[0] or "?": r[1] for r in con.execute("SELECT service_type, COUNT(*) FROM matters GROUP BY service_type")}
    # الفحص والقوائم
    M["screen_total"] = one("SELECT COUNT(*) FROM screenings")
    M["screen_sanc"] = one("SELECT COUNT(*) FROM screenings WHERE screening_scope='sanctions'")
    M["screen_int"] = one("SELECT COUNT(*) FROM screenings WHERE screening_scope='internal'")
    M["decided"] = one("SELECT COUNT(*) FROM screenings WHERE status IN ('false_positive','closed','reported')")
    M["lists_active"] = one("SELECT COUNT(DISTINCT list_name) FROM sanctions_entries WHERE active=1")
    li = con.execute("SELECT created_at FROM sanctions_import_logs WHERE status IN ('success','partial_success') ORDER BY id DESC LIMIT 1").fetchone()
    M["last_import"] = (li[0][:19] if li else "")
    M["import_age"] = _v109_days_since(M["last_import"]) if M["last_import"] else None
    # التنبيهات الجوهرية = أحدث حالة لكل زوج (مفحوص/قائمة/تطابق) — التاريخية المكررة لا تُحتسب
    open_set = {"potential_match", "high_similarity", "confirmed_match", "frozen", "under_review"}
    latest: Dict[Tuple, str] = {}
    scope_of: Dict[Tuple, str] = {}
    # ترتيب زمني حقيقي: آخر قرار (reviewed_at/updated_at) أو الإنشاء، ثم id — كي لا يُحجب صفٌّ أُعيد فتحه لاحقاً
    for r in con.execute("SELECT subject_type, subject_id, screening_scope, COALESCE(list_name,''), COALESCE(matched_name,''), status FROM screenings ORDER BY COALESCE(reviewed_at, updated_at, created_at), id").fetchall():
        key = (r[0], r[1], r[2], r[3], r[4])
        latest[key] = r[5]
        scope_of[key] = r[2]
    M["open_sanc_sub"] = sum(1 for k, s in latest.items() if s in open_set and scope_of[k] == "sanctions")
    M["open_int_sub"] = sum(1 for k, s in latest.items() if s in open_set and scope_of[k] == "internal")
    runs = con.execute("SELECT created_at FROM continuous_screening_runs ORDER BY id DESC LIMIT 1").fetchone()
    M["runs_count"] = one("SELECT COUNT(*) FROM continuous_screening_runs")
    M["last_run"] = (runs[0][:19] if runs else "")
    M["run_age"] = _v109_days_since(M["last_run"]) if M["last_run"] else None
    # PEP والاشتباه والتدقيق
    M["pep_assessed"] = one("SELECT COUNT(*) FROM pep_assessments")
    M["pep_yes"] = one("SELECT COUNT(*) FROM pep_assessments WHERE pep_status='yes'")
    M["suspicion_total"] = one("SELECT COUNT(*) FROM suspicion_cases")
    M["reported"] = one("SELECT COUNT(*) FROM screenings WHERE status='reported'")
    M["frozen"] = one("SELECT COUNT(*) FROM screenings WHERE status='frozen'")
    M["audits"] = one("SELECT COUNT(*) FROM audit_events")
    return M


_AR_LVL = {"normal": "عادي", "low": "منخفض", "medium": "متوسط", "high": "مرتفع", "critical": "حرج"}


def _v109_eff_dist_ar(M: Dict[str, object]) -> str:
    d = M.get("eff_dist") or {}
    order = ["critical", "high", "medium", "low", "normal"]
    return "، ".join(f"{_AR_LVL[k]}: {d[k]}" for k in order if k in d) or "—"


def _auto_assess(con: sqlite3.Connection) -> Tuple[Dict[Tuple[int, int], Tuple[str, str]], List[str]]:
    """يرجع: {(مطلب, بند): (الحالة, الدليل)} للبنود القابلة للتقييم الآلي،
    وقائمة المدخلات الناقصة التي تمنع رفع بنود أخرى. الحالات من مفاتيح _INSPECTION_STATUSES."""
    M = _v109_metrics(con)
    F = _gov_facts(con)

    import re as _re

    def has(k: str) -> bool:
        """«موجود» = إثبات صالح لا مجرد حقل غير فارغ (V10.9 حارس الصدق)."""
        v = F.get(k, "").strip()
        if not v:
            return False
        if k in _GOV_DATE_KEYS:
            return _v109_valid_date(v)
        if k in _GOV_PLAN_DATE_KEYS:
            try:
                import datetime as _dt
                _dt.date.fromisoformat(v.strip()[:10])
                return True
            except Exception:
                return False
        if k in _GOV_COUNT_KEYS:
            return _v109_pos_int(v) is not None
        if k in _GOV_ACTION_KEYS:
            # يتطلب تاريخاً صالحاً + رقماً (صادر/قرار)
            has_date = any(_v109_valid_date(tok) for tok in _re.findall(r"\d{4}-\d{2}-\d{2}", v))
            has_ref = bool(_re.search(r"\d", v.replace("-", "")))
            return has_date and has_ref
        return True

    def yes(k: str) -> bool:
        return F.get(k, "").strip() in ("نعم", "yes", "Yes", "y", "1")

    A: Dict[Tuple[int, int], Tuple[str, str]] = {}
    needs: List[str] = []

    def need(key: str, why: str) -> None:
        if not has(key):
            item = f"{_GOV_FACT_LABELS.get(key, key)} — {why}"
            if item not in needs:
                needs.append(item)

    pol = has("policies_approved_date")
    pol_d = F.get("policies_approved_date", "")
    signed_note = "السياسة واللائحة وقرار التعيين والمحضر موقعة (يوليو 2026)"
    pol_ev = (f"جلسة اعتماد الوثائق بتاريخ {pol_d}؛ {signed_note}" if pol
              else f"{signed_note}؛ و14 وثيقة منقحة بانتظار جلسة الاعتماد")
    need("policies_approved_date", "لرفع بنود السياسات من جزئي إلى متوفر")

    # ---- م1 السياسات والإجراءات ----
    A[(1, 1)] = ("available" if pol else "partial", pol_ev)
    A[(1, 2)] = ("available" if pol else "partial", "النصوص متوافقة مع نظام مكافحة غسل الأموال وتعاميم الوزارة الثلاثة (مضمنة نصاً في إجراء العقوبات)")
    d1 = _v109_days_since(pol_d) if pol else None
    A[(1, 3)] = ("available" if (d1 is not None and d1 <= 540) else "partial",
                 "دورية المراجعة سنوية منصوصة في جدول إدارة كل وثيقة" + (f"؛ آخر اعتماد قبل {d1} يوماً" if d1 is not None else "؛ الاعتماد الأول قيد الجدولة"))
    A[(1, 5)] = (("available", f"آخر تقرير دوري لمسؤول الامتثال: {F.get('co_report_last_date')}") if has("co_report_last_date")
                 else ("missing", "لم يصدر تقرير دوري بعد؛ النموذج جاهز ويتضمن مؤشرات النظام"))
    need("co_report_last_date", "لإثبات التقارير المنتظمة للمجلس (م1/5، م2)")
    A[(1, 6)] = (("available", f"تعميم داخلي + {F.get('circular_ack_count')} إقرار اطلاع موقع") if has("circular_ack_count")
                 else ("missing", "التعميم جاهز؛ لا توجد إقرارات اطلاع موقعة بعد"))
    need("circular_ack_count", "لإثبات إبلاغ الموظفين بالسياسات (م1/6)")
    A[(1, 7)] = ("available" if pol else "partial", "آلية الاعتماد: مجلس الإدارة بمحضر موثق + جدول إدارة وثيقة لكل سياسة")

    # ---- م2 الحوكمة ----
    A[(2, 1)] = (("available", f"محضر 1 يوليو 2026 الموقع + آخر اجتماع: {F.get('board_last_meeting_date')}") if has("board_last_meeting_date")
                 else ("partial", "محضر اجتماع 1 يوليو 2026 موقع من الحاضرين السبعة (اعتماد السياسات والتعيين)"))
    need("board_last_meeting_date", "لتوثيق انتظام اجتماعات الحوكمة (م2)")
    A[(2, 2)] = ("available" if has("co_report_last_date") else "partial",
                 "الإشراف موثق بمحضر يوليو وقرار التعيين؛ يكتمل بالتقرير الدوري الأول")
    appt = has("co_appointment_decision_ref")
    A[(2, 3)] = (("available", f"قرار التعيين الموقع ({F.get('co_appointment_decision_ref')}) ينص على رفع مسؤول الامتثال تقاريره لمجلس الإدارة مباشرة") if appt
                 else ("partial", "قرار التعيين ينص على رفع مسؤول الامتثال تقاريره لمجلس الإدارة؛ يُثبَّت مرجع القرار في مدخلات الحوكمة"))
    need("co_appointment_decision_ref", "لإثبات قرار التعيين الموقع (م2/3، م3/3)")
    A[(2, 4)] = A[(1, 5)]
    A[(2, 5)] = ("available" if has("co_report_last_date") else "partial",
                 "نموذج التقرير الدوري يشمل مؤشرات الفحص والتنبيهات وتوزيع المخاطر من النظام")

    # ---- م3 مسؤول الامتثال ----
    A[(3, 1)] = (("available", f"قرار تعيين موقع + إخطار الإدارة العامة: {F.get('co_notification_sent')}") if (appt and has("co_notification_sent"))
                 else ("partial", "قرار التعيين موقع إلكترونياً؛ خطاب إخطار الإدارة العامة جاهز — يُثبَّت الإرسال في مدخلات الحوكمة"))
    need("co_notification_sent", "عنصر التسجيل في م3 لا يكتمل إلا بإرسال الإخطار")
    A[(3, 3)] = (("available", "القرار الموقع يتضمن بنود الصلاحيات والموارد والاستقلالية (ثانياً–سادساً)") if appt
                 else ("partial", "بنود الصلاحيات والموارد والاستقلالية واردة في القرار؛ يُثبَّت مرجع القرار الموقع"))

    # ---- م4 تقييم مخاطر الأعمال ----
    bra = has("bra_approved_date")
    A[(4, 1)] = ("available" if bra else "partial", f"وثيقة تقييم مخاطر المنشأة معبأة بأرقام النظام الحية ({M['clients_total']} عميلاً)" + (f"؛ معتمدة {F.get('bra_approved_date')}" if bra else "؛ بانتظار الاعتماد"))
    need("bra_approved_date", "لرفع م4 إلى متوفر")
    d4 = _v109_days_since(F.get("bra_approved_date", "")) if bra else None
    A[(4, 2)] = ("available" if (d4 is not None and d4 <= 540) else "partial", "التحديث السنوي منصوص؛ الأرقام تُستخرج من النظام عند كل مراجعة")
    A[(4, 3)] = ("available" if bra else "partial", "الوثيقة تغطي العملاء والخدمات والجغرافيا وقنوات التقديم وطرق الدفع والتقنيات")
    A[(4, 4)] = ("available" if bra else "missing", "الاعتماد من رئيس مجلس الإدارة في جلسة الاعتماد")
    A[(4, 5)] = ("available" if (bra and pol) else "partial", "نتائج التقييم مربوطة بضوابط الإجراءات (عناية معززة، قصر التحصيل البنكي، فحص مستمر)")

    # ---- م5 تقييم مخاطر العملاء (قدرة آلية؛ الحالة تتبع وجود عملاء وحداثة الفحص) ----
    n_clients = int(M["clients_total"])
    A[(5, 1)] = (("available", f"تصنيف فعلي محسوب لكل عميل ({n_clients}): {_v109_eff_dist_ar(M)}") if n_clients > 0
                 else ("partial", "محرك التصنيف الآلي مفعّل؛ لا عملاء مسجلون بعد لعرض توزيع فعلي"))
    A[(5, 2)] = ("available", "عوامل موضوعية آلية: دولة عالية المخاطر، PEP، ملكية متعددة الطبقات، مصدر أموال غير موثق، شركة مدرجة")
    run_recent = M["run_age"] is not None and M["run_age"] <= 40
    A[(5, 3)] = (("available" if (n_clients > 0 and run_recent) else "partial"),
                 f"إعادة التقييم عند كل تعديل" + (f"؛ آخر فحص دوري: {M['last_run']}" if M['last_run'] else "؛ لم تُنفَّذ دورة فحص بعد"))
    A[(5, 4)] = ("available", "التصنيف يقود العناية: حقول مصدر الأموال إلزامية لمرتفعي المخاطر ويوثق أي تجاوز")

    # ---- م6 العناية الواجبة ----
    idp = int(M["identity_pct"]); ubop = int(M["ubo_pct"]); pup = int(M["purpose_pct"])
    A[(6, 1)] = ("available" if idp >= 90 else "partial" if idp >= 60 else "missing", f"وثائق هوية/سجل مسجلة لـ{idp}% من العملاء قبل بدء الخدمة")
    A[(6, 2)] = ("available" if ubop >= 70 else "partial" if ubop >= 40 else "missing", f"مستفيد حقيقي/أطراف ملكية موثقة لـ{ubop}% من الشركات (تتبع ملكية متداخل)")
    A[(6, 3)] = ("available" if pup >= 90 else "partial", f"الغرض موثق (نوع الخدمة والعنوان) في {pup}% من المسائل ({M['matters_total']})")
    A[(6, 4)] = ("available", "تدابير حساسة للمخاطر: عناية معززة آلية للتصنيف المرتفع وإعفاءات مقيدة وموثقة للمدرجة والحكومية")

    # ---- م7 العناية المعززة ----
    he = int(M["high_eff"]); sof = int(M["high_sof_ok"])
    if he == 0:
        # لا يوجد عملاء مرتفعو المخاطر ⇒ الضابط غير مُختبَر فعلياً ⇒ «لا ينطبق حالياً»، لا «متوفر»
        ev7 = "لا ينطبق حالياً: لا عملاء بتصنيف فعلي مرتفع؛ الضابط مفعّل في النظام وينطبق تلقائياً عند أول تصنيف مرتفع"
        A[(7, 1)] = ("na", ev7)
        A[(7, 2)] = ("na", ev7)
    else:
        ok = sof >= he
        ev7 = f"عملاء مرتفعون فعلياً: {he}؛ موثق مصدر المال/الثروة أو سبب التجاوز لـ{sof}"
        A[(7, 1)] = ("available" if ok else "partial", ev7)
        A[(7, 2)] = ("available" if ok else "partial", ev7)
    A[(7, 3)] = ("available" if pol else "partial", "نموذج موافقة الإدارة العليا على العلاقات مرتفعة المخاطر ضمن الحزمة (صاحب الصلاحية: رئيس المجلس أو من يفوضه)")
    A[(7, 4)] = (("available", f"تقييمات PEP موثقة: {M['pep_assessed']} (إيجابية: {M['pep_yes']})؛ المؤشر النصي يرفع علم مخاطر آلياً")
                 if int(M["pep_assessed"]) > 0 else ("partial", "آلية تقييم PEP متاحة (المراجعة التنظيمية)؛ لم تُقيَّم حالات بعد"))

    # ---- م8 المراقبة المستمرة ----
    st = int(M["screen_total"]); sc = int(M["screen_sanc"])
    sched_note = (f"؛ فحص دوري مجدول (آخر دورة: {M['last_run']})" if run_recent else "؛ لم تُنفَّذ دورة فحص دوري حديثة")
    A[(8, 1)] = (("available" if (st > 0 and run_recent) else "partial" if st > 0 else "missing"),
                 f"مراقبة مستمرة: {st} فحصاً؛ إعادة فحص عند تحديث القوائم{sched_note}")
    A[(8, 2)] = (("available", f"تصعيد غير العادي: صفحة الاشتباه والتصعيد + تنبيهات الفحص (حالات اشتباه: {M['suspicion_total']})") if st > 0
                 else ("partial", "قناة التصعيد وصفحة الاشتباه مفعّلتان؛ لا فحوصات بعد"))
    A[(8, 3)] = ("available", ("مراقبة معززة تلقائية للتصنيف المرتفع" + (f" ({he} عميل حالياً)" if he else " (لا عملاء مرتفعون حالياً؛ الضابط مفعّل)")))
    A[(8, 4)] = ("available", f"كل مراجعة موثقة في سجل التدقيق ({M['audits']} قيداً) مع الاحتفاظ {RETENTION_YEARS} سنوات")

    # ---- م9 العقوبات المالية المستهدفة ----
    tf_ok = yes("training_covers_tf_pf") and has("training_last_date")
    ev_tf = (f"تدريب منفذ بتاريخ {F.get('training_last_date')} يشمل تمويل الإرهاب وانتشار التسلح" if tf_ok
             else "المخاطر موثقة في اللائحة وتقييم المنشأة؛ التدريب المتخصص بانتظار التنفيذ")
    need("training_last_date", "بنود التدريب في م9 وم10 وم13")
    need("training_covers_tf_pf", "بندا تدريب تمويل الإرهاب والتسلح (م9/11-12)")
    lists_ok = int(M["lists_active"]) > 0
    A[(9, 1)] = ("available" if tf_ok else "partial", ev_tf)
    A[(9, 2)] = ("available" if tf_ok else "partial", ev_tf)
    A[(9, 3)] = (("available", f"قوائم نشطة في الأداة: {M['lists_active']}") if lists_ok
                 else ("missing", "لا قوائم عقوبات محمَّلة في الأداة بعد — يجب استيراد القائمة المحلية والقوائم الأممية"))
    A[(9, 4)] = (("available" if lists_ok else "partial"),
                 "الأداة: مسارات الامتثال" + (f" ({M['lists_active']} قوائم نشطة)" if lists_ok else " (بانتظار تحميل القوائم)") + "؛ اختبار الضمان: حِزم اختبارات موثقة لكل إصدار + مراجعتان تقنيتان عدائيتان")
    A[(9, 5)] = (("na", "تعتمد الشركة أداة فحص آلية عاملة؛ البند (الفحص اليدوي البديل) غير منطبق") if lists_ok
                 else ("partial", "الأداة معتمدة؛ لم تُحمَّل القوائم بعد للتأكد من عمل الفحص الآلي"))
    A[(9, 6)] = (("available", f"فحص تلقائي عند إنشاء العميل وأثناء الخدمة ({sc} فحص قوائم)") if sc > 0
                 else ("missing", "الفحص التلقائي مفعّل؛ لم يُجرَ فحص قوائم فعلي بعد"))
    ia = M["import_age"]
    A[(9, 7)] = ("available" if (ia is not None and ia <= 35) else "partial" if ia is not None else "missing",
                 f"آخر تحديث للقوائم: {M['last_import'] or 'لم يتم'}" + (f" (قبل {ia} يوماً)" if ia is not None else ""))
    oss = int(M["open_sanc_sub"]); osi = int(M["open_int_sub"])
    A[(9, 8)] = (("available" if oss == 0 else "partial") if sc > 0 else "partial",
                 f"تنبيهات قوائم جوهرية مفتوحة (أحدث حالة لكل زوج): {oss}؛ قرارات موثقة: {M['decided']}؛ تعارض داخلي قيد المعالجة: {osi}" if sc > 0
                 else "دورة مراجعة التنبيهات مفعّلة؛ لا فحوصات قوائم بعد")
    A[(9, 9)] = ("available", f"حالتا التجميد والإبلاغ مفعلتان في دورة القرار (تجميد: {M['frozen']}، مُبلغ: {M['reported']})؛ تنفَّذ دون إشعار العميل")
    A[(9, 10)] = ("available", f"علم «دولة عالية المخاطر» يرفع التصنيف آلياً ويوجب العناية المعززة (حالات مرصودة: {M['hrc_flag_count']})")
    A[(9, 11)] = ("available" if tf_ok else "missing", ev_tf)
    A[(9, 12)] = ("available" if tf_ok else "missing", ev_tf)

    # ---- م10 الإبلاغ عن الاشتباه ----
    A[(10, 1)] = (("available", f"عملية مراقبة قائمة وعاملة: {st} فحصاً و{M['audits']} قيد تدقيق") if st > 0
                  else ("partial", f"آلية المراقبة مفعّلة؛ لا فحوصات بعد ({M['audits']} قيد تدقيق)"))
    A[(10, 2)] = ("available" if pol else "partial", "إجراء المراقبة المستمرة ضمن الحزمة" + ("" if pol else " (بانتظار الاعتماد)"))
    A[(10, 3)] = ("available" if lists_ok else "partial", "أداة آلية (مسارات الامتثال) مع مراجعة بشرية لكل تنبيه" + ("" if lists_ok else " — بانتظار تحميل القوائم"))
    A[(10, 4)] = ("available" if pol else "partial", "دليل مؤشرات الاشتباه (علامات التحذير) ضمن الحزمة")
    A[(10, 5)] = ("available", f"تصعيد داخلي موثق: نماذج الإبلاغ الداخلي + صفحة الاشتباه (حالات: {M['suspicion_total']})")
    ev_un = "القوائم الأممية والمحلية نشطة في الأداة والتعاميم مضمنة نصاً في إجراء العقوبات والملحق التفسيري"
    ev_un_pending = "التعاميم مضمنة نصاً في إجراء العقوبات والملحق التفسيري (بانتظار الاعتماد)" + ("" if lists_ok else " وتحميل القوائم")
    un_ok = pol and lists_ok
    A[(10, 6)] = ("available" if un_ok else "partial", ev_un if un_ok else ev_un_pending)
    A[(10, 7)] = ("available" if un_ok else "partial", ev_un if un_ok else ev_un_pending)
    A[(10, 8)] = ("available" if un_ok else "partial", ev_un if un_ok else ev_un_pending)
    A[(10, 9)] = (("available", f"بلاغات مقدمة عبر تقصّي: {M['reported']}؛ لا حالات معلقة استوجبت الإبلاغ دون تقديم") if (int(M["reported"]) > 0 or st > 0)
                  else ("partial", "قناة الإبلاغ عبر تقصّي منصوصة؛ لا نشاط مراقبة أو بلاغات بعد لإثبات التطبيق الفعلي"))
    A[(10, 10)] = (("available", f"سبب القرار إلزامي عند كل إغلاق/إبلاغ ({M['decided']} قراراً موثقاً)") if int(M["decided"]) > 0
                   else ("partial", "حقل سبب القرار إلزامي في دورة القرار؛ لا قرارات موثقة بعد"))
    A[(10, 11)] = ("available" if tf_ok else "missing", ev_tf)

    # ---- م11 حفظ السجلات (قدرة آلية مثبتة في التطبيق) ----
    A[(11, 1)] = ("available", f"الاحتفاظ {RETENTION_YEARS} سنوات مطبق على العملاء والفحوصات والوثائق (ببصمات SHA-256)")
    A[(11, 2)] = ("available", f"إعادة البناء ممكنة: كل فحص يحفظ القائمة والتطابق والدرجة والسبب والقرار" + (f" ({st} سجلاً)" if st > 0 else " (البنية جاهزة)"))
    A[(11, 3)] = ("available", "وصول مقيد بالأدوار وكلمات مرور مشفرة وقفل بعد 5 محاولات وجلسات 8 ساعات وسجل تدقيق كامل")
    A[(11, 4)] = ("available", "استرجاع فوري: تقارير رقابية جاهزة (Excel/PDF) وتصدير سجل تدقيق مختوم SHA-256")

    # ---- م12 المراجعة المستقلة ----
    A[(12, 1)] = (("available", f"المراجع المكلف: {F.get('independent_reviewer')}") if has("independent_reviewer")
                  else ("missing", "برنامج المراجعة جاهز بخطة سنوية؛ لم يُكلف مراجع بعد"))
    need("independent_reviewer", "م12 لا يكتمل إلا بتكليف مراجع مستقل")
    A[(12, 2)] = (("available", f"خطة مراجعة بتواريخ؛ الأولى: {F.get('independent_review_date')}") if has("independent_review_date")
                  else ("missing", "الخطة تتضمن مواعيد مقترحة (سبتمبر/ديسمبر 2026) بانتظار التثبيت"))
    need("independent_review_date", "لتفعيل دورة المراجعة (م12/2)")

    # ---- م13 التدريب ----
    tr = has("training_last_date")
    A[(13, 1)] = (("available", f"آخر تدريب: {F.get('training_last_date')} (إلزامي لجميع المعنيين وفق الخطة)") if tr
                  else ("missing", "خطة التدريب معتمدة الجدولة لأغسطس 2026؛ لم ينفذ تدريب بعد"))
    d13 = _v109_days_since(F.get("training_last_date", "")) if tr else None
    A[(13, 2)] = ("available" if (d13 is not None and d13 <= 365) else "missing",
                  "التحديث السنوي منصوص في الخطة" + (f"؛ آخر تنفيذ قبل {d13} يوماً" if d13 is not None else ""))
    A[(13, 3)] = ("available" if tf_ok else "partial", "تدريب متخصص للعقوبات وتمويل الانتشار ضمن الخطة" + ("" if tf_ok else " (لم ينفذ بعد)"))
    A[(13, 4)] = (("available", f"إقرارات حضور موقعة: {F.get('training_ack_count')}") if has("training_ack_count")
                  else ("missing", "سجل التدريب ونموذج إقرار الحضور جاهزان؛ لا سجلات بعد"))
    need("training_ack_count", "سجلات الحضور (م13/4)")

    return A, needs


# =====================================================================
# V10.9 Stage 2 — inspection page with auto-assessment + apply-auto + facts form,
# Najiz readiness panel (/najiz), and routes.
# =====================================================================

_V109_BADGE = {"available": "ok", "na": "ok", "partial": "warn", "missing": "danger", "pending": "warn"}


def inspection_update(fields: Dict[str, List[str]], ip: str = "") -> None:  # type: ignore[override]
    """V10.9: التقييم اليدوي يوسم provenance='manual' فلا تعيد التعبئة الآلية الكتابة فوقه،
    ويُرفض انتحال بادئة «[آلي]» في دليل يدخله المستخدم."""
    item_id = int(form_value(fields, "item_id", "0") or 0)
    status = form_value(fields, "status", "pending")
    if status not in _INSPECTION_STATUSES:
        status = "pending"
    evidence = (form_value(fields, "evidence") or "").strip()
    while evidence.startswith("[آلي]"):  # لا يُسمح لمستخدم بادعاء أن دليله آلي
        evidence = evidence[len("[آلي]"):].strip()
    user = _auth_current_user() or {}
    with db() as con:
        ensure_schema(con)
        r = con.execute("SELECT * FROM inspection_checklist WHERE id=?", (item_id,)).fetchone()
        if not r:
            raise ValueError("البند غير موجود")
        con.execute("UPDATE inspection_checklist SET status=?, evidence=?, provenance='manual', updated_at=?, updated_by=? WHERE id=?",
                    (status, evidence, now_iso(), str(user.get("user_name") or ""), item_id))
        audit(con, "inspection_item_update", "inspection", item_id, f"المطلب {r['section_no']} بند {r['item_no']}: {status} (يدوي)", ip)
        con.commit()


def _v109_facts_form(con: sqlite3.Connection) -> str:
    F = _gov_facts(con)
    rows = []
    for key, label, hint in _GOV_FACTS:
        val = h(F.get(key, ""))
        rows.append(f"<div><label>{h(label)}</label><input name='{key}' value='{val}' placeholder='{h(hint)}'></div>")
    return f"""
<div class="card" id="facts"><h3>مدخلات الحوكمة (تُدخل مرة واحدة فتتحول بنودها إلى تقييم آلي)</h3>
<p class="small">تُحفظ باسم المستخدم وتاريخ التحديث وتدخل في التقييم الآلي ولوحة ناجز. اتركوا الحقل فارغاً إن لم يتحقق بعد.</p>
<form method="post" action="/governance/facts"><div class="grid">{''.join(rows)}</div>
<button>حفظ مدخلات الحوكمة</button></form></div>"""


def inspection_page(message: str = "") -> bytes:  # type: ignore[override]
    with db() as con:
        ensure_schema(con)
        _seed_inspection_checklist(con)
        con.commit()
        items = con.execute("SELECT * FROM inspection_checklist ORDER BY section_no, item_no").fetchall()
        auto_html = _inspection_auto_evidence(con)
        A, needs = _auto_assess(con)
        facts_form = _v109_facts_form(con)
    msg = f"<div class='success'>{h(message)}</div>" if message else ""

    def _prov(r) -> str:
        try:
            return r["provenance"] or "manual"
        except (IndexError, KeyError):
            return "manual"

    def _eff(r) -> Tuple[str, str, bool]:
        """الحالة الفعلية المعروضة: للبنود الآلية تُحسب حياً (لتتبع تدهور السند)؛ لليدوية تُقرأ كما خُزّنت.
        يرجع (الحالة, الدليل, هل_تدهور)."""
        key = (int(r["section_no"]), int(r["item_no"]))
        if _prov(r) == "auto" and key in A:
            a_st, a_ev = A[key]
            decayed = (r["status"] in ("available", "na")) and a_st not in ("available", "na")
            return a_st, "[آلي] " + a_ev, decayed
        return r["status"], (r["evidence"] or ""), False

    total = len(items)
    eff_map = {r["id"]: _eff(r) for r in items}
    manual_done = sum(1 for r in items if eff_map[r["id"]][0] in ("available", "na"))
    partial = sum(1 for r in items if eff_map[r["id"]][0] == "partial")
    missing = sum(1 for r in items if eff_map[r["id"]][0] == "missing")
    decayed_n = sum(1 for r in items if eff_map[r["id"]][2])
    pending_rows = [r for r in items if r["status"] == "pending" and _prov(r) != "auto"]
    auto_applicable = sum(1 for r in pending_rows if (int(r["section_no"]), int(r["item_no"])) in A)
    manual_only = sum(1 for r in items if _prov(r) != "auto" and (int(r["section_no"]), int(r["item_no"])) not in A)
    needs_html = ""
    if decayed_n:
        needs_html += (f"<div class='card'><h3>⚠ سند متدهور ({decayed_n} بنداً)</h3>"
                       f"<p class='small'>بنود عُبِّئت آلياً سابقاً لم يعد سندها الحي كافياً (تقادم القوائم/التدريب مثلاً)؛ حالتها المعروضة أُعيد حسابها تلقائياً. اضغط «تحديث التقييم الآلي» لإعادة المزامنة والتوثيق.</p></div>")
    if needs:
        lis = "".join(f"<li>{h(n)}</li>" for n in needs)
        needs_html = (f"<div class='card'><h3>⚠ مدخلات ناقصة تمنع رفع بعض البنود ({len(needs)})</h3>"
                      f"<ul class='small'>{lis}</ul><p class='small'><a href='#facts'>⬇ عبّئها في نموذج مدخلات الحوكمة أدناه</a></p></div>")
    apply_html = ""
    if auto_applicable or decayed_n:
        n_sync = auto_applicable + decayed_n
        apply_html = (f"<form method='post' action='/inspection/apply_auto' style='display:inline'>"
                      f"<button class='btn warn' onclick=\"return confirm('سيُعبأ/يُعاد مزامنة {n_sync} بنداً بالتقييم الآلي وأدلته. التقييمات اليدوية لا تُمس. متابعة؟')\">"
                      f"تحديث التقييم الآلي ({n_sync} بنداً)</button></form>")
    sections: Dict[int, List[sqlite3.Row]] = {}
    for r in items:
        sections.setdefault(int(r["section_no"]), []).append(r)
    parts = []
    for sec_no in sorted(sections):
        rows = sections[sec_no]
        trs = []
        for r in rows:
            key = (int(r["section_no"]), int(r["item_no"]))
            auto = A.get(key)
            eff_st, eff_ev, decayed = eff_map[r["id"]]
            is_auto = _prov(r) == "auto"
            opts = "".join(f"<option value='{k}' {'selected' if eff_st == k else ''}>{v}</option>" for k, v in _INSPECTION_STATUSES.items())
            badge_cls = _V109_BADGE.get(eff_st, "warn")
            if auto:
                a_st, a_ev = auto
                a_cls = _V109_BADGE.get(a_st, "warn")
                tag = ("<span class='badge ok'>✓ مطبق آلياً</span>" if is_auto and not decayed
                       else "<span class='badge danger'>⚠ سند متدهور</span>" if decayed
                       else "")
                auto_cell = (f"<div class='small'><span class='badge {a_cls}'>آلي: {h(_INSPECTION_STATUSES.get(a_st, a_st))}</span> {tag}<br>{h(a_ev)}</div>")
            else:
                auto_cell = "<span class='small'>تقييم يدوي/مستندي</span>"
            prov_lbl = "آلي" if is_auto else "يدوي"
            trs.append(
                f"<tr><td>{r['item_no']}</td><td>{h(r['question'])}<br>{auto_cell}</td>"
                f"<td><span class='badge {badge_cls}'>{h(_INSPECTION_STATUSES.get(eff_st, eff_st))}</span><br><span class='small'>{prov_lbl}</span></td>"
                f"<td><form method='post' action='/inspection/update' style='display:flex;gap:6px;flex-wrap:wrap;align-items:center'>"
                f"<input type='hidden' name='item_id' value='{r['id']}'>"
                f"<select name='status' style='max-width:130px'>{opts}</select>"
                f"<input name='evidence' value='{h(eff_ev)}' placeholder='الدليل / المرفق / الملاحظة' style='max-width:260px'>"
                f"<button class='btn secondary' style='margin:0;padding:8px 12px'>حفظ (يدوي)</button></form>"
                f"<span class='small'>{h(r['updated_by'] or '')} {h((r['updated_at'] or '')[:16])}</span></td></tr>")
        parts.append(
            f"<div class=\"card\"><h3>المطلب {sec_no}: {h(rows[0]['section_title'])}</h3>"
            f"<div class=\"table-wrap\"><table><thead><tr><th>#</th><th>البند والتقييم الآلي</th><th>الحالة المعتمدة</th><th>التقييم والدليل</th></tr></thead>"
            f"<tbody>{''.join(trs)}</tbody></table></div></div>")
    body = f"""
<div class="card"><div class="section-title"><div><h2>جاهزية التفتيش — استمارة تفتيش الإدارة العامة للمحاماة (مكافحة غسل الأموال وتمويل الإرهاب)</h2>
<p class="small">التقييم الآلي يُحسب مباشرة من بيانات النظام ومدخلات الحوكمة ويظهر تحت كل بند؛ زر «التعبئة الآلية» يعتمد الآلي للبنود غير المقيَّمة فقط ولا يمس أي تقييم يدوي.</p></div>
<div>{apply_html} <a class="btn secondary" href="/najiz">لوحة جاهزية ناجز</a> <button class="btn secondary" onclick="window.print()">طباعة</button></div></div>{msg}
<div class="grid"><div class="card kpi status-green"><div>متوفر / لا ينطبق (معتمد)</div><div class="num">{manual_done}</div></div>
<div class="card kpi status-yellow"><div>جزئي</div><div class="num">{partial}</div></div>
<div class="card kpi status-red"><div>غير متوفر</div><div class="num">{missing}</div></div>
<div class="card kpi"><div>غير مقيَّم — تقييم آلي جاهز</div><div class="num">{auto_applicable}</div><span class="small">يدوي بحت: {manual_only} من {total}{f' · سند متدهور: {decayed_n}' if decayed_n else ''}</span></div></div>
{needs_html}
{auto_html}
{''.join(parts)}
{facts_form}
"""
    return layout("جاهزية التفتيش", body, "/compliance")


def _inspection_apply_auto(ip: str = "") -> int:
    """يعتمد/يعيد مزامنة التقييم الآلي: البنود غير المقيَّمة (pending) + البنود التي سبق أن عُبِّئت آلياً
    (provenance='auto') كي تتبع تدهور السند. لا يمس أبداً البنود المقيَّمة يدوياً (provenance='manual')."""
    user = _auth_current_user() or {}
    applied = 0
    with db() as con:
        ensure_schema(con)
        _seed_inspection_checklist(con)
        A, _ = _auto_assess(con)
        for r in con.execute("SELECT * FROM inspection_checklist").fetchall():
            try:
                prov = r["provenance"] or "manual"
            except (IndexError, KeyError):
                prov = "manual"
            # نطبّق فقط على: غير المقيَّم (pending) أو ما سبق أن كان آلياً — لا نمس اليدوي المعتمد
            if not (r["status"] == "pending" or prov == "auto"):
                continue
            auto = A.get((int(r["section_no"]), int(r["item_no"])))
            if not auto:
                continue
            st, ev = auto
            con.execute("UPDATE inspection_checklist SET status=?, evidence=?, provenance='auto', updated_at=?, updated_by=? WHERE id=?",
                        (st, "[آلي] " + ev, now_iso(), f"{user.get('user_name') or ''} (تعبئة آلية)", r["id"]))
            applied += 1
        audit(con, "inspection_auto_fill", "inspection", 0, f"تعبئة/مزامنة آلية لـ{applied} بنداً", ip)
        con.commit()
    return applied


def najiz_page(message: str = "") -> bytes:
    with db() as con:
        ensure_schema(con)
        M = _v109_metrics(con)
        F = _gov_facts(con)
    msg = f"<div class='success'>{h(message)}</div>" if message else ""

    def fv(key: str, default: str = "— يُدخل في مدخلات الحوكمة") -> str:
        return h(F.get(key, "").strip() or default)

    def live(v) -> str:
        return f"<b>{h(str(v))}</b> <span class='badge ok'>حي من النظام</span>"

    ct = M["clients_by_type"]
    mt = M["matter_types"]
    mt_ar = {"litigation": "تقاضٍ", "contract": "عقود", "consulting": "استشارات", "retainer_agreement": "اتفاقيات أتعاب", "receivership": "حراسة قضائية"}
    mt_txt = "، ".join(f"{mt_ar.get(k, k)}: {v}" for k, v in mt.items())
    # فحص اتساق أرقام العمليات ≥50 ألفاً (الخطأ الذي ظهر في مسودة ناجز)
    ops_warn = ""
    try:
        c50 = int(F.get("najiz_ops50k_count", "") or 0)
        t50 = int((F.get("najiz_ops50k_total", "") or "0").replace(",", ""))
        if c50 > 0 and t50 < c50 * 50000:
            ops_warn = f"<div class='error'>تنبيه اتساق: {c50} عملية ≥ 50,000 ريال تستلزم إجمالياً لا يقل عن {c50 * 50000:,} ريال — الإجمالي المدخل ({t50:,}) غير منطقي.</div>"
    except Exception:
        pass
    filled = sum(1 for k in _GOV_FACT_KEYS if k.startswith(("najiz_", "matters_")) and F.get(k, "").strip())
    total_manual = sum(1 for k in _GOV_FACT_KEYS if k.startswith(("najiz_", "matters_")))
    rows = f"""
<div class="card"><h3>1) بيانات المنشأة ومسؤول الامتثال</h3><table>
<tr><th>الكيان</th><td>شركة مسارات للاستشارات القانونية — س.ت 1010443594 — الرقم الموحد 7009421665</td></tr>
<tr><th>الشكل النظامي</th><td>مساهمة مقفلة (النظام الأساس 1081142 بتاريخ 25 صفر 1447) — <b>تحقق من تحديثه في ناجز (يظهر حالياً: ذ.م.م مهنية)</b></td></tr>
<tr><th>مسؤول الامتثال</th><td>قرار تعيين موقع (نفاذ 1 أغسطس 2026)؛ الإخطار: {fv('co_notification_sent', 'لم يُرسل بعد')}</td></tr></table></div>
<div class="card"><h3>2) بيانات العاملين (تُدمج مرفقات كل فئة في PDF واحد)</h3><table>
<tr><th>المحامون المرخصون</th><td>{fv('najiz_lawyers_count')}</td><th>المستشارون</th><td>{fv('najiz_consultants_count')}</td></tr>
<tr><th>الإداريون</th><td>{fv('najiz_admins_count')}</td><th>المتدربون السعوديون</th><td>{fv('najiz_trainees_count')} (لا متدربين غير سعوديين)</td></tr></table></div>
<div class="card"><h3>3) الخدمات القانونية والمخاطر</h3>
<p class="small">أكمِلوا جدول نسب الخدمات في ناجز حتى 100%، وارفعوا وثيقتي «تقييم مخاطر المنشأة» و«منهجية تقييم مخاطر العميل» بعد توقيعهما في جلسة الاعتماد.</p>
<table><tr><th>المسائل القائمة</th><td>{live(M['matters_total'])} — {h(mt_txt)}</td></tr>
<tr><th>المخاطر (كامنة ← متبقية)</th><td>وفق وثيقة تقييم المنشأة: مرتفع ← متوسط (العملاء، الخدمات، الجغرافيا، الدفع، تمويل الإرهاب)؛ متوسط ← منخفض (القنوات، التقنيات)</td></tr></table></div>
<div class="card"><h3>4) بيانات العملاء</h3><table>
<tr><th>إجمالي العملاء</th><td>{live(M['clients_total'])} (شركات: {ct.get('company', 0)}، جهات حكومية: {ct.get('government', 0)}، أفراد: {ct.get('individual', 0)})</td></tr>
<tr><th>التصنيف الفعلي للمخاطر</th><td>{live(_v109_eff_dist_ar(M))}</td></tr>
<tr><th>الأشخاص المعرَّضون سياسياً</th><td>{live(f"{M['pep_yes']} (قُيِّمت {M['pep_assessed']} حالات)")}</td></tr>
<tr><th>مرتبطون بدول عالية المخاطر</th><td>{live(M['hrc_flag_count'])}</td></tr>
<tr><th>الأنشطة المحددة نظاماً</th><td>إدارة أموال: {fv('matters_funds_mgmt')} · عقارات: {fv('matters_realestate')} · تأسيس كيانات: {fv('matters_entity_formation')} · بيع/شراء شركات: {fv('matters_company_sale')}</td></tr></table></div>
<div class="card"><h3>5) العمليات المالية والبلاغات</h3>{ops_warn}<table>
<tr><th>عمليات ≥ 50,000 ريال</th><td>العدد: {fv('najiz_ops50k_count')} · الإجمالي: {fv('najiz_ops50k_total')}</td></tr>
<tr><th>الأتعاب النقدية</th><td>العدد: {fv('najiz_cash_fees_count')} · الإجمالي: {fv('najiz_cash_fees_total')}</td></tr>
<tr><th>الدخل / الأصول</th><td>{fv('najiz_income_range')} / {fv('najiz_assets_range')}</td></tr>
<tr><th>بلاغات تقصّي</th><td>{live(f"خارجية: {M['reported']} · حالات اشتباه داخلية: {M['suspicion_total']}")}</td></tr></table></div>
<div class="card"><h3>تنبيهات قبل التقديم</h3><ul class="small">
<li>الأرقام في المسودة الحالية على ناجز تجريبية — استبدلوها بالقيم أعلاه.</li>
<li>جدول نسب الخدمات القانونية يظهر 0% — يجب إكماله إلى 100%.</li>
<li>خطوتا «بيانات العملاء» و«معاينة الطلب» لم تُلتقطا في النسخ المحفوظة — راجعوهما مباشرة في ناجز بالقيم الحية أعلاه.</li>
<li>تطابق أعداد البلاغات المدخلة مع سجل النظام (خارجية: {M['reported']}).</li></ul></div>
"""
    body = f"""
<div class="card"><div class="section-title"><div><h2>لوحة جاهزية ناجز — تقييم المنشأة القانونية</h2>
<p class="small">القيم الموسومة «حي من النظام» تُنسخ إلى استمارة ناجز كما هي؛ والبقية تُدخل مرة واحدة في <a href="/inspection#facts">مدخلات الحوكمة</a>. مكتمل من المدخلات اليدوية: {filled}/{total_manual}.</p></div>
<div><a class="btn secondary" href="/inspection">لوحة جاهزية التفتيش</a> <button class="btn secondary" onclick="window.print()">طباعة</button></div></div>{msg}
{rows}
"""
    return layout("جاهزية ناجز", body, "/compliance")


_get_pre_v109 = AppHandler.do_GET

def _do_get_v109(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    if parsed.path != "/najiz":
        return _get_pre_v109(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    try:
        return self._send(najiz_page())
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر عرض الصفحة: {h(exc)}</div>", "/compliance"), 500)

AppHandler.do_GET = _do_get_v109


_post_pre_v109 = AppHandler.do_POST

def _do_post_v109(self: AppHandler) -> None:
    path = urlparse(self.path).path
    if path not in ("/governance/facts", "/inspection/apply_auto"):
        return _post_pre_v109(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    if (user.get("role") or "") not in ("admin", "compliance"):
        return self._send(layout("غير مصرح", "<div class='error'>هذه العملية تتطلب دور مدير أو مسؤول امتثال.</div>", "/compliance"), 403)
    try:
        fields, files, ip = _parse_request_fields(self)
        if path == "/governance/facts":
            _save_gov_facts(fields, ip)
            return send_redirect(self, "/inspection")
        applied = _inspection_apply_auto(ip)
        return send_redirect(self, f"/inspection?msg=applied_{applied}")
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر التنفيذ: {h(exc)}</div>", "/compliance"), 500)

AppHandler.do_POST = _do_post_v109


APP_VERSION = "V10.15.0 - Durable internal-conflict closure (reopen-safe suppression, honest records)"

# V10.13.3: أضِف زر «واثق» إلى القائمة العلوية (يظهر لمدير/مسؤول الامتثال فقط) — يفتح صفحة
# اختبار الربط وحالة المفاتيح والجلب. كانت الصفحة تُفتح بالعنوان فقط بلا رابط ظاهر.
_layout_pre_wathqnav = layout

def layout(title: str, body: str, active: str = "") -> bytes:  # type: ignore[override]
    raw = _layout_pre_wathqnav(title, body, active).decode("utf-8")
    try:
        u = _auth_current_user() or {}
        if (u.get("role") or "") in ("admin", "compliance") and "/wathq/selftest" not in raw:
            link = '<a href="/wathq/selftest">واثق — اختبار الربط</a>'
            # ضع الرابط داخل قائمة «الإدارة» المنسدلة (أول عنصر بعد فتح dropdown-content بعد رابط /production)
            pi = raw.find('href="/production"')
            inserted = False
            if pi != -1:
                dd = raw.find('<div class="dropdown-content">', pi)
                if dd != -1:
                    cut = dd + len('<div class="dropdown-content">')
                    raw = raw[:cut] + link + raw[cut:]
                    inserted = True
            if not inserted:
                # احتياط: أضِفه كعنصر أعلى القائمة بعد رابط «الرئيسية»
                home = raw.find('href="/">الرئيسية</a>')
                if home != -1:
                    cut = home + len('href="/">الرئيسية</a>')
                    raw = raw[:cut] + link + raw[cut:]
    except Exception:
        pass
    return raw.encode("utf-8")


APP_VERSION = "V10.15.0 - Durable internal-conflict closure (reopen-safe suppression, honest records)"

# =====================================================================
# V10.12 — Map the Wathq /commercial-registration/fullinfo response into client
# fields + owners/managers, with an explicit fetch→preview→confirm-save flow (never
# auto-writes). Mapping is built against the OFFICIAL OpenAPI v6.7.0 schema + its
# documented example (crNationalNumber=700, crNumber, name, status.name, capital,
# parties[].identity.id + partnerShare, management.managers[]). Provenance recorded.
# =====================================================================

def _wq(d, *path, default=None):
    """قراءة متداخلة آمنة من dict/list استجابة واثق."""
    cur = d
    for k in path:
        if isinstance(cur, dict):
            cur = cur.get(k)
        elif isinstance(cur, list) and isinstance(k, int) and 0 <= k < len(cur):
            cur = cur[k]
        else:
            return default
    return cur if cur is not None else default


def _wathq_map_cr(raw: Dict[str, Any]) -> Dict[str, Any]:
    """يحوّل استجابة fullinfo إلى حقول التطبيق (مبني على استجابة واثق الحقيقية v6).
    متسامح مع اختلاف الهياكل بين ذ.م.م (contributionCapital + parties) والمساهمة
    (stockCapital + management.managers) والحقول الناقصة/القيم null والكائنات المتداخلة."""
    if not isinstance(raw, dict) or not raw:
        return {}

    # --- الشكل النظامي: entityType.name + entityType.formName + الصفات (مهنية...) ---
    et = raw.get("entityType") or {}
    form_parts = [str(et.get("name") or "").strip(), str(et.get("formName") or "").strip()]
    for ch in (et.get("characters") or []):
        if isinstance(ch, dict) and ch.get("name"):
            form_parts.append(str(ch["name"]).strip())
    if not any(form_parts):
        form_parts = [str(raw.get("formName") or raw.get("structureName") or "").strip()]
    form_text = " ".join(p for p in form_parts if p)

    # --- رأس المال: قد يكون stockCapital (مساهمة) أو contributionCapital (ذ.م.م) + crCapital أعلى ---
    cap = raw.get("capital") or {}
    detail = cap.get("stockCapital") or cap.get("contributionCapital") or {}
    cap_bits = []
    total_cap = raw.get("crCapital") if raw.get("crCapital") is not None else detail.get("capital")
    if total_cap:
        cap_bits.append(f"رأس المال: {total_cap}")
    for key, lbl in (("cashCapital", "نقدي"), ("inKindCapital", "عيني"), ("paidCapital", "مدفوع")):
        v = detail.get(key)
        if v:
            cap_bits.append(f"{lbl}: {v}")
    cur_name = cap.get("currencyName") or ""
    capital_text = ("، ".join(cap_bits) + (f" ({cur_name})" if cur_name and cap_bits else "")) if cap_bits else ""

    acts = raw.get("activities") or []
    activities_text = "؛ ".join(str(a.get("name") or "").strip() for a in acts if isinstance(a, dict) and a.get("name"))

    _NAT_HINTS = ("سعودي", "سعودية", "غير سعودي", "خليجي", "أجنبي")

    def _nat(p) -> str:
        nat = p.get("nationality")
        if isinstance(nat, dict):
            return str(nat.get("name") or "").strip()
        if isinstance(nat, str) and nat.strip():
            return nat.strip()
        tn = str(p.get("typeName") or "").strip()  # e.g. "فرد سعودي"
        for hint in _NAT_HINTS:
            if hint in tn:
                return hint
        return ""

    def _positions(p) -> str:
        return "، ".join(str(x.get("name") or "").strip() for x in (p.get("positions") or [])
                         if isinstance(x, dict) and x.get("name"))

    def _partnership_names(p) -> str:
        return "، ".join(str(x.get("name") or "").strip() for x in (p.get("partnership") or [])
                         if isinstance(x, dict) and x.get("name"))

    def _party(p, role):
        label = _positions(p) or _partnership_names(p)  # منصب المدير أو صفة الشريك (شريك برأس المال…)
        return {
            "full_name": (p.get("name") or "").strip(),
            "id_number": str(_wq(p, "identity", "id", default="") or "").strip(),
            "id_type": (_wq(p, "identity", "typeName", default="") or "").strip(),
            "nationality": _nat(p),
            "type_name": label or (p.get("typeName") or "").strip(),
            "role": (label or role),
            "share": _wq(p, "partnerShare", "totalContributionCount", default=None),
            # نسبة الربح/الخسارة = نسبة الملكية الفعلية عند توفرها (أدق من احتساب أعداد المساهمة)
            "profit_pct": _wq(p, "partnerProfitLossDistribution", "profitDistribution", default=None),
            "party_cr": (str(p.get("crNumber")).strip() if p.get("crNumber") else ""),
        }

    parties = [_party(p, "شريك") for p in (raw.get("parties") or []) if isinstance(p, dict) and p.get("name")]
    managers_raw = _wq(raw, "management", "managers", default=[]) or raw.get("managers") or []
    managers = [_party(m, "مدير") for m in managers_raw if isinstance(m, dict) and m.get("name")]
    # نسبة الملكية: نفضّل نسبة توزيع الأرباح (profitDistribution) لأنها النسبة المعلنة الفعلية؛
    # وإلا نحتسبها نسبياً من أعداد المساهمة.
    total_share = sum(float(p["share"]) for p in parties if isinstance(p.get("share"), (int, float)))
    for p in parties:
        if isinstance(p.get("profit_pct"), (int, float)):
            p["ownership_percent"] = round(float(p["profit_pct"]), 2)
        elif isinstance(p.get("share"), (int, float)) and total_share > 0:
            p["ownership_percent"] = round(100.0 * float(p["share"]) / total_share, 2)
        else:
            p["ownership_percent"] = 0.0
    for m in managers:
        m["ownership_percent"] = 0.0

    return {
        "legal_name": (raw.get("name") or "").strip(),
        "unified_number": str(raw.get("crNationalNumber") or "").strip(),
        "registration_number": str(raw.get("crNumber") or "").strip(),
        "status_text": (_wq(raw, "status", "name", default="") or "").strip(),
        "form_text": form_text,
        "city_text": (raw.get("headquarterCityName") or "").strip(),
        "capital_text": capital_text,
        "activities_text": activities_text,
        "in_liquidation": bool(raw.get("inLiquidationProcess")),
        "parties": parties,
        "managers": managers,
    }


def _wathq_enrich_parties(m: Dict[str, Any], cr: str) -> Dict[str, Any]:
    """يُثري ملاك/مديري نتيجة السجل التجاري بشركاء «عقد الشركة» (مفيد للشركات ذات
    المسؤولية المحدودة حيث تكون parties في السجل التجاري فارغة). يعيد الاستخدام لنفس
    مُحوّل السجل التجاري على كائن entity المطابق. عملية آمنة: لا شيء إن لم يُضبط المفتاح
    أو فشل الطلب، ودمج مُزال التكرار (اسم + رقم هوية). لا يستبدل أي بيانات."""
    if not (cr and _wathq_configured("company")):
        return m
    try:
        st, data, _ = wathq_company_contract(cr)
        if st == 200 and isinstance(data, dict):
            cc = _wathq_map_cr((data.get("entity") or {}))
            existing = {}
            for lst_key in ("parties", "managers"):
                for p in m.get(lst_key, []):
                    existing[(p.get("full_name"), p.get("id_number"))] = p
            for lst_key in ("parties", "managers"):
                for cp in cc.get(lst_key, []):
                    if not cp.get("full_name"):
                        continue
                    key = (cp.get("full_name"), cp.get("id_number"))
                    ex = existing.get(key)
                    if ex is not None:
                        # نفس الطرف موجود من السجل التجاري — نُثريه ببيانات عقد الشركة الأدق:
                        # نسبة الملكية من توزيع الأرباح (99/1) أدق من نسبة أعداد المساهمة (100/0)،
                        # ونملأ الجنسية/الصفة إن كانت ناقصة. لا نكرّر الطرف.
                        if cp.get("profit_pct") is not None:
                            ex["ownership_percent"] = cp.get("ownership_percent", ex.get("ownership_percent"))
                        if not ex.get("nationality") and cp.get("nationality"):
                            ex["nationality"] = cp["nationality"]
                        if not ex.get("type_name") and cp.get("type_name"):
                            ex["type_name"] = cp["type_name"]
                    else:
                        cp["type_name"] = ((cp.get("type_name") or "") + " — عقد الشركة").strip(" —")
                        m.setdefault(lst_key, []).append(cp)
                        existing[key] = cp
    except Exception:
        pass
    return m


def _wathq_lookup_for_client(con: sqlite3.Connection, client_id: int, cr_override: str = "") -> Tuple[Optional[sqlite3.Row], str, int, Any, str]:
    """يحدد رقم الاستعلام (المدخل، أو الرقم الموحد، أو السجل التجاري للعميل) ثم يستعلم واثق.
    يرجع (صف العميل، الرقم المستخدم، رمز HTTP، البيانات، الرسالة)."""
    c = con.execute("SELECT * FROM clients WHERE id=?", (client_id,)).fetchone()
    if not c:
        return None, "", 0, None, "العميل غير موجود"
    cr = "".join(ch for ch in (cr_override or "") if ch.isdigit())
    if not cr:
        # واثق يشترط الرقم الوطني الموحّد (700) للسجلات النشطة/المعلّقة في fullinfo — نفضّله أولاً.
        cr = "".join(ch for ch in ((c["unified_number"] or "") or (c["registration_number"] or "")) if ch.isdigit())
    if not cr:
        return c, "", 0, None, "لا يوجد رقم موحّد (700) أو سجل تجاري لهذا العميل؛ أدخله يدوياً"
    status, data, msg = wathq_cr_fullinfo(cr)
    # إن استُخدم رقم سجل تجاري (يبدأ بـ101) على سجل نشط، يطلب واثق الرقم الموحّد (700).
    if status == 400 and "700" in (msg or "") and not cr.startswith("7"):
        alt = "".join(ch for ch in (c["unified_number"] or "") if ch.isdigit())
        if alt and alt != cr:
            status, data, msg = wathq_cr_fullinfo(alt)
            if status == 200:
                cr = alt
    return c, cr, status, data, msg


def wathq_fetch_page(client_id: int, cr_override: str = "", message: str = "") -> bytes:
    with db() as con:
        ensure_schema(con)
        c, cr, status, data, msg = _wathq_lookup_for_client(con, client_id, cr_override)
    if not c:
        return layout("خطأ", "<div class='error'>العميل غير موجود</div>", "/clients")
    msg_html = f"<div class='success'>{h(message)}</div>" if message else ""
    if not _wathq_configured("cr"):
        body = (f"<div class='card'><h2>جلب بيانات العميل من واثق</h2>{msg_html}"
                f"<div class='error'>لم يُضبط مفتاح تطبيق «السجل التجاري» (WATHQ_KEY_CR) على الخادم بعد. راجع دليل WATHQ_SETUP_AR.txt.</div>"
                f"<p><a class='btn secondary' href='/wathq/selftest'>صفحة حالة المفاتيح والاختبار</a> "
                f"<a class='btn secondary' href='/client?id={client_id}'>عودة لملف العميل</a></p></div>")
        return layout("جلب من واثق", body, "/clients")
    form = (f"<div class='card'><h3>الاستعلام</h3><form method='get' action='/wathq/fetch'>"
            f"<input type='hidden' name='client_id' value='{client_id}'>"
            f"<div class='grid'><div><label>الرقم الوطني الموحّد (700) — مُفضَّل للسجلات النشطة</label>"
            f"<input name='cr' value='{h(cr)}' placeholder='مثال: 700xxxxxxx (أو رقم السجل 1010… للسجلات الملغاة)'></div></div>"
            f"<button>استعلم من واثق</button></form></div>")
    if status != 200 or data is None:
        hint = ""
        if status == 400 and "700" in (msg or ""):
            hint = ("<p class='notice'>هذا رقم سجل تجاري (يبدأ بـ1010…)؛ واثق يتطلب <b>الرقم الوطني الموحّد (700)</b> "
                    "للسجلات النشطة والمعلّقة. أدخل رقم المنشأة الموحّد (يبدأ بـ700) في الحقل أعلاه، "
                    "أو أضِفه في ملف العميل ثم أعد المحاولة.</p>")
        body = (f"<div class='card'><h2>جلب بيانات العميل من واثق</h2>{msg_html}</div>{form}"
                f"<div class='card'><div class='error'>تعذّر الجلب — HTTP {h(status)}: {h(msg)}</div>{hint}</div>")
        return layout("جلب من واثق", body, "/clients")
    m = _wathq_enrich_parties(_wathq_map_cr(data), cr)

    def cmp_row(lbl, old, new):
        changed = (new or "") and (str(old or "").strip() != str(new or "").strip())
        badge = "<span class='badge warn'>سيُحدّث</span>" if changed else ("<span class='badge ok'>مطابق</span>" if new else "")
        return f"<tr><th>{h(lbl)}</th><td dir='auto'>{h(old or '—')}</td><td dir='auto'>{h(new or '—')}</td><td>{badge}</td></tr>"

    core = "".join([
        cmp_row("الاسم النظامي", c["legal_name"], m["legal_name"]),
        cmp_row("الرقم الموحّد (700)", c["unified_number"], m["unified_number"]),
        cmp_row("رقم السجل التجاري", c["registration_number"], m["registration_number"]),
    ])
    extra = "".join(f"<tr><th>{h(k)}</th><td colspan='3' dir='auto'>{h(v)}</td></tr>" for k, v in [
        ("الحالة في واثق", m["status_text"]), ("الشكل النظامي", m["form_text"]), ("المدينة", m["city_text"]),
        ("رأس المال", m["capital_text"]), ("الأنشطة", m["activities_text"]),
        ("تحت التصفية", "نعم" if m["in_liquidation"] else "لا")] if v)
    prows = "".join(f"<tr><td dir='auto'>{h(p['full_name'])}</td><td dir='ltr'>{h(p['id_number'])}</td>"
                    f"<td>{h(p.get('type_name') or p.get('nationality') or '—')}</td><td>{h(p['ownership_percent'])}%</td></tr>" for p in m["parties"]) or "<tr><td colspan='4'>لا يوجد</td></tr>"
    mrows = "".join(f"<tr><td dir='auto'>{h(mm['full_name'])}</td><td dir='ltr'>{h(mm['id_number'])}</td>"
                    f"<td>{h(mm.get('nationality') or mm.get('type_name') or '—')}</td></tr>" for mm in m["managers"]) or "<tr><td colspan='3'>لا يوجد</td></tr>"
    apply_form = (f"<div class='card'><h3>اعتماد وحفظ</h3>"
                  f"<p class='small'>سيُحدَّث الاسم/الرقم الموحّد/السجل التجاري في ملف العميل، وتُضاف الأطراف (ملاك ومديرون) كأطراف مرتبطة، مع تسجيل المصدر «واثق» وتاريخه. راجع الجدول أعلاه أولاً.</p>"
                  f"<form method='post' action='/wathq/apply'><input type='hidden' name='client_id' value='{client_id}'>"
                  f"<input type='hidden' name='cr' value='{h(cr)}'>"
                  f"<label><input type='checkbox' name='import_parties' value='1' checked> استيراد الملاك والمديرين كأطراف مرتبطة ({len(m['parties'])} مالك، {len(m['managers'])} مدير)</label><br>"
                  f"<button class='btn warn' onclick=\"return confirm('اعتماد بيانات واثق وحفظها في ملف العميل؟')\">اعتماد وحفظ من واثق</button> "
                  f"<a class='btn secondary' href='/client?id={client_id}'>إلغاء</a></form></div>")
    body = f"""
<div class="card"><h2>جلب بيانات العميل من واثق — معاينة قبل الحفظ</h2>{msg_html}
<p class="small">مصدر البيانات: منصة واثق الرسمية (السجل التجاري) — رقم الاستعلام: <span dir="ltr">{h(cr)}</span></p></div>
{form}
<div class="card"><h3>الحقول الأساسية</h3><div class="table-wrap"><table><thead><tr><th>الحقل</th><th>الحالي</th><th>من واثق</th><th></th></tr></thead><tbody>{core}{extra}</tbody></table></div></div>
<div class="card"><h3>الملاك / الشركاء (المستفيدون الحقيقيون المحتملون)</h3><div class="table-wrap"><table><thead><tr><th>الاسم</th><th>رقم الهوية</th><th>الجنسية/النوع</th><th>نسبة الملكية</th></tr></thead><tbody>{prows}</tbody></table></div></div>
<div class="card"><h3>المديرون</h3><div class="table-wrap"><table><thead><tr><th>الاسم</th><th>رقم الهوية</th><th>الجنسية/النوع</th></tr></thead><tbody>{mrows}</tbody></table></div></div>
{apply_form}
"""
    return layout("جلب من واثق", body, "/clients")


def wathq_apply(fields: Dict[str, List[str]], ip: str = "") -> int:
    client_id = int(form_value(fields, "client_id", "0") or 0)
    cr_override = form_value(fields, "cr", "")
    import_parties = form_value(fields, "import_parties", "") == "1"
    user = _auth_current_user() or {}
    with db() as con:
        ensure_schema(con)
        c, cr, status, data, msg = _wathq_lookup_for_client(con, client_id, cr_override)
        if not c:
            raise ValueError("العميل غير موجود")
        if status != 200 or data is None:
            raise ValueError(f"تعذّر الجلب من واثق (HTTP {status}): {msg}")
        m = _wathq_enrich_parties(_wathq_map_cr(data), cr)
        stamp = now_iso()[:10]
        # حقول أساسية — تُملأ فقط إن كانت واثق تحملها؛ لا تُمسح قيمة موجودة بقيمة فارغة
        sets, vals = [], []
        if m["legal_name"]:
            sets.append("legal_name=?"); vals.append(m["legal_name"])
        if m["unified_number"]:
            sets.append("unified_number=?"); vals.append(m["unified_number"])
        if m["registration_number"]:
            sets.append("registration_number=?"); vals.append(m["registration_number"])
        # V10.17: بيانات السجل (الحالة/الشكل/المدينة/رأس المال/الأنشطة/التصفية) تُحفظ منظَّمة
        # في client_registry — لم نعد نحشرها في الملاحظات. وننظّف أي كتل واثق سابقة من ملاحظات
        # هذا العميل مع الإبقاء التام على الملاحظات اليدوية.
        cleaned_note = _wathq_clean_client_notes(c["notes"] or "")
        sets.append("notes=?"); vals.append(cleaned_note)
        sets.append("updated_at=?"); vals.append(now_iso())
        vals.append(client_id)
        con.execute(f"UPDATE clients SET {', '.join(sets)} WHERE id=?", vals)
        added = 0
        if import_parties:
            for p in (m["parties"] + m["managers"]):
                if not p["full_name"]:
                    continue
                # dedup: نفس الاسم+الهوية لنفس العميل
                exists = con.execute(
                    "SELECT 1 FROM related_parties WHERE parent_type='client' AND parent_id=? AND full_name=? AND COALESCE(id_number,'')=?",
                    (client_id, p["full_name"], p["id_number"] or "")).fetchone()
                if exists:
                    continue
                con.execute(
                    "INSERT INTO related_parties(created_at, parent_type, parent_id, party_role, full_name, id_number, registration_number, nationality, country, ownership_percent, notes, source) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                    (now_iso(), "client", client_id, p["role"], p["full_name"], p["id_number"] or None,
                     p.get("party_cr") or None, p.get("nationality") or None, None,
                     float(p.get("ownership_percent") or 0),
                     f"من واثق {stamp} — {p.get('type_name') or p['role']}؛ الهوية: {p.get('id_type','')}",
                     "wathq"))
                added += 1
        try:
            _wathq_upsert_registry(con, client_id, m, cr, str(user.get("user_name") or ""))
        except Exception:
            pass
        try:
            evaluate_client_risk(con, client_id)
        except Exception:
            pass
        try:
            _wathq_record_provenance(con, client_id, cr, m, added, str(user.get("user_name") or ""))
        except Exception:
            pass
        audit(con, "wathq_apply", "client", client_id,
              json.dumps({"cr": cr, "fields": len(sets) - 2, "parties_added": added,
                          "by": str(user.get("user_name") or "")}, ensure_ascii=False), ip)
        con.commit()
    # إعادة فحص العميل بعد تحديث بياناته (أفضل جهد)
    try:
        run_client_screening(int(client_id), ip)
    except Exception:
        pass
    return client_id


# --- client-detail button + routes ---
_client_detail_pre_v1012 = client_detail

def client_detail(client_id: int) -> bytes:  # type: ignore[override]
    raw = _client_detail_pre_v1012(client_id).decode("utf-8")
    try:
        btn = (f"<div class=\"card\"><h3>واثق — السجل التجاري الرسمي</h3>"
               f"<p class=\"small\">جلب الاسم النظامي والرقم الموحّد (700) والحالة ورأس المال والملّاك والمديرين من منصة واثق، مع معاينة قبل الحفظ.</p>"
               f"<a class=\"btn\" href=\"/wathq/fetch?client_id={client_id}\">جلب من واثق</a></div>")
        raw = raw.replace("</main>", btn + "</main>", 1) if "</main>" in raw else raw + btn
    except Exception:
        pass
    return raw.encode("utf-8")


_get_pre_v1012 = AppHandler.do_GET

def _do_get_v1012(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    if parsed.path != "/wathq/fetch":
        return _get_pre_v1012(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    if (user.get("role") or "") not in ("admin", "compliance"):
        return self._send(layout("غير مصرح", "<div class='error'>جلب واثق يتطلب دور مدير أو مسؤول امتثال.</div>", "/clients"), 403)
    q = parse_qs(parsed.query)
    try:
        cid = int((q.get("client_id", ["0"])[0] or 0))
    except (TypeError, ValueError):
        cid = 0
    cr = (q.get("cr", [""])[0] or "").strip()
    try:
        return self._send(wathq_fetch_page(cid, cr))
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذّر تنفيذ الجلب: {h(exc)}</div>", "/clients"), 500)

AppHandler.do_GET = _do_get_v1012


_post_pre_v1012 = AppHandler.do_POST

def _do_post_v1012(self: AppHandler) -> None:
    if urlparse(self.path).path != "/wathq/apply":
        return _post_pre_v1012(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    if (user.get("role") or "") not in ("admin", "compliance"):
        return self._send(layout("غير مصرح", "<div class='error'>اعتماد بيانات واثق يتطلب دور مدير أو مسؤول امتثال.</div>", "/clients"), 403)
    try:
        fields, _files, ip = _parse_request_fields(self)
        cid = wathq_apply(fields, ip)
        return send_redirect(self, f"/client?id={cid}")
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذّر اعتماد بيانات واثق: {h(exc)}</div>", "/clients"), 500)

AppHandler.do_POST = _do_post_v1012

# (V10.11 Wathq connector foundation follows; APP_VERSION stays V10.12.0 — set above)

# =====================================================================
# V10.11 — Wathq (واثق) official commercial-registration connector foundation.
# Env-driven: the API key is NEVER in code/repo — it is read from the WATHQ_API_KEY
# environment variable set on the pilot host by the firm. This layer ships the safe
# HTTP client + a read-only SELF-TEST so, once the key is dropped in, the team can
# verify reachability/auth AND see the real JSON response — which is what the
# field-mapping + write-back (next version) will be built against, not guessed.
# SSRF-guarded (host allowlist + HTTPS), audited (never logs the key), fail-safe.
# =====================================================================

WATHQ_BASE_URL = (os.environ.get("WATHQ_BASE_URL", "").strip() or "https://api.wathq.sa").rstrip("/")
_WATHQ_ALLOWED_HOSTS = {"api.wathq.sa"}

# V10.13: كل تطبيق في واثق له مفتاحه الخاص (apiKey). سجل التطبيقات ذات الصلة بـKYC:
# code → (label, base_path, key_env). المفتاح يُقرأ من متغير البيئة الخاص بالتطبيق،
# أو من ملف أسرار JSON اختياري، أو من WATHQ_API_KEY القديم (توافق خلفي). الأساس المؤكد
# للمسارات: /commercial-registration، /commercial-registration/beneficiary، /spl/national/address.
_WATHQ_APIS = {
    "cr":      {"label": "السجل التجاري", "base": "/commercial-registration", "key_env": "WATHQ_KEY_CR"},
    "crb":     {"label": "المستفيد من السجل التجاري (UBO)", "base": "/commercial-registration/beneficiary", "key_env": "WATHQ_KEY_CRB"},
    "company": {"label": "عقود الشركات (الشركاء)", "base": "/company-contract", "key_env": "WATHQ_KEY_COMPANY_CONTRACT"},
    "investor": {"label": "مستثمر وزارة الاستثمار", "base": "/investor", "key_env": "WATHQ_KEY_INVESTOR"},
    "realestate": {"label": "العقارات", "base": "/moj/real-estate", "key_env": "WATHQ_KEY_REALESTATE"},
    "address": {"label": "العنوان الوطني", "base": "/spl/national/address", "key_env": "WATHQ_KEY_ADDRESS"},
}


def _wathq_keys_file() -> str:
    """مسار ملف أسرار اختياري (خارج مجلد التطبيق والنسخ الاحتياطي). قابل للتجاوز بـ WATHQ_KEYS_FILE."""
    override = os.environ.get("WATHQ_KEYS_FILE", "").strip()
    if override:
        return override
    data_dir = os.environ.get("MASARAT_KYC_DATA", "").strip()
    base = os.path.dirname(data_dir.rstrip("/\\")) if data_dir else "."
    return os.path.join(base, "secrets", "wathq_keys.json")


def _wathq_keys_from_file() -> Dict[str, str]:
    try:
        p = _wathq_keys_file()
        if os.path.isfile(p):
            raw = json.loads(open(p, encoding="utf-8").read())
            out = {}
            for k, v in (raw or {}).items():
                if isinstance(v, dict):
                    out[k] = str(v.get("key") or "").strip()
                else:
                    out[k] = str(v or "").strip()
            return out
    except Exception:
        pass
    return {}


def _wathq_clean_key(v: str) -> str:
    """تنظيف المفتاح من الفراغات ومحارف التحكم الاتجاهية/الصفرية غير المرئية التي كثيراً ما
    تُلصق مع النص من بوابات RTL (LRM/RLM U+200E/F، التضمين/التجاوز U+202A-E وU+2066-9،
    والعرض الصفري U+200B-D وBOM U+FEFF). بدونها يفشل الاستيثاق بـ401 دون سبب ظاهر."""
    if not v:
        return ""
    bad = {0x200B, 0x200C, 0x200D, 0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D,
           0x202E, 0x2066, 0x2067, 0x2068, 0x2069, 0xFEFF}
    return "".join(ch for ch in v if ord(ch) not in bad).strip()


def _wathq_key(app_code: str = "cr") -> str:
    """مفتاح التطبيق: متغير البيئة الخاص → ملف الأسرار → WATHQ_API_KEY القديم. يُنظَّف دائماً."""
    api = _WATHQ_APIS.get(app_code)
    if api:
        v = _wathq_clean_key(os.environ.get(api["key_env"], ""))
        if v:
            return v
        fv = _wathq_clean_key(_wathq_keys_from_file().get(app_code, ""))
        if fv:
            return fv
    return _wathq_clean_key(os.environ.get("WATHQ_API_KEY", ""))  # legacy single-key fallback


def _wathq_configured(app_code: str = "cr") -> bool:
    return bool(_wathq_key(app_code))


def _wathq_any_configured() -> bool:
    return any(_wathq_configured(c) for c in _WATHQ_APIS)


def _wathq_mask(key: str) -> str:
    """عرض آمن لبصمة المفتاح دون كشفه (للتشخيص فقط)."""
    if not key:
        return "(غير مضبوط)"
    return f"مضبوط ({len(key)} حرفاً، ينتهي بـ …{key[-4:]})" if len(key) >= 6 else "مضبوط (قصير)"


def _wathq_get(path: str, app_code: str = "cr", timeout: int = 30) -> Tuple[int, Any, str]:
    """طلب GET آمن إلى واثق باستخدام مفتاح التطبيق المحدد. يرجع (رمز الحالة، البيانات، رسالة).
    SSRF: المضيف محصور في api.wathq.sa وHTTPS فقط. المفتاح لا يُسجّل أبداً."""
    import urllib.request
    import urllib.error
    import ssl
    from urllib.parse import urlparse as _up
    key = _wathq_key(app_code)
    if not key:
        env = _WATHQ_APIS.get(app_code, {}).get("key_env", "WATHQ_API_KEY")
        return 0, None, f"لم يُضبط مفتاح هذا التطبيق ({env}) على الخادم"
    url = f"{WATHQ_BASE_URL}/{path.lstrip('/')}"
    p = _up(url)
    if p.scheme != "https" or p.hostname not in _WATHQ_ALLOWED_HOSTS:
        return 0, None, f"وجهة غير مسموح بها: {h(p.hostname)} (يُسمح فقط بـ api.wathq.sa عبر HTTPS)"
    headers = {"apiKey": key, "Accept": "application/json",
               "Accept-Encoding": "gzip, deflate", "User-Agent": "LegalTracks-Compliance/10.13"}
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as r:
            body = r.read(20 * 1024 * 1024)
            enc = (r.headers.get("Content-Encoding") or "").lower()
            ctype = (r.headers.get("Content-Type") or "").split(";")[0].strip()
            # فك الضغط إن كان الرد مضغوطاً (urllib لا يفكه تلقائياً)
            if "gzip" in enc:
                try:
                    import gzip as _gz
                    body = _gz.decompress(body)
                except Exception:
                    pass
            elif "deflate" in enc:
                try:
                    import zlib as _zl
                    try:
                        body = _zl.decompress(body)
                    except Exception:
                        body = _zl.decompress(body, -_zl.MAX_WBITS)
                except Exception:
                    pass
            # كشف الحاويات الشائعة عبر التوقيع (لو لم تُذكر في الترويسة)
            if body[:2] == b"\x1f\x8b":  # gzip magic
                try:
                    import gzip as _gz
                    body = _gz.decompress(body)
                    enc = enc or "gzip"
                except Exception:
                    pass
            txt = body.decode("utf-8", "replace")
            try:
                return r.status, json.loads(txt), "نجح"
            except Exception:
                sig = body[:8].hex()
                kind = "PDF" if body[:4] == b"%PDF" else ("ZIP/Office" if body[:2] == b"PK" else "ثنائي/غير JSON")
                return r.status, None, f"الرد ليس JSON — النوع: {ctype or '?'} | الترميز: {enc or 'عادي'} | التصنيف: {kind} | التوقيع: {sig} | مقتطف: {txt[:200]}"
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = e.read(4000).decode("utf-8", "replace")
        except Exception:
            pass
        # 401/403 = مفتاح/اشتراك؛ 404 = رقم غير موجود أو مسار خاطئ؛ 429 = تجاوز الحصة
        return e.code, None, f"HTTP {e.code}: {detail[:1500]}"
    except Exception as e:
        return 0, None, f"تعذر الاتصال: {type(e).__name__}: {str(e)[:300]}"


def wathq_cr_fullinfo(cr_number: str) -> Tuple[int, Any, str]:
    cr = "".join(ch for ch in (cr_number or "") if ch.isdigit())
    if not cr:
        return 0, None, "رقم السجل التجاري غير صالح"
    return _wathq_get(f"{_WATHQ_APIS['cr']['base']}/fullinfo/{cr}", "cr")


def wathq_cr_beneficiary(cr_number: str) -> Tuple[int, Any, str]:
    cr = "".join(ch for ch in (cr_number or "") if ch.isdigit())
    if not cr:
        return 0, None, "رقم السجل التجاري غير صالح"
    return _wathq_get(f"{_WATHQ_APIS['crb']['base']}/{cr}", "crb")


def wathq_national_address(cr_number: str) -> Tuple[int, Any, str]:
    cr = "".join(ch for ch in (cr_number or "") if ch.isdigit())
    if not cr:
        return 0, None, "رقم غير صالح"
    return _wathq_get(f"{_WATHQ_APIS['address']['base']}/{cr}", "address")


def wathq_company_contract(cr_number: str) -> Tuple[int, Any, str]:
    # عقود الشركات: يُستعلم بالرقم الوطني الموحّد (700). يعيد entity + شركاء التأسيس.
    cr = "".join(ch for ch in (cr_number or "") if ch.isdigit())
    if not cr:
        return 0, None, "رقم غير صالح"
    return _wathq_get(f"{_WATHQ_APIS['company']['base']}/info/{cr}", "company")


def wathq_investor(cr_number: str) -> Tuple[int, Any, str]:
    # مستثمر وزارة الاستثمار: entityInfo + parties (الشركاء الأجانب وجنسياتهم ونسبهم).
    cr = "".join(ch for ch in (cr_number or "") if ch.isdigit())
    if not cr:
        return 0, None, "رقم غير صالح"
    return _wathq_get(f"{_WATHQ_APIS['investor']['base']}/fullinfo/{cr}", "investor")


def wathq_real_estate(id_number: str) -> Tuple[int, Any, str]:
    cr = "".join(ch for ch in (id_number or "") if ch.isdigit())
    if not cr:
        return 0, None, "رقم غير صالح"
    return _wathq_get(f"{_WATHQ_APIS['realestate']['base']}/{cr}", "realestate")


_WATHQ_TESTERS = {"cr": wathq_cr_fullinfo, "crb": wathq_cr_beneficiary, "address": wathq_national_address,
                  "company": wathq_company_contract, "investor": wathq_investor, "realestate": wathq_real_estate}


def _wathq_selftest(cr_number: str, app_code: str = "cr", ip: str = "") -> Dict[str, Any]:
    """تشخيص للقراءة فقط لتطبيق واثق محدد: يتحقق من المفتاح والوصول ويعيد الاستجابة الخام."""
    if app_code not in _WATHQ_APIS:
        app_code = "cr"
    status, data, msg = _WATHQ_TESTERS[app_code](cr_number)
    ok = status == 200  # الاتصال والمصادقة نجحا؛ قد يكون الرد فارغاً (لا بيانات لهذا الرقم)
    try:
        with db() as con:
            ensure_schema(con)
            audit(con, "wathq_selftest", "wathq", 0,
                  json.dumps({"app": app_code, "cr": "".join(c for c in (cr_number or "") if c.isdigit()),
                              "status": status, "ok": ok}, ensure_ascii=False), ip)
            con.commit()
    except Exception:
        pass
    return {"app": app_code, "configured": _wathq_configured(app_code),
            "key": _wathq_mask(_wathq_key(app_code)), "base_url": WATHQ_BASE_URL,
            "http_status": status, "ok": ok, "message": msg, "raw": data}


def wathq_selftest_page(cr_number: str = "", app_code: str = "cr", message: str = "") -> bytes:
    cr = (cr_number or "").strip()
    if app_code not in _WATHQ_APIS:
        app_code = "cr"
    # جدول حالة مفاتيح كل التطبيقات
    _status_parts = []
    for code, a in _WATHQ_APIS.items():
        badge = "<span class='badge ok'>مضبوط</span>" if _wathq_configured(code) else "<span class='badge danger'>غير مضبوط</span>"
        _status_parts.append(
            f"<tr><td>{h(a['label'])}</td><td dir='ltr'>{h(a['key_env'])}</td>"
            f"<td>{badge}</td><td dir='ltr'>{h(_wathq_mask(_wathq_key(code)))}</td></tr>")
    status_rows = "".join(_status_parts)
    result_html = ""
    if cr:
        res = _wathq_selftest(cr, app_code)
        raw = json.dumps(res.get("raw"), ensure_ascii=False, indent=2) if res.get("raw") is not None else "(لا توجد استجابة JSON)"
        state_cls = "success" if res["ok"] else "error"
        result_html = f"""
<div class="card"><h3>نتيجة الاختبار — {h(_WATHQ_APIS[app_code]['label'])}</h3>
<div class="{state_cls}">الحالة: {'نجح' if res['ok'] else 'لم ينجح'} — HTTP {h(res['http_status'])}{' — لا توجد بيانات لهذا الرقم في هذا التطبيق' if (res['ok'] and res['raw'] is None) else ''}</div>
{"<p class='notice'>الرقم المُدخل رقم سجل تجاري (1010…)؛ استخدم <b>الرقم الوطني الموحّد (700)</b> للسجلات النشطة والمعلّقة.</p>" if (res['http_status'] == 400 and '700' in (res['message'] or '')) else ""}
{"<p class='success small'>الاتصال والمصادقة ناجحان (المفتاح صحيح). ٤٠٤ = لا سجل لهذا الرقم في هذا التطبيق (جرّب رقم منشأة من النوع الصحيح — مثلاً منشأة استثمار أجنبي لتطبيق وزارة الاستثمار، أو شركة ذات مسؤولية محدودة لعقود الشركات).</p>" if res['http_status'] == 404 else ""}
{"<p class='notice'>٤٠٣ = المفتاح صحيح لكن باقة/منتج هذا التطبيق غير مفعّل (قد يكون <b>معلّقاً</b>) في لوحة واثق؛ فعّله/جدّده هناك ثم أعد المحاولة.</p>" if res['http_status'] == 403 else ""}
{"<p class='success small'>نجح الاتصال؛ ردّ الخادم فارغ لهذا الرقم — غالباً لأن نوع المنشأة لا يملك سجلاً في هذا التطبيق (مثال: شركة مساهمة ليس لها «عقد شركة»). جرّب رقم شركة ذات مسؤولية محدودة.</p>" if (res['ok'] and res['raw'] is None) else ""}
<table><tr><th>المفتاح</th><td>{h(res['key'])}</td></tr>
<tr><th>الرسالة</th><td dir="auto">{h(res['message'])}</td></tr></table>
<h4>الاستجابة الخام (لبناء الربط)</h4>
<pre dir="ltr" style="white-space:pre-wrap;max-height:420px;overflow:auto;background:#0d1b16;color:#e8f0ec;padding:12px;border-radius:8px">{h(raw)}</pre></div>"""
    banner = ("<div class='success'>يوجد مفتاح واثق واحد على الأقل مضبوط على الخادم.</div>" if _wathq_any_configured()
              else "<div class='error'>لم يُضبط أي مفتاح واثق بعد. لكل تطبيق مفتاحه الخاص — اضبط متغيرات البيئة على الخادم (راجع WATHQ_SETUP_AR.txt) ثم أعد تشغيل الخدمة.</div>")
    msg = f"<div class='success'>{h(message)}</div>" if message else ""
    app_opts = "".join(f"<option value='{code}' {'selected' if code == app_code else ''}>{h(a['label'])}</option>" for code, a in _WATHQ_APIS.items())
    body = f"""
<div class="card"><div class="section-title"><div><h2>اختبار الربط مع واثق</h2>
<p class="small">اختبار للقراءة فقط لكل تطبيق على حدة (لكل تطبيق مفتاحه). يعرض الاستجابة الخام لبناء الربط بدقة. لا يُخزَّن شيء في ملفات العملاء.</p></div></div>{banner}{msg}</div>
<div class="card"><h3>حالة مفاتيح التطبيقات</h3><div class="table-wrap"><table><thead><tr><th>التطبيق</th><th>متغير البيئة</th><th>الحالة</th><th>بصمة المفتاح</th></tr></thead><tbody>{status_rows}</tbody></table></div></div>
<div class="card"><form method="get" action="/wathq/selftest"><div class="grid">
<div><label>التطبيق</label><select name="app">{app_opts}</select></div>
<div><label>الرقم الوطني الموحّد (700) — للسجلات النشطة</label><input name="cr" value="{h(cr)}" placeholder="مثال: 700xxxxxxx"></div></div>
<button>اختبر الآن</button></form></div>
{result_html}"""
    return layout("اختبار واثق", body, "/production")


_get_pre_v1011 = AppHandler.do_GET

def _do_get_v1011(self: AppHandler) -> None:
    parsed = urlparse(self.path)
    if parsed.path != "/wathq/selftest":
        return _get_pre_v1011(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    if (user.get("role") or "") not in ("admin", "compliance"):
        return self._send(layout("غير مصرح", "<div class='error'>اختبار واثق يتطلب دور مدير أو مسؤول امتثال.</div>", "/production"), 403)
    q = parse_qs(parsed.query)
    cr = (q.get("cr", [""])[0] or "").strip()
    app_code = (q.get("app", ["cr"])[0] or "cr").strip()
    try:
        return self._send(wathq_selftest_page(cr, app_code))
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر تنفيذ الاختبار: {h(exc)}</div>", "/production"), 500)

AppHandler.do_GET = _do_get_v1011



# =====================================================================
# V10.10 — Automated refresh of official sanctions lists.
# The manual direct-update per source already exists (direct_update_list, SSRF-safe).
# This layer adds: (1) refresh_official_lists() iterating the registry with per-source
# failure isolation; (2) CLI --refresh-lists for scheduling; (3) a non-blocking
# "refresh all" background button on /lists. A dead source never affects the others,
# and a failed fetch never touches the active list (direct_update_list logs + raises).
# =====================================================================

# القوائم المُدرجة في التحديث الآلي (الوطنية + الأممية المعتمدة سعودياً). لا تشمل OFAC/EU
# افتراضياً — قرار مستقل بسبب الحجم الكبير وضجيج الإيجابيات الكاذبة لمكتب محاماة سعودي.
_AUTO_REFRESH_CODES = ["NATIONAL_1373", "UN_TF_1267_ALQAIDA", "UN_TF_1988_TALIBAN",
                       "UN_PF_1718_DPRK", "UN_PF_1737_IRAN"]


def refresh_official_lists(ip: str = "", only_codes: Optional[List[str]] = None) -> Dict[str, Any]:
    """يحدّث كل مصدر رسمي عبر direct_update_list مع عزل فشل كل مصدر عن البقية.
    يُستدعى من CLI (--refresh-lists) أو من زر خلفي. لا يوقف بقية القوائم إن فشل مصدر."""
    codes = only_codes or _AUTO_REFRESH_CODES
    valid = {s["code"] for s in OFFICIAL_LIST_SOURCES}
    results: List[Dict[str, str]] = []
    ok = 0
    fail = 0
    for code in codes:
        if code not in valid:
            results.append({"code": code, "status": "skipped", "message": "غير مسجل في المصادر الرسمية"})
            continue
        src = next(s for s in OFFICIAL_LIST_SOURCES if s["code"] == code)
        fields = {"list_name": [code], "list_type": [src.get("list_type", "TF")],
                  "source_url": [src.get("download_url", "")]}
        try:
            msg = direct_update_list(fields, ip)
            results.append({"code": code, "status": "success", "message": msg})
            ok += 1
        except Exception as exc:  # direct_update_list logs the failure + leaves active list intact
            results.append({"code": code, "status": "failed", "message": str(exc)[:300]})
            fail += 1
    summary = {"ok": ok, "failed": fail, "total": len(codes), "results": results}
    try:
        with db() as con:
            ensure_schema(con)
            audit(con, "official_lists_refresh", "sanctions", 0,
                  json.dumps({"ok": ok, "failed": fail, "total": len(codes)}, ensure_ascii=False), ip)
            con.commit()
    except Exception:
        pass
    return summary


# --- non-blocking "refresh all" button on /lists (admin/compliance) ---
_lists_page_pre_v1010 = lists_page

def lists_page(message: str = "") -> bytes:  # type: ignore[override]
    html = _lists_page_pre_v1010(message).decode("utf-8")
    btn = ("<h3>المصادر الرسمية</h3>"
           "<form method='post' action='/lists/refresh-all' style='display:inline;margin-inline-start:12px'>"
           "<button class='btn warn' onclick=\"return confirm('سيبدأ تحديث جميع القوائم الرسمية (الوطنية + الأممية) من مصادرها مباشرةً في الخلفية. متابعة؟')\">"
           "تحديث جميع القوائم الآن (خلفي)</button></form>")
    html = html.replace("<h3>المصادر الرسمية</h3>", btn, 1)
    return html.encode("utf-8")


_post_pre_v1010 = AppHandler.do_POST

def _do_post_v1010(self: AppHandler) -> None:
    if urlparse(self.path).path != "/lists/refresh-all":
        return _post_pre_v1010(self)
    user = _v1512_ctx(self)
    if not user:
        return _auth_send_redirect(self, "/login")
    if user.get("must_change_password"):
        return _auth_send_redirect(self, "/account")
    if (user.get("role") or "") not in ("admin", "compliance"):
        return self._send(layout("غير مصرح", "<div class='error'>تحديث القوائم يتطلب دور مدير أو مسؤول امتثال.</div>", "/lists"), 403)
    try:
        _fields, _files, ip = _parse_request_fields(self)
        uname = str(user.get("user_name") or "")
        enqueue_job("تحديث جميع القوائم الرسمية من مصادرها", lambda i=ip: refresh_official_lists(i), uname, ip)
        return send_redirect(self, "/lists")
    except Exception as exc:
        return self._send(layout("خطأ", f"<div class='error'>تعذر بدء التحديث: {h(exc)}</div>", "/lists"), 500)

AppHandler.do_POST = _do_post_v1010


# =====================================================================
# V10.16 — توثيق واثق (سلالة البيانات): مؤشر واضح في ملف العميل يبيّن أن بياناته جُلبت من واثق،
# ماذا جُلب ومتى وبواسطة من. يعالج غياب أي دلالة على مصدر البيانات (رسمي/يدوي) للمفتش.
# =====================================================================
_ensure_schema_pre_v1016 = ensure_schema

def ensure_schema(con: sqlite3.Connection, force: bool = False) -> None:  # type: ignore[override]
    _ensure_schema_pre_v1016(con, force)
    con.execute("""CREATE TABLE IF NOT EXISTS wathq_provenance(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        client_id INTEGER NOT NULL,
        cr_used TEXT,
        applied_by TEXT NOT NULL DEFAULT '',
        fields_updated TEXT NOT NULL DEFAULT '[]',
        parties_added INTEGER NOT NULL DEFAULT 0,
        status_text TEXT,
        source_label TEXT NOT NULL DEFAULT 'واثق — السجل التجاري'
    )""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_wathq_prov_client ON wathq_provenance(client_id, id)")
    # علم مصدر غير قابل لتحرير المستخدم على الأطراف المرتبطة: يفصل «مصدرها واثق» عن حقل
    # الملاحظات الحر (الذي يمكن لأي موظف كتابة «من واثق» فيه). لا تُبنى بطاقة التوثيق إلا عليه.
    try:
        rp_cols = [r[1] for r in con.execute("PRAGMA table_info(related_parties)").fetchall()]
        if rp_cols and "source" not in rp_cols:
            con.execute("ALTER TABLE related_parties ADD COLUMN source TEXT NOT NULL DEFAULT 'manual'")
            # ترقية لمرة واحدة: صفوف كتبها مُستورد واثق تحمل توقيعه الدقيق («من واثق … ؛ الهوية:»).
            # الملاحظة المكتوبة يدوياً لا تحمل ذيل «؛ الهوية:»، فتبقى manual. هذا يحفظ التوثيق
            # للعملاء المجلوبين فعلاً دون الوثوق بمجرد عبارة «من واثق» المكتوبة يدوياً.
            con.execute("UPDATE related_parties SET source='wathq' WHERE source='manual' AND notes LIKE 'من واثق%؛ الهوية:%'")
    except Exception:
        pass


def _wathq_record_provenance(con: sqlite3.Connection, client_id: int, cr: str, m: Dict[str, Any], added: int, actor: str) -> None:
    fields = []
    if m.get("legal_name"): fields.append("الاسم النظامي")
    if m.get("unified_number"): fields.append("الرقم الموحّد (700)")
    if m.get("registration_number"): fields.append("رقم السجل التجاري")
    if m.get("status_text"): fields.append("الحالة النظامية")
    if m.get("form_text"): fields.append("الشكل النظامي")
    if m.get("city_text"): fields.append("المدينة")
    if m.get("capital_text"): fields.append("رأس المال")
    if m.get("activities_text"): fields.append("الأنشطة")
    con.execute(
        "INSERT INTO wathq_provenance(created_at, client_id, cr_used, applied_by, fields_updated, parties_added, status_text) VALUES(?,?,?,?,?,?,?)",
        (now_iso(), int(client_id), cr, actor, json.dumps(fields, ensure_ascii=False), int(added), m.get("status_text", "")))


def _wathq_provenance_card(client_id: int) -> str:
    try:
        with db() as con:
            ensure_schema(con)
            pr = con.execute("SELECT * FROM wathq_provenance WHERE client_id=? ORDER BY id DESC LIMIT 1", (int(client_id),)).fetchone()
            # مصدر الأطراف = العلم غير القابل للتحرير (source='wathq') لا حقل الملاحظات الحر
            wparties = con.execute(
                "SELECT full_name, id_number, party_role FROM related_parties WHERE parent_type='client' AND parent_id=? AND COALESCE(source,'')='wathq' ORDER BY id DESC",
                (int(client_id),)).fetchall()
    except Exception:
        return ""
    if not pr and not wparties:
        return ("<div class=\"card\"><h3>توثيق واثق (مصدر البيانات)</h3>"
                "<p class=\"small\">ℹ️ لم تُجلب بيانات هذا العميل من منصة واثق الرسمية بعد — البيانات الحالية مُدخلة يدوياً. "
                "استخدم زر «جلب من واثق» أدناه للتوثيق الرسمي.</p></div>")
    pcount = len(wparties)
    prows = "".join(
        f"<tr><td dir='auto'>{h(p['full_name'])}</td><td dir='ltr'>{h(p['id_number'] or '—')}</td><td>{h(p['party_role'] or '')}</td></tr>"
        for p in wparties) or "<tr><td colspan='3'>لا يوجد</td></tr>"
    parties_block = (
        f"<p class=\"small\" style=\"margin-top:8px\">الأطراف المرتبطة المسجّل مصدرها «واثق» ({pcount}):</p>"
        f"<div class=\"table-wrap\"><table><thead><tr><th>الاسم</th><th>رقم الهوية</th><th>الصفة</th></tr></thead><tbody>{prows}</tbody></table></div>"
    ) if wparties else ""
    if pr:
        # جلب موثّق بسجل بنيوي كامل (التاريخ/المنفّذ/رقم الاستعلام/الحقول)
        when = pr["created_at"][:16].replace("T", " ")
        by = pr["applied_by"] or "-"
        cr = pr["cr_used"] or "-"
        try:
            flds = json.loads(pr["fields_updated"]) if pr["fields_updated"] else []
        except Exception:
            flds = []
        flds_html = "، ".join(h(x) for x in flds) or "—"
        meta = (
            f"<table><tr><th>آخر جلب من واثق</th><td dir=\"ltr\">{h(when)}</td><th>بواسطة</th><td dir=\"auto\">{h(by)}</td></tr>"
            f"<tr><th>رقم الاستعلام</th><td dir=\"ltr\">{h(cr)}</td><th>الحالة في واثق</th><td dir=\"auto\">{h((pr['status_text'] or '') or '—')}</td></tr>"
            f"<tr><th>الحقول المجلوبة من واثق</th><td colspan=\"3\" dir=\"auto\">{flds_html}</td></tr></table>"
        )
        footer = "البيانات أعلاه مستمدة من منصة واثق الرسمية بتاريخ الجلب المذكور؛ ما عداها مُدخل يدوياً. كل عملية جلب مُقيَّدة في سجل التدقيق."
    else:
        # أطراف مصدرها واثق موجودة لكن دون سجل جلب بنيوي (جلب سابق لتفعيل هذه الميزة)
        meta = ("<p class=\"small\">أطرافٌ مصدرها المُسجَّل «واثق» موثّقة في هذا الملف، لكن تفاصيل آخر عملية جلب "
                "(التاريخ/المنفّذ/رقم الاستعلام) غير مُسجَّلة بنيوياً لأن الجلب سبق تفعيل هذه الميزة. "
                "أعد «الجلب من واثق» لتسجيل التفاصيل الكاملة.</p>")
        footer = "الأطراف أدناه مصدرها المُسجَّل منصة واثق الرسمية؛ ما عداها مُدخل يدوياً."
    return f"""
<div class="card" style="border-right:6px solid var(--ltb-teal,#2E8C73)">
<div class="section-title"><h3>✅ توثيق واثق (مصدر البيانات الرسمي)</h3>
<span class="badge ok">موثّقة من واثق</span></div>
{meta}
{parties_block}
<p class="small">{footer}</p></div>"""


_client_detail_pre_v1016 = client_detail

def client_detail(client_id: int) -> bytes:  # type: ignore[override]
    raw = _client_detail_pre_v1016(client_id).decode("utf-8")
    try:
        card = _wathq_provenance_card(client_id)
        if card:
            marker = "<h3>واثق — السجل التجاري الرسمي</h3>"
            if marker in raw:
                # ضع بطاقة التوثيق أعلى بطاقة «جلب من واثق» مباشرةً (أظهر المصدر قبل زر الجلب)
                anchor = raw.rfind("<div class=\"card\">", 0, raw.find(marker))
                if anchor != -1:
                    raw = raw[:anchor] + card + raw[anchor:]
                else:
                    raw = raw.replace("</main>", card + "</main>", 1)
            elif "</main>" in raw:
                raw = raw.replace("</main>", card + "</main>", 1)
            else:
                raw = raw + card
    except Exception:
        pass
    return raw.encode("utf-8")


APP_VERSION = "V10.16.0 - Wathq data-provenance indicator in client files (source lineage card)"


# =====================================================================
# V10.17 — بيانات السجل التجاري المنظَّمة (من واثق) + تغذية المخاطر + تنظيف الملاحظات.
# بدل حشر (الحالة/الشكل/المدينة/رأس المال/الأنشطة/التصفية) في حقل الملاحظات، تُحفظ منظَّمة
# في جدول client_registry (لقطة واحدة لكل عميل، تُحدَّث عند كل جلب)، وتُعرض في بطاقة واضحة
# بملف العميل، وتُغذّي إشارات المخاطر (تحت التصفية ← مرتفع؛ أنشطة عالية المخاطر ← إشارة)
# دون المساس بمستوى المخاطر اليدوي. وتُنظَّف كتل واثق المكررة من الملاحظات عند إعادة الجلب.
# =====================================================================
_ensure_schema_pre_v1017 = ensure_schema

def ensure_schema(con: sqlite3.Connection, force: bool = False) -> None:  # type: ignore[override]
    _ensure_schema_pre_v1017(con, force)
    con.execute("""CREATE TABLE IF NOT EXISTS client_registry(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id INTEGER NOT NULL UNIQUE,
        cr_used TEXT,
        cr_status TEXT,
        legal_form TEXT,
        city TEXT,
        capital_text TEXT,
        activities TEXT,
        in_liquidation INTEGER,
        fetched_at TEXT NOT NULL,
        fetched_by TEXT
    )""")


# قطاعات عالية المخاطر (DNFBP وفق FATF/الهيئة) — تُشتق من أنشطة السجل التجاري.
# قائمة مُنتقاة عمداً لتفادي إغراق منشأة صغيرة بإنذارات: (رمز، شدة، وصف، كلمات مفتاحية).
# المطابقة تجزئية بعد توحيد الهمزات/الألف (ضرورية للتصريف العربي: العقارية/العقارات…)،
# مع تفادي فخاخ التجزئة المعروفة: أُسقطت «عقار» (تطابق «عقاقير») و«وقف» (تطابق «مواقف»).
_WATHQ_ACTIVITY_RISK = [
    ("WATHQ_ACT_REALESTATE", "high", "نشاط عقاري (قطاع مرتفع المخاطر)",
     ["عقاري", "عقارات", "أراضي", "البيع على الخارطة"]),
    ("WATHQ_ACT_MSB", "high", "خدمات مالية/صرافة/تحويل أموال",
     ["صرافة", "حوالات", "تحويل الأموال", "تحويل أموال"]),
    ("WATHQ_ACT_PRECIOUS", "high", "معادن ثمينة/أحجار كريمة/مجوهرات",
     ["مجوهرات", "معادن ثمينة", "أحجار كريمة", "سبائك ذهب", "تجارة الذهب"]),
    ("WATHQ_ACT_VASP", "high", "أصول افتراضية/عملات رقمية",
     ["عملات رقمية", "عملات مشفرة", "أصول افتراضية", "أصول مشفرة"]),
    ("WATHQ_ACT_NPO", "medium", "كيان/نشاط غير ربحي (مخاطر تمويل إرهاب)",
     ["جمعية خيرية", "الأعمال الخيرية", "أوقاف", "تبرعات"]),
    ("WATHQ_ACT_FININT", "high", "وساطة مالية/تمويل",
     ["وساطة مالية", "تمويل جماعي", "تمويل استهلاكي", "التمويل الأصغر"]),
]
_WATHQ_ACTIVITY_CODES = tuple(x[0] for x in _WATHQ_ACTIVITY_RISK) + ("WATHQ_LIQUIDATION",)

# توقيع كتلة واثق الآلية في الملاحظات: تنتهي دائماً بـ « | مصدر: واثق YYYY-MM-DD».
# نُطابق على البادئة « | مصدر: واثق» تحديداً كي لا نمسّ سطر ملاحظة يدوية مثل «المصدر: واثق».
_WATHQ_BLOCK_SIG = re.compile(r"\|\s*مصدر:\s*واثق")


def _wathq_norm_act(s: Optional[str]) -> str:
    """توحيد خفيف (همزات/ألف مقصورة/تطويل) للمطابقة التجزئية على أسماء الأنشطة."""
    s = s or ""
    for a in ("أ", "إ", "آ"):
        s = s.replace(a, "ا")
    return s.replace("ى", "ي").replace("ـ", "")


def _wathq_clean_client_notes(notes: Optional[str]) -> str:
    """يزيل كتل واثق المحشورة سابقاً (كل سطر يحمل توقيع الكتلة الآلية « | مصدر: واثق»)
    مع الإبقاء التام على الملاحظات اليدوية — بما فيها سطر يدوي يذكر «المصدر: واثق» (لا بادئة «|»)."""
    if not notes:
        return notes or ""
    kept = [ln for ln in str(notes).split("\n") if not _WATHQ_BLOCK_SIG.search(ln)]
    return "\n".join(kept).strip()


def _wathq_upsert_registry(con: sqlite3.Connection, client_id: int, m: Dict[str, Any], cr: str, actor: str) -> None:
    con.execute(
        "INSERT INTO client_registry(client_id, cr_used, cr_status, legal_form, city, capital_text, activities, in_liquidation, fetched_at, fetched_by) "
        "VALUES(?,?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(client_id) DO UPDATE SET cr_used=excluded.cr_used, cr_status=excluded.cr_status, "
        "legal_form=excluded.legal_form, city=excluded.city, capital_text=excluded.capital_text, "
        "activities=excluded.activities, in_liquidation=excluded.in_liquidation, "
        "fetched_at=excluded.fetched_at, fetched_by=excluded.fetched_by",
        (int(client_id), cr, m.get("status_text", ""), m.get("form_text", ""), m.get("city_text", ""),
         m.get("capital_text", ""), m.get("activities_text", ""),
         1 if (m.get("in_liquidation") or ("تصفية" in _wathq_norm_act(m.get("status_text", "")))) else 0,
         now_iso(), actor or ""))


_evaluate_client_risk_pre_v1017 = evaluate_client_risk

def evaluate_client_risk(con: sqlite3.Connection, client_id: int) -> None:  # type: ignore[override]
    _evaluate_client_risk_pre_v1017(con, int(client_id))
    # إشارات مخاطر مشتقة من لقطة السجل الرسمية — تُضاف كأعلام (لا تمسّ مستوى المخاطر اليدوي)،
    # وتُعاد اشتقاقها كل مرة (شفاء ذاتي: تختفي إن زالت التصفية أو تغيّر النشاط عند إعادة الجلب).
    try:
        reg = con.execute("SELECT in_liquidation, activities FROM client_registry WHERE client_id=?", (int(client_id),)).fetchone()
    except Exception:
        reg = None
    if not reg:
        return
    if reg["in_liquidation"] == 1:
        _add_risk_flag(con, "client", int(client_id), "WATHQ_LIQUIDATION",
                       "الكيان تحت التصفية (سجل واثق الرسمي)", "high",
                       "كيان في طور التصفية — عناية معززة والتحقق من استمرار العلاقة والغرض التجاري")
    acts_n = _wathq_norm_act(reg["activities"] or "")
    if acts_n:
        for code, sev, label, kws in _WATHQ_ACTIVITY_RISK:
            if any(_wathq_norm_act(k) in acts_n for k in kws):
                _add_risk_flag(con, "client", int(client_id), code,
                               label + " — من أنشطة السجل التجاري (واثق)", sev,
                               "قطاع مرتفع المخاطر وفق مؤشرات FATF/الهيئة — يستوجب عناية معززة وفهم الغرض التجاري")


def _wathq_registry_card(client_id: int) -> str:
    try:
        with db() as con:
            ensure_schema(con)
            r = con.execute("SELECT * FROM client_registry WHERE client_id=?", (int(client_id),)).fetchone()
    except Exception:
        return ""
    if not r:
        return ""
    liq = r["in_liquidation"]
    if liq == 1:
        liq_html = "<span class=\"badge danger\">نعم — تحت التصفية</span>"
    elif liq == 0:
        liq_html = "<span class=\"badge ok\">لا</span>"
    else:
        liq_html = "غير معروف"
    act_list = [a.strip() for a in (r["activities"] or "").split("؛") if a.strip()]
    if act_list:
        acts_html = ("<details><summary style=\"cursor:pointer;font-weight:800\">عرض الأنشطة (" + str(len(act_list)) + ")</summary>"
                     "<ul style=\"margin:8px 0\">" + "".join("<li>" + h(a) + "</li>" for a in act_list) + "</ul></details>")
    else:
        acts_html = "—"
    when = (r["fetched_at"] or "")[:16].replace("T", " ")
    return ("<div class=\"card\" style=\"border-right:6px solid var(--ltb-gold700,#B49670)\">"
            "<div class=\"section-title\"><h3>بيانات السجل التجاري (من واثق)</h3>"
            "<span class=\"badge ok\">مصدر رسمي</span></div>"
            "<div class=\"table-wrap\"><table>"
            "<tr><th>الحالة في واثق</th><td dir=\"auto\">" + h(r["cr_status"] or "—") + "</td>"
            "<th>الشكل النظامي</th><td dir=\"auto\">" + h(r["legal_form"] or "—") + "</td></tr>"
            "<tr><th>المدينة</th><td dir=\"auto\">" + h(r["city"] or "—") + "</td>"
            "<th>رأس المال</th><td dir=\"auto\">" + h(r["capital_text"] or "—") + "</td></tr>"
            "<tr><th>تحت التصفية</th><td dir=\"auto\">" + liq_html + "</td>"
            "<th>تاريخ الجلب من واثق</th><td dir=\"ltr\">" + h(when) + "</td></tr>"
            "<tr><th>الأنشطة</th><td colspan=\"3\" dir=\"auto\">" + acts_html + "</td></tr>"
            "</table></div>"
            "<p class=\"small\">مستمدة من منصة واثق الرسمية بتاريخ الجلب المذكور؛ إشارات المخاطر المشتقة منها تظهر ضمن أعلام مخاطر العميل.</p></div>")


_client_detail_pre_v1017 = client_detail

def client_detail(client_id: int) -> bytes:  # type: ignore[override]
    raw = _client_detail_pre_v1017(client_id).decode("utf-8")
    try:
        card = _wathq_registry_card(client_id)
        if card:
            # ضع بطاقة بيانات السجل أعلى بطاقة «توثيق واثق» (البيانات ← مصدرها ← زر الجلب)
            pos = raw.find("توثيق واثق")
            if pos != -1:
                cstart = raw.rfind("<div class=\"card\"", 0, pos)
                if cstart != -1:
                    raw = raw[:cstart] + card + raw[cstart:]
                else:
                    raw = raw.replace("</main>", card + "</main>", 1)
            elif "</main>" in raw:
                raw = raw.replace("</main>", card + "</main>", 1)
            else:
                raw = raw + card
    except Exception:
        pass
    return raw.encode("utf-8")


def refetch_wathq_clients(ip: str = "cli") -> Dict[str, Any]:
    """إعادة جلب مجمّعة للعملاء الذين سبق جلبهم من واثق: يملأ client_registry المنظَّم
    وينظّف كتل واثق من ملاحظاتهم. يُستخدم مرة واحدة بعد ترقية V10.17 (يتطلب مفاتيح واثق)."""
    with db() as con:
        ensure_schema(con)
        ids = set()
        for row in con.execute("SELECT DISTINCT client_id FROM wathq_provenance"):
            ids.add(int(row[0]))
        for row in con.execute("SELECT DISTINCT parent_id FROM related_parties WHERE parent_type='client' AND COALESCE(source,'')='wathq'"):
            ids.add(int(row[0]))
        for row in con.execute("SELECT id FROM clients WHERE notes LIKE '%مصدر: واثق%'"):
            ids.add(int(row[0]))
    ok, fail, failed_ids = 0, 0, []
    # نسبة العملية إلى فاعل واضح في سجلّي التوثيق/التدقيق بدل فاعل فارغ (خارج سياق HTTP)
    _orig_auth = _auth_current_user
    globals()["_auth_current_user"] = lambda: {"user_name": "ترحيل V10.17 (إعادة جلب مجمّعة)", "role": "system"}
    try:
        for cid in sorted(ids):
            try:
                wathq_apply({"client_id": [str(cid)], "import_parties": ["1"]}, ip)
                ok += 1
            except Exception:
                fail += 1
                failed_ids.append(cid)
    finally:
        globals()["_auth_current_user"] = _orig_auth
    return {"clients": len(ids), "ok": ok, "fail": fail, "failed_ids": failed_ids}


APP_VERSION = "V10.17.0 - Structured commercial-registry snapshot (Wathq) + risk feed + notes cleanup"


# =====================================================================
# V10.18 — التصنيف الواعي بالمقعد للفحص الداخلي: «التعارض الداخلي» الحقيقي هو تقاطع جهة
# الموكِّل مع جهة الطرف المقابل عبر الملفات. أما الشخص نفسه في مقعد العميل بأكثر من ملف
# (مباشرة أو كطرف مرتبط) بهوية مؤكدة (رقم هوية/سجل/700) فيُوثَّق «ارتباطاً داخلياً» بحالة
# معلوماتية (known_relationship) — يبقى ظاهراً في السجل ولا يُعامل تعارض خصومة.
# التشابه الاسمي بلا هوية مؤكدة يبقى تنبيهاً (قد يكون شخصين مختلفين أو ازدواج سجلات).
# =====================================================================

def _internal_ids_confirmed(sub: Dict[str, Any], ent: Dict[str, Any]) -> bool:
    """هوية مؤكدة بين سجلّين داخليين: تساوي رقم الهوية أو السجل التجاري أو الرقم الموحد (700)
    بعد توحيد الصيغة. تطابق الاسم التام وحده (100) لا يُعد هوية مؤكدة — قد يتشابه اسمان.
    V10.18 (مراجعة عدائية): تساوي نصوص الحشو («لا يوجد»/«بدون»/«0000000000») ليس هوية —
    يُشترط أن تكون القيمة معرّفاً حقيقياً: لاتينية/أرقام فقط، تحوي رقماً، وليست محرفاً مكرراً."""
    for a, b in ((sub.get("id_number"), ent.get("id_number")),
                 (sub.get("registration_number"), ent.get("registration_number")),
                 (sub.get("unified_number"), ent.get("unified_number"))):
        na = normalize_identifier(str(a or ""))
        nb = normalize_identifier(str(b or ""))
        if not (na and nb and len(na) >= 4 and na == nb):
            continue
        if not re.fullmatch(r"[A-Z0-9]+", na):
            continue  # يحوي أحرفاً عربية = نص حشو وليس رقماً مميزاً
        if not re.search(r"[0-9]", na):
            continue  # معرّف حقيقي يحمل رقماً واحداً على الأقل
        if len(set(na)) <= 1:
            continue  # حشو مكرر مثل 0000000000
        return True
    return False


def _internal_names_consistent(name_a: str, name_b: str, cat_a: str = "", cat_b: str = "") -> bool:
    """اتساق الاسمين لاعتبار السجلّين شخصاً/كياناً واحداً — قاعدة بنيوية صارمة قابلة للتفسير:
    (1) تطابق تام بعد التوحيد، أو (2) الاسم الأقصر متوالية جزئية مرتبة من الأطول مع تطابق
    أول مقطع (الاسم الشخصي) وثاني مقطع (اسم الأب — يرفض تسلسل «سُمّي على جدّه») وآخر
    مقطع (العائلة/ذيل الاسم) معاً. يقبل «فيصل عبدالعزيز القاسم» مع «فيصل عبدالعزيز محمد
    القاسم» (الشخص نفسه بصيغة أقصر)، ويرفض أب/ابنة (يختلف الأول) وفرعَي «الأول/الثانية»
    (يختلف الأخير) والحفيد المسمّى على جدّه (يختلف اسم الأب) — فهوية متطابقة باسم غير
    متسق تبقى تنبيهاً مفتوحاً (خلل بيانات/انتحال محتمل)."""
    try:
        na, nb = normalize_name(name_a or ""), normalize_name(name_b or "")
        if not na or not nb:
            return False
        if na == nb:
            return True
        ta, tb = na.split(), nb.split()
        short, long_ = (ta, tb) if len(ta) <= len(tb) else (tb, ta)
        if len(short) < 2 or short[0] != long_[0] or short[-1] != long_[-1]:
            return False
        i = 0
        for tok in long_:
            if i < len(short) and tok == short[i]:
                i += 1
        if i != len(short):
            return False
        # V10.18 (مراجعة عدائية): ترسيخ اسم الأب — الصيغة الأقصر للشخص نفسه تحفظ أباه في
        # المقطع الثاني؛ الحفيد المسمّى على جدّه يُدخل أباه بينهما فيُرفض ويبقى تنبيهاً.
        if len(short) >= 3:
            return short[1] == long_[1]
        # اسمان بمقطعين (شخصي+عائلة): يُقبل فقط مقابل صيغة ثلاثية — السلاسل الأطول عالية
        # الالتباس بين الأقارب فتبقى تنبيهاً للمراجعة.
        return len(long_) <= 3
    except Exception:
        return False


def reclassify_sameseat_links(actor: str = "مسؤول الامتثال", ip: str = "cli") -> int:
    """ترحيل لمرة واحدة: إعادة تصنيف نتائج «تعارض داخلي» المفتوحة (تطابق مؤكد 100) التي
    يجلس طرفاها في مقعد العميل بملفين مختلفين وبهوية مؤكدة — إلى «ارتباط داخلي موثق»
    (known_relationship) بقرار موثق وتدقيق. لا يمسّ تقاطع المقعدين ولا التشابه الاسمي."""
    n = 0
    with db() as con:
        ensure_schema(con)
        rp_map, cp_map, _instr = _internal_context_maps(con)
        ids: Dict[Tuple[str, int], Dict[str, Any]] = {}
        for e in all_internal_entities(con):
            ids[(str(e.get("matched_entity_type")), int(e.get("matched_entity_id") or 0))] = e
        # V10.18 (مراجعة عدائية): لا يمسّ الترحيل أي صف قرّره إنسان — صفوف المحرك لا تحمل
        # decision_reason/reviewed_by أبداً؛ ما راجعه موظف امتثال وأبقاه مؤكداً يبقى كما قرّر.
        rows = con.execute(
            "SELECT id, subject_type, subject_id, subject_name, matched_entity_type, matched_entity_id, matched_name "
            "FROM screenings WHERE screening_scope='internal' AND status='confirmed_match' AND match_score>=100 "
            "AND COALESCE(decision_reason,'')='' AND COALESCE(reviewed_by,'')=''").fetchall()
        for r in rows:
            s_ctx = _relation_ctx(r["subject_type"], int(r["subject_id"]), rp_map, cp_map)
            e_ctx = _relation_ctx(r["matched_entity_type"], int(r["matched_entity_id"]), rp_map, cp_map)
            s_seat = "client" if s_ctx[0] else ("cp" if s_ctx[2] else None)
            e_seat = "client" if e_ctx[0] else ("cp" if e_ctx[2] else None)
            if s_seat != "client" or e_seat != "client":
                continue
            if s_ctx[0] and e_ctx[0] and s_ctx[0] == e_ctx[0]:
                continue  # نفس الملف — خارج النطاق
            se = ids.get((str(r["subject_type"]), int(r["subject_id"])))
            ee = ids.get((str(r["matched_entity_type"]), int(r["matched_entity_id"])))
            if not se or not ee or not _internal_ids_confirmed(se, ee):
                continue
            # نفس شرط المحرك: الاسمان متسقان أيضاً — هوية متطابقة باسم مغاير تبقى تنبيهاً
            if not _internal_names_consistent(r["subject_name"] or "", r["matched_name"] or "",
                                              str(se.get("entity_category") or ""), str(ee.get("entity_category") or "")):
                continue
            con.execute(
                "UPDATE screenings SET status=?, decision_reason=?, reviewed_by=?, reviewed_at=?, updated_at=? WHERE id=?",
                (_KNOWN_REL_STATUS,
                 "إعادة تصنيف موثقة (V10.18): الجانبان في مقعد العميل بملفين مختلفين وبهوية مؤكدة — "
                 "ارتباط داخلي موثق وليس تعارض خصومة؛ يبقى ظاهراً في السجل للمعلومية وتوحيد السجلات",
                 actor, now_iso(), now_iso(), int(r["id"])))
            n += 1
        audit(con, "reclassify_sameseat_links", "screening", 0,
              json.dumps({"reclassified": n, "criteria": "internal confirmed_match>=100, client-seat both sides, ids confirmed",
                          "actor": actor}, ensure_ascii=False), ip)
        con.commit()
    return n


APP_VERSION = "V10.18.0 - Seat-aware internal screening (client-seat linkage vs true adverse-seat conflict)"


def bulk_close_internal_weak(actor: str = "مسؤول الامتثال", ip: str = "cli") -> int:
    """إغلاق جماعي موثق للتعارضات الداخلية الضعيفة: تطابق محتمل داخلي بدرجة 83–89 (تشابه أسماء
    دون عتبة التشابه العالي 90) كنتيجة false_positive مع سبب موثق وقيد تدقيق. التطابقات المؤكدة
    (100%) والتشابه العالي (90–98%) لا تُمس. بعد الإغلاق يكبت المحرك إعادة إثارتها فيبقى الإغلاق دائماً.
    الشرط محصور بالدرجة 83–89 مطابقةً لنص المبرِّر (لا يُغلق ما دون 83 إن وُجد)."""
    reason = ("إغلاق جماعي موثق: تعارض داخلي — تطابق محتمل بدرجة تشابه أسماء 83–89% (دون عتبة "
              "التشابه العالي 90%، غير جوهري) — مراجعة مجمّعة معتمدة من مسؤول الامتثال؛ أُبقيت "
              "التطابقات المؤكدة (100%) والتشابه العالي (90–98%) مفتوحة للمراجعة.")
    where = "screening_scope='internal' AND status='potential_match' AND match_score BETWEEN 83 AND 89"
    with db() as con:
        ensure_schema(con)
        n = con.execute(f"SELECT COUNT(*) FROM screenings WHERE {where}").fetchone()[0]
        try:
            ru = retention_until_date()
            con.execute(f"UPDATE screenings SET status='false_positive', decision_reason=?, reviewed_by=?, reviewed_at=?, updated_at=?, retention_until=? WHERE {where}",
                        (reason, actor, now_iso(), now_iso(), ru))
        except Exception:
            con.execute(f"UPDATE screenings SET status='false_positive', decision_reason=?, reviewed_by=?, reviewed_at=?, updated_at=? WHERE {where}",
                        (reason, actor, now_iso(), now_iso()))
        audit(con, "bulk_close_internal_weak", "screening", 0,
              json.dumps({"closed": n, "criteria": "internal potential_match (83-89)", "actor": actor}, ensure_ascii=False), ip)
        con.commit()
    return n


def main(argv: Optional[List[str]] = None) -> int:
    # V10.5.6 fix: مخرجات CLI تحتوي مسارات ونصوصاً عربية؛ توحيد الترميز إلى UTF-8 يمنع
    # انهيار الأوامر (--maintenance/--init-db/--daily-screening) على وحدة تحكم Windows بترميز غير UTF-8.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
        except Exception:
            pass
    parser = argparse.ArgumentParser(description="Legal Tracks (مسارات الامتثال) KYC Compliance Edition V10")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8088)
    parser.add_argument("--init-db", action="store_true")
    parser.add_argument("--backup", action="store_true")
    parser.add_argument("--maintenance", action="store_true")
    parser.add_argument("--daily-screening", action="store_true")
    parser.add_argument("--refresh-lists", action="store_true", help="تحديث القوائم الرسمية من مصادرها ثم الخروج")
    parser.add_argument("--wathq-selftest", metavar="CR", help="اختبار الاتصال بواثق برقم سجل تجاري ثم الخروج")
    parser.add_argument("--close-internal-weak", action="store_true", help="إغلاق جماعي للتعارضات الداخلية الضعيفة (83–89) ثم الخروج")
    parser.add_argument("--refetch-wathq", action="store_true", help="إعادة جلب مجمّعة للعملاء المجلوبين سابقاً من واثق (يملأ السجل المنظَّم وينظّف الملاحظات) ثم الخروج")
    parser.add_argument("--reclassify-sameseat", action="store_true", help="إعادة تصنيف الارتباطات الداخلية بمقعد العميل (هوية مؤكدة، ملفان مختلفان) من تعارض مؤكد إلى ارتباط موثق ثم الخروج")
    args = parser.parse_args(argv)
    validate_environment_safety()
    if args.init_db:
        init_db(); print("DB initialized", DB_PATH); return 0
    if args.backup:
        print(create_backup("cli")); return 0
    if args.maintenance:
        print(json.dumps(maintenance_check(), ensure_ascii=False, indent=2)); return 0
    if args.daily_screening:
        print(json.dumps(run_daily_screening(), ensure_ascii=False, indent=2)); return 0
    if args.refresh_lists:
        init_db(); print(json.dumps(refresh_official_lists("cli"), ensure_ascii=False, indent=2)); return 0
    if args.close_internal_weak:
        init_db(); print(json.dumps({"closed_internal_weak": bulk_close_internal_weak("مسؤول الامتثال (إغلاق جماعي معتمد)", "cli")}, ensure_ascii=False)); return 0
    if args.refetch_wathq:
        init_db(); print(json.dumps(refetch_wathq_clients("cli"), ensure_ascii=False, indent=2)); return 0
    if args.reclassify_sameseat:
        init_db(); print(json.dumps({"reclassified_sameseat": reclassify_sameseat_links("مسؤول الامتثال (إعادة تصنيف معتمدة)", "cli")}, ensure_ascii=False)); return 0
    if args.wathq_selftest:
        init_db()
        res = _wathq_selftest(args.wathq_selftest, "cr", "cli")
        safe = {k: v for k, v in res.items() if k != "raw"}
        safe["raw_present"] = res.get("raw") is not None
        print(json.dumps(safe, ensure_ascii=False, indent=2))
        if res.get("raw") is not None:
            print("--- RAW ---")
            print(json.dumps(res["raw"], ensure_ascii=False, indent=2)[:4000])
        return 0
    run_server(args.host, args.port)
    return 0


# ── مسارات قانونية: سجل الوثائق الصادرة (ملف مستقل؛ يُزال بحذف هذين السطرين) ──
import contracts_register as _cr
_cr.install(globals())
# ── مسارات قانونية: إرفاق الموقَّع والرفع إلى أبواب الأتمتة (ملف مستقل؛ يُزال بحذف هذين السطرين) ──
import contracts_upload as _cu
_cu.install(globals())
# ── مسارات قانونية: تبويب «الاتفاقيات» وحالاته التجريبية (ملف مستقل؛ يُزال بحذف هذين السطرين) ──
import agreement_scenarios as _asc
_asc.install(globals())
# ── مسارات قانونية: طبقة الواجهة — الخطوط والهوية والنصوص وحقل الدولة (ملف مستقل؛ يُزال بحذف هذين السطرين) ──
import ui_layer as _uil
_uil.install(globals())
# ── مسارات قانونية: حارس سجل الاشتباه — البلاغ لكل موظف، والسجل للمخوَّلين (ملف مستقل؛ يُزال بحذف هذين السطرين) ──
import access_guard as _agd
_agd.install(globals())
# ── مسارات قانونية: فحص العميل بالمرحلتين معاً وموعد إعادة فحصه الدوري (ملف مستقل؛ يُزال بحذف هذين السطرين) ──
import screening_flow as _scf
_scf.install(globals())
# ── مسارات قانونية: زرّ «املأ ببيانات تجريبية» في نسخة التجربة وحدها — مؤقت (ملف مستقل؛ يُزال بحذف هذين السطرين) ──
import demo_fill as _dmf
_dmf.install(globals())
# ── مسارات قانونية: دخول تلقائي في نسخة التجربة وحدها — مؤقت (ملف مستقل؛ يُزال بحذف هذين السطرين) ──
import dev_autologin as _dal
_dal.install(globals())
# ── مسارات قانونية: نسخة المراجعة — ملاحظات المراجِعين وتعطيل ما لا يُسترجع — مؤقت (ملف مستقل؛ يُزال بحذف هذين السطرين) ──
import review_feedback as _rvf
_rvf.install(globals())

if __name__ == "__main__":
    raise SystemExit(main())

# -*- coding: utf-8 -*-
"""مسارات قانونية — زرّ «املأ ببيانات تجريبية» المؤقت (ملف مستقل؛ يُزال بحذف سطرَي الوصل في آخر app.py).

الغرض: أن يجرّب المالك نماذج الإدخال بسرعة في نسخة التجربة، فلا يكتب كل حقل بيده.
– لا يعمل في الإنتاج بحال: install() لا تضيف شيئاً إن كانت البيئة PRODUCTION (يثبته الاختبار).
– يُحقن في كل صفحة HTML فيها نموذج إرسال (post) سطرٌ واحد من الأنماط وسطرٌ واحد من الشيفرة قبل </body>؛
  ولا يُغيَّر من الصفحة حرف غيرهما (يثبته الاختبار بالمقارنة بعد نزعهما).
– الزرّ يملأ ولا يرسل أبداً (type=button)؛ والإرسال بيد المستخدم.
– يُترك: نموذج الدخول وتغيير كلمة المرور، ونماذج الحذف والسحب والتعطيل وإعادة التعيين، ونماذج الرفع التي
  لا حقل فيها غير الملف، وقرارات الفحص والتفتيش صفّاً صفّاً، والحقول المخفية، وما فيه قيمة من المنصة.
– البيانات تخيّلية بلا لبس: كل اسم شخص أو منشأة يحمل «(تجريبي)»، والبريد على example.test.
– الحقول التي تغيّر نتيجة الامتثال تأخذ القيمة العادية (المخاطر «عادي»، الإدراج «لا»، الحالة «جديد»،
  القرار «موافقة»، الشخص السياسي «لا»...) كي لا يصنع التجريب إنذارات عالية المخاطر بغير قصد.

نص الشيفرة كله بحروف ASCII (العربية تُكتب \\uXXXX)، فلا تلمسه جداول النصوص في ui_copy التي تمرّ على الصفحة بعده.
"""
from __future__ import annotations

import os
import re
from typing import Any, Dict

# ─────────────── ما يُحقن ───────────────
STYLE = """<style id="ltdf-style">.ltdf-bar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:0 0 10px}
form button.ltdf-btn{background:#fff!important;color:#7A5A00!important;border:1px dashed #B49670!important;border-radius:3px!important;
padding:5px 12px!important;margin:0!important;width:auto!important;font-weight:500!important;font-size:13px!important;cursor:pointer}
form button.ltdf-btn:hover{background:#FBF6EC!important;border-color:#7A5A00!important}
.ltdf-tag{display:inline-block;margin-inline-start:8px;padding:0 6px;border:1px dashed currentColor;border-radius:2px;font-size:11px}
.ltdf-msg{font-size:12.5px;color:#6B6B6B}</style>"""

JS = r"""(function(){if(window.__ltdf)return;window.__ltdf=1;
var TAG=' (تجريبي)';
// ───── النماذج التي لا يُوضع عليها الزرّ ─────
var DENY=/(login|logout|password|account|delete|remove|withdraw|toggle|reset|refresh|backup|restore|maintenance|daily_screening|run_|rescan|direct-update|apply_auto|\/screening\/update|\/screening\/report|\/inspection\/update|update_user|update_client_type|update_service_type|document-policy|\/lists\/|data-import|bulk_screen|staff\/import|\/document\/signed)/i;
var TEXTY={text:1,textarea:1,number:1,date:1,email:1,tel:1,url:1,search:1};
// ───── أدوات ─────
function R(n){return Math.floor(Math.random()*n);}
function pick(a){return a[R(a.length)];}
function digits(n){var s='';for(var i=0;i<n;i++)s+=R(10);return s;}
function between(a,b,st){st=st||1;return a+R(Math.floor((b-a)/st)+1)*st;}
function amount(a,b){return String(between(a,b,pick([250,500,1000,1000,2500])));}
function day(off){var t=new Date(Date.now()+off*864e5);return t.toISOString().slice(0,10);}
// ───── الأسماء والمنشآت ─────
var MEN=[['فهد','Fahad'],['عبدالله','Abdullah'],['خالد','Khalid'],['سلطان','Sultan'],['ماجد','Majed'],['تركي','Turki'],['نايف','Naif'],['فيصل','Faisal'],['سعود','Saud'],['ياسر','Yasser'],['مشاري','Mishari'],['بندر','Bandar']];
var WOMEN=[['نورة','Noura'],['سارة','Sarah'],['هيفاء','Haifa'],['ريم','Reem'],['لمى','Lama'],['العنود','Alanoud'],['منيرة','Munira'],['أمل','Amal']];
var FATHERS=[['محمد','Mohammed'],['إبراهيم','Ibrahim'],['سليمان','Sulaiman'],['ناصر','Nasser'],['عبدالرحمن','Abdulrahman'],['صالح','Saleh'],['حمد','Hamad']];
var FAMILY=[['القحطاني','Al-Qahtani'],['الدوسري','Al-Dosari'],['العتيبي','Al-Otaibi'],['الشهري','Al-Shehri'],['الغامدي','Al-Ghamdi'],['الزهراني','Al-Zahrani'],['المطيري','Al-Mutairi'],['الحربي','Al-Harbi'],['السبيعي','Al-Subaie'],['الشمري','Al-Shammari'],['البقمي','Al-Buqami'],['العمري','Al-Omari']];
var RESIDENTS=[['أحمد محمود عبدالحليم','Ahmed Mahmoud Abdelhalim','مصري'],['محمد يوسف الخطيب','Mohammad Yousef Al-Khatib','أردني'],['راجيش كومار','Rajesh Kumar','هندي'],['عمران أحمد خان','Omran Ahmed Khan','باكستاني'],['مارك أنتوني رييس','Mark Anthony Reyes','فلبيني']];
var CORES=[['الواحة','Al-Waha'],['سنام','Sanam'],['أفق الجزيرة','Ufuq Al-Jazeera'],['منارة الخليج','Manarat Al-Khaleej'],['درة العارض','Durrat Al-Aridh'],['ركائز','Rakaez'],['مدار','Madar'],['بوابة الشمال','Bawabat Al-Shamal'],['نخبة الرواد','Nukhbat Al-Rowad'],['غيم','Ghaim']];
var ACTS=[['للتجارة','Trading'],['للمقاولات العامة','General Contracting'],['للتطوير العقاري','Real Estate Development'],['للاستثمار','Investment'],['للصناعات الغذائية','Food Industries'],['للاستشارات الإدارية','Management Consulting'],['للخدمات الطبية','Medical Services'],['للتقنية المالية','Fintech']];
var LEGAL=[['المحدودة','Ltd.'],['القابضة','Holding Co.'],['المساهمة المقفلة','Closed JSC']];
function slug(s){return s.toLowerCase().replace(/[^a-z]+/g,'.').replace(/^\.|\.$/g,'');}
function person(){
 if(R(4)===0){var r=pick(RESIDENTS);return {ar:r[0]+TAG,en:r[1]+' (Test)',id:'2'+digits(9),nat:r[2],slug:slug(r[1])};}
 var f=R(3)===0,g=pick(f?WOMEN:MEN),fa=pick(FATHERS),fm=pick(FAMILY);
 return {ar:g[0]+(f?' بنت ':' بن ')+fa[0]+' '+fm[0]+TAG,en:g[1]+' '+fa[1]+' '+fm[1]+' (Test)',id:'1'+digits(9),
  nat:f?'سعودية':'سعودي',slug:slug(g[1]+' '+fm[1])};}
function company(){var c=pick(CORES),a=pick(ACTS),l=pick(LEGAL);
 return {ar:'شركة '+c[0]+' '+a[0]+' '+l[0]+TAG,en:c[1]+' '+a[1]+' '+l[1]+' (Test)',cr:pick(['1010','4030','2050'])+digits(6),
  un:'7'+digits(9),vat:'3'+digits(13)+'3',nat:'سعودية',slug:slug(c[1])};}
// ───── نصوص متقابلة (العربي وترجمته معاً في النقرة الواحدة) ─────
var PAIRS={
 scope:[['مراجعة عقود التوريد والمشتريات وصياغة ملاحقها','Reviewing supply and procurement contracts and drafting their annexes'],
  ['تمثيل العميل في الدعوى التجارية المقامة أمام المحكمة التجارية بالرياض','Representing the Client in the commercial claim before the Commercial Court in Riyadh'],
  ['تقديم الاستشارات القانونية في إعادة هيكلة الشركة وتعديل عقد تأسيسها','Advising on the restructuring of the company and the amendment of its articles of association'],
  ['إعداد لوائح الحوكمة الداخلية ومراجعة سياسات الامتثال','Preparing internal governance regulations and reviewing compliance policies']],
 ph1:[['دراسة المستندات وإعداد المذكرة الأولية','Reviewing the documents and preparing the initial memorandum','عند توقيع الاتفاقية','upon signing the Agreement']],
 ph2:[['صياغة العقود والملاحق','Drafting the contracts and annexes','عند تسليم المسودة الأولى','upon delivery of the first draft']],
 ph3:[['المراجعة النهائية والاعتماد','Final review and approval','عند اعتماد الصيغة النهائية','upon approval of the final version']],
 cap:[['مائة ألف ريال','one hundred thousand riyals'],['مائتا ألف ريال','two hundred thousand riyals'],['خمسون ألف ريال','fifty thousand riyals']],
 event:[['صدور حكم نهائي لصالح العميل في الدعوى',"a final judgment in the Client's favour in the claim"],
  ['تحصيل المبلغ المحكوم به كاملاً','full collection of the adjudged amount'],
  ['إبرام تسوية ودية يوقّعها الطرفان','the conclusion of an amicable settlement signed by both parties']],
 tasks:[['حضور الجلسات وإعداد المذكرات الجوابية ومتابعة التنفيذ','Attending hearings, preparing reply memoranda and following up on enforcement'],
  ['مراجعة المسودات الواردة من الطرف الآخر وإعداد جدول الملاحظات','Reviewing drafts received from the other party and preparing a comments table']],
 title:[['نائب الرئيس للشؤون القانونية','Vice President, Legal Affairs'],['مدير الشؤون المالية','Chief Financial Officer']]};
var NOTES=['أفاد العميل بأن البيانات محدّثة حتى تاريخه، ويُستكمل ما ينقص عند التجديد.',
 'أُحيل الملف إلى الشريك المسؤول للاطلاع، ولا ملاحظات جوهرية حتى الآن.',
 'البيانات مأخوذة من صورة السجل المقدَّمة في الاجتماع الأول، وتُطابَق مع واثق لاحقاً.',
 'تواصل الفريق مع ممثل العميل هاتفياً، فأكّد صحة البيانات المسجّلة.'];
var EN_NOTES=['Details confirmed by the client representative by phone.','To be reconciled with the Wathq record at the next review.'];
var TXT={
 funds_entity:['إيرادات تشغيلية من عقود التوريد','رأس مال الشركاء المدفوع','أرباح استثمارات عقارية'],
 funds_person:['راتب ومكافآت نهاية الخدمة','دخل إيجارات عقارات مملوكة','أرباح أسهم في السوق المالية'],
 wealth_entity:['أرباح متراكمة من النشاط التجاري منذ التأسيس','عوائد بيع أصل عقاري في الرياض'],
 wealth_person:['إرث عائلي موثّق بصك حصر ورثة','مدخرات من العمل الوظيفي لأكثر من خمس عشرة سنة'],
 description:['يطلب العميل مراجعة العقود القائمة مع المورّدين الرئيسيين وتحديد مخاطرها قبل تجديدها.',
  'نزاع على مستحقات متأخرة عن أعمال منفَّذة، والمطلوب تقييم الموقف ثم رفع الدعوى إن لزم.',
  'استشارة في تعديل عقد التأسيس لدخول شريك جديد وزيادة رأس المال.'],
 control_description:['يملك الحصة الأكبر ويعيّن أغلب أعضاء مجلس الإدارة، ولا اتفاقات تصويت معلنة.',
  'يسيطر عبر الشركة القابضة المملوكة له بالكامل، ويوقّع وحده على القرارات الجوهرية.'],
 facts:['طلب العميل سداد الأتعاب من حساب طرف ثالث لا صلة له بالتكليف، ولم يقدّم تفسيراً مقنعاً.',
  'قدّم العميل مستند ملكية تختلف بياناته عن السجل التجاري، وتعذّر عليه بيان سبب الاختلاف.'],
 indicators:['الدفع من طرف ثالث؛ الاستعجال غير المبرّر في إنهاء الإجراءات.','عدم اتساق المستندات مع السجلات الرسمية.'],
 reason:['العميل في طور تجديد السجل التجاري، وتعهّد بتقديم النسخة المحدّثة خلال المهلة.',
  'عقد التأسيس المعدّل لدى كاتب العدل ولم يصدر بعد.','ممثل العميل خارج المملكة حتى نهاية الشهر.'],
 conditions:['تقديم شهادة المستفيد الحقيقي من واثق قبل بدء العمل.'],
 role_in_matter:['مدعى عليه','الطرف الثاني في العقد','المورّد','المؤجر','المقاول من الباطن'],
 title:['مراجعة عقود التوريد لعام 2027','دعوى مطالبة بمستحقات مقاول من الباطن','استشارة في نظام الشركات وتعديل عقد التأسيس',
  'صياغة اتفاقية مشروع مشترك','تمثيل في نزاع عمالي أمام المحكمة العمالية']};
var CITIES=[['الرياض','Riyadh','حي العليا','Al Olaya','طريق الملك فهد','King Fahd Road','12241'],['جدة','Jeddah','حي الروضة','Al Rawdah','شارع الأمير سلطان','Prince Sultan Street','23435'],
 ['الدمام','Dammam','حي الشاطئ','Al Shati','طريق الملك سعود','King Saud Road','32413']];
// ───── القيم المفضّلة للقوائم التي تغيّر نتيجة الامتثال ─────
var PREFER={risk_level:['normal'],listed_saudi_market:['0'],status:['new'],pep_status:['no'],external_reported:['0'],role:['user'],
 decision:['موافقة'],a_instalments:['1','2','4'],client_type:['company','individual'],party_type:['company','individual'],
 owner_type:['company','individual'],entity_category:['individual','company'],screening_mode:['both']};
var SKIP={matter_number:1,agreement_date_h:1,compliance_decision:1,external_reference:1,joint_client_id:1,import_type:1};
var FIRST=['client_type','party_type','owner_type','entity_category','subject_type','fee_model','hourly_option','succ_type',
 'pep_status','decision','signatory_title_ar','document_type'];
var KIND_FIELDS=['client_type','party_type','owner_type','entity_category'];
function visible(el){return !!(el.offsetWidth||el.offsetHeight||el.getClientRects().length);}
function named(form,n){return form.querySelector('[name="'+n+'"]');}
function fillable(el){
 if(!el.name||el.disabled||el.readOnly||SKIP[el.name])return false;
 var t=(el.type||'').toLowerCase();
 if(el.tagName==='SELECT')return true;
 if(el.tagName==='TEXTAREA')return true;
 return t==='radio'||!!TEXTY[t];}
function mine(el){return el.getAttribute('data-ltdf')==='1';}
function hasValue(el){
 if(mine(el))return false;
 if(el.tagName==='SELECT'){for(var i=0;i<el.options.length;i++){var o=el.options[i];if(o.defaultSelected&&o.value)return true;}return false;}
 var v=(el.value||'').trim();
 return v!==''&&v!=='مكتب / شركة مستخدمة التطبيق';}
function fire(el){['input','change'].forEach(function(t){el.dispatchEvent(new Event(t,{bubbles:true}));});}
function set(el,v){el.value=v;el.setAttribute('data-ltdf','1');fire(el);return 1;}
function kindOf(form){for(var i=0;i<KIND_FIELDS.length;i++){var s=named(form,KIND_FIELDS[i]);
 if(s&&s.value)return s.value==='individual'?'person':'entity';}return null;}
function pair(ctx,k){return ctx.pairs[k]||(ctx.pairs[k]=pick(PAIRS[k]));}
function email(who){return who.slug+'.'+digits(3)+'@example.test';}
// ───── قيمة الحقل النصي بحسب اسمه ثم نوعه ثم عنوانه ─────
function value(el,form,ctx){
 var n=el.name,t=(el.type||el.tagName).toLowerCase(),act=form.getAttribute('action')||'',kind=kindOf(form);
 var ent=kind==='entity',who=kind===null?ctx.p:(ent?ctx.c:ctx.p);
 var m=/^ph(\d)_(desc|due)_(ar|en)$/.exec(n);
 if(m){if(+m[1]>3)return null;var p=pair(ctx,'ph'+m[1]);return p[(m[2]==='desc'?0:2)+(m[3]==='en'?1:0)];}
 if(/^ph[4-9]_amount$/.test(n))return null;
 if(/^ph\d_amount$/.test(n))return amount(12000,65000);
 switch(n){
 case 'legal_name':case 'subject_name':case 'owner_name':return who.ar;
 case 'full_name':return kind?who.ar:ctx.p.ar;
 case 'id_number':return ent?null:who.id;
 case 'registration_number':return ent?ctx.c.cr:null;
 case 'unified_number':return ent?ctx.c.un:null;
 case 'nationality':return who.nat;
 case 'country':return 'المملكة العربية السعودية';
 case 'parent_owner':return 'شركة '+pick(CORES)[0]+' القابضة'+TAG;
 case 'ownership_percent':return String(between(10,100)+(R(3)===0?0.5:0)).replace(/\.0$/,'');
 case 'name_en':return ctx.c.en;
 case 'address_en':var c=pick(CITIES);return 'Building '+between(1000,9999)+', '+c[5]+', '+c[3]+' District, '+c[1]+' '+c[6]+', Saudi Arabia';
 case 'signatory_name_ar':return ctx.sig.ar;
 case 'signatory_name_en':return ctx.sig.en;
 case 'signatory_id':return ctx.sig.id;
 case 'email':return email(kind==='person'?ctx.p:ctx.c);
 case 'user_name':return 'tajribi.'+digits(4)+'@legaltracks.sa';
 case 'vat_number':case 'company_vat_number':return ctx.c.vat;
 case 'company_registration':return ctx.c.cr;
 case 'company_name':return 'مكتب '+pick(FAMILY)[0].replace(/^ال/,'')+' للمحاماة والاستشارات القانونية'+TAG;
 case 'company_national_address':var c2=pick(CITIES);return pick(['RAAA','RHOA','JRDA','DSHB'])+digits(4)+'، '+between(1000,9999)+' '+c2[4]+'، '+c2[2]+'، '+c2[0]+' '+c2[6];
 case 'scope_ar':return pair(ctx,'scope')[0];case 'scope_en':return pair(ctx,'scope')[1];
 case 'succ_cap_ar':return pair(ctx,'cap')[0];case 'succ_cap_en':return pair(ctx,'cap')[1];
 case 'succ_event_ar':return pair(ctx,'event')[0];case 'succ_event_en':return pair(ctx,'event')[1];
 case 'tasks_ar':return pair(ctx,'tasks')[0];case 'tasks_en':return pair(ctx,'tasks')[1];
 case 'title_manual_ar':return pair(ctx,'title')[0];case 'title_manual_en':return pair(ctx,'title')[1];
 case 'a_fee':return amount(96000,480000);case 'c_advance':return amount(25000,90000);
 case 'd_rate':return String(between(850,2400,50));case 'e_cap':return amount(250000,750000);
 case 'f_fee':return amount(18000,240000);case 'succ_lump':return amount(50000,400000);
 case 'succ_pct':return String(between(5,15));
 case 'title':return pick(TXT.title)+TAG;
 case 'source_of_funds':case 'source_of_wealth':
  var cs=named(form,'client_id'),corp=kind?ent:!!(cs&&cs.selectedIndex>=0&&/^\s*(شركة|مؤسسة|جمعية)/.test(cs.options[cs.selectedIndex].text));
  return pick(TXT[(n==='source_of_funds'?'funds_':'wealth_')+(corp?'entity':'person')]);
 case 'source_notes':return null;
 case 'reviewed_by':case 'reported_by':return ctx.staff.ar;
 case 'related_person_name':var ps=named(form,'pep_status');return (ps&&ps.value&&ps.value!=='no')?ctx.p.ar:null;
 case 'conditions':var d=named(form,'decision');return (d&&/مشروطة/.test(d.value))?pick(TXT.conditions):null;
 case 'document_title':var dt=named(form,'document_type');return (dt&&dt.selectedIndex>=0?dt.options[dt.selectedIndex].text:'مستند')+' - نسخة تجريبية';
 case 'code':return 'test_'+'abcdefghjkmnpqrstuvwxyz'.split('').sort(function(){return Math.random()-.5}).slice(0,5).join('');
 case 'label_ar':return (/service/.test(act)?pick(['تحكيم تجاري','ملكية فكرية','حوكمة شركات','امتثال تنظيمي']):pick(['وقف','جمعية تعاونية','صندوق استثماري','مؤسسة فردية']))+TAG;
 // وقائع الحوكمة وناجز (صفحة التفتيش)
 case 'policies_approved_date':case 'board_last_meeting_date':case 'co_report_last_date':case 'training_last_date':case 'bra_approved_date':
  return day(-between(20,200));
 case 'independent_review_date':return day(between(30,120));
 case 'co_appointment_decision_ref':return day(-between(60,240))+' / قرار '+between(2,30);
 case 'co_notification_sent':return day(-between(20,59))+' / صادر '+between(100,999);
 case 'independent_reviewer':return 'مكتب '+pick(FAMILY)[0].replace(/^ال/,'')+' للمراجعة والتدقيق'+TAG+' / قرار '+between(3,40);
 case 'training_covers_tf_pf':return 'نعم';
 case 'staff_total':return String(ctx.staffTotal);
 case 'training_ack_count':case 'circular_ack_count':return String(ctx.staffTotal-R(4));
 case 'najiz_lawyers_count':return String(between(8,25));case 'najiz_consultants_count':return String(between(2,8));
 case 'najiz_admins_count':return String(between(4,12));case 'najiz_trainees_count':return String(between(3,12));
 case 'najiz_income_range':return 'من 10 إلى 50 مليون ريال';case 'najiz_assets_range':return 'من 5 إلى 10 ملايين ريال';
 case 'najiz_ops50k_count':return String(between(5,40));case 'najiz_ops50k_total':return amount(400000,6000000);
 case 'najiz_cash_fees_count':return String(ctx.cash);case 'najiz_cash_fees_total':return ctx.cash?amount(3000,60000):'0';
 case 'matters_funds_mgmt':case 'matters_realestate':case 'matters_entity_formation':case 'matters_company_sale':return String(between(0,6));
 }
 if(TXT[n])return pick(TXT[n]);
 if(n==='notes'||n==='evidence'||n==='decision_reason')return pick(NOTES);
 var lab=(el.closest('div,label')||{}).textContent||'';
 if(/_en$/.test(n))return pick(EN_NOTES);
 if(t==='email'||/email/.test(n)||/بريد/.test(lab))return email(ctx.p);
 if(t==='tel'||/phone|mobile|jawal/.test(n)||/جوال|هاتف/.test(lab))return '05'+digits(8);
 if(t==='date'||/_date$/.test(n))return day(-between(10,300));
 if(t==='url')return 'https://example.test/';
 if(t==='number'){var lo=el.min!==''?+el.min:1,hi=el.max!==''?+el.max:Math.max(lo+19,20);return String(between(lo,hi));}
 if(t==='textarea')return pick(NOTES);
 if(/رقم/.test(lab))return digits(10);
 return 'قيمة تجريبية '+digits(3);}
// ───── الملء ─────
function chooseSelect(el){
 var opts=[].filter.call(el.options,function(o){return o.value!==''&&o.value.indexOf('__')!==0&&!o.disabled
  &&o.getAttribute('data-defer')!=='0'&&o.getAttribute('data-category')!=='mandatory';});
 if(!opts.length)return null;
 var pref=PREFER[el.name];
 if(pref){var hit=opts.filter(function(o){return pref.indexOf(o.value)>=0;});if(hit.length)return pick(hit).value;
  if(el.name==='decision')return opts[0].value;}
 return pick(opts).value;}
function fill(form){
 var ctx={p:person(),c:company(),sig:person(),staff:person(),pairs:{},staffTotal:between(28,60),cash:R(3)};
 var shut=[].filter.call(form.querySelectorAll('details'),function(d){return !d.open;});
 shut.forEach(function(d){d.open=true;});
 var els=[].slice.call(form.elements).filter(fillable),done={},n=0;
 var rank=function(el){var i=FIRST.indexOf(el.name);return i<0?99:i;};
 var choice=els.filter(function(e){return e.tagName==='SELECT'||e.type==='radio';}).sort(function(a,b){return rank(a)-rank(b);});
 choice.forEach(function(el){
  if(done[el.name])return;done[el.name]=1;
  if(el.type==='radio'){var grp=[].filter.call(form.elements,function(r){return r.type==='radio'&&r.name===el.name&&!r.disabled;});
   if(!grp.some(visible))return;
   if(grp.some(function(r){return r.defaultChecked&&r.getAttribute('data-ltdf')!=='1';}))return;
   var r=pick(grp);r.checked=true;grp.forEach(function(x){x.setAttribute('data-ltdf','1');});fire(r);n++;return;}
  if(!visible(el)||hasValue(el))return;
  var v=chooseSelect(el);if(v!==null)n+=set(el,v);});
 els.filter(function(e){return e.tagName!=='SELECT'&&e.type!=='radio';}).forEach(function(el){
  if(!visible(el)||hasValue(el))return;
  var v=value(el,form,ctx);if(v===null||v===undefined)return;
  if(el.maxLength>0&&v.length>el.maxLength)v=v.slice(0,el.maxLength);
  n+=set(el,v);});
 shut.forEach(function(d){if(!d.querySelector('[data-ltdf="1"]'))d.open=false;});
 return n;}
function eligible(form){
 if((form.getAttribute('method')||'').toLowerCase()!=='post')return false;
 if(DENY.test(form.getAttribute('action')||''))return false;
 if(form.querySelector('input[type=password],.btn.danger,button.danger'))return false;
 var els=[].slice.call(form.elements).filter(fillable);
 if(!els.length)return false;
 if(form.querySelector('input[type=file]')&&!els.some(function(e){return e.tagName!=='SELECT'&&e.type!=='radio';}))return false;
 return true;}
[].forEach.call(document.querySelectorAll('form'),function(form){
 if(!eligible(form)||form.querySelector('.ltdf-btn'))return;
 var bar=document.createElement('div');bar.className='ltdf-bar';
 var b=document.createElement('button');b.type='button';b.className='ltdf-btn';b.textContent='املأ ببيانات تجريبية';
 var tg=document.createElement('span');tg.className='ltdf-tag';tg.textContent='تجريبي';b.appendChild(tg);
 var msg=document.createElement('span');msg.className='ltdf-msg';msg.setAttribute('aria-live','polite');
 b.addEventListener('click',function(e){e.preventDefault();var k=fill(form);
  msg.textContent=k?('مُلئ '+k+' من الحقول ببيانات تخيّلية؛ راجعها ثم احفظ بنفسك.'):'لا حقل فارغاً يُملأ هنا.';});
 bar.appendChild(b);bar.appendChild(msg);form.insertBefore(bar,form.firstChild);});
window.__ltdfFill=fill;window.__ltdfEligible=eligible;})();"""


# ─────────────── سجل الحقول: كل اسم حقل في نماذج الإدخال وما يُفعل به (الاختبار يفشل إن ظهر اسم لا يعرفه) ───────────────
FIELD_RULES: Dict[str, str] = {
    # الأسماء والأرقام — تتبع نوع الكيان المختار في النموذج (فرد/منشأة)
    "legal_name": "company or person name + (تجريبي), by client_type",
    "full_name": "person name + (تجريبي); company name when the form has party_type/client_type=company",
    "subject_name": "name by entity_category", "owner_name": "name by owner_type",
    "id_number": "person: 10 digits, 1… citizen / 2… resident; left empty for an entity",
    "registration_number": "entity: CR 10 digits starting 1010/4030/2050; empty for a person",
    "unified_number": "entity: 10 digits starting 7", "nationality": "سعودي/سعودية or resident nationality; entity: سعودية",
    "country": "المملكة العربية السعودية (platform default kept)", "parent_owner": "holding company name + (تجريبي)",
    "ownership_percent": "10–100, sometimes .5", "sequence_no": "platform default kept",
    "email": "<name>.<3 digits>@example.test", "user_name": "tajribi.<4 digits>@legaltracks.sa (المنصة لا تقبل إلا نطاق المكتب؛ في نسخة التجربة وحدها)",
    "vat_number": "15 digits, starts and ends with 3", "company_vat_number": "15 digits, starts and ends with 3",
    "company_registration": "CR 10 digits", "company_name": "fictional law office + (تجريبي); replaces the platform placeholder",
    "company_national_address": "short address code + street, district, city, postal code",
    "name_en": "English company name + (Test)", "address_en": "English Saudi address",
    "signatory_name_ar": "person + (تجريبي)", "signatory_name_en": "same person in English + (Test)", "signatory_id": "citizen id 1…",
    "title_manual_ar": "only when «manual» title is chosen (visible)", "title_manual_en": "pair of title_manual_ar",
    "reviewed_by": "staff person + (تجريبي)", "reported_by": "staff person + (تجريبي)",
    "related_person_name": "only if pep_status is not «no»", "conditions": "only if decision is conditional",
    # نصوص حرة عربية
    "notes": "Arabic note (one sentence)", "source_of_funds": "Arabic phrase, business or personal by client kind",
    "source_of_wealth": "Arabic phrase, business or personal by client kind", "description": "Arabic sentence", "control_description": "Arabic sentence",
    "facts": "Arabic sentence", "indicators": "Arabic phrase", "reason": "Arabic sentence", "role_in_matter": "Arabic role",
    "title": "matter title + (تجريبي)", "document_title": "chosen document type + «نسخة تجريبية»",
    "code": "test_<5 letters>", "label_ar": "client/service type label + (تجريبي)",
    # الاتفاقية
    "scope_ar": "Arabic scope (paired)", "scope_en": "English scope (paired)", "agreement_date": "platform default kept",
    "effective_date": "past ISO date, only when visible (effective_on ticked by hand)",
    "a_fee": "96,000–480,000 varied step", "a_notice_days": "platform default kept", "c_advance": "25,000–90,000",
    "d_rate": "850–2,400 step 50", "e_cap": "250,000–750,000", "f_fee": "18,000–240,000",
    "f_pct_sign": "platform default kept", "f_pct_delivery": "platform default kept",
    "succ_lump": "50,000–400,000", "succ_pct": "5–15", "succ_cap_ar": "Arabic cap in words (paired)",
    "succ_cap_en": "English cap (paired)", "succ_event_ar": "Arabic event (paired)", "succ_event_en": "English event (paired)",
    "tasks_ar": "Arabic tasks (paired)", "tasks_en": "English tasks (paired)",
    # القوائم والاختيارات
    "risk_level": "SELECT → normal", "listed_saudi_market": "SELECT → 0 (لا)", "status": "SELECT → new",
    "pep_status": "SELECT → no", "external_reported": "SELECT → 0", "role": "SELECT → user", "decision": "SELECT → موافقة",
    "a_instalments": "SELECT → 1/2/4 (never 12, which blocks issuing)", "client_type": "SELECT → company/individual",
    "party_type": "SELECT → company/individual", "owner_type": "SELECT → company/individual",
    "entity_category": "SELECT → individual/company", "party_role": "SELECT random", "document_type": "SELECT random",
    "term": "SELECT random unless preselected", "succ_basis": "SELECT random", "partner_ar": "SELECT random unless preselected",
    "partner_en": "SELECT random unless preselected", "managing_partner": "SELECT random", "executing_partner": "SELECT random",
    "client_id": "SELECT random existing client", "service_type": "SELECT random", "subject_type": "SELECT random",
    "verification_method": "SELECT random", "partner_name": "SELECT random", "document_code": "SELECT random among deferrable documents (never «mandatory» / data-defer=0)",
    "responsible_partner": "SELECT random", "signatory_title_ar": "SELECT random, never «manual»",
    "signatory_authority_ar": "SELECT random", "verification_date": "platform default kept", "days": "platform default kept",
    "fee_model": "RADIO random unless preselected", "hourly_option": "RADIO random", "succ_type": "RADIO random (visible only)",
    # وقائع الحوكمة وناجز (صفحة التفتيش)
    "policies_approved_date": "past ISO date", "board_last_meeting_date": "past ISO date", "co_report_last_date": "past ISO date",
    "training_last_date": "past ISO date", "bra_approved_date": "past ISO date", "independent_review_date": "future ISO date",
    "co_appointment_decision_ref": "«date / قرار n»", "co_notification_sent": "«date / صادر n»",
    "independent_reviewer": "review office + (تجريبي) / decision no.", "training_covers_tf_pf": "نعم",
    "training_ack_count": "≤ staff_total", "circular_ack_count": "≤ staff_total", "staff_total": "28–60",
    "najiz_lawyers_count": "8–25", "najiz_consultants_count": "2–8", "najiz_admins_count": "4–12",
    "najiz_trainees_count": "3–12", "najiz_income_range": "fixed Arabic range (Najiz list not verified)",
    "najiz_assets_range": "fixed Arabic range (Najiz list not verified)", "najiz_ops50k_count": "5–40",
    "najiz_ops50k_total": "400,000–6,000,000", "najiz_cash_fees_count": "0–2", "najiz_cash_fees_total": "0 when count is 0",
    "matters_funds_mgmt": "0–6", "matters_realestate": "0–6", "matters_entity_formation": "0–6", "matters_company_sale": "0–6",
}
for _i in range(1, 7):
    for _k in ("desc_ar", "desc_en", "due_ar", "due_en", "amount"):
        FIELD_RULES[f"ph{_i}_{_k}"] = ("phase text/amount (paired)" if _i <= 3 else "phases 4–6 left empty")
# يُترك عمداً: لا يملؤه الزرّ
LEFT_ALONE: Dict[str, str] = {
    "matter_number": "numbered by the platform", "agreement_date_h": "computed by the page from the Gregorian date",
    "compliance_decision": "a new internal report carries no decision", "external_reference": "no external report",
    "joint_client_id": "joint clients chosen by hand",
    "source_notes": "reason for NOT documenting sources: left empty because the sources are filled", "import_type": "file-only form",
    "effective_on": "agreement toggle", "cap_on": "agreement toggle", "succ_on": "agreement toggle", "tasks_on": "agreement toggle",
    "member": "checkbox (team) left as is", "verified": "checkbox left as is", "partner_undertaking": "checkbox left as is",
    "set_lead": "checkbox left as is",
}


def _ascii(src: str) -> str:
    return "".join(c if ord(c) < 128 else "\\u%04x" % ord(c) for c in src)


# التعليقات للقارئ هنا، ولا تُرسل في الصفحة
JS_ASCII = _ascii(re.sub(r"\n[ \t]*// [^\n]*", "", JS))
BLOCK = STYLE + '<script id="ltdf-script">' + JS_ASCII + "</script>"

_RE_POSTFORM = re.compile(r"""<form\b[^>]*\bmethod\s*=\s*["']?post""", re.I)
_NS: Dict[str, Any] = {}
ACTIVE = True                                       # يطفئه الاختبار ليقارن الصفحة قبل الحقن


def enabled(ns: Dict[str, Any] | None = None) -> bool:
    ns = _NS if ns is None else ns
    # H2 من مراجعة فابل: نسخة محمد التجريبية تعمل بـUAT والموظفون فيها، فلا يكفي «غير الإنتاج»؛
    # بل نسختنا وحدها: غير الإنتاج، وقاعدة في dev-data
    import dev_autologin
    return dev_autologin.dev_copy(ns)


def inject(data: Any) -> Any:
    """يضيف الكتلة قبل آخر </body> إن كان في الصفحة نموذج post؛ وإلا تعود الصفحة كما هي."""
    try:
        raw = data.decode("utf-8") if isinstance(data, bytes) else data
    except UnicodeDecodeError:
        return data
    if not isinstance(raw, str) or 'id="ltdf-script"' in raw or not _RE_POSTFORM.search(raw):
        return data
    at = raw.rfind("</body>")
    if at < 0:
        return data
    return (raw[:at] + BLOCK + raw[at:]).encode("utf-8")


def strip(page: str) -> str:
    return page.replace(BLOCK, "")


def install(ns: Dict[str, Any]) -> None:
    if not enabled(ns):
        return                                      # الإنتاج: لا شيء البتة
    _NS.update(ns)
    handler = ns.get("AppHandler")
    if not handler or getattr(handler, "_lt_demo_fill", False):
        return
    base_send = handler._send

    def _send(self, data, status: int = 200, content_type: str = "text/html; charset=utf-8") -> None:
        if ACTIVE and enabled() and str(content_type).startswith("text/html"):
            data = inject(data)
        return base_send(self, data, status, content_type)

    handler._send = _send
    handler._lt_demo_fill = True

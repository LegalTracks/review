# -*- coding: utf-8 -*-
"""مسارات قانونية — تبويب «الاتفاقيات» وحالاته التجريبية (ملف مستقل؛ يُزال بحذف سطرَي الوصل في آخر app.py).

– /agreements: صفحة واحدة يصل منها الإداري إلى إصدار اتفاقية أي تكليف، وإلى تقريري المستندات الصادرة.
– الحالات التجريبية: عملاء تخيّليون يُنشؤون بدوالّ المنصة نفسها (لا بإدخال مباشر في الجداول)،
  ولكل حالة قيمٌ جاهزة تملأ شاشة الإصدار فيُختبر بها كل نموذج أتعاب؛ ولا يُنشأ شيء قبل «إنشاء الاتفاقية».
  والحالات لا تظهر ولا تعمل في بيئة الإنتاج أبداً.
"""
from __future__ import annotations

import os
import sqlite3
from typing import Any, Callable, Dict, List, Optional

HUB_PATH = "/agreements"
PARTNER = "abdulrahman@legaltracks.sa"
TAG = "(تجريبي)"

# العملاء التخيّليون — أسماؤهم تحمل «(تجريبي)» كي لا يلتبس أحدهم بعميل حقيقي
CLIENTS = {
    "co": {"client_type": "company", "legal_name": "شركة الأفق للتطوير العقاري " + TAG,
           "registration_number": "1010999001", "country": "المملكة العربية السعودية",
           "source_of_funds": "إيرادات تشغيلية", "risk_level": "normal",
           "contract": {"email": "legal@ufuq.test", "name_en": "Al-Ufuq Real Estate Development Co. (Test)",
                        "signatory_name_ar": "خالد بن عبدالله التجريبي", "signatory_name_en": "Khalid Abdullah (Test)",
                        "signatory_id": "1000000009"}},
    "man": {"client_type": "individual", "legal_name": "فهد بن سالم " + TAG, "id_number": "1099999001",
            "nationality": "سعودي", "country": "المملكة العربية السعودية", "source_of_funds": "راتب",
            "risk_level": "normal",
            "contract": {"email": "fahad@example.test", "name_en": "Fahad Salem (Test)", "salutation_gender": "M"}},
    "woman": {"client_type": "individual", "legal_name": "نورة بنت عبدالله " + TAG, "id_number": "1099999002",
              "nationality": "سعودية", "country": "المملكة العربية السعودية", "source_of_funds": "راتب",
              "risk_level": "normal",
              "contract": {"email": "noura@example.test", "name_en": "Noura Abdullah (Test)",
                           "salutation_gender": "F"}},
}
# التكليفات: نوع الخدمة يحدد نوع التكليف في العقد (قضية ← تمثيل في منازعة، وغيرها ← استشاري)
MATTERS = {
    "co_contract": ("co", "استشارات عقارية مستمرة " + TAG, "contract"),
    "co_dispute": ("co", "دعوى مطالبة مالية " + TAG, "litigation"),
    "man_consult": ("man", "استشارة في عقد إيجار " + TAG, "consulting"),
    "woman_dispute": ("woman", "دعوى حقوقية " + TAG, "litigation"),
}

_COMMON = {"scope_ar": "تقديم الاستشارات القانونية في المسائل المحددة في هذه الحالة التجريبية",
           "scope_en": "Providing legal advice on the matters set out in this test case",
           "term": "سنة (1) واحدة", "partner_ar": PARTNER, "partner_en": PARTNER}

# (المفتاح، العنوان، ما تختبره، التكليف، القيم)
SCENARIOS: List[Dict[str, Any]] = [
    {"key": "annual", "title": "أتعاب سنوية بأربعة أقساط", "matter": "co_contract",
     "tests": "البند أ كاملاً، والمبلغ بالحروف",
     "form": {"fee_model": "annual", "a_fee": "360000", "a_instalments": "4"}},
    {"key": "annual12", "title": "أتعاب سنوية باثني عشر قسطاً", "matter": "co_contract",
     "tests": "المانع المؤقت (ع-28): يجب أن يمنع الإنشاء برسالته",
     "form": {"fee_model": "annual", "a_fee": "360000", "a_instalments": "12"}},
    {"key": "hourly", "title": "بالساعة بمعدلات الملحق", "matter": "co_contract",
     "tests": "البلوك ب والملحق (ب)",
     "form": {"fee_model": "hourly", "hourly_option": "none"}},
    {"key": "advance_cap", "title": "دفعة مقدمة مع سقف", "matter": "co_contract",
     "tests": "جمع ج وهـ، والملحق باقٍ (القرار 172)",
     "form": {"fee_model": "hourly", "hourly_option": "advance", "c_advance": "50000",
              "cap_on": "1", "e_cap": "400000"}},
    {"key": "blended_cap", "title": "سعر موحّد مع سقف", "matter": "co_contract",
     "tests": "جمع د وهـ، والملحق ساقط (القرار 172)",
     "form": {"fee_model": "hourly", "hourly_option": "blended", "d_rate": "1500",
              "cap_on": "1", "e_cap": "300000"}},
    {"key": "fixed", "title": "أتعاب ثابتة بين التوقيع والتسليم", "matter": "co_contract",
     "tests": "البند و ونسبتا الدفع",
     "form": {"fee_model": "fixed", "f_fee": "85000", "f_pct_sign": "50", "f_pct_delivery": "50"}},
    {"key": "phases", "title": "أتعاب على ثلاث مراحل", "matter": "co_contract",
     "tests": "البند ز وجدول المراحل ومجموعها",
     "form": {"fee_model": "phases",
              "ph1_desc_ar": "دراسة المستندات وإعداد المذكرة", "ph1_desc_en": "Reviewing documents and preparing the memorandum",
              "ph1_amount": "20000", "ph1_due_ar": "عند التوقيع", "ph1_due_en": "upon signing",
              "ph2_desc_ar": "صياغة العقود", "ph2_desc_en": "Drafting the contracts",
              "ph2_amount": "30000", "ph2_due_ar": "عند تسليم المسودة", "ph2_due_en": "upon delivery of the draft",
              "ph3_desc_ar": "المراجعة النهائية", "ph3_desc_en": "Final review",
              "ph3_amount": "10000", "ph3_due_ar": "عند الاعتماد", "ph3_due_en": "upon approval"}},
    {"key": "dispute_lump", "title": "تمثيل في منازعة بأتعاب نجاح مقطوعة", "matter": "co_dispute",
     "tests": "نوع التكليف «تمثيل»، والنجاح المقطوع بواقعة مكتوبة",
     "form": {"fee_model": "fixed", "f_fee": "150000", "f_pct_sign": "50", "f_pct_delivery": "50",
              "succ_on": "1", "succ_type": "lump", "succ_lump": "250000",
              "succ_event_ar": "صدور حكم نهائي لصالح العميل في الدعوى",
              "succ_event_en": "a final judgment in the Client's favour in the claim"}},
    {"key": "woman_pct", "title": "عميلة فرد: نسبة نجاح بلا واقعة مكتوبة", "matter": "woman_dispute",
     "tests": "مخاطبة «الأستاذة»، والهوية أو الإقامة، والبديل النظامي للواقعة",
     "form": {"fee_model": "fixed", "f_fee": "40000", "f_pct_sign": "100", "f_pct_delivery": "0",
              "succ_on": "1", "succ_type": "pct", "succ_pct": "10",
              "succ_cap_ar": "مائة ألف ريال", "succ_cap_en": "one hundred thousand riyals"}},
    {"key": "man_consult", "title": "عميل فرد: استشارة بأتعاب ثابتة", "matter": "man_consult",
     "tests": "مخاطبة «الأستاذ»، ونوع التكليف «استشاري»",
     "form": {"fee_model": "fixed", "f_fee": "15000", "f_pct_sign": "100", "f_pct_delivery": "0"}},
    {"key": "effective", "title": "تاريخ سريان يسبق التوقيع", "matter": "co_contract",
     "tests": "سطر تاريخ السريان يظهر بتفعيله وحده",
     "form": {"fee_model": "annual", "a_fee": "240000", "a_instalments": "4",
              "effective_on": "1", "effective_date": "2026-09-01"}},
]
BY_KEY = {s["key"]: s for s in SCENARIOS}

_NS: Dict[str, Any] = {}


def enabled() -> bool:
    """الحالات التجريبية لنسختنا وحدها (H2 من مراجعة فابل): غير الإنتاج وقاعدة في dev-data، لا «غير الإنتاج» وحده."""
    import dev_autologin
    return dev_autologin.dev_copy(_NS)


def scenario_form(key: str) -> Optional[Dict[str, str]]:
    s = BY_KEY.get(key)
    return dict(_COMMON, **s["form"]) if s else None


def _matter_ids(con: sqlite3.Connection) -> Dict[str, int]:
    out = {}
    for key, (_ck, title, _st) in MATTERS.items():
        r = con.execute("SELECT id FROM matters WHERE title=? ORDER BY id DESC LIMIT 1", (title,)).fetchone()
        if r:
            out[key] = r[0]
    return out


def seed(ns: Dict[str, Any]) -> Dict[str, int]:
    """ينشئ العملاء والتكليفات التجريبية بدوالّ المنصة، مرةً واحدة؛ ويرفض أي قاعدة خارج dev-data."""
    db_path = str(ns.get("DB_PATH") or "")
    if "dev-data" not in db_path.replace("\\", "/"):
        raise RuntimeError("الزرع مقصور على نسخة التطوير (dev-data): %s" % db_path)
    import contracts_register as cr
    F = lambda **kw: {k: (v if isinstance(v, list) else [v]) for k, v in kw.items()}
    # نسخة التطوير بلا قائمة عقوبات، فيبقى كل عميل «قيد المراجعة» -وهو الصواب-؛ فتُحمَّل قائمة اختبار
    # تخيّلية بدالّة الاستيراد نفسها، كما يفعل اختبار الدورة الكاملة
    with ns["db"]() as con:
        has_list = con.execute("SELECT 1 FROM sanctions_entries WHERE active=1 LIMIT 1").fetchone()
    if not has_list:
        csv = ("full_name,id_number,registration_number,nationality,country,notes\n"
               "Fictional Listed Person,X-000,,XX,Nowhere,dev test list\n")
        ns["import_sanctions_file"](F(list_name="DEV_TEST_LIST", source_url="dev", list_type="TF"),
                                    {"list_file": ("dev-list.csv", csv.encode("utf-8"))})
    cids: Dict[str, int] = {}
    for ck, c in CLIENTS.items():
        with ns["db"]() as con:
            r = con.execute("SELECT id FROM clients WHERE legal_name=?", (c["legal_name"],)).fetchone()
        if r:
            cids[ck] = r[0]
            with ns["db"]() as con:
                st = con.execute("SELECT status FROM clients WHERE id=?", (r[0],)).fetchone()[0]
            if st != "active":
                ns["run_client_screening"](r[0])      # يُعاد الفحص بعد تحميل القائمة
            continue
        base = {k: v for k, v in c.items() if k != "contract"}
        cid = ns["create_client"](F(listed_saudi_market="0", **base), {})
        ns["run_client_screening"](cid)
        with ns["db"]() as con:
            cr.save_client_fields(con, cid, F(**c["contract"]), "seed")
        cids[ck] = cid
    with ns["db"]() as con:
        have = _matter_ids(con)
        # عضو من الدليل غير الشريك: المنصة تشترط عضواً واحداً على الأقل مع الشريك المسؤول
        r = con.execute("SELECT email FROM staff_directory WHERE is_active=1 AND COALESCE(is_signatory,0)=0 "
                        "AND email<>? ORDER BY email LIMIT 1", (PARTNER,)).fetchone()
        if not r:
            raise RuntimeError("لا موظف في الدليل يصلح عضواً في فريق التكليف")
        member = r[0]
    for mk, (ck, title, stype) in MATTERS.items():
        if mk not in have:
            have[mk] = ns["create_matter"](F(client_id=str(cids[ck]), title=title, service_type=stype,
                                             matter_number=""), "")
        with ns["db"]() as con:
            if not con.execute("SELECT 1 FROM matter_team WHERE matter_id=?", (have[mk],)).fetchone():
                cr.save_team(con, have[mk], F(partner_ar=PARTNER, partner_en=PARTNER, member=[member]), "seed")
    return have


def scenario_bar(con: sqlite3.Connection, h: Callable[[Any], str], current: str, matter_id: int) -> str:
    """شريط أعلى شاشة الإصدار: الحالة الحالية وما تختبره، وقائمة للتبديل بينها."""
    ids = _matter_ids(con)
    opts = ['<option value="">— اختر حالة —</option>']
    for s in SCENARIOS:
        mid = ids.get(s["matter"])
        if not mid:
            continue
        url = f"{AGREEMENT_URL}?id={mid}&scenario={s['key']}"
        opts.append(f'<option value="{h(url)}"{" selected" if s["key"] == current else ""}>{h(s["title"])}</option>')
    s = BY_KEY.get(current)
    what = (f'<p class="ltx-scn-what"><b>{h(s["title"])}</b> — يختبر: {h(s["tests"])}؛ '
            f'ولا يُنشأ شيء حتى تضغط «إنشاء الاتفاقية».</p>') if s else ""
    return (f'<div class="ltx-scn" role="region" aria-label="الحالات التجريبية">'
            f'<label for="ltx-scn-pick">حالة تجريبية</label>'
            f'<select id="ltx-scn-pick" onchange="if(this.value)location.href=this.value">{"".join(opts)}</select>'
            f'{what}</div>')


AGREEMENT_URL = "/matter/agreement"


def hub_html(con: sqlite3.Connection, h: Callable[[Any], str]) -> str:
    con.row_factory = sqlite3.Row
    rows = con.execute(
        """SELECT m.id, m.matter_number, m.title, m.status, c.legal_name,
                  (SELECT d.status FROM issued_documents d WHERE d.matter_id=m.id AND d.doc_type='agreement'
                    ORDER BY d.id DESC LIMIT 1) AS agr
           FROM matters m JOIN clients c ON c.id=m.client_id ORDER BY m.id DESC""").fetchall()
    label = {"issued": "صادرة لم تُوقَّع", "signed": "موقَّعة", "uploaded": "موقَّعة ومرفوعة",
             "withdrawn": "مسحوبة", None: "لم تصدر"}
    trs = "".join(
        f"<tr><td class='ltx-num'>{h(r['matter_number'])}</td><td>{h(r['legal_name'])}</td><td>{h(r['title'])}</td>"
        f"<td>{h(label.get(r['agr'], r['agr']))}</td>"
        f"<td><a class='btn' href='{AGREEMENT_URL}?id={r['id']}'>إصدار الاتفاقية</a></td></tr>" for r in rows)
    body = (
        "<div class='card ltx-hub'><h2>الاتفاقيات</h2>"
        "<p>اختر التكليف ثم أصدر اتفاقيته؛ وتُقرأ بيانات العميل والفريق من ملفّيهما.</p>"
        "<div class='ltx-links'><a href='/reports/contracts/unsigned'>الصادرة ولم تُوقَّع</a>"
        "<a href='/reports/contracts/signed-not-uploaded'>الموقَّعة ولم تُرفع</a></div>"
        "<input type='search' class='ltx-filter' placeholder='ابحث باسم العميل أو رقم التكليف' "
        "oninput=\"var q=this.value.trim();document.querySelectorAll('.ltx-hub tbody tr').forEach(function(r){r.hidden=q&&r.textContent.indexOf(q)<0})\">"
        "<div class='ltx-tablewrap'><table><thead><tr><th>رقم التكليف</th><th>العميل</th><th>التكليف</th>"
        "<th>حال الاتفاقية</th><th></th></tr></thead><tbody>" + trs + "</tbody></table></div></div>")
    if enabled():
        ids = _matter_ids(con)
        cards = "".join(
            f"<li><a href='{AGREEMENT_URL}?id={ids[s['matter']]}&scenario={s['key']}'><b>{h(s['title'])}</b>"
            f"<span>{h(s['tests'])}</span></a></li>" for s in SCENARIOS if s["matter"] in ids)
        body += ("<div class='card ltx-hub'><h2>الحالات التجريبية</h2>"
                 "<p>عملاء تخيّليون في نسخة التجربة وحدها، لكل حالة قيمٌ جاهزة تملأ شاشة الإصدار؛ "
                 "بدّل بينها واختبر ما يدخل العقد وما يخرج منه.</p>"
                 + (f"<ul class='ltx-scn-list'>{cards}</ul>" if cards else
                    "<p>لم تُزرع الحالات بعد: شغّل <code dir='ltr'>tools/seed_dev_scenarios.py</code>.</p>")
                 + "</div>")
    return body


def _matter_buttons(raw: str) -> str:
    """زرّا «إصدار الاتفاقية» و«فريق التكليف» في رأس صفحة التكليف، قبل «تعديل المشروع» (ن-1 من تدقيق الاستخدام)."""
    import re as _re
    m = _re.search(r"<a class='btn secondary' href='/matter/edit\?id=(\d+)'>", raw)
    if not m or f"{AGREEMENT_URL}?id={m.group(1)}" in raw:
        return raw
    mid = m.group(1)
    btns = (f"<a class='btn' href='{AGREEMENT_URL}?id={mid}'>إصدار الاتفاقية</a> "
            f"<a class='btn secondary' href='/matter/team?id={mid}'>فريق التكليف</a> ")
    return raw[:m.start()] + _matter_status(int(mid)) + btns + raw[m.start():]


def _matter_status(mid: int) -> str:
    """ن-6: شريط حال التكليف — فحص العميل، والفريق، والاتفاقية — والخطوة التالية واحدة."""
    try:
        import contracts_register as cr
        with _NS["db"]() as con:
            con.row_factory = sqlite3.Row
            cst = con.execute("SELECT c.id, c.status FROM matters m JOIN clients c ON c.id=m.client_id WHERE m.id=?",
                              (mid,)).fetchone()
            team = con.execute("SELECT COUNT(*) FROM matter_team WHERE matter_id=?", (mid,)).fetchone()[0]
            doc = con.execute("SELECT id, status FROM issued_documents WHERE matter_id=? AND doc_type='agreement' "
                              "AND status!='withdrawn' ORDER BY id DESC LIMIT 1", (mid,)).fetchone()
    except Exception:
        return ""
    if not cst:
        return ""
    ready = cst["status"] in cr.CLIENT_OK
    cells = [("فحص العميل", "اجتاز" if cst["status"] == cr.CLIENT_READY else cr.CLIENT_STATUS_AR.get(cst["status"] or "", cst["status"] or "—"), ready),
             ("الفريق", "محدَّد" if team else "لم يُحدَّد", bool(team)),
             ("الاتفاقية", cr.DOC_STATUS_AR.get(doc["status"], doc["status"]) if doc else "لم تصدر",
              bool(doc) and doc["status"] == "uploaded")]
    if not ready:
        nxt = (f"/client?id={cst['id']}", "أكمل فحص العميل")
    elif not team:
        nxt = (f"/matter/team?id={mid}", "حدّد فريق التكليف")
    elif not doc:
        nxt = (f"{AGREEMENT_URL}?id={mid}", "أصدر الاتفاقية")
    elif doc["status"] in ("issued", "signed"):
        nxt = (f"/document/signed?id={doc['id']}", "أرفق الموقَّعة وارفعها" if doc["status"] == "issued" else "ارفع الموقَّعة")
    else:
        nxt = None
    li = "".join(f"<li class='{'ltx-ok' if good else 'ltx-wait'}'><span>{t}</span><b>{v}</b></li>" for t, v, good in cells)
    step = f"<a class='ltx-next' href='{nxt[0]}'>الخطوة التالية: {nxt[1]}</a>" if nxt else "<span class='ltx-next ltx-done'>اكتملت الدورة</span>"
    return f"<div class='ltx-mstatus'><ul>{li}</ul>{step}</div>"


def install(ns: Dict[str, Any]) -> None:
    _NS.update(ns)
    base_md = ns.get("matter_detail")
    if base_md and not getattr(base_md, "_ltx", False):
        def matter_detail(matter_id: int) -> bytes:
            return _matter_buttons(base_md(matter_id).decode("utf-8")).encode("utf-8")
        matter_detail._ltx = True
        ns["matter_detail"] = matter_detail
    handler = ns.get("AppHandler")
    if not handler or getattr(handler, "_ltx_hub", False):
        return
    base_get = handler.do_GET

    def do_get(self) -> None:
        parsed = ns["urlparse"](self.path)
        q = ns["parse_qs"](parsed.query)
        if parsed.path not in (HUB_PATH, AGREEMENT_URL) or (parsed.path == AGREEMENT_URL and "scenario" not in q):
            return base_get(self)
        user = ns["_v1512_ctx"](self)
        if not user:
            return ns["_auth_send_redirect"](self, "/login")
        if user.get("must_change_password"):
            return ns["_auth_send_redirect"](self, "/account")
        layout, h = ns["layout"], ns["h"]
        import contracts_register as cr
        with ns["db"]() as con:
            cr.ensure_schema(con)
            if parsed.path == HUB_PATH:
                return self._send(layout("الاتفاقيات", hub_html(con, h), HUB_PATH))
            key = (q.get("scenario") or [""])[0]
            try:
                mid = int((q.get("id") or ["0"])[0] or 0)
            except ValueError:
                mid = 0
            form = scenario_form(key) if enabled() else None
            if not form:
                return base_get(self)
            try:
                body = cr.screen_html(con, mid, h, form)
            except cr.RegisterError as exc:
                return self._send(layout("إصدار الاتفاقية", f"<div class='error'>{h(exc)}</div>", HUB_PATH), 409)
            bar = scenario_bar(con, h, key, mid)
            return self._send(layout("إصدار الاتفاقية — حالة تجريبية", bar + body, HUB_PATH))

    handler.do_GET = do_get
    handler._ltx_hub = True

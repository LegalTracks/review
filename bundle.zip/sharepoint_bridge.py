# -*- coding: utf-8 -*-
"""جسر أبواب سامح -مسارات Power Automate الأربعة- من المنصة إلى نظام إدارة الوثائق.

ملف مستقل لا يُربط بالمنصة بعد؛ يُراجَع أولاً ثم يُوصل. مكتبة بايثون القياسية وحدها
(urllib و json و base64) على طريقة app.py.

المصدر: source/sameh-specs/postman-2026-09-25/ -مجموعات Postman من سامح بتاريخ 25/09-، وهي المعتمدة؛
فالتسليم الأول (source/sameh-specs/1..4-*.json) وصل بأسماء الأبواب مبدَّلة زوجاً زوجاً (انظر README).
وأسماء الحقول هنا منقولة من أجسام Postman حرفاً بحرف، ولا يُغيَّر منها شيء.

القواعد التي يطبّقها:
- الروابط لا تُكتب في أي ملف: تُقرأ من متغيرات البيئة ساعة الإرسال؛ فإن غاب المتغير
  أو حمل الرابط المحجوب «<REDACTED>» رُفض الإرسال بخطأ صريح، ولا رجوع إلى رابط المواصفة.
- التوقيع (sig) مفتاح الباب؛ فلا يظهر في رسالة خطأ ولا في سجل ولا في نتيجة.
- محتوى الملفات لا يُسجَّل أبداً؛ يُسجَّل عددها وحجم الطلب فقط.
- إعادة المحاولة على أخطاء الشبكة و 5xx و 429 وحدها، بعدد محدود وانتظار متصاعد؛
  وأخطاء 4xx الأخرى لا تُعاد لأن تكرارها لا يغيّر نتيجتها.

حارس الحجم (الافتراض 7 في README):
المحتوى base64 فيزيد نحو الثلث، وحدّ Power Automate للطلب قرابة 100 ميغابايت.
فيُحسب حجم الطلب مرمَّزاً كما سيُرسل بالبايت؛ فإن جاوز الحدّ -افتراضياً 90,000,000 بايت،
ويُغيَّر بالمعامل max_bytes أو بالمتغير MASARAT_SP_MAX_REQUEST_BYTES- وُزِّعت الملفات
على عدة استدعاءات للباب نفسه، تحمل كلها الحقول الأخرى نفسها بلا تغيير، ويحمل كل منها
جزءاً من الملفات بترتيبها الأصلي. والملف الواحد لا يُجزَّأ: إن جاوز الحدّ وحده رُفض الطلب
كله قبل أي إرسال. والأجزاء تُرسل بالترتيب ويتوقف الإرسال عند أول جزء يفشل؛ وتبيّن النتيجة
ما وصل منها، فيُعاد إرسال الباقي وحده لا الكل، كي لا يتكرر في شيربوينت ما وصل.
"""
from __future__ import annotations

import base64
import http.client
import json
import logging
import os
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

log = logging.getLogger("masarat.sharepoint_bridge")

DEFAULT_MAX_BYTES = 90_000_000
MAX_BYTES_ENV = "MASARAT_SP_MAX_REQUEST_BYTES"
REDACTED_MARK = "<REDACTED>"
# المضيفات التي يُقبل لها http بلا تشفير -للاختبار المحلي وحده-؛ وما عداها https إلزاماً
_LOCAL_HOSTS = {"127.0.0.1", "localhost", "::1"}
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_SIG_RE = re.compile(r"(sig=)[^&\s'\"<>]+", re.IGNORECASE)


class BridgeError(Exception):
    """خطأ في الجسر يُعرض بنصه؛ ولا يحمل رابطاً ولا توقيعاً."""


class BridgeConfigError(BridgeError):
    """رابط الباب غير مهيّأ أو غير صالح."""


class BridgeValidationError(BridgeError):
    """جسم الطلب لا يستوفي ما يلزم قبل الإرسال."""


# ─────────────────────────── الأبواب ───────────────────────────

@dataclass(frozen=True)
class Door:
    """باب واحد من أبواب سامح: اسمه في المواصفة ومتغير رابطه وحقوله بترتيبها،
    ومعرّف مساره في Power Automate (ليس سراً؛ السرّ هو التوقيع وحده)."""
    key: str
    spec_name: str
    env_var: str
    fields: Tuple[str, ...]
    files_field: Optional[str] = None
    workflow_id: str = ""

    def url(self) -> str:
        """يقرأ الرابط من البيئة ساعة الطلب؛ ولا يعيد رابط المواصفة المحجوب أبداً."""
        raw = (os.environ.get(self.env_var) or "").strip()
        if not raw:
            raise BridgeConfigError(
                f"رابط الباب «{self.spec_name}» غير مهيّأ: عيّن متغير البيئة {self.env_var} "
                f"بالرابط الكامل من بريد سامح؛ ولا يُكتب الرابط في أي ملف")
        if REDACTED_MARK.lower() in raw.lower() or "%3credacted%3e" in raw.lower():
            raise BridgeConfigError(
                f"متغير البيئة {self.env_var} يحمل الرابط المحجوب من المواصفة لا الرابط الحقيقي")
        parts = urllib.parse.urlsplit(raw)
        host = (parts.hostname or "").lower()
        if parts.scheme == "https" and host:
            # حارس التبديل: الأسماء وصلت في التسليم الأول مبدَّلة زوجاً زوجاً؛ فرابط الباب
            # يجب أن يحمل معرّف مساره، وإلا فهو رابط باب آخر وُضع في غير متغيره
            if self.workflow_id and f"/workflows/{self.workflow_id}/" not in parts.path.lower():
                raise BridgeConfigError(
                    f"متغير البيئة {self.env_var} يحمل رابط مسار غير مسار «{self.spec_name}» "
                    f"(المعرّف المنتظر يبدأ بـ {self.workflow_id[:8]})؛ ولعله رابط باب آخر")
            return raw
        if parts.scheme == "http" and host in _LOCAL_HOSTS:
            return raw
        raise BridgeConfigError(
            f"متغير البيئة {self.env_var} لا يحمل رابط https صالحاً")


_PM = "postman-2026-09-25/"
CUSTOMER_ONBOARDING = Door(
    "customer_onboarding", _PM + "Customer Onboarding", "MASARAT_SP_URL_CUSTOMER_ONBOARDING",
    ("CustomerName", "CustomerNo", "CustomerEmail", "KYCFiles"), "KYCFiles",
    "5267c4887fdc42708cc8d640727c094e")
UPDATE_KYC = Door(
    "update_kyc", _PM + "Update KYC", "MASARAT_SP_URL_UPDATE_KYC",
    ("CustomerName", "KYCFiles"), "KYCFiles",
    "b51c396d257a4e34aecca1dae7d5c8e9")
PROJECT_ONBOARDING = Door(
    "project_onboarding", _PM + "Project Onboarding", "MASARAT_SP_URL_PROJECT_ONBOARDING",
    ("ProjectName", "CustomerName", "ProjectType", "ProjectTeam", "ContractNo",
     "ProjectManager", "FinancialFiles"), "FinancialFiles",
    "af296a8db391428d8c23ca11dfd0668c")
UPDATE_PROJECT_TEAM = Door(
    "update_project_team", _PM + "Change Project Team", "MASARAT_SP_URL_UPDATE_PROJECT_TEAM",
    ("ProjectName", "CustomerName", "ProjectType", "ProjectTeam", "ProjectManager"), None,
    "4314d41533af492daaa0233143233fac")

DOORS: Dict[str, Door] = {d.key: d for d in
                          (CUSTOMER_ONBOARDING, UPDATE_KYC, PROJECT_ONBOARDING, UPDATE_PROJECT_TEAM)}


# ─────────────────────────── التحقق والبناء ───────────────────────────

def _text(value: Any, label: str) -> str:
    if value is None or isinstance(value, (bytes, bytearray)):
        raise BridgeValidationError(f"الحقل {label} مطلوب نصاً")
    s = str(value).strip()
    if not s:
        raise BridgeValidationError(f"الحقل {label} مطلوب ولا يُقبل فارغاً")
    return s


def _email(value: Any, label: str) -> str:
    s = _text(value, label)
    if not _EMAIL_RE.match(s):
        raise BridgeValidationError(f"قيمة {label} ليست بريداً صالحاً: {s}")
    return s


def _files(files: Optional[Iterable[Any]], label: str, required: bool) -> List[Dict[str, str]]:
    """يقبل (الاسم، البايتات) أو {"FileName", "FileContent": bytes}، ويعيدها مرمَّزة base64."""
    out: List[Dict[str, str]] = []
    for i, item in enumerate(files or []):
        if isinstance(item, dict):
            name, content = item.get("FileName"), item.get("FileContent")
        else:
            try:
                name, content = item
            except (TypeError, ValueError):
                raise BridgeValidationError(f"العنصر {i + 1} في {label} ليس (اسماً، محتوى)") from None
        name = _text(name, f"{label}[{i + 1}].FileName")
        if not isinstance(content, (bytes, bytearray)):
            raise BridgeValidationError(
                f"محتوى الملف «{name}» في {label} يُمرَّر بايتات خاماً؛ والجسر يتولى ترميزه")
        out.append({"FileName": name, "FileContent": base64.b64encode(bytes(content)).decode("ascii")})
    if required and not out:
        raise BridgeValidationError(f"الحقل {label} يستلزم ملفاً واحداً على الأقل")
    return out


def _email_list(items: Any, label: str) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    seen = set()
    for i, it in enumerate(items or []):
        e = _email(it.get("Email") if isinstance(it, dict) else it, f"{label}[{i + 1}].Email")
        if e.lower() not in seen:
            seen.add(e.lower())
            out.append({"Email": e})
    return out


def _team(team: Any) -> Tuple[List[Dict[str, str]], List[Dict[str, str]]]:
    """يقبل ناتج contracts_register.team_for_sharepoint كما هو، ويرفض مديراً فارغاً."""
    if not isinstance(team, dict):
        raise BridgeValidationError("الفريق يُمرَّر قاموساً فيه ProjectManager و ProjectTeam")
    managers = _email_list(team.get("ProjectManager"), "ProjectManager")
    if not managers:
        raise BridgeValidationError("ProjectManager فارغ: لا يُفتح مشروع ولا يُحدَّث بلا مدير")
    members = _email_list(team.get("ProjectTeam"), "ProjectTeam")
    return members, managers


def customer_onboarding(name: str, no: str, email: str, files: Sequence[Any]) -> Dict[str, Any]:
    """فتح العميل (Customer Onboarding): الاسم من سجله، و CustomerNo مفترض أنه الرقم الموحّد 700
    (الافتراض 1 والقرار 64)، وبريده، ومستندات الامتثال مع تقرير الامتثال (القرار 72)."""
    return {"CustomerName": _text(name, "CustomerName"),
            "CustomerNo": _text(no, "CustomerNo"),
            "CustomerEmail": _email(email, "CustomerEmail"),
            "KYCFiles": _files(files, "KYCFiles", required=True)}


def update_kyc(name: str, files: Sequence[Any]) -> Dict[str, Any]:
    """تحديث مستندات الامتثال (Update KYC) لعميل قائم: الاسم والملفات وحدهما."""
    return {"CustomerName": _text(name, "CustomerName"),
            "KYCFiles": _files(files, "KYCFiles", required=True)}


def project_onboarding(project_name: str, customer_name: str, project_type: str,
                       team: Dict[str, Any], contract_no: str,
                       files: Optional[Sequence[Any]] = None) -> Dict[str, Any]:
    """فتح المشروع (Project Onboarding) بعد التوقيع؛ و team ناتج team_for_sharepoint،
    و ContractNo رقم المرجع. والملفات اختيارية في المواصفة؛ وموضع العقد الموقّع في
    FinancialFiles مسألة مفتوحة (الافتراض 3، والمعلَّقة «ل»)."""
    members, managers = _team(team)
    return {"ProjectName": _text(project_name, "ProjectName"),
            "CustomerName": _text(customer_name, "CustomerName"),
            "ProjectType": _text(project_type, "ProjectType"),
            "ProjectTeam": members,
            "ContractNo": _text(contract_no, "ContractNo"),
            "ProjectManager": managers,
            "FinancialFiles": _files(files, "FinancialFiles", required=False)}


def update_project_team(project_name: str, customer_name: str, project_type: str,
                        team: Dict[str, Any]) -> Dict[str, Any]:
    """تغيير فريق المشروع (Change Project Team) بعد الرفع (القرار 141): لا رقم عقد فيه ولا ملفات."""
    members, managers = _team(team)
    return {"ProjectName": _text(project_name, "ProjectName"),
            "CustomerName": _text(customer_name, "CustomerName"),
            "ProjectType": _text(project_type, "ProjectType"),
            "ProjectTeam": members,
            "ProjectManager": managers}


def check_body(door: Door, body: Dict[str, Any]) -> None:
    """الجسم يحمل حقول الباب بأسمائها بالضبط، لا زائد ولا ناقص."""
    if not isinstance(body, dict):
        raise BridgeValidationError("جسم الطلب يجب أن يكون قاموساً")
    extra = sorted(set(body) - set(door.fields))
    missing = [f for f in door.fields if f not in body]
    if extra or missing:
        raise BridgeValidationError(
            f"حقول الباب «{door.spec_name}» لا تطابق المواصفة؛ ناقص: {missing or '-'}، زائد: {extra or '-'}")
    if "ProjectManager" in door.fields and not body.get("ProjectManager"):
        raise BridgeValidationError("ProjectManager فارغ: لا يُرسل الباب بلا مدير")


# ─────────────────────────── حارس الحجم ───────────────────────────

def encode(body: Dict[str, Any]) -> bytes:
    """الترميز نفسه الذي يُرسل؛ فالحجم المحسوب هو الحجم الواصل."""
    return json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def resolve_max_bytes(max_bytes: Optional[int] = None) -> int:
    if max_bytes is None:
        raw = (os.environ.get(MAX_BYTES_ENV) or "").strip()
        max_bytes = int(raw) if raw else DEFAULT_MAX_BYTES
    if max_bytes <= 0:
        raise BridgeConfigError("حدّ حجم الطلب يجب أن يكون موجباً")
    return int(max_bytes)


def split_body(door: Door, body: Dict[str, Any], max_bytes: Optional[int] = None) -> List[Dict[str, Any]]:
    """يوزّع ملفات الطلب على أجزاء لا يجاوز أيها الحدّ، والحقول الأخرى ثابتة في كلها."""
    limit = resolve_max_bytes(max_bytes)
    if len(encode(body)) <= limit:
        return [body]
    if not door.files_field:
        raise BridgeValidationError(
            f"طلب الباب «{door.spec_name}» يجاوز الحدّ ({limit} بايت) وليس فيه ملفات تُوزَّع")
    files = list(body.get(door.files_field) or [])
    base = dict(body)
    base[door.files_field] = []
    base_size = len(encode(base))
    parts: List[List[Dict[str, str]]] = []
    current: List[Dict[str, str]] = []
    size = base_size
    for f in files:
        entry = len(json.dumps(f, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
        if base_size + entry > limit:
            raise BridgeValidationError(
                f"الملف «{f.get('FileName')}» وحده يجاوز حدّ الطلب ({limit} بايت بعد الترميز)؛ "
                f"والملف الواحد لا يُجزَّأ")
        add = entry + (1 if current else 0)   # الفاصلة بين عناصر المصفوفة
        if current and size + add > limit:
            parts.append(current)
            current, size = [], base_size
            add = entry
        current.append(f)
        size += add
    if current:
        parts.append(current)
    bodies = []
    for chunk in parts:
        b = dict(base)
        b[door.files_field] = chunk
        assert len(encode(b)) <= limit, "خطأ في حساب الحجم"
        bodies.append(b)
    return bodies


# ─────────────────────────── الإرسال ───────────────────────────

@dataclass
class PartResult:
    index: int
    ok: bool
    status: Optional[int]
    attempts: int
    error: str = ""
    file_names: List[str] = field(default_factory=list)
    bytes_sent: int = 0
    response: str = ""


@dataclass
class SendResult:
    """نتيجة الإرسال؛ لا تحمل رابطاً ولا توقيعاً ولا محتوى ملف.

    parts بترتيب الإرسال؛ وما فشل منها هو أول فاشل، وما بعده لم يُرسل (sent=False).
    """
    door: str
    ok: bool
    status: Optional[int]
    attempts: int
    error: str = ""
    parts: List[PartResult] = field(default_factory=list)
    parts_total: int = 0

    @property
    def parts_sent(self) -> int:
        return sum(1 for p in self.parts if p.ok)

    def pending_bodies(self, bodies: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """ما لم يصل بعد من أجزاء الطلب، لإعادة إرساله وحده."""
        return bodies[self.parts_sent:]


def scrub(text: str, url: str = "") -> str:
    """يحجب الرابط وسلسلة استعلامه وأي توقيع من نص قبل عرضه أو تسجيله."""
    s = str(text)
    if url:
        q = urllib.parse.urlsplit(url).query
        for secret in (url, q, urllib.parse.unquote(url), urllib.parse.unquote(q)):
            if secret:
                s = s.replace(secret, REDACTED_MARK)
        for val in urllib.parse.parse_qs(q).get("sig", []):
            if val:
                s = s.replace(val, REDACTED_MARK)
                s = s.replace(urllib.parse.quote(val, safe=""), REDACTED_MARK)
    return _SIG_RE.sub(r"\1" + REDACTED_MARK, s)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """لا اتباع لإعادة التوجيه: urllib يحوّل POST إلى GET بلا جسم، فيضيع الطلب صامتاً."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_opener = urllib.request.build_opener(_NoRedirect)

_RETRY_STATUS = {429}
_NETWORK_ERRORS = (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError,
                   http.client.HTTPException, OSError)


def _retry_after(headers: Any, cap: float) -> Optional[float]:
    try:
        v = headers.get("Retry-After") if headers is not None else None
        return min(float(v), cap) if v is not None else None
    except (TypeError, ValueError):
        return None


def _post_once(url: str, data: bytes, timeout: float) -> Tuple[int, str, Any]:
    req = urllib.request.Request(url, data=data, method="POST", headers={
        "Content-Type": "application/json; charset=utf-8", "Accept": "application/json"})
    with _opener.open(req, timeout=timeout) as resp:
        return resp.status, resp.read(4096).decode("utf-8", "replace"), resp.headers


def _send_part(door: Door, url: str, body: Dict[str, Any], index: int, timeout: float,
               max_attempts: int, backoff: float, backoff_cap: float,
               sleep: Callable[[float], None]) -> PartResult:
    data = encode(body)
    names = [f.get("FileName", "") for f in (body.get(door.files_field) or [])] if door.files_field else []
    pr = PartResult(index=index, ok=False, status=None, attempts=0, file_names=names, bytes_sent=len(data))
    for attempt in range(1, max_attempts + 1):
        pr.attempts = attempt
        wait: Optional[float] = None
        try:
            status, text, _h = _post_once(url, data, timeout)
            pr.status = status
            if 200 <= status < 300:
                pr.ok, pr.error, pr.response = True, "", scrub(text, url)
                log.info("باب %s جزء %d: %d بعد %d محاولة (%d بايت، %d ملف)",
                         door.spec_name, index + 1, status, attempt, len(data), len(names))
                return pr
            pr.error = f"استجابة غير متوقعة {status}"
            retryable = False
        except urllib.error.HTTPError as e:
            pr.status = e.code
            try:
                detail = e.read(1024).decode("utf-8", "replace")
            except Exception:
                detail = ""
            pr.error = scrub(f"HTTP {e.code} {e.reason or ''} {detail}".strip(), url)
            retryable = e.code >= 500 or e.code in _RETRY_STATUS
            if retryable:
                wait = _retry_after(e.headers, backoff_cap)
        except _NETWORK_ERRORS as e:
            pr.status = None
            pr.error = scrub(f"خطأ شبكة: {type(e).__name__}: {e}", url)
            retryable = True
        log.warning("باب %s جزء %d محاولة %d/%d فشلت: %s",
                    door.spec_name, index + 1, attempt, max_attempts, pr.error)
        if not retryable or attempt == max_attempts:
            break
        sleep(wait if wait is not None else min(backoff * (2 ** (attempt - 1)), backoff_cap))
    return pr


def send(door: Door, body: Dict[str, Any], timeout: float = 120.0, *, max_attempts: int = 4,
         backoff: float = 2.0, backoff_cap: float = 60.0, max_bytes: Optional[int] = None,
         sleep: Callable[[float], None] = time.sleep) -> SendResult:
    """يرسل الجسم إلى الباب، مقسوماً إن جاوز الحدّ؛ ولا يرفع استثناءً على فشل الشبكة أو الخادم.

    يرفع BridgeConfigError إن غاب الرابط، و BridgeValidationError إن خالف الجسم المواصفة
    أو جاوز ملف واحد الحدّ؛ وكلاهما قبل أي اتصال. وما عداهما يعود في النتيجة.
    تنبيه: إعادة المحاولة بعد انقطاع المهلة قد تكرر طلباً وصل فعلاً، لأن الباب لا يُعرف
    عنه أنه يتسامح مع التكرار؛ والحدّ الأعلى للمحاولات يحصر هذا الأثر.
    """
    if max_attempts < 1:
        raise BridgeConfigError("عدد المحاولات لا يقل عن واحدة")
    check_body(door, body)
    url = door.url()
    bodies = split_body(door, body, max_bytes)
    result = SendResult(door=door.key, ok=False, status=None, attempts=0, parts_total=len(bodies))
    if len(bodies) > 1:
        log.info("باب %s: الطلب قُسم إلى %d أجزاء", door.spec_name, len(bodies))
    for i, b in enumerate(bodies):
        pr = _send_part(door, url, b, i, timeout, max_attempts, backoff, backoff_cap, sleep)
        result.parts.append(pr)
        result.attempts += pr.attempts
        result.status = pr.status
        if not pr.ok:
            done = sum(1 for p in result.parts if p.ok)
            result.error = scrub(f"الجزء {i + 1} من {len(bodies)} فشل ({done} وصل): {pr.error}", url)
            return result
    result.ok = True
    return result

# -*- coding: utf-8 -*-
"""مسارات قانونية — نسخة المراجعة: ملاحظات المراجِعين على كل صفحة، وتعطيل ما لا يُسترجع (مؤقت؛ يُزال بحذف سطرَي الوصل).

طلبه المالك 30/09 ليجرّب المدراء ومدير التقاضي المنصة ويعلّقوا على الشكل والتقسيم والوظائف، بلا حسابات.
– زرّ «ملاحظة على هذه الصفحة» في كل صفحة: الاسم (يُحفظ في متصفح المراجِع) والملاحظة، وتُحفظ مع رابط الصفحة وعنوانها
  في ملف review-feedback.jsonl بجانب قاعدة التجربة، لا في القاعدة.
– /review/feedback: كل الملاحظات مجموعة بالصفحة، وزرّ نسخها.
– وتُرفض في نسخة المراجعة الأفعال التي لا تُسترجع (الاستعادة، والحذف، وإدارة المستخدمين، وأوامر مركز التحكم).
لا يعمل إلا بما يعمل به الدخول التلقائي: المفتاح، وبيئة غير الإنتاج، وقاعدة في dev-data.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
from pathlib import Path
from typing import Any, Dict

import dev_autologin

FEED_PATH = "/review/feedback"
POST_PATH = "/review/feedback/add"
BLOCKED = ("/backups/restore", "/restore", "delete", "reset_user_password", "toggle_user", "/settings/add_user",
           "/settings/update_user", "/production/", "/users/")
_NS: Dict[str, Any] = {}
# خادم مجاني يمحو ملفاته إذا نام: فتُرسَل الملاحظة بالبريد أيضاً إلى هذا العنوان (يُضبط في نسخة الاستضافة وحدها)
MAILTO = "".join(ch for ch in os.environ.get("MASARAT_FEEDBACK_MAILTO", "") if ch.isalnum() or ch in "@.-_")

WIDGET = """<style id="ltr-style">
#ltr-btn{position:fixed;inset-inline-start:18px;bottom:96px;z-index:3000;background:#244037;color:#fff;border:0;border-radius:3px;
 padding:10px 16px;font:700 14px Tajawal,sans-serif;box-shadow:0 6px 18px rgba(20,37,31,.22);cursor:pointer}
#ltr-btn:hover{background:#335248}
#ltr-panel{position:fixed;inset-inline-start:18px;bottom:144px;z-index:3000;width:min(360px,calc(100vw - 36px));background:#fff;
 border:1px solid #CFC6B6;border-radius:3px;box-shadow:0 12px 32px rgba(20,37,31,.18);padding:14px;font-family:Tajawal,sans-serif}
#ltr-panel[hidden]{display:none}
#ltr-panel h4{margin:0 0 8px;font:400 17px "Hacen Liner","Tajawal",sans-serif;color:#14251F}
#ltr-panel input,#ltr-panel textarea{width:100%;box-sizing:border-box;border:1px solid #CFC6B6;border-radius:3px;padding:8px;
 font:15px Tajawal,sans-serif;margin-bottom:8px}
#ltr-panel textarea{min-height:110px}
#ltr-panel .ltr-row{display:flex;gap:8px;align-items:center}
#ltr-panel .ltr-row button{background:#244037;color:#fff;border:0;border-radius:3px;padding:8px 14px;font:700 14px Tajawal,sans-serif;cursor:pointer}
#ltr-panel .ltr-row a{margin-inline-start:auto;font-size:13px;color:#265871}
#ltr-msg{font-size:13px;color:#2E8C73;margin-top:6px}
</style>
<button type="button" id="ltr-btn">ملاحظة على هذه الصفحة</button>
<div id="ltr-panel" hidden><h4>ملاحظتك على هذه الصفحة</h4>
<input id="ltr-name" placeholder="اسمك" autocomplete="name">
<textarea id="ltr-note" placeholder="ما الذي لم يتضح، أو ما تقترح تغييره؟"></textarea>
<div class="ltr-row"><button type="button" id="ltr-send">إرسال</button><a href="/review/feedback">كل الملاحظات</a></div>
<div id="ltr-msg" role="status"></div></div>
<script>(function(){var mt='__LTR_MAILTO__',b=document.getElementById('ltr-btn'),p=document.getElementById('ltr-panel'),n=document.getElementById('ltr-name'),
t=document.getElementById('ltr-note'),m=document.getElementById('ltr-msg');
try{n.value=localStorage.getItem('ltr-name')||'';}catch(e){}
b.addEventListener('click',function(){p.hidden=!p.hidden;if(!p.hidden)(n.value?t:n).focus();});
document.getElementById('ltr-send').addEventListener('click',function(){
 if(!n.value.trim()){m.textContent='اكتب اسمك أولاً';n.focus();return;} if(!t.value.trim()){m.textContent='اكتب ملاحظتك';t.focus();return;}
 try{localStorage.setItem('ltr-name',n.value.trim());}catch(e){}
 var h=document.querySelector('main h2,main h1');
 fetch('/review/feedback/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({page:location.pathname+location.search,
  title:(h?h.textContent.trim():document.title),name:n.value.trim(),note:t.value.trim()})}).then(function(r){
  if(r.ok||mt){t.value='';m.textContent=mt?'فُتحت رسالة بريد فيها ملاحظتك؛ اضغط «إرسال» فيها لتصل.':'وصلت ملاحظتك، شكراً لك.';}else{m.textContent='تعذّر الحفظ؛ أعد المحاولة.';}});
 if(mt){location.href='mailto:'+mt+'?subject='+encodeURIComponent('ملاحظة على المنصة: '+(h?h.textContent.trim():document.title))+
  '&body='+encodeURIComponent(t.value.trim()+'

الصفحة: '+location.href+'
من: '+n.value.trim());}});})();</script>"""


def enabled(ns: Dict[str, Any]) -> bool:
    return dev_autologin.enabled(ns)


def _file(ns: Dict[str, Any]) -> Path:
    return Path(str(ns.get("DB_PATH"))).parent / "review-feedback.jsonl"


def _feed_html(ns: Dict[str, Any]) -> str:
    h = ns["h"]
    rows = []
    f = _file(ns)
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            try:
                rows.append(json.loads(line))
            except ValueError:
                pass
    groups: Dict[str, list] = {}
    for r in rows:
        groups.setdefault(f"{r.get('title') or ''} — {r.get('page') or ''}", []).append(r)
    parts = []
    for key, rs in groups.items():
        items = "".join(f"<li><b>{h(r.get('name'))}</b> <span class='small'>{h(r.get('at'))}</span><br>{h(r.get('note'))}</li>" for r in rs)
        parts.append(f"<section class='card'><h3>{h(key)}</h3><ul>{items}</ul></section>")
    text = "\n\n".join(f"{k}\n" + "\n".join(f"– {r.get('name')}: {r.get('note')}" for r in rs) for k, rs in groups.items())
    copy = ("<button type='button' onclick=\"navigator.clipboard.writeText(document.getElementById('ltr-all').value)"
            ".then(function(){alert('نُسخت الملاحظات')})\">نسخ الملاحظات كلها</button>"
            f"<textarea id='ltr-all' hidden>{h(text)}</textarea>")
    head = (f"<div class='card'><h2>ملاحظات المراجِعين</h2><p>{len(rows)} ملاحظة على {len(groups)} صفحة؛ "
            "تُحفظ في ملف بجانب قاعدة التجربة، لا في القاعدة.</p>" + (copy if rows else "") + "</div>")
    return head + ("".join(parts) or "<div class='card'><p>لا ملاحظات بعد.</p></div>")


def install(ns: Dict[str, Any]) -> None:
    _NS.update(ns)
    handler = ns.get("AppHandler")
    if not handler or getattr(handler, "_lt_review", False) or not enabled(ns):
        return
    base_get, base_post, base_send = handler.do_GET, handler.do_POST, handler._send

    def _send(self, data, status: int = 200, content_type: str = "text/html; charset=utf-8") -> None:
        if content_type.startswith("text/html"):
            raw = data.decode("utf-8") if isinstance(data, bytes) else data
            if "</body>" in raw and 'id="ltr-btn"' not in raw and 'name="password"' not in raw:
                i = raw.rfind("</body>")
                data = (raw[:i] + WIDGET.replace("__LTR_MAILTO__", MAILTO) + raw[i:]).encode("utf-8")
        return base_send(self, data, status, content_type)

    def do_get(self) -> None:
        if ns["urlparse"](self.path).path == FEED_PATH:
            return self._send(ns["layout"]("ملاحظات المراجِعين", _feed_html(ns), "/"))
        return base_get(self)

    def do_post(self) -> None:
        path = ns["urlparse"](self.path).path
        if path == POST_PATH:
            n = int(self.headers.get("Content-Length") or 0)
            try:
                d = json.loads(self.rfile.read(min(n, 20000)).decode("utf-8"))
                rec = {k: str(d.get(k) or "")[:4000] for k in ("page", "title", "name", "note")}
            except (ValueError, UnicodeDecodeError):
                return self._send(b'{"ok":false}', 400, "application/json")
            if not rec["note"].strip() or not rec["name"].strip():
                return self._send(b'{"ok":false}', 400, "application/json")
            rec["at"] = _dt.datetime.now().strftime("%Y-%m-%d %H:%M")
            with _file(ns).open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            return self._send(b'{"ok":true}', 200, "application/json")
        if any(b in path for b in BLOCKED):
            return self._send(ns["layout"]("نسخة المراجعة",
                "<div class='card'><h2>معطَّل في نسخة المراجعة</h2><p>هذا الفعل لا يُسترجع، فعُطّل في النسخة التي يجرّبها "
                "المراجِعون؛ ويعمل في النسخة الفعلية لمن له صلاحيته.</p></div>", "/"), 403)
        return base_post(self)

    handler._send, handler.do_GET, handler.do_POST = _send, do_get, do_post
    handler._lt_review = True

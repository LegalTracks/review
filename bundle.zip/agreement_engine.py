# -*- coding: utf-8 -*-
"""محرّك الاتفاقية داخل المنصة — منقول من المولّد المستعمل (generator/in-use) بمنطقه نفسه.

الفرق عن الأصل في الآلة ثلاثة (القرار 128):
  1- يُبنى الملف في الذاكرة بمكتبة zipfile، لا بأمر zip الغائب عن ويندوز؛ و[Content_Types].xml أولاً.
  2- الخطأ استثناء EngineError يُعرض للإداري، لا sys.exit يُسقط الخادم.
  3- لا مجلد عمل مشترك؛ فلا يختلط طلبان متزامنان.
وزيادتان: الوسم الباقي بلا قيمة مانعٌ هنا (والأصل كان ينبّه فقط)، و«[●]» يُظلَّل بالأصفر.

والقالب `agreement/template.docx` يبنيه tools/build_agreement_template.py: قالب الوسوم المستعمل
على الورق الرسمي لمهارة الخطابات 1.0.2، بلا الصفحة الفارغة. ومكتبة الاستبدال نسخة مطابقة للأصل.
"""
import io
import re
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

import datetime as _dt

from agreement.tafqeet import tafqeet_ar, tafqeet_en
from agreement.wtext import P_RE, replace_all

TEMPLATE = Path(__file__).resolve().parent / "agreement" / "template.docx"


class EngineError(Exception):
    """خطأ في المدخلات يمنع إنشاء الملف."""


TR_RE = re.compile(r'<w:tr\b.*?</w:tr>', re.S)

CORE_FIELDS = ["CLIENT_NAME_AR", "CLIENT_NAME_EN", "CLIENT_CR", "REF",
               "SCOPE_AR", "SCOPE_EN", "TERM_AR", "TERM_EN",
               "PARTNER_NAME_AR", "PARTNER_NAME_EN",
               "CLIENT_EMAIL", "FIRM_EMAIL",
               "GT_VERSION", "GT_DATE", "KYC_NOTIFY_DAYS"]
SUCCESS_FIELDS = {
    "N": [],
    "L": ["SUCC_LUMP", "SUCC_EVENT_AR", "SUCC_EVENT_EN", "SUCC_TAIL_MONTHS"],
    "P": ["SUCC_PCT", "SUCC_BASIS_AR", "SUCC_BASIS_EN", "SUCC_CAP_AR", "SUCC_CAP_EN",
          "SUCC_EVENT_AR", "SUCC_EVENT_EN", "SUCC_TAIL_MONTHS"],
}
# ── قالب 2.3 المعتمد ببنوده (القرار 158) ──
# واقعة الاستحقاق اختيارية حين يحمل القالب البديلَ (SEVN)؛ وأرقام الفرد بدل السجل (CTYPE:I)
EVENT_FIELDS = ("SUCC_EVENT_AR", "SUCC_EVENT_EN")
CLIENT_TYPE_NAMES = {"C": "شركة أو منشأة", "I": "فرد"}
# الملحق (ب) يبقى حيث تُحال إليه الأتعاب بمعدلاته: بالساعة بلا دفعة وبدفعة، والسقف؛ لا مع السعر الموحّد (12)
ANNEX_BLOCKS = ("B", "C", "E")
# معدلات الملحق (ب) بالترتيب: شريك، مستشار، محامي أول، محامي، محامي متدرب، مساعد قانوني — من «جدول معدلات
# الأتعاب القياسية» الذي سلّمه المالك (جدول الساعات.docx، 27/09/2026م، العمود القياسي وحده)؛ القرار 160
ANNEX_RATES = ("2,250", "2,065", "1,875", "1,785", "1,125", "940")
# عنوان الشركة الوطني للتقابل في بند العنوان (10): من تذييل الورق الرسمي المعتمد، وأكّده المالك (160)
FIRM_ADDRESS = ("RHOC7906", "RHOC7906")
# تاريخ الاتفاقية هجرياً ثم ميلادياً «18/04/1448هـ الموافق 29/09/2026م» — مطفأ حتى يعتمد المالك
# صيغته في مراجعة الصياغة (القرار 169)؛ والهجري من الشاشة بعد التحقق من موافقته للميلادي
HIJRI_IN_CONTRACT = False


def date_pair(greg_iso, hijri_dmy):
    """كل رقمٍ بعلامتي اتجاه من اليسار، وإلا قلب وورد التاريخ المائل داخل السطر العربي."""
    y, m, d = greg_iso.split("-")
    return "%s%s%sهـ الموافق %s%s/%s/%s%sم" % (LRM, hijri_dmy, LRM, LRM, d, m, y, LRM)


# المبالغ التي تُكتب بالحروف في العقد (3) — بالتفقيط المصحّح (القرار 149)
WORD_TAGS = ("A_FEE", "C_ADVANCE", "D_RATE", "E_CAP", "F_FEE", "SUCC_LUMP")
SUCCESS_NAMES = {"N": "بلا أتعاب نجاح", "L": "مبلغ مقطوع", "P": "نسبة"}
ENGAGEMENT_NAMES = {"D": "تمثيل في منازعة", "P": "مسألة قد تؤول إلى منازعة",
                    "A": "استشارة أو عمل استشاري"}
BLOCK_FIELDS = {
    "A": ["A_FEE", "A_INSTALMENTS_AR", "A_INSTALMENTS_EN", "A_NOTICE_DAYS"],
    "B": [],
    "C": ["C_ADVANCE"],
    "D": ["D_RATE"],
    "E": ["E_CAP"],
    "F": ["F_FEE", "F_PCT_SIGN", "F_PCT_DELIVERY"],
    "G": ["G_PHASES_AR", "G_PHASES_EN"],
}
# القرار 74: السقف (هـ) خيار مستقل يُجمع مع المقدمة (ج) أو السعر الموحّد (د)؛ و«ج+د» لا يُجمعان
# لأن ج/1 يخصم «وفق معدلات الساعة… في الملحق (ب)» والسعر الموحّد لا ملحق له (القرار 172)
FEE_EXTRA_ALLOWED = {"B": ("E",), "C": ("E",), "D": ("E",)}   # «ب+هـ»: الملحق أساس الاحتساب والسقف حدّه (خ-3 من مراجعة فابل)


def fee_blocks(data):
    """البلوك الأساسي والإضافي إن وُجد: ("C", "E") أو ("A", "")."""
    return (str(data.get("FEE_BLOCK", "")).strip().upper(),
            str(data.get("FEE_EXTRA", "") or "").strip().upper())


def annex_kept(blocks):
    """الملحق (ب) مع بلوكات الملحق، ويسقط متى كان السعر الموحّد في الاختيار."""
    blocks = [b for b in blocks if b]
    return any(b in ANNEX_BLOCKS for b in blocks) and "D" not in blocks


def _sel_match(sel, fam, val):
    v = sel.get(fam)
    return val in v if isinstance(v, frozenset) else v == val


BLOCK_NAMES = {"A": "أتعاب سنوية ثابتة", "B": "بالساعة دون دفعة مقدمة",
               "C": "بالساعة مع دفعة مقدمة", "D": "متوسط سعر الساعة",
               "E": "أتعاب محددة بسقف", "F": "أتعاب ثابتة لكل تكليف",
               "G": "أتعاب على مراحل"}
CONTROL = {"FEE_BLOCK", "FEE_EXTRA", "HIDE_BLOCK_LABEL", "ENGAGEMENT_TYPE", "SUCCESS_TYPE", "USE_TASKS", "CLIENT_TYPE"}

LRM = "‎"
_ARABIC = re.compile(r'[؀-ۿ]')
_FAMS = "FEE|ENG|SUCC|TASKS|CTYPE|SEVT|SEVN|CONT"
MARKER_RE = re.compile(r'\{\{(%s):([A-Z]+)\}\}' % _FAMS)
SPAN_RE = re.compile(r'\{\{SPAN:([A-Z0-9_]+)\}\}')
TAG_RE = re.compile(r'\{\{[A-Z0-9_:]+\}\}')


def lrm_wrap(v):
    if v and not _ARABIC.search(v) and re.search(r'[0-9A-Za-z]', v):
        return LRM + v + LRM
    return v


def phases_text(phases, lang):
    out = []
    ordinals_ar = ["الأولى", "الثانية", "الثالثة", "الرابعة", "الخامسة", "السادسة"]
    for i, ph in enumerate(phases):
        if lang == "ar":
            o = ordinals_ar[i] if i < len(ordinals_ar) else str(i + 1)
            out.append("المرحلة %s: %s — %s ريال سعودي، مستحقة عند %s"
                       % (o, ph["desc_ar"], ph["amount"], ph["due_ar"]))
        else:
            out.append("Phase %d: %s — SAR %s, due upon %s"
                       % (i + 1, ph["desc_en"], ph["amount"], ph["due_en"]))
    return ("؛ " if lang == "ar" else "; ").join(out) + "."


def prune_blocks(xml, selected):
    kept = removed = 0
    out, cursor = [], 0
    for m in TR_RE.finditer(xml):
        out.append(xml[cursor:m.start()])
        cursor = m.end()
        marks = MARKER_RE.findall(m.group())
        if not marks:
            out.append(m.group())
        elif any(_sel_match(selected, fam, val) for fam, val in marks):
            out.append(m.group())
            kept += 1
        else:
            removed += 1
    out.append(xml[cursor:])
    return ''.join(out), kept, removed


def strip_markers(xml):
    return re.sub(r'<w:r>(?:(?!</w:r>).)*?\{\{(?:%s):[A-Z]+\}\}' % _FAMS +
                  r'(?:(?!</w:r>).)*?</w:r>', '', xml, flags=re.S)


def selection_for(data, xml):
    """الاختيار الذي يُحكم به على الصفوف الموسومة — واحد للإنشاء ولـ«أثر الاختيار»."""
    block = str(data.get("FEE_BLOCK", "")).strip().upper()
    eng = str(data.get("ENGAGEMENT_TYPE", "")).strip().upper()
    succ = str(data.get("SUCCESS_TYPE", "N")).strip().upper()
    sel = {"FEE": block, "ENG": eng}
    extra = fee_blocks(data)[1]
    if extra:
        sel["FEE"] = frozenset((block, extra))
    if succ != "N":
        sel["SUCC"] = succ
        if "{{SEVN:" in xml:            # قالب فيه البديل: الواقعة المكتوبة أو البديل
            ev = str(data.get("SUCC_EVENT_AR", "")).strip()
            sel["SEVT" if ev and ev != PLACEHOLDER else "SEVN"] = "Y"
    if data.get("USE_TASKS"):
        sel["TASKS"] = "Y"
    sel["CTYPE"] = "I" if str(data.get("CLIENT_TYPE", "C")).upper() == "I" else "C"
    if str(data.get("CLIENT_CONTACT", "")).strip():
        sel["CONT"] = "Y"
    return sel


def apply_annex(xml, block, extra=""):
    """الملحق (ب) يبقى مع ANNEX_BLOCKS ويُحذف مع غيرها؛ وفقرتا حدّيه تُحذفان في الحالين."""
    if "{{SPAN:ANNEXB_START}}" not in xml:
        return xml
    paras = list(P_RE.finditer(xml))
    s = next(m for m in paras if "{{SPAN:ANNEXB_START}}" in m.group())
    e = next(m for m in paras if "{{SPAN:ANNEXB_END}}" in m.group())
    if annex_kept((block, extra)):
        return xml[:s.start()] + xml[s.end():e.start()] + xml[e.end():]
    return xml[:s.start()] + xml[e.end():]


def _drop_label_rows(xml):
    out, cursor = [], 0
    for m in TR_RE.finditer(xml):
        out.append(xml[cursor:m.start()])
        cursor = m.end()
        t = ''.join(re.findall(r'<w:t(?: [^>]*)?>([^<]*)</w:t>', m.group())).strip()
        if not (t.startswith("[ بلوك") or t.startswith("[ Block")):
            out.append(m.group())
    out.append(xml[cursor:])
    return ''.join(out)


PLACEHOLDER = "[●]"
RUN_RE = re.compile(r'<w:r\b[^>]*>(?:(?!</w:r>).)*?</w:r>', re.S)
# ما يأتي بعد w:highlight في ترتيب CT_RPr؛ فيُدرج قبل أولها، وإلا في آخر الخصائص
_AFTER_HL = ("u", "effect", "bdr", "shd", "fitText", "vertAlign", "rtl", "cs", "em", "lang",
             "eastAsianLayout", "specVanish", "oMath")


def _with_highlight(rpr):
    if not rpr:
        return '<w:rPr><w:highlight w:val="yellow"/></w:rPr>'
    rpr = re.sub(r'<w:highlight\b[^>]*/>', '', rpr)
    m = re.search(r'<w:(?:%s)\b' % "|".join(_AFTER_HL), rpr)
    at = m.start() if m else rpr.rindex("</w:rPr>")
    return rpr[:at] + '<w:highlight w:val="yellow"/>' + rpr[at:]


def highlight_placeholders(xml):
    """كل «[●]» في تشغيل مستقل مظلَّل بالأصفر، ليراه الإداري فيملأه قبل التوقيع (القرار 135)."""
    count = 0

    def split(m):
        nonlocal count
        run = m.group(0)
        if PLACEHOLDER not in run:
            return run
        ts = re.findall(r'<w:t(?: [^>]*)?>([^<]*)</w:t>', run)
        head = re.match(r'<w:r\b[^>]*>', run).group(0)
        rpr_m = re.search(r'<w:rPr>.*?</w:rPr>', run, re.S)
        rpr = rpr_m.group(0) if rpr_m else ""
        if len(ts) != 1 or re.search(r'<w:(?:tab|br|drawing|fldChar|instrText)\b', run):
            count += run.count(PLACEHOLDER)          # تشغيل مركّب: يُظلَّل كله ولا يُقسَم
            return run.replace(rpr, _with_highlight(rpr)) if rpr else \
                run.replace(head, head + _with_highlight(""), 1)
        out = []
        for i, piece in enumerate(ts[0].split(PLACEHOLDER)):
            if i:
                out.append('%s%s<w:t xml:space="preserve">%s</w:t></w:r>' % (head, _with_highlight(rpr), PLACEHOLDER))
                count += 1
            if piece:
                out.append('%s%s<w:t xml:space="preserve">%s</w:t></w:r>' % (head, rpr, piece))
        return "".join(out)

    return RUN_RE.sub(split, xml), count


DATE_FIELD_RE = re.compile(
    r'<w:r\b[^>]*>(?:<w:rPr>(?:(?!</w:r>).)*?</w:rPr>)?<w:fldChar w:fldCharType="begin"/></w:r>'
    r'(?:(?!<w:fldChar w:fldCharType="begin"/>).)*?<w:instrText[^>]*>\s*DATE\b[^<]*</w:instrText></w:r>'
    r'(?:(?!<w:fldChar w:fldCharType="begin"/>).)*?<w:fldChar w:fldCharType="separate"/></w:r>'
    r'((?:(?!<w:fldChar).)*?)'
    r'<w:r\b[^>]*>(?:<w:rPr>(?:(?!</w:r>).)*?</w:rPr>)?<w:fldChar w:fldCharType="end"/></w:r>', re.S)


def apply_dates(xml, data):
    """تاريخ الاتفاقية نصٌّ ثابت بدل حقل DATE -الذي يصير تاريخَ كلِّ فتحٍ للملف-، وسطر السريان
    يُملأ إن فُعِّل ويُحذف إن لم يُفعَّل (القرار 139). ولا يُمسّ شيء إن لم تُمرَّر المفاتيح."""
    if "_AGREEMENT_DATE" in data:
        ad = data["_AGREEMENT_DATE"]

        def fix(m):
            result = m.group(1)
            return re.sub(r'(<w:t(?: [^>]*)?>)[^<]*(</w:t>)', lambda t: t.group(1) + lrm_wrap(ad) + t.group(2), result, count=1)
        xml, n = DATE_FIELD_RE.subn(fix, xml)
        if n != 1:
            raise EngineError("حقل تاريخ الاتفاقية في القالب لم يوجد كما يُتوقَّع (وُجد %d)" % n)
    if "_EFFECTIVE_DATE" in data:
        paras = [m for m in P_RE.finditer(xml) if "<w:date " in m.group(0) and "Effective Date" in m.group(0)]
        if len(paras) != 1:
            raise EngineError("سطر تاريخ السريان في القالب لم يوجد كما يُتوقَّع (وُجد %d)" % len(paras))
        p = paras[0]
        ed = data["_EFFECTIVE_DATE"]
        if ed:
            new = re.sub(r'w:fullDate="[^"]*"', 'w:fullDate="%sT00:00:00Z"' % ed, p.group(0))
            new = re.sub(r'(<w:sdtContent>.*?<w:t(?: [^>]*)?>)[^<]*(</w:t>)',
                         lambda t: t.group(1) + lrm_wrap(ed) + t.group(2), new, count=1, flags=re.S)
        else:
            new = ""
        xml = xml[:p.start()] + new + xml[p.end():]
    return xml


FAMILY_NAMES = {"FEE": ("الأتعاب", BLOCK_NAMES), "ENG": ("نوع التكليف", ENGAGEMENT_NAMES),
                "SUCC": ("أتعاب النجاح", dict(SUCCESS_NAMES, X="البند كله")),
                "TASKS": ("المهام والمراحل", {"Y": "البند كله"}),
                "CTYPE": ("صيغة العميل", {"C": "منشأة بسجلّها", "I": "فرد بهويته"}),
                "SEVT": ("واقعة الاستحقاق", {"Y": "المكتوبة"}), "SEVN": ("واقعة الاستحقاق", {"Y": "البديل النظامي"}),
                "CONT": ("وسيلة التواصل", {"Y": "صفّها"})}


def _row_arabic(row_xml, values=None):
    """أول نص عربي في صفّ الجدول -عمود العربية-، بقيم المدخلات مكان وسومها («[●]» لما لم يُكتب)،
    مقصوصاً للعرض."""
    from xml.sax.saxutils import unescape
    values = values or {}
    for cell in re.findall(r'<w:tc\b.*?</w:tc>', row_xml, re.S):
        t = unescape("".join(re.findall(r'<w:t(?: [^>]*)?>([^<]*)</w:t>', cell)))
        t = re.sub(r'\{\{[A-Z]+:[A-Z]+\}\}', '', t)
        t = re.sub(r'\{\{([A-Z0-9_]+)\}\}', lambda m: str(values.get(m.group(1)) or PLACEHOLDER), t)
        t = t.replace(LRM, "").strip()
        if _ARABIC.search(t):
            return (t[:110] + "…") if len(t) > 110 else t
    return ""


def choice_effect(data, template=TEMPLATE):
    """أثر الاختيار (القرار 37): يُقاس من القالب نفسه لا من قراءة الشيفرة — كل صفّ موسوم
    يُحكم عليه بالاختيار الحالي كما يحكم عليه الإنشاء، فيُعرض ما يدخل العقد وما يخرج منه."""
    block = str(data.get("FEE_BLOCK", "")).strip().upper()
    eng = str(data.get("ENGAGEMENT_TYPE", "")).strip().upper()
    succ = str(data.get("SUCCESS_TYPE", "N")).strip().upper()
    with zipfile.ZipFile(template) as z:
        xml = z.read("word/document.xml").decode("utf-8")
    if succ != "N":
        xml = xml.replace("{{SUCC:X}}", "{{SUCC:%s}}" % succ)
    selection = selection_for(data, xml)               # الاختيار نفسه الذي يحكم به الإنشاء
    vals = {k: v for k, v in data.items() if isinstance(v, (str, int, float)) and not k.startswith("_")}
    for tag in WORD_TAGS:
        vals.setdefault(tag + "_WORDS_AR", tafqeet_ar(str(data.get(tag, ""))) or PLACEHOLDER)
    if block == "G" and data.get("G_PHASES"):
        vals["G_PHASES_AR"] = phases_text(data["G_PHASES"], "ar")
    kept, removed = [], {}
    for m in TR_RE.finditer(xml):
        marks = MARKER_RE.findall(m.group())
        if not marks:
            continue
        text = _row_arabic(m.group(), vals)
        if text.startswith("[ بلوك") or text.startswith("[ Block"):
            continue                                   # صفّ العنوان الداخلي يُحذف في كل حال
        if any(_sel_match(selection, f, v) for f, v in marks):
            kept.append(text)
        else:
            for f, v in marks:
                fam, names = FAMILY_NAMES.get(f, (f, {}))
                key = "%s: %s" % (fam, names.get(v, v))
                removed[key] = removed.get(key, 0) + 1
    if "{{SPAN:ANNEXB_START}}" in xml:                  # الملحق (ب) مدىً لا صفّ
        if annex_kept(fee_blocks(data)):
            kept.append("الملحق (ب) — معدلات الساعة المعتمدة")
        else:
            removed["الملحق (ب) — معدلات الساعة"] = 1
    return {"in": [t for t in kept if t], "out": sorted(removed.items())}


def generate_docx(data, template=TEMPLATE):
    """يعيد (bytes, report). ولا يكتب شيئاً على القرص."""
    data = dict(data)
    block = str(data.get("FEE_BLOCK", "")).strip().upper()
    if block not in BLOCK_FIELDS:
        raise EngineError("نموذج الأتعاب غير معروف: %r" % block)
    extra = fee_blocks(data)[1]
    if extra and extra not in FEE_EXTRA_ALLOWED.get(block, ()):
        raise EngineError("لا يُجمع البلوك %r مع %r" % (extra, block))
    eng = str(data.get("ENGAGEMENT_TYPE", "")).strip().upper()
    if eng not in ENGAGEMENT_NAMES:
        raise EngineError("نوع التكليف غير معروف: %r" % eng)
    succ = str(data.get("SUCCESS_TYPE", "N")).strip().upper()
    if succ not in SUCCESS_FIELDS:
        raise EngineError("نوع أتعاب النجاح غير معروف: %r" % succ)
    use_tasks = bool(data.get("USE_TASKS", False))
    if use_tasks and not (str(data.get("TASKS_AR", "")).strip()
                          and str(data.get("TASKS_EN", "")).strip()):
        raise EngineError("طُلبت المهام ولم يُكتب نصها باللغتين")
    if block == "G":
        phases = data.get("G_PHASES") or []
        if not phases:
            raise EngineError("الأتعاب على مراحل بلا مراحل")
        data["G_PHASES_AR"] = phases_text(phases, "ar")
        data["G_PHASES_EN"] = phases_text(phases, "en")
    with zipfile.ZipFile(template) as z:
        infos = [i for i in z.infolist() if not i.filename.endswith("/")]
        parts = {i.filename: z.read(i.filename) for i in infos}
    xml = parts["word/document.xml"].decode("utf-8")
    new_tpl = "{{CTYPE:" in xml                       # قالب 2.3 المعتمد ببنوده (القرار 158)

    required = CORE_FIELDS + BLOCK_FIELDS[block] + (BLOCK_FIELDS[extra] if extra else []) + SUCCESS_FIELDS[succ]
    ctype = "I" if str(data.get("CLIENT_TYPE", "C")).upper() == "I" else "C"
    if new_tpl:
        required = [k for k in required if k not in EVENT_FIELDS]     # البديل يغني عن الواقعة (7)
        if ctype == "I":
            required = [("CLIENT_ID" if k == "CLIENT_CR" else k) for k in required]   # الفرد (2)
    missing = [k for k in required if not str(data.get(k, "")).strip()]
    if missing:
        raise EngineError("حقول لازمة فارغة: " + ", ".join(missing))

    if new_tpl:
        data.setdefault("CLIENT_TYPE_LABEL_AR", CLIENT_TYPE_NAMES[ctype])
        data.setdefault("FIRM_ADDRESS_AR", FIRM_ADDRESS[0])
        data.setdefault("FIRM_ADDRESS_EN", FIRM_ADDRESS[1])
        for i, rate in enumerate(ANNEX_RATES, 1):
            data.setdefault("ANNEX_RATE_%d" % i, rate or PLACEHOLDER)
        for tag in WORD_TAGS:                          # المبالغ بالحروف (3) من التفقيط المصحّح
            v = str(data.get(tag, "")).strip()
            data.setdefault(tag + "_WORDS_AR", tafqeet_ar(v) or PLACEHOLDER)
            data.setdefault(tag + "_WORDS_EN", tafqeet_en(v) or PLACEHOLDER)
        if ctype == "C" and not str(data.get("CLIENT_ID", "")).strip():
            data["CLIENT_ID"] = data.get("CLIENT_CR", "")     # خاصية «Client ID» للمنشأة: سجلّها (13)
        for k in ("CLIENT_ADDRESS_AR", "CLIENT_ADDRESS_EN", "PARTNER_TITLE_AR", "PARTNER_TITLE_EN", "CLIENT_ID",
                  "SALUTATION_AR"):
            if not str(data.get(k, "")).strip():
                data[k] = PLACEHOLDER
        if not str(data.get("SUCC_EVENT_AR", "")).strip() or data.get("SUCC_EVENT_AR") == PLACEHOLDER:
            data.pop("SUCC_EVENT_AR", None)
            data.pop("SUCC_EVENT_EN", None)
        # التاريخان وسمان (1): تاريخ الاتفاقية نصٌّ ثابت، وسطر السريان يسقط إن لم يُفعَّل
        data["AGREEMENT_DATE"] = data.get("_AGREEMENT_DATE") or data.get("AGREEMENT_DATE") or _dt.date.today().isoformat()
        if HIJRI_IN_CONTRACT and data.get("_AGREEMENT_DATE_H"):
            data["AGREEMENT_DATE"] = date_pair(data["AGREEMENT_DATE"], data["_AGREEMENT_DATE_H"])
        eff = data.get("_EFFECTIVE_DATE") if "_EFFECTIVE_DATE" in data else data.get("EFFECTIVE_DATE")
        if eff:
            data["EFFECTIVE_DATE"] = eff
        else:
            data.pop("EFFECTIVE_DATE", None)
            ep = [m for m in P_RE.finditer(xml) if "{{EFFECTIVE_DATE}}" in m.group()]
            if len(ep) != 1:
                raise EngineError("سطر تاريخ السريان في القالب لم يوجد كما يُتوقَّع")
            xml = xml[:ep[0].start()] + xml[ep[0].end():]

    if succ != "N":
        xml = xml.replace("{{SUCC:X}}", "{{SUCC:%s}}" % succ)
    selection = selection_for(data, xml)
    xml, kept, removed = prune_blocks(xml, selection)
    xml = strip_markers(xml)
    xml = apply_annex(xml, block, extra)

    data.setdefault("ENGAGEMENT_LABEL_AR", ENGAGEMENT_NAMES[eng])
    data.setdefault("FEE_LABEL_AR", BLOCK_NAMES[block] + ("، " + BLOCK_NAMES[extra] if extra else ""))
    data.setdefault("SUCCESS_LABEL_AR", SUCCESS_NAMES[succ])
    values = [(k, v) for k, v in data.items()
              if isinstance(v, (str, int, float)) and not k.startswith("_") and k not in CONTROL]
    xml, counts = replace_all(xml, [("{{%s}}" % k, lrm_wrap(str(v))) for k, v in values])
    for part in ("docProps/core.xml", "docProps/custom.xml"):
        if part in parts:
            t = parts[part].decode("utf-8")
            for k, v in values:
                t = t.replace("{{%s}}" % k, escape(str(v)))
            parts[part] = t.encode("utf-8")
    if data.get("HIDE_BLOCK_LABEL", True):
        xml = _drop_label_rows(xml)
    if not new_tpl:
        xml = apply_dates(xml, data)             # القالب القديم: حقل DATE ومنتقي التاريخ
    xml, marked = highlight_placeholders(xml)
    parts["word/document.xml"] = xml.encode("utf-8")

    leftover = sorted(set(TAG_RE.findall(xml)))
    if leftover:
        raise EngineError("وسوم بقيت بلا قيمة: " + ", ".join(t.strip("{}") for t in leftover))

    first = ["[Content_Types].xml", "_rels/.rels"]
    order = [n for n in first if n in parts] + [i.filename for i in infos if i.filename not in first]
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as out:
        for name in order:
            out.writestr(name, parts[name])
    report = {"kept": kept, "removed": removed, "block": block, "engagement": eng, "success": succ,
              "tasks": use_tasks, "placeholders": marked, "unused": sorted(k.strip("{}") for k, c in counts.items() if c == 0)}
    return buf.getvalue(), report

# -*- coding: utf-8 -*-
"""مسارات قانونية — دخول تلقائي في نسخة التجربة وحدها (مؤقت؛ يُزال بحذف سطرَي الوصل في آخر app.py).

طلبه المالك 30/09 لأن الجلسة تُحفظ في ذاكرة الخادم فتسقط مع كل إعادة تشغيل، فيعيد الدخول في كل مرة.
لا يعمل إلا باجتماع ثلاثة شروط: المفتاح MASARAT_DEV_AUTOLOGIN=1 -لا يضعه إلا tools/run_dev.py-،
وبيئة غير الإنتاج، وقاعدة بيانات داخل مجلد dev-data. فلا يعمل على نسخة محمد ولا في الإنتاج بحال.
ويُقيَّد كل دخول تلقائي في سجل الدخول باسمه، فلا يختلط بدخول حقيقي.
وتبديل الصلاحية للتجربة: ‎?as=partner‎ أو ‎?as=user‎ أو ‎?as=compliance‎ أو ‎?as=admin‎ في أي رابط.
"""
from __future__ import annotations

import datetime as _dt
import os
import secrets
from typing import Any, Dict, Optional

AS_USERS = {"admin": "admin"}                     # الدور ← اسم المستخدم؛ وحسابات الأدوار الأخرى تُنشأ عند أول طلب
_NS: Dict[str, Any] = {}


def dev_copy(ns: Dict[str, Any]) -> bool:
    """نسختنا التجريبية: غير الإنتاج وقاعدةٌ في dev-data (لا نسخة محمد التجريبية ولو كانت UAT)."""
    env = str(ns.get("APP_ENV") or os.environ.get("MASARAT_APP_ENV") or "").upper()
    return env != "PRODUCTION" and "/dev-data/" in str(ns.get("DB_PATH") or "").replace("\\", "/")


def enabled(ns: Dict[str, Any]) -> bool:
    env = str(ns.get("APP_ENV") or os.environ.get("MASARAT_APP_ENV") or "").upper()
    db_path = str(ns.get("DB_PATH") or "").replace("\\", "/")
    return os.environ.get("MASARAT_DEV_AUTOLOGIN") == "1" and env != "PRODUCTION" and "/dev-data/" in db_path


def _user_row(ns: Dict[str, Any], role: str) -> Optional[Dict[str, Any]]:
    with ns["db"]() as con:
        ns["_auth_ensure_schema"](con)
        name = AS_USERS.get(role) or f"dev-{role}@legaltracks.sa"
        row = con.execute("SELECT * FROM app_users WHERE user_name=? AND is_active=1", (name,)).fetchone()
        if not row and role in ("partner", "user", "compliance"):
            label = {"partner": "شريك تجريبي", "user": "موظف تجريبي", "compliance": "مسؤول امتثال تجريبي"}[role]
            salt, ph = ns["_auth_hash"](secrets.token_urlsafe(24))   # كلمة مرور عشوائية لا تُعرف: الدخول تلقائي وحده
            con.execute("INSERT INTO app_users(created_at, full_name, user_name, role, is_active, password_salt, password_hash, "
                        "must_change_password) VALUES(?,?,?,?,1,?,?,0)", (ns["now_iso"](), label, name, role, salt, ph))
            con.commit()
            row = con.execute("SELECT * FROM app_users WHERE user_name=?", (name,)).fetchone()
        if row:
            con.execute("INSERT INTO user_login_audit(created_at,user_name,event_type,success,ip_address,details) "
                        "VALUES(?,?,?,?,?,?)", (ns["now_iso"](), row["user_name"], "login", 1, "127.0.0.1",
                                                "دخول تلقائي — نسخة التجربة"))
            con.commit()
        return dict(row) if row else None


def install(ns: Dict[str, Any]) -> None:
    _NS.update(ns)
    handler = ns.get("AppHandler")
    if not handler or getattr(handler, "_lt_autologin", False) or not enabled(ns):
        return
    base_get = handler.do_GET

    def do_get(self) -> None:
        parsed = ns["urlparse"](self.path)
        q = ns["parse_qs"](parsed.query)
        want = (q.get("as") or [""])[0]
        if parsed.path == "/logout" or parsed.path.startswith(("/brand/", "/lt-agr/", "/favicon")):   # الملفات الثابتة لا تُحوَّل
            return base_get(self)
        user = ns["_session_user"](self)
        if user and not (want and want != user.get("role")) and parsed.path != "/login":
            return base_get(self)
        row = _user_row(ns, want if want in ("admin", "partner", "user", "compliance") else "admin")
        if not row:
            return base_get(self)
        token = secrets.token_urlsafe(32)
        ns["_AUTH_SESSIONS"][token] = {"user": row, "expires": _dt.datetime.now().timestamp() + 12 * 3600}
        dest = "/" if parsed.path == "/login" else parsed.path + (
            "?" + "&".join(f"{k}={v[0]}" for k, v in q.items() if k != "as") if len(q) > (1 if want else 0) else "")
        # في Hugging Face تُعرض المنصة داخل إطار من نطاق آخر، فلا يُرسل المتصفح الجلسة إلا بـSameSite=None مع Secure
        cross = os.environ.get("MASARAT_COOKIE_CROSS_SITE") == "1"
        attrs = "; Path=/; HttpOnly; " + ("SameSite=None; Secure" if cross else "SameSite=Lax")
        return ns["_auth_send_redirect"](self, dest, "masarat_session=" + token + attrs)

    handler.do_GET = do_get
    handler._lt_autologin = True

# -*- coding: utf-8 -*-
"""مسارات قانونية — طبقة الواجهة (ملف مستقل؛ يُزال بحذف سطرَي الوصل في آخر app.py فتعود المنصة كما كانت).

تُركَّب فوق layout() وصفحة الدخول، ولا تمسّ منطق أي صفحة ولا ما يُحفظ في القاعدة:
1- الخطوط: كل عنصر يرث Tajawal -كانت الأزرار كلها تُرسم بـArial لأن المتصفح لا يورّثها الخط-،
   والعناوين Hacen Liner.
2- لغة بصرية من هوية الشركة، بعيدة عن القوالب الجاهزة: لا شرائط جانبية ملوّنة، ولا أزرار كالأقراص،
   ولا تدرّج في الرأس، ولا ظلال؛ بل خطوط شعرية وزوايا شبه قائمة ومؤشر ذهبي تحت التبويب النشط.
3- نصوص الواجهة: رأس الصفحة بلا رقم الإصدار ولا وصفه التقني، وعبارات عربية بدل الإنجليزية والمقتضبة.
4- حقل الدولة: قائمة بكل الدول بالعربية يُبحث فيها بالكتابة، والافتراض «المملكة العربية السعودية».
   والأسماء الشائعة مقصودة: فحص الدول عالية المخاطر يبحث في النص عن «إيران» و«سوريا» و«كوريا الشمالية»…
   فلو كُتب «الجمهورية العربية السورية» لما التقطه؛ واختبار test_ui_layer يثبت التقاط كلٍّ منها.
5- تبويب «الاتفاقيات» في القائمة الرئيسية.
"""
from __future__ import annotations

import re
from typing import Any, Dict

ROLE_AR = {"admin": "مدير النظام", "compliance": "مسؤول الامتثال", "partner": "شريك", "user": "مستخدم"}

# ─────────────── الدول بالعربية — الاسم الشائع لا الرسمي الطويل ───────────────
COUNTRIES = [
    "المملكة العربية السعودية",
    # الخليج والعالم العربي
    "الإمارات العربية المتحدة", "البحرين", "الكويت", "قطر", "عُمان", "اليمن", "العراق", "الأردن", "سوريا",
    "لبنان", "فلسطين", "مصر", "السودان", "جنوب السودان", "ليبيا", "تونس", "الجزائر", "المغرب", "موريتانيا",
    "الصومال", "جيبوتي", "جزر القمر",
    # آسيا
    "أفغانستان", "إيران", "تركيا", "باكستان", "الهند", "بنغلاديش", "سريلانكا", "نيبال", "بوتان", "جزر المالديف",
    "الصين", "هونغ كونغ", "ماكاو", "تايوان", "اليابان", "كوريا الجنوبية", "كوريا الشمالية", "منغوليا",
    "إندونيسيا", "ماليزيا", "سنغافورة", "تايلاند", "فيتنام", "الفلبين", "ميانمار", "كمبوديا", "لاوس",
    "بروناي", "تيمور الشرقية", "كازاخستان", "أوزبكستان", "تركمانستان", "قيرغيزستان", "طاجيكستان",
    "أذربيجان", "أرمينيا", "جورجيا", "قبرص",
    # أوروبا
    "المملكة المتحدة", "أيرلندا", "فرنسا", "ألمانيا", "إيطاليا", "إسبانيا", "البرتغال", "هولندا", "بلجيكا",
    "لوكسمبورغ", "سويسرا", "النمسا", "ليختنشتاين", "موناكو", "أندورا", "سان مارينو", "الفاتيكان", "مالطا",
    "اليونان", "الدنمارك", "السويد", "النرويج", "فنلندا", "آيسلندا", "إستونيا", "لاتفيا", "ليتوانيا",
    "بولندا", "التشيك", "سلوفاكيا", "المجر", "رومانيا", "بلغاريا", "صربيا", "كرواتيا", "سلوفينيا",
    "البوسنة والهرسك", "الجبل الأسود", "مقدونيا الشمالية", "ألبانيا", "كوسوفو", "مولدوفا", "أوكرانيا",
    "بيلاروس", "روسيا",
    # الأمريكتان
    "الولايات المتحدة", "كندا", "المكسيك", "غواتيمالا", "بليز", "هندوراس", "السلفادور", "نيكاراغوا",
    "كوستاريكا", "بنما", "كوبا", "جامايكا", "هايتي", "جمهورية الدومينيكان", "جزر البهاما", "باربادوس",
    "ترينيداد وتوباغو", "غرينادا", "سانت لوسيا", "سانت فنسنت والغرينادين", "أنتيغوا وباربودا", "دومينيكا",
    "سانت كيتس ونيفيس", "كولومبيا", "فنزويلا", "غيانا", "سورينام", "الإكوادور", "بيرو", "بوليفيا",
    "البرازيل", "باراغواي", "أوروغواي", "الأرجنتين", "تشيلي",
    "جزر كايمان", "جزر العذراء البريطانية", "برمودا", "بورتوريكو",
    # أفريقيا
    "إثيوبيا", "إريتريا", "كينيا", "أوغندا", "تنزانيا", "رواندا", "بوروندي", "جمهورية الكونغو الديمقراطية",
    "جمهورية الكونغو", "الغابون", "غينيا الاستوائية", "الكاميرون", "تشاد", "جمهورية أفريقيا الوسطى",
    "نيجيريا", "النيجر", "مالي", "بوركينا فاسو", "السنغال", "غامبيا", "غينيا", "غينيا بيساو", "سيراليون",
    "ليبيريا", "ساحل العاج", "غانا", "توغو", "بنين", "الرأس الأخضر", "ساو تومي وبرينسيب", "أنغولا",
    "زامبيا", "زيمبابوي", "ملاوي", "موزمبيق", "مدغشقر", "موريشيوس", "سيشل", "ناميبيا", "بوتسوانا",
    "جنوب أفريقيا", "ليسوتو", "إسواتيني",
    # أوقيانوسيا
    "أستراليا", "نيوزيلندا", "بابوا غينيا الجديدة", "فيجي", "جزر سليمان", "فانواتو", "ساموا", "تونغا",
    "كيريباتي", "توفالو", "ناورو", "بالاو", "ميكرونيزيا", "جزر مارشال",
]
DEFAULT_COUNTRY = COUNTRIES[0]

# ─────────────── نصوص الواجهة — الأصل حرفاً ← البديل ───────────────
COPY = [
    ("<div class=\"step\">Counterparties متعددة</div>", "<div class=\"step\">الأطراف المقابلة في التكليف</div>"),
    ("<div class=\"step\">تصعيد/تجميد/إبلاغ</div>",
     "<div class=\"step\">الإجراء عند الاشتباه<small>إحالة إلى مسؤول الامتثال، ثم التجميد والإبلاغ عند لزومهما</small></div>"),
    ("بيئة التجربة التشغيلية (Pilot)", "بيئة التجربة التشغيلية"),
]

CSS = """<style id="lt-ui-layer">
/* 1- الخطوط: كل عنصر يرث الخط، والأزرار وعناصر النماذج أولها */
html body,body *{font-family:"Tajawal","Hacen Liner",system-ui,sans-serif}
button,input,select,textarea,optgroup,option,summary{font-family:inherit!important;font-size:inherit}
body h1,body h2,body h3,.lt-agr h2,.lt-agr h3{font-family:"Hacen Liner","Tajawal",sans-serif!important;font-weight:400!important;letter-spacing:0}
code,pre,kbd{font-family:Consolas,"Courier New",monospace!important}
:root{--lx-line:#E2DBCF;--lx-line2:#CFC6B6;--lx-paper:#FAF7F1;--lx-ink:#1A1A1A;--lx-mute:#6B6B6B;
 --lx-g:#244037;--lx-g2:#335248;--lx-g9:#14251F;--lx-gold:#E3CCAD;--lx-gold7:#B49670;
 --lx-ok:#2E8C73;--lx-warn:#B98200;--lx-bad:#C4431A;color-scheme:light}
body{background:var(--lx-paper)!important;color:var(--lx-ink)!important}

/* 2- الرأس: أخضر مصمت وخط ذهبي شعري، بلا تدرّج؛ والمستخدم نصٌّ لا صندوق */
header{background:var(--lx-g9)!important;border-bottom:1px solid var(--lx-gold7)!important;box-shadow:none!important;
 padding:16px 24px!important}
header h1{font-size:22px!important;margin:0!important;color:#fff!important}
header small{color:var(--lx-gold)!important;font-size:13px!important;letter-spacing:0}
.user-menu{top:12px!important}
.user-button{background:transparent!important;border:0!important;border-radius:0!important;color:#fff!important;
 box-shadow:none!important;padding:6px 4px!important;min-width:0!important;font-weight:700!important;text-align:left!important}
.user-button small{color:var(--lx-gold)!important;font-weight:400}
.user-button:hover{background:transparent!important;text-decoration:underline;text-underline-offset:4px}
.env-banner{background:#F3EBDD!important;color:var(--lx-g9)!important;border-bottom:1px solid var(--lx-line2)!important;
 font-size:13px;padding:4px 24px!important;text-align:center}

/* 3- القائمة الرئيسية: تبويبات نصّية، والنشط بخط ذهبي تحته */
.main-nav{background:#fff!important;box-shadow:none!important;border-bottom:1px solid var(--lx-line)!important;
 padding:0 16px!important;gap:0!important}
.main-nav>a,.main-nav>.dropdown>a,nav a{background:transparent!important;border:0!important;border-radius:0!important;
 color:var(--lx-g)!important;font-weight:700!important;padding:14px 16px 12px!important;
 border-bottom:2px solid transparent!important;outline:0!important;box-shadow:none!important}
.main-nav a.active,.main-nav>a:hover,.main-nav>.dropdown>a:hover,.main-nav a:focus-visible{background:transparent!important;
 color:var(--lx-g9)!important;border-bottom-color:var(--lx-gold7)!important;outline:0!important}
.dropdown-content{border:1px solid var(--lx-line)!important;border-radius:2px!important;box-shadow:0 8px 24px rgba(20,37,31,.08)!important;padding:6px 0!important}
.dropdown-content a{display:block;padding:9px 16px!important;border-bottom:0!important;font-weight:500!important}
.dropdown-content a:hover{background:var(--lx-paper)!important}

/* 4- البطاقات: مسطّحة بخط شعري، والعنوان تحته خط قصير */
.card{background:#fff!important;border:1px solid var(--lx-line)!important;border-radius:2px!important;box-shadow:none!important}
.card>h2,.card>h3{color:var(--lx-g9)!important;padding-bottom:8px;border-bottom:1px solid var(--lx-line);margin-top:0}
h2,h3{color:var(--lx-g9)!important}

/* 5- المؤشرات: رقم كبير بخط العناوين، والنوع بمربّع صغير لا بشريط */
.kpi{border-right:1px solid var(--lx-line)!important}
.kpi .num{font-family:"Hacen Liner","Tajawal",sans-serif!important;font-size:34px!important;color:var(--lx-g)!important;line-height:1.2}
.status-red,.status-yellow,.status-green{border-right-width:1px!important;border-right-color:var(--lx-line)!important;background:#fff!important}
.status-red>div:first-child,.status-yellow>div:first-child,.status-green>div:first-child{position:relative;padding-inline-start:16px}
.status-red>div:first-child::before,.status-yellow>div:first-child::before,.status-green>div:first-child::before{
 content:"";position:absolute;inset-inline-start:0;top:.55em;width:8px;height:8px}
.status-red>div:first-child::before{background:var(--lx-bad)}.status-red .num{color:var(--lx-bad)!important}
.status-yellow>div:first-child::before{background:#E0A100}.status-yellow .num{color:var(--lx-warn)!important}
.status-green>div:first-child::before{background:var(--lx-ok)}.status-green .num{color:var(--lx-ok)!important}
a.lt-kpi:hover .card{border-color:var(--lx-g)!important;filter:none!important}

/* 6- الرسائل: إطار شعري كامل بلون وظيفتها وخلفية فاتحة، بلا شريط جانبي */
.notice,.success,.error,.warning,.alert{border:1px solid var(--lx-line2)!important;border-right-width:1px!important;
 border-radius:2px!important;box-shadow:none!important;padding:12px 16px!important}
.notice{background:#FBF6EC!important;border-color:#E6D5B8!important}
.success{background:#EEF6F3!important;border-color:#B9DCCF!important}
.error{background:#FCEFEA!important;border-color:#F0C3B2!important}

/* 7- الأزرار: مستطيلة بخط الهوية، بلا ظلّ */
button,.btn,input[type=submit]{border-radius:3px!important;box-shadow:none!important;font-weight:700!important;letter-spacing:0}
button:not(.user-button),.btn{background:var(--lx-g)!important;color:#fff!important;border:1px solid var(--lx-g)!important}
button:not(.user-button):hover,.btn:hover{background:var(--lx-g2)!important;border-color:var(--lx-g2)!important}
.btn.secondary{background:#fff!important;color:var(--lx-g)!important;border:1px solid var(--lx-line2)!important}
.btn.secondary:hover{border-color:var(--lx-g)!important;background:#fff!important}
.btn.warn{background:#fff!important;color:#7A5A00!important;border:1px solid #D9B25C!important}
.btn.danger{background:var(--lx-bad)!important;border-color:var(--lx-bad)!important}
.btn.ok{background:var(--lx-ok)!important;border-color:var(--lx-ok)!important}

/* 8- الشارات: مستطيل صغير بلون خافت، لا قرص */
.badge{border-radius:2px!important;border:1px solid currentColor!important;font-weight:700!important;padding:1px 8px!important;font-size:.85em}

/* 9- الجداول: رأس ورقي بخط أخضر تحته، وأسطر شعرية */
th{background:#F4EFE6!important;color:var(--lx-g9)!important;border:0!important;border-bottom:2px solid var(--lx-g)!important;font-weight:700!important}
td{border:0!important;border-bottom:1px solid var(--lx-line)!important}
tbody tr:nth-child(even) td{background:transparent!important}
tbody tr:hover td{background:#FBF8F2!important}

/* 10- الحقول */
input,select,textarea{border:1px solid var(--lx-line2)!important;border-radius:3px!important;background:#fff!important}
input:focus,select:focus,textarea:focus{outline:2px solid var(--lx-g)!important;outline-offset:1px;border-color:var(--lx-g)!important;box-shadow:none!important}
label{color:var(--lx-g9)!important;font-weight:700!important}

/* 11- خريطة العمل: خطوات مرقّمة يصل بينها خط، لا صناديق وأسهم */
.workflow{counter-reset:lxstep;display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr));gap:0 8px!important;align-items:stretch!important}
@media (max-width:760px){.workflow{grid-template-columns:repeat(2,minmax(0,1fr))}}
.workflow .arrow{display:none!important}
.workflow .step{counter-increment:lxstep;border:0!important;border-top:2px solid var(--lx-line2)!important;border-radius:0!important;
 background:transparent!important;padding:10px 12px 4px 16px!important;flex:1 1 140px;font-weight:700;color:var(--lx-g9)!important;position:relative}
.workflow .step::before{content:counter(lxstep);display:block;font-family:"Hacen Liner","Tajawal",sans-serif;font-size:22px;color:var(--lx-gold7);line-height:1.1;margin-bottom:4px}
.workflow .step small{display:block;font-weight:400;color:var(--lx-mute);font-size:12.5px;margin-top:2px}

/* 12- شاشات الاتفاقية (ورقة جلسة التصميم): إزالة الشرائط الجانبية نفسها */
.lt-agr [class*="lt-agr-"]{box-shadow:none!important}
.lt-agr .lt-agr-cond,.lt-agr .lt-agr-sec,.lt-agr .lt-agr-tell,.lt-agr [class*="lt-agr-tell"]{border-inline-start-width:1px!important;border-inline-end-width:1px!important}
.lt-agr .lt-agr-pick:has(input:checked){border-inline-start-width:1px!important;border-color:var(--lx-g)!important;background:#F4F8F6!important}

/* 13- تبويب الاتفاقيات وحالاته التجريبية */
.ltx-hub .ltx-links{display:flex;gap:20px;margin:6px 0 14px}.ltx-hub .ltx-filter{max-width:420px;margin-bottom:12px}
.ltx-tablewrap{overflow-x:auto}.ltx-num{direction:ltr;text-align:right;white-space:nowrap}
.ltx-scn-list{list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));border-top:1px solid var(--lx-line)}
.ltx-scn-list li{border-bottom:1px solid var(--lx-line)}
.ltx-scn-list a{display:block;padding:12px 4px;text-decoration:none;color:var(--lx-ink)}
.ltx-scn-list a:hover b{text-decoration:underline;text-underline-offset:4px}
.ltx-scn-list b{display:block;color:var(--lx-g9)}.ltx-scn-list span{font-size:13px;color:var(--lx-mute)}
.ltx-scn{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;background:#F4EFE6;border:1px solid var(--lx-line2);
 padding:10px 16px;margin:0 0 14px}
.ltx-scn label{margin:0!important}.ltx-scn select{width:auto!important;min-width:260px}
.ltx-scn-what{flex-basis:100%;margin:0;font-size:14px}
@media (max-width:640px){header{padding:12px 16px!important}.user-menu{position:static!important;margin-top:8px}
 .main-nav{flex-wrap:wrap!important;white-space:normal}.ltx-scn select{min-width:0;width:100%!important}
 .card>table,.card table{display:block;overflow-x:auto;max-width:100%}}

/* 14- الشريط المبني من جدول: رؤوس أزرار تُفتح بالنقر وبالمرور */
nav.ltn{display:flex!important;align-items:stretch;flex-wrap:wrap;position:sticky!important;top:var(--ltx-bh,0px)!important;z-index:1100}
.ltn-item{position:relative}
nav.ltn .ltn-head{background:transparent!important;border:0!important;border-bottom:2px solid transparent!important;border-radius:0!important;
 color:var(--lx-g)!important;font-weight:700!important;padding:14px 18px 12px!important;cursor:pointer;font-size:15.5px}
nav.ltn .ltn-head::after{content:"";display:inline-block;width:6px;height:6px;border-right:1.5px solid currentColor;
 border-bottom:1.5px solid currentColor;transform:rotate(45deg);margin-inline-start:9px;vertical-align:4px;opacity:.6}
nav.ltn .ltn-item.open>.ltn-head::after{transform:rotate(-135deg);vertical-align:0}
nav.ltn .ltn-item.active>.ltn-head,nav.ltn .ltn-head:hover,nav.ltn .ltn-item.open>.ltn-head{color:var(--lx-g9)!important;border-bottom-color:var(--lx-gold7)!important;background:transparent!important}
.ltn-menu{display:none;position:absolute;inset-inline-start:0;top:100%;min-width:250px;background:#fff;border:1px solid var(--lx-line);
 border-radius:2px;box-shadow:0 10px 28px rgba(20,37,31,.09);padding:6px 0}
.ltn-item.open>.ltn-menu{display:block}
@media (hover:hover){.ltn-item:hover>.ltn-menu,.ltn-item:focus-within>.ltn-menu{display:block}}
.ltn-menu a{display:block;padding:9px 18px!important;color:var(--lx-ink)!important;font-weight:500!important;text-decoration:none;
 border:0!important;background:transparent!important}
.ltn-menu a:hover,.ltn-menu a[aria-current]{background:var(--lx-paper)!important;color:var(--lx-g9)!important}
.ltn-grp{display:block;padding:10px 18px 4px;font-size:12px;color:var(--lx-gold7);font-weight:700;border-top:1px solid var(--lx-line)}
.ltn-menu .ltn-grp:first-child{border-top:0}
@media (max-width:640px){nav.ltn{overflow:visible!important;white-space:normal!important}
 nav.ltn .ltn-head{padding:11px 12px 9px!important}
 .ltn-item{position:static}
 .ltn-menu{position:absolute;inset-inline:8px;top:100%;min-width:0!important;z-index:1200;max-height:calc(100vh - 140px);overflow-y:auto;
  box-shadow:0 14px 34px rgba(20,37,31,.22)}}

/* 15- خريطة العمل: ست خطوات روابط */
.workflow.ltx-journey{grid-template-columns:repeat(6,minmax(0,1fr))}
a.step{text-decoration:none;display:block}
a.step:hover{border-top-color:var(--lx-gold7)!important;color:var(--lx-g)!important}
.ltx-journey-note{margin:14px 0 0;font-size:14px;color:var(--lx-mute)}
@media (max-width:980px){.workflow.ltx-journey{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:560px){.workflow.ltx-journey{grid-template-columns:repeat(2,minmax(0,1fr))}}

/* 16- شريط حال التكليف */
.ltx-mstatus{display:flex;flex-wrap:wrap;align-items:center;gap:10px 24px;border-top:1px solid var(--lx-line);border-bottom:1px solid var(--lx-line);
 padding:10px 0;margin:6px 0 14px}
.ltx-mstatus ul{list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:6px 22px}
.ltx-mstatus li{display:flex;align-items:center;gap:8px;font-size:14px}
.ltx-mstatus li::before{content:"";width:8px;height:8px;flex:none}
.ltx-mstatus li.ltx-ok::before{background:var(--lx-ok)}.ltx-mstatus li.ltx-wait::before{background:#E0A100}
.ltx-mstatus li span{color:var(--lx-mute)}
.ltx-next{margin-inline-start:auto;font-weight:700;color:var(--lx-g)!important;text-decoration:underline;text-underline-offset:4px}
.ltx-done{text-decoration:none;color:var(--lx-ok)!important}

/* 17- مراجعة مهارة إعادة التصميم (ما يناسب أداة بيانات داخلية وحده) */
.kpi .num,td,th,.ltx-num{font-variant-numeric:tabular-nums}
.grid:has(>.card.kpi){grid-template-columns:repeat(auto-fit,minmax(160px,1fr))!important}
h1,h2,h3{text-wrap:balance}p,li,.small{text-wrap:pretty}
html{scroll-behavior:smooth}
button,.btn,a,input,select,textarea,.ltn-head{transition:background-color .18s ease,border-color .18s ease,color .18s ease}
button:active,.btn:active{transform:translateY(1px)}
a:focus-visible,button:focus-visible,.btn:focus-visible,summary:focus-visible{outline:2px solid var(--lx-gold7)!important;outline-offset:2px}
.ltx-skip{position:absolute;inset-inline-start:12px;top:-60px;z-index:2000;background:var(--lx-g9);color:#fff!important;padding:8px 14px;text-decoration:none}
.ltx-skip:focus{top:8px}
@media (prefers-reduced-motion:reduce){*{transition:none!important;scroll-behavior:auto!important}}

/* 18- أزرار العدّ في الجداول لا تنكسر سطرين */
td .btn,td a.btn{white-space:nowrap}

/* 19- نماذج الإضافة المطويّة */
details.ltx-fold{margin:10px 0 4px}
details.ltx-fold>summary{display:inline-block;cursor:pointer;list-style:none;font-weight:700;color:var(--lx-g);
 border:1px solid var(--lx-line2);border-radius:3px;padding:7px 14px;background:#fff}
details.ltx-fold>summary::-webkit-details-marker{display:none}
details.ltx-fold>summary::before{content:"+";margin-inline-end:8px;color:var(--lx-gold7)}
details.ltx-fold[open]>summary{border-color:var(--lx-g)}
details.ltx-fold[open]>summary::before{content:"−"}
details.ltx-fold>form{margin-top:12px}

/* 20- الشعار المربع في الرأس */
header{display:flex!important;align-items:center;gap:14px}
header .ltx-logo{width:46px;height:46px;flex:none}
header .ltx-brand{display:flex;flex-direction:column;gap:2px}
@media (max-width:640px){header .ltx-logo{width:36px;height:36px}header{flex-wrap:wrap}}

/* 21- الرئيسية «ابدأ من هنا» وشرح الروابط */
.ltn-menu a .ltn-d{display:block;font-size:12.5px;color:var(--lx-mute);font-weight:400;margin-top:2px}
.ltn-menu{min-width:300px}
.ltx-home h3{margin:18px 0 8px;border:0!important;padding:0!important;font-size:18px}
.ltx-wait-list{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:8px}
.ltx-wait-list a{display:flex;align-items:baseline;gap:12px;padding:12px 14px;border:1px solid var(--lx-line);text-decoration:none;color:var(--lx-ink)!important;background:#fff}
.ltx-wait-list a:hover{border-color:var(--lx-g)}
.ltx-n{font-family:"Hacen Liner","Tajawal",sans-serif;font-size:26px;color:var(--lx-g);font-weight:400;font-variant-numeric:tabular-nums}
.ltx-empty{color:var(--lx-mute)}
.ltx-lead{margin:0 0 8px;color:var(--lx-mute);font-size:14px}
.ltx-steps{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:0 8px}
.ltx-steps a{display:block;border-top:2px solid var(--lx-line2);padding:10px 4px;text-decoration:none;color:var(--lx-g9)!important}
.ltx-steps a:hover{border-top-color:var(--lx-gold7)}
.ltx-steps .ltx-sn{display:block;font-family:"Hacen Liner","Tajawal",sans-serif;font-size:22px;color:var(--lx-gold7)}
.ltx-steps b{display:block}.ltx-steps small{display:block;color:var(--lx-mute);font-size:12.5px;margin-top:2px}
.ltx-status-h{margin:22px 0 10px;font-size:20px}
@media (max-width:980px){.ltx-steps{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:560px){.ltx-steps{grid-template-columns:repeat(2,minmax(0,1fr))}}

/* 22- فحص العميل بالمرحلتين معاً وموعده القادم */
.ltx-screen{display:flex;flex-wrap:wrap;align-items:center;gap:8px 16px;margin:12px 0;padding:10px 0;border-top:1px solid var(--lx-line);border-bottom:1px solid var(--lx-line)}
.ltx-screen form{margin:0}.ltx-screen span{font-size:14px;color:var(--lx-mute)}
.ltx-screen.ltx-due span{color:#8A5A00;font-weight:700}

/* 23- الشاشات الواسعة (ملاحظة المالك 30/09 على شاشة عالية الدقة): المحتوى يمتد إلى الهامش بلا حصر 1340،
   والصفحة كلها تكبر بنسبة ثابتة فيبقى الخط متناسباً مع العرض */
main,main#lt-main{max-width:none!important;margin:0!important;padding:24px 32px!important}
@media (min-width:2400px){body{zoom:1.25}}
@media (min-width:3000px){body{zoom:1.5}}
@media (min-width:3600px){body{zoom:1.8}}

/* 24- ألوان حالة الحقول في شاشة الاتفاقية: نقطة أمام العنوان ولون حدٍّ خفيف، بلا شريط */
.lt-agr .lt-agr-f[data-state]>label::before{content:"";display:inline-block;width:8px;height:8px;border-radius:50%;
 margin-inline-end:7px;vertical-align:1px}
.lt-agr .lt-agr-f[data-state=done]>label::before{background:#2E8C73}
.lt-agr .lt-agr-f[data-state=todo]>label::before{background:#FDB614}
.lt-agr .lt-agr-f[data-state=err]>label::before{background:#F15722}
.lt-agr .lt-agr-f[data-state=done] :is(input,select,textarea){border-color:#9CCBBE!important}
.lt-agr .lt-agr-f[data-state=todo] :is(input,select,textarea){border-color:#F1C95C!important;background:#FFFCF3!important}
.lt-agr .lt-agr-f[data-state=err] :is(input,select,textarea){border-color:#F15722!important;background:#FFF6F2!important}
/* تفاصيل فنية مطويّة (وكيل مسح النصوص) */
details.ltx-tech{margin:.5rem 0;color:#5b5b5b;font-size:.9em}
details.ltx-tech>summary{cursor:pointer;color:#244037}

/* 25- عنوان القسم الشرطي: تصميم الشاشة يرفعه 12 نقطة ليقعد على الحدّ كاللسان، وبلا أرضية يقطعه الخط؛ فيُنزَل داخل القسم */
.lt-agr .lt-agr-sec.lt-agr-cond>h3{transform:none!important;margin:16px 0 6px!important;padding:0!important}
.lt-agr .lt-agr-sec.lt-agr-cond{border-color:#B9CCD6!important;border-inline-start-width:1px!important;background:#FBFCFD!important}

/* 26- ألوان ثانوية وتفاعل يسير (طلب المالك 30/09): لون خفيف بحسب نوع ما ينتظرك، ورفعٌ طفيف عند المرور */
.ltx-wait-list a{transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease}
.ltx-wait-list a:hover{transform:translateY(-2px);box-shadow:0 6px 16px rgba(20,37,31,.08)}
.ltx-wait-list a.ltx-k-cmp{background:#FBF5EB!important;border-color:#E6D5B8!important}
.ltx-wait-list a.ltx-k-cmp .ltx-n{color:#8A6200}
.ltx-wait-list a.ltx-k-agr{background:#EEF6F3!important;border-color:#B9DCCF!important}
.ltx-wait-list a.ltx-k-agr .ltx-n{color:#2E8C73}
.ltx-wait-list a.ltx-k-cli{background:#EEF3F6!important;border-color:#C4D6E0!important}
.ltx-wait-list a.ltx-k-cli .ltx-n{color:#265871}
.ltx-steps a{transition:background-color .18s ease}
.ltx-steps a:hover{background:#FBF8F2}
.ltx-steps .ltx-sn{width:32px;height:32px;border:1.5px solid var(--lx-gold7);border-radius:50%;display:flex!important;
 align-items:center;justify-content:center;font-size:17px!important;margin-bottom:6px;transition:background-color .18s ease,color .18s ease}
.ltx-steps a:hover .ltx-sn{background:var(--lx-gold7);color:#fff}
.card.kpi{transition:transform .18s ease,box-shadow .18s ease}
a.lt-kpi:hover .card,.card.kpi:hover{transform:translateY(-2px);box-shadow:0 6px 16px rgba(20,37,31,.07)!important}
.ltn-menu a{transition:background-color .15s ease,padding .15s ease}
.ltn-menu a:hover{padding-inline-start:22px!important}
@media (prefers-reduced-motion:reduce){.ltx-wait-list a:hover,a.lt-kpi:hover .card,.card.kpi:hover{transform:none}}
</style>"""

# التعليقات للقارئ في هذا الملف وحده، ولا تُرسل في الصفحة: كانت كلمة «أخضر» في تعليقٍ تُفشل اختبار سجل
# الفحص (test_v10_5_13) لأنه يبحث في الصفحة عن اسم حالة «أخضر» ليتحقق من إخفائها
CSS = re.sub(r"/\*.*?\*/", "", CSS, flags=re.S)

# ملفّ الرفع: زرّ المتصفح الأصلي يكتب «Choose File / No file chosen» بلغة المتصفح؛ فيُخفى ويُرسم بدله زرّ عربي
FILE_CSS = """<style id="lt-ui-file">.lx-file{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.lx-file input[type=file]{position:absolute!important;width:1px!important;height:1px!important;opacity:0!important;pointer-events:none}
.lx-file .lx-file-btn{display:inline-block;cursor:pointer;border:1px solid #CFC6B6;border-radius:3px;padding:8px 14px;background:#fff;
 color:#244037;font-weight:700}.lx-file .lx-file-btn:hover{border-color:#244037}
.lx-file input[type=file]:focus-visible+.lx-file-btn{outline:2px solid #244037;outline-offset:1px}
.lx-file .lx-file-name{color:#6B6B6B;font-size:14px}</style>"""
FILE_SCRIPT = """<script>(function(){document.querySelectorAll('input[type=file]').forEach(function(inp,n){
 if(inp.closest('.lx-file'))return;var w=document.createElement('span');w.className='lx-file';
 inp.parentNode.insertBefore(w,inp);w.appendChild(inp);if(!inp.id)inp.id='lx-file-'+n;
 var b=document.createElement('label');b.className='lx-file-btn';b.htmlFor=inp.id;b.textContent=inp.multiple?'اختر الملفات':'اختر ملفاً';
 var t=document.createElement('span');t.className='lx-file-name';t.textContent='لم يُختر ملف';w.appendChild(b);w.appendChild(t);
 inp.addEventListener('change',function(){var k=inp.files.length;t.textContent=!k?'لم يُختر ملف':(k===1?inp.files[0].name:('اختيرت '+k+' ملفات'));});});})();</script>"""

COUNTRY_SCRIPT = """<script>(function(){document.querySelectorAll('input[list="lt-countries"]').forEach(function(i){
 i.addEventListener('focus',function(){if(i.value===i.getAttribute('data-default'))i.select();});});})();</script>"""

_NS: Dict[str, Any] = {}
COPY_ENABLED = True
_RE_USER = re.compile(r"<button class='user-button'>(.*?)<small>(.*?)</small>")
_RE_TITLE = re.compile(r"<title>(.*?)</title>", re.S)
_RE_COUNTRY = re.compile(r'<input name="country"( value="([^"]*)")?>')


def _country_input(m: "re.Match[str]") -> str:
    val = m.group(2)
    if val is not None and val.strip().lower() in ("saudi arabia", ""):
        val = DEFAULT_COUNTRY                      # الافتراض القديم «Saudi Arabia» يصير عربياً
    v = f' value="{val}"' if val is not None else ""
    return (f'<input name="country"{v} list="lt-countries" autocomplete="off" '
            f'data-default="{DEFAULT_COUNTRY}" placeholder="اكتب لتبحث في الدول">')


# ─────────────── الشريط الرئيسي من جدول واحد (تدقيق الاستخدام: ن-4، ن-11، ن-15، ن-18) ───────────────
# كان الشريط تبنيه تسع طبقات تحقن بعد نصوص بعينها، فتغيير اسم في إحداها يُسقط حقن غيرها صامتاً.
# القاعدة: يظهر الرابط لدورٍ إن كان الشريط القديم يعطيه إياه، أو كان من الروابط الجديدة المفتوحة لكل داخل؛
# ويُحجب ما يرفضه الخادم لذلك الدور (كانت «الإعدادات» و«النسخ الاحتياطية» و«مركز التحكم» تظهر للموظف فيلقى 403)؛
# وما لا يعرفه الجدول من روابط الشريط القديم لا يسقط، بل يذهب إلى «أخرى» تحت «الإدارة».
PRIV = {"admin", "compliance"}
ADDED = {"/clients/new", "/matters/new", "/agreements", "/reports/contracts/unsigned",
         "/reports/contracts/signed-not-uploaded", "/staff/import"}
# «القوائم» تُفتح لكل داخل لكن رفعها مرفوض لغير المخوَّلين (ثبت بالتجربة: 403)، فلا حاجة للموظف بها (طلب المالك 30/09)
HIDDEN_FOR_STAFF = {"/lists"}
ROLE_ONLY = {"/production": {"admin"}, "/settings": {"admin"}, "/backups": {"admin"}, "/data-import": PRIV, "/lists": PRIV,
             "/wathq/selftest": PRIV, "/staff/import": {"admin"}}
NAV = [
    ("الرئيسية", "/", [(None, [("/", "لوحة اليوم"), ("/partner-dashboard", "مهامي")])]),
    ("العملاء", "/clients", [(None, [("/clients", "العملاء"), ("/clients/new", "إضافة عميل"),
                                     ("/data-import", "استيراد العملاء والتكليفات")])]),
    ("التكليفات", "/matters", [(None, [("/matters", "التكليفات"), ("/matters/new", "فتح تكليف")])]),
    ("الاتفاقيات", "/agreements", [(None, [("/agreements", "إصدار اتفاقية"),
                                           ("/reports/contracts/unsigned", "صادرة لم تُوقَّع"),
                                           ("/reports/contracts/signed-not-uploaded", "موقَّعة لم تُرفع")])]),
    ("الامتثال", "/compliance", [
        ("الفحص", [("/quick_screen", "الفحص السريع"), ("/bulk_screen", "الفحص الجماعي"),
                   ("/screenings", "نتائج الفحص والتطابقات")]),
        ("المراجعات", [("/regulatory-review", "المراجعة التنظيمية"), ("/document-obligations", "استكمال المستندات")]),
        ("المتابعة", [("/compliance", "لوحة الامتثال"), ("/reports", "التقارير")]),
        ("السري", [("/suspicion-cases", "سجل الاشتباه")]),
    ]),
    ("الإدارة", "/production", [(None, [("/lists", "القوائم وضوابطها"), ("/staff/import", "دليل الموظفين والموقّعون"),
                                        ("/settings", "الإعدادات"), ("/audit", "سجل التدقيق"),
                                        ("/backups", "النسخ الاحتياطية والاستعادة"), ("/production", "مركز التحكم والصيانة"),
                                        ("/wathq/selftest", "واثق: اختبار الربط")])]),
]
_RE_NAV = re.compile(r'<nav class="main-nav"[^>]*>.*?</nav>', re.S)
_RE_HREF = re.compile(r'<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>', re.S)

NAV_SCRIPT = """<script>(function(){var n=document.querySelector('nav.ltn');if(!n)return;
function shut(x){n.querySelectorAll('.ltn-item.open').forEach(function(i){if(i!==x){i.classList.remove('open');
 i.querySelector('.ltn-head').setAttribute('aria-expanded','false');}});}
n.querySelectorAll('.ltn-head').forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();
 var it=b.parentNode,o=!it.classList.contains('open');shut(it);it.classList.toggle('open',o);b.setAttribute('aria-expanded',o?'true':'false');});});
document.addEventListener('click',function(e){if(!n.contains(e.target))shut(null);});
document.addEventListener('keydown',function(e){if(e.key==='Escape')shut(null);});
function bh(){var b=document.querySelector('.env-banner'),c=b&&getComputedStyle(b);document.documentElement.style.setProperty('--ltx-bh',(b&&c.position==='sticky'?b.offsetHeight:0)+'px');}
bh();window.addEventListener('resize',bh);})();</script>"""


def _role() -> str:
    fn = _NS.get("_auth_current_user")
    try:
        return str(((fn() if fn else None) or {}).get("role") or "")
    except Exception:
        return ""


def nav_links(old_hrefs: Dict[str, str], role: str):
    """[(عنوان القسم، رابطه، [(عنوان المجموعة، [(الرابط، الاسم)])])] لهذا الدور؛ وما لا يعرفه الجدول يذهب إلى «أخرى»."""
    known, out = set(), []
    for title, home, groups in NAV:
        gs = []
        for gtitle, links in groups:
            keep = []
            for href, label in links:
                known.add(href)
                if href not in old_hrefs and href not in ADDED:
                    continue
                if href in ROLE_ONLY and role not in ROLE_ONLY[href]:
                    continue
                if href == "/suspicion-cases" and role not in PRIV:
                    label = "بلاغ اشتباه داخلي"          # الموظف يبلّغ ولا يرى السجل (القرار 178)
                keep.append((href, label))
            if keep:
                gs.append((gtitle, keep))
        if gs:
            out.append((title, home, gs))
    extra = [(hr, lb) for hr, lb in old_hrefs.items() if hr not in known]
    if extra:
        admin = next((x for x in out if x[0] == "الإدارة"), None)
        if admin is None:
            admin = ("الإدارة", "/production", [])
            out.append(admin)
        admin[2].append(("أخرى", extra))
    return out


def rebuild_nav(raw: str, active: str = "") -> str:
    m = _RE_NAV.search(raw)
    if not m or "ltn-item" in m.group(0):
        return raw
    old: Dict[str, str] = {}
    for href, label in _RE_HREF.findall(m.group(0)):
        old.setdefault(href, re.sub(r"<[^>]+>", "", label).strip())
    items = []
    for n, (title, home, groups) in enumerate(nav_links(old, _role())):
        hrefs = {hr for _g, ls in groups for hr, _l in ls}
        on = " active" if active and (active in hrefs or active == home) else ""
        menu = []
        for gtitle, links in groups:
            if gtitle:
                menu.append(f'<span class="ltn-grp">{gtitle}</span>')
            for hr, lb in links:
                cur = ' aria-current="page"' if hr == active else ""
                ds = _desc(hr, _role() in PRIV)
                menu.append(f'<a href="{hr}"{cur}>{lb}' + (f'<span class="ltn-d">{ds}</span>' if ds else "") + '</a>')
        items.append(f'<div class="ltn-item{on}"><button type="button" class="ltn-head" aria-expanded="false" '
                     f'aria-controls="ltn-m{n}">{title}</button><div class="ltn-menu" id="ltn-m{n}">{"".join(menu)}</div></div>')
    nav = f'<nav class="main-nav ltn" aria-label="القائمة الرئيسية">{"".join(items)}</nav>'
    raw = raw[:m.start()] + nav + raw[m.end():]
    return raw.replace("</body>", NAV_SCRIPT + "</body>", 1) if "</body>" in raw else raw + NAV_SCRIPT


# ─────────────── خريطة العمل في الرئيسية: ست خطوات قابلة للنقر، فيها الاتفاقية والتوقيع (ن-5) ───────────────
JOURNEY = [
    ("/clients/new", "فتح العميل", "بياناته ووثيقته الرئيسة"),
    ("/clients", "الملّاك والمستندات", "من ملف العميل: المسيطرون ومصدر الأموال"),
    ("/screenings", "الفحص", "تعارض المصالح ثم قوائم العقوبات"),
    ("/matters/new", "التكليف والفريق", "والأطراف المقابلة وفحصها"),
    ("/agreements", "الاتفاقية", "إصدارها من بيانات العميل والفريق"),
    ("/reports/contracts/unsigned", "التوقيع والرفع", "إرفاق الموقَّعة ورفعها إلى شيربوينت"),
]
_RE_WORKFLOW = re.compile(r'<div class="workflow">.*?(?=<p class="notice">)', re.S)


def _journey(role: str) -> str:
    steps = "".join(f'<a class="step" href="{hr}">{t}<small>{sub}</small></a>' for hr, t, sub in JOURNEY)
    tail = ('<p class="ltx-journey-note">وعند الاشتباه في أي مرحلة: '
            f'<a href="/suspicion-cases">{"سجل الاشتباه" if role in PRIV else "بلاغ اشتباه داخلي"}</a>.</p>')
    return f'<div class="workflow ltx-journey">{steps}</div>{tail}'


# ─────────────── طيّ نماذج الإضافة في صفحتي العميل والتكليف (ن-13) ───────────────
# النموذج نفسه لا يتغير حرفاً، بل يُلفّ في «details»؛ ويُطوى في آخر مرحلة قبل الإرسال فلا يمسّ ما تحقنه الطبقات.
FOLD = {"/client/add_party": "إضافة طرف", "/client/add_ownership_trace": "إضافة طبقة ملكية",
        "/counterparty/new": "إضافة طرف مقابل", "/counterparty/add_party": "إضافة عضو إلى الطرف المقابل",
        "/documents/upload": "رفع وثيقة"}
_RE_FORM = re.compile(r'<form method="post" action="([^"?]+)[^"]*"[^>]*>.*?</form>', re.S)


def fold_forms(raw: str) -> str:
    def _fold(m: "re.Match[str]") -> str:
        label = FOLD.get(m.group(1))
        before = raw[max(0, m.start() - 40):m.start()]
        if not label or "ltx-fold" in before:
            return m.group(0)
        return f'<details class="ltx-fold"><summary>{label}</summary>{m.group(0)}</details>'
    return _RE_FORM.sub(_fold, raw)


# ─────────────── الشعار المربع في الرأس (بطلب المالك 30/09) ───────────────
# العلامة الذهبية الشفافة من «LT Logo Assets» (نسخة في ui_assets)؛ على الرأس الأخضر الداكن تبين، واللوح الأخضر لا يبين عليه
def _logo_svg() -> str:
    try:
        from pathlib import Path as _P
        svg = (_P(__file__).resolve().parent / "ui_assets" / "lt-mark-gold.svg").read_text(encoding="utf-8")
    except Exception:
        return ""
    svg = re.sub(r'\swidth="[^"]*"\s+height="[^"]*"', "", svg, count=1)
    return svg.replace("<svg ", '<svg class="ltx-logo" role="img" aria-label="مسارات قانونية" ', 1)


LOGO = _logo_svg()

# ─────────────── شرح الروابط في القوائم: سطر تحت كل رابط يقول ما تفعله صفحته (طلب المالك 30/09) ───────────────
DESC = {
    "/": "ما ينتظرك وحال المنصة", "/partner-dashboard": "المهام والموافقات المسندة إليك",
    "/clients": "البحث في ملفات العملاء وفتحها", "/clients/new": "ملف عميل جديد، قبل أي تكليف",
    "/data-import": "إدخال عملاء وتكليفات كثيرة من ملف واحد",
    "/matters": "كل التكليفات وحال كل منها", "/matters/new": "تكليف جديد لعميل اجتاز الفحص",
    "/agreements": "اختر التكليف وأصدر اتفاقيته", "/reports/contracts/unsigned": "اتفاقيات تنتظر توقيع العميل",
    "/reports/contracts/signed-not-uploaded": "موقَّعة لم تصل إلى شيربوينت بعد",
    "/quick_screen": "فحص اسمٍ قبل أن يصير عميلاً", "/bulk_screen": "فحص قائمة أسماء من ملف دفعة واحدة",
    "/screenings": "النتائج والتطابقات التي تنتظر قراراً",
    "/regulatory-review": "المستفيد الحقيقي والمعرّض سياسياً وقرار الشريك",
    "/document-obligations": "مستندات أُجّلت ومواعيد استكمالها", "/compliance": "مؤشرات الامتثال لمسؤوله",
    "/reports": "تقارير الفحص الدورية والتقارير الرقابية",
    "/lists": "تحميل قوائم العقوبات وتحديثها", "/staff/import": "الموظفون والشركاء الموقّعون من مايكروسوفت",
    "/settings": "أنواع العملاء والخدمات وسياسات المنصة", "/audit": "كل عملية في المنصة ومن أجراها",
    "/backups": "نسخ قاعدة البيانات واستعادتها", "/production": "حال الخادم والصيانة",
    "/wathq/selftest": "التحقق من الربط بمركز واثق",
}
DESC_ROLE = {("/suspicion-cases", True): "البلاغات السرية وقراراتها",
             ("/suspicion-cases", False): "أبلغ مسؤول الامتثال عن شبهة، ولا يطّلع عليها غيره",
             ("/audit", False): "ما أجريته أنت في المنصة"}


def _desc(href: str, priv: bool) -> str:
    return DESC_ROLE.get((href, priv)) or DESC.get(href, "")


# ─────────────── الرئيسية «ابدأ من هنا» (طلب المالك 30/09) ───────────────
# ثلاثة أجزاء: ما ينتظرك -بحسب الصلاحية-، وابدأ عملاً جديداً، وحال المنصة (المؤشرات القائمة كما هي).
# ويُحذف منها بطاقة الخطوات القديمة لأن «ابدأ عملاً جديداً» تحلّ محلها.
def _waiting(user: Dict[str, Any]) -> list:
    role = str(user.get("role") or "")
    me = str(user.get("user_name") or "").lower()
    priv = role in PRIV
    items = []
    try:
        with _NS["db"]() as con:
            q = lambda sql, *a: (con.execute(sql, a).fetchone() or [0])[0] or 0
            mine = "" if priv else " AND d.matter_id IN (SELECT matter_id FROM matter_team WHERE lower(email)=?)"
            args = () if priv else (me,)
            if priv:
                items.append((q("SELECT COUNT(*) FROM screenings WHERE status IN ('confirmed_match','high_similarity','potential_match')"),
                              "تطابقات تنتظر قرار الامتثال", "/screenings?filter=open"))
                items.append((q("SELECT COUNT(*) FROM clients WHERE status='under_review'"),
                              "عملاء ينتظرون حسم تطابقاتهم قبل أي تكليف", "/clients"))
                items.append((q("SELECT COUNT(*) FROM suspicion_cases WHERE status='new'"),
                              "بلاغات اشتباه جديدة", "/suspicion-cases"))
                try:
                    import screening_flow
                    items.append((len(screening_flow.due_clients(con)), "عملاء حلّ موعد مراجعة ملفاتهم", "/clients"))
                except Exception:
                    pass
            items.append((q("SELECT COUNT(*) FROM clients WHERE status='draft'"),
                          "عملاء فُتحت ملفاتهم ولم يُفحصوا بعد", "/clients"))
            items.append((q("SELECT COUNT(*) FROM issued_documents d WHERE d.status='issued'" + mine, *args),
                          "اتفاقيات صدرت ولم تُوقَّع", "/reports/contracts/unsigned"))
            items.append((q("SELECT COUNT(*) FROM issued_documents d WHERE d.status='signed'" + mine, *args),
                          "اتفاقيات موقَّعة لم تُرفع إلى شيربوينت", "/reports/contracts/signed-not-uploaded"))
            no_agr = ("SELECT COUNT(*) FROM matters m JOIN clients c ON c.id=m.client_id WHERE c.status IN ('active','approved') "
                      "AND NOT EXISTS (SELECT 1 FROM issued_documents d WHERE d.matter_id=m.id AND d.doc_type='agreement' "
                      "AND d.status!='withdrawn')")
            if not priv:
                no_agr += " AND m.id IN (SELECT matter_id FROM matter_team WHERE lower(email)=?)"
            items.append((q(no_agr, *args), "تكليفات اجتاز عملاؤها الفحص ولم تصدر اتفاقياتها", "/agreements"))
            items.append((q("SELECT COUNT(*) FROM outstanding_documents WHERE status IN ('pending','deferred') "
                            "AND due_date<=date('now','+7 day')"), "مستندات مؤجَّلة يحلّ موعد استكمالها خلال أسبوع", "/document-obligations"))
    except Exception:
        return []
    kind = lambda h: ("cmp" if h.startswith(("/screenings", "/suspicion", "/clients?"))
                      else "agr" if h.startswith(("/reports/contracts", "/agreements")) else "cli")
    return [(n, t, h, kind(h) if "مراجعة ملفاتهم" not in t and "حسم" not in t else "cmp") for n, t, h in items if n]


def home_block(user: Dict[str, Any]) -> str:
    priv = str(user.get("role") or "") in PRIV
    from html import escape as _esc
    name = _esc(str(user.get("full_name") or ""))    # H4 من مراجعة فابل: الاسم يُهرَّب كبقية الطبقات
    wait = _waiting(user)
    if wait:
        lis = "".join(f'<li><a class="ltx-k-{k}" href="{h}"><b class="ltx-n">{n}</b><span>{t}</span></a></li>' for n, t, h, k in wait)
        waiting = f'<ul class="ltx-wait-list">{lis}</ul>'
    else:
        waiting = '<p class="ltx-empty">لا شيء ينتظرك الآن.</p>'
    steps = "".join(
        f'<li><a href="{hr}"><span class="ltx-sn">{i}</span><b>{t}</b><small>{sub}</small></a></li>'
        for i, (hr, t, sub) in enumerate(JOURNEY, 1))
    note = "سجل الاشتباه" if priv else "بلاغ اشتباه داخلي"
    return (f'<section class="card ltx-home"><h2>ابدأ من هنا{("، " + name) if name else ""}</h2>'
            f'<h3>ما ينتظرك</h3>{waiting}'
            f'<h3>ابدأ عملاً جديداً</h3><p class="ltx-lead">الخطوات بترتيبها؛ اضغط الخطوة التي أنت فيها.</p>'
            f'<ol class="ltx-steps">{steps}</ol>'
            f'<p class="ltx-journey-note">وعند الاشتباه في أي مرحلة: <a href="/suspicion-cases">{note}</a>.</p></section>'
            '<h2 class="ltx-status-h">إحصائيات المنصة</h2>')


_RE_OLD_JOURNEY_CARD = re.compile(r'<div class="card">\s*<h2>[^<]*</h2>\s*<div class="workflow ltx-journey">.*?</div>'
                                  r'<p class="ltx-journey-note">.*?</p>', re.S)


def rebuild_home(raw: str) -> str:
    fn = _NS.get("_auth_current_user")
    try:
        user = (fn() if fn else None) or {}
    except Exception:
        user = {}
    if 'class="card ltx-home"' in raw or '<main id="lt-main" tabindex="-1">' not in raw:
        return raw
    raw = _RE_OLD_JOURNEY_CARD.sub('<div class="card">', raw, count=1)
    # جملة «تعمل V10 بمنطق الفحص المستمر…» لا تعني المستخدم (طلب المالك 30/09): تُحذف بطاقتها
    raw = re.sub(r'<div class="card">\s*<p class="notice">تعمل V10[^<]*</p>\s*</div>', "", raw, count=1)
    # «رفع القوائم» عمل مدير النظام ومسؤول الامتثال: لا يظهر لغيرهما، ولا يُبرَز بالأخضر لهما
    if str(user.get("role") or "") in PRIV:
        raw = raw.replace('<a class="btn" href="/lists">رفع القوائم</a>', '<a class="btn secondary" href="/lists">رفع القوائم</a>', 1)
    else:
        raw = raw.replace('<a class="btn" href="/lists">رفع القوائم</a>', "", 1)
    return raw.replace('<main id="lt-main" tabindex="-1">', '<main id="lt-main" tabindex="-1">' + home_block(user), 1)


def rewrite(raw: str, active: str = "") -> str:
    # الخطوط واللغة البصرية: آخر طبقة في الرأس
    if 'id="lt-ui-layer"' not in raw and "</head>" in raw:
        raw = raw.replace("</head>", CSS + "</head>", 1)
    # عنوان التبويب: بلا رقم الإصدار ووصفه
    raw = _RE_TITLE.sub(lambda m: "<title>" + re.split(r"\s+-\s+Compliance Tracks", m.group(1))[0].strip()
                        + " — مسارات الامتثال</title>", raw, count=1)
    # سطر الرأس الفرعي: ما يحتاجه المستخدم وحده؛ ويبقى رقم الإصدار في تلميح العنوان للدعم الفني
    version = "الإصدار " + str(_NS.get("APP_VERSION") or "").split(" - ")[0].strip()
    raw = re.sub(r"<header><h1>(.*?)</h1><small>.*?</small>",
                 lambda m: f"<header>{LOGO}<div class=\"ltx-brand\"><h1 title=\"{version}\">{m.group(1)}</h1><small>منصة الامتثال ومعرفة العميل</small></div>",
                 raw, count=1, flags=re.S)
    # زرّ المستخدم: الصفة بالعربية، ولا تتكرر إن طابقت الاسم
    def _user(m: "re.Match[str]") -> str:
        name, role = m.group(1), ROLE_AR.get(m.group(2).strip(), m.group(2))
        return f"<button class='user-button'>{name}" + ("" if role == name else f"<small>{role}</small>")
    raw = _RE_USER.sub(_user, raw, count=1)
    for old, new in COPY:
        raw = raw.replace(old, new)
    # رابط «انتقل إلى المحتوى» لمستعمل لوحة المفاتيح، ومعرّف للمحتوى
    if "<main>" in raw and 'class="ltx-skip"' not in raw:
        raw = raw.replace("<body>", '<body><a class="ltx-skip" href="#lt-main">انتقل إلى المحتوى</a>', 1)
        raw = raw.replace("<main>", '<main id="lt-main" tabindex="-1">', 1)
    # الشريط الرئيسي: يُبنى كله من جدول واحد (NAV) بدل حقن طبقات متعاقبة
    raw = rebuild_nav(raw, active)
    if '<div class="workflow">' in raw:
        raw = _RE_WORKFLOW.sub(lambda m: _journey(_role()), raw, count=1)
    if active == "/":
        raw = rebuild_home(raw)
    if 'type="file"' in raw or "type='file'" in raw:
        if 'id="lt-ui-file"' not in raw:
            raw = raw.replace("</head>", FILE_CSS + "</head>", 1).replace("</body>", FILE_SCRIPT + "</body>", 1)
    # حقل الدولة
    if '<input name="country"' in raw:
        raw = _RE_COUNTRY.sub(_country_input, raw)
        if 'id="lt-countries"' not in raw:
            opts = "".join(f'<option value="{c}">' for c in COUNTRIES)
            raw = raw.replace("</body>", f'<datalist id="lt-countries">{opts}</datalist>{COUNTRY_SCRIPT}</body>', 1)
    # نصوص الجرد (ui_copy): عرضٌ فقط، ومثبتٌ باختباره أن الحقول والروابط لا تتغير
    if not COPY_ENABLED:                               # يطفئه اختبار الجرد ليرى الصفحة قبل التطبيق
        return raw
    try:
        import ui_copy
    except Exception:                                  # ملف الجرد في طور العمل: لا تُعطَّل صفحة بسببه
        return raw
    return ui_copy.apply(raw)


def install(ns: Dict[str, Any]) -> None:
    _NS.update(ns)
    if ns.get("_lt_ui_layer"):
        return
    base_layout, base_login = ns["layout"], ns.get("login_page")

    def layout(title: str, body: str, active: str = "") -> bytes:
        return rewrite(base_layout(title, body, active).decode("utf-8"), active).encode("utf-8")

    ns["layout"] = layout
    if base_login:
        def login_page(message: str = "") -> bytes:
            return rewrite(base_login(message).decode("utf-8")).encode("utf-8")
        ns["login_page"] = login_page
    # نصوص الجرد الأخيرة (ui_copy.COPY_FINAL) على الاستجابة نفسها بعد كل الطبقات: طبقاتٌ في app.py
    # تبحث في الصفحة عن نصٍّ لتحقن بجانبه، فلو تغيّر قبلها لسقط حقنها صامتاً (كشفه اختبار الجرد)
    handler = ns.get("AppHandler")
    if handler and not getattr(handler, "_lt_final_copy", False):
        base_send = handler._send

        def _send(self, data, status: int = 200, content_type: str = "text/html; charset=utf-8") -> None:
            if COPY_ENABLED and content_type.startswith("text/html"):
                try:
                    import ui_copy
                    raw = data.decode("utf-8") if isinstance(data, bytes) else data
                    import audit_view
                    data = audit_view.apply(fold_forms(ui_copy.apply(raw, final=True))).encode("utf-8")
                except Exception:
                    pass
            return base_send(self, data, status, content_type)

        handler._send = _send
        handler._lt_final_copy = True
    # القرار 189: «التعارض الداخلي» اسمه «فحص تعارض المصالح» في الشاشة والتقارير واسم الملف المرفوع؛
    # يُعدَّل العنوان في القاموسين اللذين تقرأ منهما دوالّ التقارير، فلا تُمسّ شيفرة التقرير
    for dname, key, title in (("_CLIENT_REPORT_KINDS", "internal", "تقرير فحص تعارض المصالح"),
                              ("_BATCH_REPORTS", "internal-conflicts", "تقرير فحص تعارض المصالح للعملاء")):
        dct = ns.get(dname)
        if isinstance(dct, dict) and key in dct and isinstance(dct[key], tuple):
            dct[key] = (title,) + dct[key][1:]
    ns["_lt_ui_layer"] = True

# -*- coding: utf-8 -*-
"""سجل الوثائق الصادرة — إضافة مسارات قانونية على منصة الامتثال.

ملف مستقل عن app.py عمداً (القرار 97): يُربط بسطرين في آخر app.py
    import contracts_register as _cr
    _cr.install(globals())
ويُزال بحذفهما دون مساس بشيء آخر.

القواعد التي يطبّقها (من rules/DECISIONS.md):
- المرجع هو رقم التكليف نفسه بصيغة المنصة العاملة «عميل.تكليف» (95).
- إعادة الإنشاء قبل التوقيع لا تستهلك رقماً ولا تُنشئ صفاً جديداً (77).
- لا نُسخ للوثيقة قبل التوقيع؛ يُحفظ كائن المدخلات النهائي وبصمة الملف (58).
- الملحق وثيقة مستقلة بمرجع مشتق من مرجع التكليف: «…/م1» (59).
- الرفع يبدأ من صفّ الوثيقة، وما صدر ولم يُوقَّع يظهر بعمره (81).
- كل انتقال حالة يُقيَّد بوقته وفاعله في سجل الأحداث وفي سجل تدقيق المنصة.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import sqlite3
from typing import Any, Callable, Dict, List, Optional

# مراجع إلى دوال المنصة، تُقرأ ساعة الاستدعاء لا ساعة التحميل؛
# لأن app.py يعيد تعريف بعض دواله (audit مرتين، create_matter خمس مرات)
# والنسخة العاملة هي الأخيرة.
_NS: Dict[str, Any] = {}

DOC_TYPES = ("agreement", "offer", "addendum")
STATUSES = ("issued", "signed", "uploaded", "withdrawn")
# الانتقالات المسموح بها؛ وما عداها يُرفض
TRANSITIONS = {
    "issued": {"signed", "withdrawn"},
    "signed": {"uploaded"},
    "uploaded": set(),
    "withdrawn": set(),
}


class RegisterError(Exception):
    """خطأ في قواعد السجل — يُعرض للمستخدم بنصه."""


def _now() -> str:
    fn = _NS.get("now_iso")
    return fn() if fn else _dt.datetime.now().isoformat(timespec="seconds")


def _audit(con: sqlite3.Connection, action: str, doc_id: int, details: str, ip: str = "") -> None:
    fn = _NS.get("audit")
    if fn:
        fn(con, action, "issued_document", doc_id, details, ip)


# ─────────────────────────── البنية ───────────────────────────

def ensure_schema(con: sqlite3.Connection) -> None:
    con.execute("""
        CREATE TABLE IF NOT EXISTS issued_documents(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            matter_id INTEGER NOT NULL REFERENCES matters(id),
            client_id INTEGER NOT NULL REFERENCES clients(id),
            doc_type TEXT NOT NULL,
            reference_no TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'issued',
            language TEXT,
            fee_model TEXT,
            fee_amount TEXT,
            term TEXT,
            inputs_json TEXT,
            file_name TEXT,
            file_sha256 TEXT,
            regenerations INTEGER NOT NULL DEFAULT 0,
            issued_by TEXT,
            signed_at TEXT,
            uploaded_at TEXT,
            sharepoint_ref TEXT,
            withdrawn_at TEXT,
            notes TEXT,
            UNIQUE(reference_no, doc_type)
        )""")
    con.execute("""
        CREATE TABLE IF NOT EXISTS issued_document_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            document_id INTEGER NOT NULL REFERENCES issued_documents(id),
            event TEXT NOT NULL,
            actor TEXT,
            details TEXT
        )""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_issued_documents_matter ON issued_documents(matter_id)")
    con.execute("CREATE INDEX IF NOT EXISTS ix_issued_documents_status ON issued_documents(status)")
    # خطر التزامن في الترقيم (القرار 96): فهرس تفرّد على رقم التكليف.
    # إن كانت في القاعدة أرقام مكرّرة من قبل فشل إنشاؤه؛ فلا يُوقف المنصة،
    # بل يُقيَّد ليُعالَج يدوياً.
    try:
        con.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_matters_number ON matters(matter_number)")
    except sqlite3.IntegrityError as exc:
        _audit(con, "matter_number_duplicates_found", 0, f"تعذّر فهرس التفرّد: {exc}")


def _event(con: sqlite3.Connection, doc_id: int, event: str, actor: str, details: str = "") -> None:
    con.execute(
        "INSERT INTO issued_document_events(created_at,document_id,event,actor,details) VALUES(?,?,?,?,?)",
        (_now(), doc_id, event, actor, details))


# ─────────────────────────── الإصدار ───────────────────────────

def _matter(con: sqlite3.Connection, matter_id: int) -> sqlite3.Row:
    con.row_factory = sqlite3.Row
    row = con.execute("SELECT id, client_id, matter_number FROM matters WHERE id=?", (matter_id,)).fetchone()
    if not row:
        raise RegisterError("التكليف غير موجود")
    if not (row["matter_number"] or "").strip():
        raise RegisterError("التكليف بلا رقم؛ ولا يصدر عنه مستند")
    return row


def _addendum_ref(con: sqlite3.Connection, base_ref: str) -> str:
    rows = con.execute(
        "SELECT reference_no FROM issued_documents WHERE doc_type='addendum' AND reference_no LIKE ?",
        (base_ref + "/م%",)).fetchall()
    nums = []
    for (ref,) in rows:
        tail = ref.rsplit("/م", 1)[-1]
        if tail.isdigit():
            nums.append(int(tail))
    return f"{base_ref}/م{(max(nums) + 1) if nums else 1}"


def issue(con: sqlite3.Connection, matter_id: int, doc_type: str, inputs: Dict[str, Any],
          file_bytes: bytes, file_name: str, actor: str, ip: str = "") -> Dict[str, Any]:
    """يُنشئ صف الوثيقة أو يحدّثه إن أُعيد إنشاؤها قبل التوقيع.

    الاتفاقية والعرض: صف واحد لكل تكليف ما دام «صادراً»؛ فإعادة الإنشاء
    تحدّث الصف ولا تستهلك رقماً (77). أما الملحق فكل إصدار منه وثيقة جديدة.
    """
    if doc_type not in DOC_TYPES:
        raise RegisterError(f"نوع مستند غير معروف: {doc_type}")
    sha = hashlib.sha256(file_bytes).hexdigest()
    payload = json.dumps(inputs, ensure_ascii=False, sort_keys=True)
    m = _matter(con, matter_id)
    now = _now()

    # معاملة واحدة تحجز الكتابة من أولها، فلا يصدر رقمان لطلبين متزامنين
    con.execute("BEGIN IMMEDIATE")
    try:
        if doc_type != "addendum":
            live = con.execute(
                "SELECT id, status, regenerations FROM issued_documents "
                "WHERE matter_id=? AND doc_type=? AND status!='withdrawn'",
                (matter_id, doc_type)).fetchone()
            if live and live[1] != "issued":
                raise RegisterError(
                    "لهذا التكليف مستند من النوع نفسه تجاوز مرحلة الإصدار (موقّع أو مرفوع)؛ "
                    "وأي تعديل عليه بعد التوقيع يكون ملحقاً مستقلاً")
            if live:
                doc_id = live[0]
                con.execute(
                    "UPDATE issued_documents SET updated_at=?, inputs_json=?, file_name=?, file_sha256=?, "
                    "language=?, fee_model=?, fee_amount=?, term=?, regenerations=regenerations+1 WHERE id=?",
                    (now, payload, file_name, sha, inputs.get("language"), inputs.get("fee_model"),
                     inputs.get("fee_amount"), inputs.get("term"), doc_id))
                _event(con, doc_id, "regenerated", actor, f"sha256={sha[:16]}")
                _audit(con, "document_regenerated", doc_id, f"{m['matter_number']} · {doc_type}", ip)
                con.execute("COMMIT")
                return get(con, doc_id)
            ref = m["matter_number"]
        else:
            ref = _addendum_ref(con, m["matter_number"])

        cur = con.execute(
            "INSERT INTO issued_documents(created_at,updated_at,matter_id,client_id,doc_type,reference_no,"
            "status,language,fee_model,fee_amount,term,inputs_json,file_name,file_sha256,issued_by) "
            "VALUES(?,?,?,?,?,?, 'issued',?,?,?,?,?,?,?,?)",
            (now, now, matter_id, m["client_id"], doc_type, ref, inputs.get("language"),
             inputs.get("fee_model"), inputs.get("fee_amount"), inputs.get("term"),
             payload, file_name, sha, actor))
        doc_id = cur.lastrowid
        _event(con, doc_id, "issued", actor, f"{ref} · sha256={sha[:16]}")
        _audit(con, "document_issued", doc_id, f"{ref} · {doc_type}", ip)
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise
    return get(con, doc_id)


def _move(con: sqlite3.Connection, doc_id: int, to: str, actor: str, ip: str = "",
          extra: Optional[Dict[str, Any]] = None, details: str = "") -> Dict[str, Any]:
    doc = get(con, doc_id)
    if to not in TRANSITIONS.get(doc["status"], set()):
        raise RegisterError(f"لا ينتقل المستند من «{DOC_STATUS_AR.get(doc['status'], doc['status'])}» إلى «{DOC_STATUS_AR.get(to, to)}»")
    now = _now()
    cols = {"status": to, "updated_at": now}
    stamp = {"signed": "signed_at", "uploaded": "uploaded_at", "withdrawn": "withdrawn_at"}.get(to)
    if stamp:
        cols[stamp] = now
    cols.update(extra or {})
    sets = ", ".join(f"{k}=?" for k in cols)
    con.execute(f"UPDATE issued_documents SET {sets} WHERE id=?", (*cols.values(), doc_id))
    _event(con, doc_id, to, actor, details)
    _audit(con, f"document_{to}", doc_id, f"{doc['reference_no']} · {details}", ip)
    con.commit()
    return get(con, doc_id)


def mark_signed(con, doc_id: int, signed_file: bytes, actor: str, ip: str = "") -> Dict[str, Any]:
    """يُرفق الموقَّع على صفّه. وبصمته تُحفظ ولا تُقارن بالمسودة — فالموقَّع ممسوح غالباً."""
    sha = hashlib.sha256(signed_file).hexdigest()
    return _move(con, doc_id, "signed", actor, ip, details=f"signed_sha256={sha[:16]}")


def mark_uploaded(con, doc_id: int, sharepoint_ref: str, actor: str, ip: str = "") -> Dict[str, Any]:
    return _move(con, doc_id, "uploaded", actor, ip, {"sharepoint_ref": sharepoint_ref}, sharepoint_ref)


def record_upload_failure(con, doc_id: int, reason: str, actor: str = "system") -> None:
    """الفشل لا يغيّر الحالة؛ يُقيَّد فقط ليُعاد المحاولة ويُرى في التقرير."""
    _event(con, doc_id, "upload_failed", actor, reason[:500])
    con.commit()


def withdraw(con, doc_id: int, reason: str, actor: str, ip: str = "") -> Dict[str, Any]:
    if not reason.strip():
        raise RegisterError("سحب المستند يستلزم سبباً مكتوباً")
    return _move(con, doc_id, "withdrawn", actor, ip, {"notes": reason}, reason)


# ─────────────────────────── القراءة والتقارير ───────────────────────────

def get(con: sqlite3.Connection, doc_id: int) -> Dict[str, Any]:
    con.row_factory = sqlite3.Row
    row = con.execute("SELECT * FROM issued_documents WHERE id=?", (doc_id,)).fetchone()
    if not row:
        raise RegisterError("المستند غير موجود")
    return dict(row)


def events(con: sqlite3.Connection, doc_id: int) -> List[Dict[str, Any]]:
    con.row_factory = sqlite3.Row
    return [dict(r) for r in con.execute(
        "SELECT created_at, event, actor, details FROM issued_document_events WHERE document_id=? ORDER BY id",
        (doc_id,))]


def unsigned_report(con: sqlite3.Connection, older_than_days: int = 0) -> List[Dict[str, Any]]:
    """الصادر ولم يُوقَّع، بعمره — وهو ما يعجز عنه شيربوينت (القرار 81)."""
    con.row_factory = sqlite3.Row
    rows = con.execute("""
        SELECT d.id, d.reference_no, d.doc_type, d.created_at, d.issued_by, d.regenerations,
               c.legal_name AS client_name,
               CAST(julianday('now') - julianday(d.created_at) AS INTEGER) AS age_days
        FROM issued_documents d JOIN clients c ON c.id = d.client_id
        WHERE d.status = 'issued'
        ORDER BY d.created_at""").fetchall()
    return [dict(r) for r in rows if (r["age_days"] or 0) >= older_than_days]


def signed_not_uploaded(con: sqlite3.Connection) -> List[Dict[str, Any]]:
    con.row_factory = sqlite3.Row
    return [dict(r) for r in con.execute(
        "SELECT id, reference_no, doc_type, signed_at FROM issued_documents WHERE status='signed' ORDER BY signed_at")]


# ─────────────────────────── الربط بالمنصة ───────────────────────────

def install(ns: Dict[str, Any]) -> None:
    """يُستدعى من آخر app.py بـ globals(). يلفّ init_db على طريقة المنصة نفسها."""
    _NS.clear()
    _NS["_ns"] = ns
    # تُقرأ عند الاستدعاء: نحفظ القاموس نفسه لا الدوال
    for name in ("now_iso", "audit", "db"):
        if name in ns:
            _NS[name] = _Live(ns, name)
    base_init = ns.get("init_db")
    if base_init and not getattr(base_init, "_cr_wrapped", False):
        def init_db() -> None:
            base_init()
            with ns["db"]() as con:
                ensure_schema(con)
                con.commit()
        init_db._cr_wrapped = True  # type: ignore[attr-defined]
        ns["init_db"] = init_db


class _Live:
    """يستدعي أحدث تعريف للدالة في مساحة أسماء المنصة ساعة الاستدعاء."""
    def __init__(self, ns: Dict[str, Any], name: str):
        self.ns, self.name = ns, name

    def __call__(self, *a, **k):
        return self.ns[self.name](*a, **k)


# ═══════════════════════ سجل الموظفين وفريق التكليف ═══════════════════════
# القرارات 88 و100–107: السجل يُستورد من تصدير دليل مايكروسوفت 365، لا يُكتب بيد.
# والاستيراد يحدّث الاسمين والإدارة ولا يمسّ مسميات التوقيع (الدليل لا يحملها).
# ومن خرج من الدليل يُعلَّم غير نشط ولا يُحذف، لتبقى الفرق القديمة مقروءة.

import csv as _csv
import io as _io
import re as _re

_AR = _re.compile(r"[؀-ۿ]")
# حسابات في الدليل ليست أشخاصاً، أو لا تُدرج في الفرق بقرار المالك (104)
EXCLUDED_ACCOUNTS = {
    "accountreceivable@legaltracks.sa", "contact@legaltracks.sa",
    "meetingrooma@legaltracks.sa", "sadmin@legaltracks.sa",
    "sameh@legaltracks.sa", "adhamelkhatib@legaltracks.sa",
    # غادرا المكتب وحساباهما ما زالا مرخّصين في الدليل (القرار 110)
    "alzaydan@legaltracks.sa", "ali@legaltracks.sa",
}


def ensure_staff_schema(con: sqlite3.Connection) -> None:
    con.execute("""
        CREATE TABLE IF NOT EXISTS staff_directory(
            email TEXT PRIMARY KEY,
            name_ar TEXT, name_en TEXT,
            department TEXT, directory_title TEXT,
            is_signatory INTEGER NOT NULL DEFAULT 0,
            title_ar TEXT, title_en TEXT,
            sign_name_ar TEXT, sign_name_en TEXT,
            is_active INTEGER NOT NULL DEFAULT 1,
            imported_at TEXT, deactivated_at TEXT
        )""")
    con.execute("""
        CREATE TABLE IF NOT EXISTS matter_team(
            matter_id INTEGER NOT NULL REFERENCES matters(id),
            email TEXT NOT NULL REFERENCES staff_directory(email),
            role TEXT NOT NULL DEFAULT 'member',
            added_at TEXT NOT NULL, added_by TEXT,
            PRIMARY KEY(matter_id, email)
        )""")


def _staff_migrate(con: sqlite3.Connection) -> None:
    cols = {r[1] for r in con.execute("PRAGMA table_info(staff_directory)")}
    for c in ("sign_name_ar", "sign_name_en"):
        if c not in cols:
            con.execute(f"ALTER TABLE staff_directory ADD COLUMN {c} TEXT")


def split_display_name(display: str):
    """«English | عربي» بأي فاصل وبأي ترتيب — يُفصل بنوع الحروف لا بالفاصل."""
    parts = [p.strip() for p in _re.split(r"\s*\|\s*|\s+I\s+", display or "") if p.strip()]
    if len(parts) < 2:
        parts = (display or "").split()
    ar = " ".join(p for p in parts if _AR.search(p))
    en = " ".join(p for p in parts if not _AR.search(p))
    return _re.sub(r"\s+", " ", ar).strip(), _re.sub(r"\s+", " ", en).strip()


def import_directory(con: sqlite3.Connection, csv_text: str, actor: str = "admin") -> Dict[str, int]:
    """يقبل تصدير مايكروسوفت الخام (Display name / User principal name / Licenses …).

    «Unlicensed» = خارج المكتب. ومن كان نشطاً ثم غاب عن التصدير أو صار
    غير مرخّص يُعلَّم غير نشط.
    """
    ensure_staff_schema(con)
    rows = list(_csv.DictReader(_io.StringIO(csv_text.lstrip("﻿"))))
    if not rows or "User principal name" not in rows[0]:
        raise RegisterError("الملف ليس تصدير مستخدمين من مايكروسوفت 365 (لا عمود «User principal name»)")
    now = _now()
    seen, stats = set(), {"added": 0, "updated": 0, "deactivated": 0, "skipped": 0}
    for r in rows:
        email = (r.get("User principal name") or "").strip().lower()
        if not email or email in EXCLUDED_ACCOUNTS:
            stats["skipped"] += 1
            continue
        if (r.get("Licenses") or "").strip() == "Unlicensed":
            continue
        seen.add(email)
        ar, en = split_display_name(r.get("Display name", ""))
        dept, title = (r.get("Department") or "").strip(), (r.get("Title") or "").strip()
        if con.execute("SELECT 1 FROM staff_directory WHERE email=?", (email,)).fetchone():
            # لا يُمسّ is_signatory ولا title_ar/title_en
            con.execute("UPDATE staff_directory SET name_ar=?, name_en=?, department=?, directory_title=?, "
                        "is_active=1, deactivated_at=NULL, imported_at=? WHERE email=?",
                        (ar, en, dept, title, now, email))
            stats["updated"] += 1
        else:
            con.execute("INSERT INTO staff_directory(email,name_ar,name_en,department,directory_title,imported_at) "
                        "VALUES(?,?,?,?,?,?)", (email, ar, en, dept, title, now))
            stats["added"] += 1
    for (email,) in con.execute("SELECT email FROM staff_directory WHERE is_active=1").fetchall():
        if email not in seen:
            con.execute("UPDATE staff_directory SET is_active=0, deactivated_at=? WHERE email=?", (now, email))
            stats["deactivated"] += 1
    fn = _NS.get("audit")
    if fn:
        fn(con, "staff_directory_imported", "staff_directory", 0, json.dumps(stats, ensure_ascii=False), "")
    con.commit()
    return stats


def set_signatory(con, email: str, title_ar: str, title_en: str, on: bool = True,
                  sign_name_ar: str = "", sign_name_en: str = "") -> None:
    """مسميات التوقيع واسم التوقيع تُضبط هنا وحدها — لا من الاستيراد.
    واسم التوقيع يحمل ما لا يحمله الدليل، كلقب «د.» (القرار 103)؛ وإن تُرك أُخذ اسم الدليل."""
    if on and not (title_ar.strip() and title_en.strip()):
        raise RegisterError("الموقّع يلزمه مسمّاه بالعربية والإنجليزية")
    n = con.execute("UPDATE staff_directory SET is_signatory=?, title_ar=?, title_en=?, sign_name_ar=?, sign_name_en=? "
                    "WHERE email=?", (1 if on else 0, title_ar.strip(), title_en.strip(),
                                     sign_name_ar.strip() or None, sign_name_en.strip() or None, email.lower())).rowcount
    if not n:
        raise RegisterError(f"لا موظف بهذا البريد: {email}")
    con.commit()


def signatories(con) -> List[Dict[str, Any]]:
    """قائمتا الشريك المربوطتان: كل صف يحمل الاسمين والمسميين والبريد معاً."""
    con.row_factory = sqlite3.Row
    return [dict(r) for r in con.execute(
        "SELECT email, COALESCE(sign_name_ar, name_ar) AS name_ar, COALESCE(sign_name_en, name_en) AS name_en, "
        "title_ar, title_en FROM staff_directory WHERE is_signatory=1 AND is_active=1 ORDER BY name_ar")]


def team_candidates(con) -> List[Dict[str, Any]]:
    con.row_factory = sqlite3.Row
    return [dict(r) for r in con.execute(
        "SELECT email, name_ar, name_en, department FROM staff_directory WHERE is_active=1 ORDER BY department, name_ar")]


def team_lock_reason(con, matter_id: int) -> str:
    """الفريق يُقفل متى رُفع للتكليف مستند إلى شيربوينت (القرار 141): صلاحيات المجلد بُنيت عليه،
    فتعديله في المنصة وحدها يُفرّق السجلّين. وما بعد ذلك يمرّ بباب سامح «تحديث فريق المشروع»."""
    try:
        row = con.execute("SELECT reference_no FROM issued_documents WHERE matter_id=? AND status='uploaded' "
                          "ORDER BY id LIMIT 1", (matter_id,)).fetchone()
    except sqlite3.OperationalError:
        return ""
    return (f"رُفع للتكليف مستند إلى شيربوينت ({row[0]})، وصلاحيات مجلده مبنية على هذا الفريق؛ "
            "فلا يُعدَّل من هنا، وتعديله بعد الرفع يمرّ بباب «تحديث فريق المشروع»") if row else ""


def set_team(con, matter_id: int, partner_email: str, member_emails: List[str], actor: str) -> List[str]:
    """فريق التكليف مانع (88): لا يُحفظ فارغاً، والشريك المسؤول فيه تلقائياً (87)،
    ولا يدخله إلا موظف نشط من السجل — فلا بريد يُكتب بيد. ويُقفل بعد الرفع (141)."""
    locked = team_lock_reason(con, matter_id)
    if locked:
        raise RegisterError(locked)
    partner_email = (partner_email or "").strip().lower()
    emails = {e.strip().lower() for e in member_emails if e and e.strip()}
    if not partner_email:
        raise RegisterError("الشريك المسؤول مطلوب")
    emails.add(partner_email)
    active = {e for (e,) in con.execute("SELECT email FROM staff_directory WHERE is_active=1")}
    unknown = sorted(emails - active)
    if unknown:
        raise RegisterError("ليسوا موظفين نشطين في السجل: " + "، ".join(unknown))
    if len(emails) < 2:
        raise RegisterError("فريق التكليف يلزمه عضو واحد على الأقل غير الشريك المسؤول")
    now = _now()
    con.execute("DELETE FROM matter_team WHERE matter_id=?", (matter_id,))
    for e in sorted(emails):
        con.execute("INSERT INTO matter_team(matter_id,email,role,added_at,added_by) VALUES(?,?,?,?,?)",
                    (matter_id, e, "partner" if e == partner_email else "member", now, actor))
    fn = _NS.get("audit")
    if fn:
        fn(con, "matter_team_set", "matter", matter_id, ", ".join(sorted(emails)), "")
    con.commit()
    return sorted(emails)


def team_for_sharepoint(con, matter_id: int) -> Dict[str, List[Dict[str, str]]]:
    """بالشكل الذي ينتظره باب سامح الثالث: ProjectManager و ProjectTeam بقوائم Email."""
    rows = con.execute("SELECT email, role FROM matter_team WHERE matter_id=? ORDER BY email", (matter_id,)).fetchall()
    return {"ProjectManager": [{"Email": e} for e, r in rows if r == "partner"],
            "ProjectTeam": [{"Email": e} for e, r in rows if r != "partner"]}


# يُضاف إلى إنشاء البنية عند init_db
_base_ensure_schema = ensure_schema
def ensure_schema(con: sqlite3.Connection) -> None:  # noqa: F811
    _base_ensure_schema(con)
    ensure_staff_schema(con)
    _staff_migrate(con)


# ═══════════════════════ حقول العميل للعقد ═══════════════════════
# القرارات 25–28 و31 و86: ما ينقص سجل العميل ليُكتب منه العقد.
# والموجود أصلاً يُقرأ ولا يُكرَّر: phone و email و address (والعنوان حقل واحد
# يقبل الكامل أو المختصر) و unified_number و registration_number و id_number.

CLIENT_EXTRA_COLUMNS = {
    "name_en": "TEXT",
    "address_en": "TEXT",
    "vat_number": "TEXT",
    "signatory_name_ar": "TEXT",
    "signatory_name_en": "TEXT",
    "signatory_title_ar": "TEXT",
    "signatory_title_en": "TEXT",
    "signatory_id": "TEXT",
    "signatory_authority_ar": "TEXT",
    "salutation_gender": "TEXT",      # M أو F — للعميل الفرد وحده، لمخاطبته «الأستاذ/» أو «الأستاذة/» (القرار 162)
}

# قوائم مقترحة بخيار يدوي — والمقابل الإنجليزي يتبع العربي تلقائياً.
# تنبيه: مقترحة، تُعرض على المالك قبل الاعتماد.
SIGNATORY_TITLES = [
    ("الرئيس التنفيذي", "Chief Executive Officer"),
    ("المدير العام", "General Manager"),
    ("رئيس مجلس الإدارة", "Chairman of the Board"),
    ("العضو المنتدب", "Managing Director"),
    ("شريك مفوّض", "Authorised Partner"),
]
SIGNATORY_AUTHORITIES = [
    ("النظام الأساس", "Bylaws"),
    ("النظام الأساسي", "Articles of Association"),
    ("قرار مجلس الإدارة", "Board Resolution"),
    ("قرار الشركاء", "Partners Resolution"),
    ("تفويض", "Delegation of Authority"),
    ("وكالة", "Power of Attorney"),
]

_SHORT_ADDR = _re.compile(r"^[A-Za-z]{4}\s?\d{4}$")


def is_short_address(addr: str) -> bool:
    """العنوان المختصر أربعة أحرف وأربعة أرقام — لا عربي ولا إنجليزي (86)."""
    return bool(_SHORT_ADDR.match((addr or "").strip()))


def _client_migrate(con: sqlite3.Connection) -> None:
    cols = {r[1] for r in con.execute("PRAGMA table_info(clients)")}
    for c, t in CLIENT_EXTRA_COLUMNS.items():
        if c not in cols:
            con.execute(f"ALTER TABLE clients ADD COLUMN {c} {t}")


def title_en_for(title_ar: str) -> str:
    return dict(SIGNATORY_TITLES).get((title_ar or "").strip(), "")


def client_snapshot(con: sqlite3.Connection, client_id: int, language: str = "ar") -> Dict[str, Any]:
    """نسخة مجمَّدة من العميل تُكتب في العقد لحظة الإنشاء (57)،
    ومعها النواقص مصنّفةً على درجات الإلزام الثلاث."""
    if language not in ("ar", "ar_en"):
        raise RegisterError("لغة الاتفاقية: عربية، أو عربية وإنجليزية")
    con.row_factory = sqlite3.Row
    row = con.execute("SELECT * FROM clients WHERE id=?", (client_id,)).fetchone()
    if not row:
        raise RegisterError("العميل غير موجود")
    c = dict(row)

    def g(k: str) -> str:
        v = c.get(k)
        return v.strip() if isinstance(v, str) else ("" if v is None else str(v))

    ctype = g("client_type") or "company"
    addr = g("address")
    short = is_short_address(addr)
    snap: Dict[str, Any] = {
        "type": ctype,
        "name_ar": g("legal_name"),
        "cr": g("registration_number"),
        "national_id": g("id_number"),
        "unified_no": g("unified_number"),
        "address": addr.upper().replace(" ", "") if short else addr,
        "address_is_short": short,
        "email": g("email"),
        "phone": g("phone"),
        "vat": g("vat_number"),
        "gender": g("salutation_gender"),
        "signatory": {
            "name_ar": g("signatory_name_ar"),
            "title_ar": g("signatory_title_ar"),
            "id": g("signatory_id"),
            "authority_ar": g("signatory_authority_ar"),
        },
    }
    if language == "ar_en":
        snap["name_en"] = g("name_en")
        snap["address_en"] = snap["address"] if short else g("address_en")
        snap["signatory"]["name_en"] = g("signatory_name_en")
        snap["signatory"]["title_en"] = g("signatory_title_en") or title_en_for(g("signatory_title_ar"))

    block: List[str] = []
    warn: List[str] = []
    optional: List[str] = []
    if not snap["name_ar"]:
        block.append("اسم العميل")
    if ctype == "company" and not snap["cr"]:
        block.append("رقم السجل التجاري")
    if ctype == "individual" and not snap["national_id"]:
        block.append("رقم الهوية الوطنية")
    if ctype in ("government", "charity") and not (snap["cr"] or snap["unified_no"]):
        # لا قاعدة مقرّة للجهة الحكومية والجمعية؛ تحذير لا منع حتى يقرّر المالك
        warn.append("رقم تعريف الجهة")
    if not addr:
        warn.append("العنوان الوطني")
    if not snap["email"]:
        warn.append("بريد الإشعارات")
    # العميل الفرد يوقّع بنفسه ولا يُطلب منه رقم ضريبي في الغالب؛ فلا تُطلب منه حقول المنشأة (كشفتها خريطة أثر الخيارات 30/09)
    if ctype != "individual":
        if not snap["vat"]:
            warn.append("الرقم الضريبي")
        for k, label in (("name_ar", "اسم ممثل التوقيع"), ("title_ar", "صفة ممثل التوقيع"),
                         ("id", "هوية ممثل التوقيع"), ("authority_ar", "سند الصلاحية")):
            if not snap["signatory"][k]:
                warn.append(label)
    elif not snap["vat"]:
        optional.append("الرقم الضريبي (إن كان العميل مسجَّلاً في ضريبة القيمة المضافة)")
    if language == "ar_en":
        if not snap["name_en"]:
            warn.append("اسم العميل بالإنجليزية")
        if addr and not short and not snap["address_en"]:
            warn.append("العنوان بالإنجليزية")
        if snap["signatory"]["name_ar"] and not snap["signatory"]["name_en"]:
            warn.append("اسم ممثل التوقيع بالإنجليزية")
    if ctype == "individual" and snap["gender"] not in ("M", "F"):
        warn.append("مخاطبة العميل الفرد (الأستاذ أو الأستاذة)")
    if not snap["phone"]:
        optional.append("وسيلة التواصل")
    snap["_missing"] = {"block": block, "warn": warn, "optional": optional}
    return snap


_base_ensure_schema_2 = ensure_schema
def ensure_schema(con: sqlite3.Connection) -> None:  # noqa: F811
    _base_ensure_schema_2(con)
    _client_migrate(con)


# ═══════════════════════ صفحة المولّد على التكليف — ب1 ═══════════════════════
# المسار: /matter/agreement?id=<رقم التكليف الداخلي>
# على طريقة المنصة نفسها: التفاف على موزّع الطلبات، ثم التحقق من الدخول،
# ثم بناء الصفحة بإطارها (layout). ولا تُفتح على تكليفٍ عميلُه لم يجتز الفحص.

AGREEMENT_PATH = "/matter/agreement"
# حالات العميل في المنصة: draft · under_review · active · blocked · frozen
CLIENT_READY = "active"
# القرار 188: قرار الشريك بالموافقة في المراجعة التنظيمية يجعل الحالة «approved»، فتُقبل مع «active»؛
# وإعادة الفحص الدوري تُرجع الحالة إلى «نشط» أو «قيد المراجعة» بحسب نتيجتها، فلا يبقى قبولٌ قديم يغطي تطابقاً جديداً
CLIENT_OK = {"active", "approved"}


CLIENT_STATUS_AR = {"draft": "مسودة", "under_review": "قيد المراجعة", "active": "نشط", "approved": "موافَق عليه بقرار الشريك", "rejected": "مرفوض",
                    "suspended": "موقوف", "closed": "مغلق"}


DOC_STATUS_AR = {"issued": "صادر لم يُوقَّع", "signed": "موقَّع", "uploaded": "موقَّع ومرفوع", "withdrawn": "مسحوب"}


def regen_ar(n) -> str:
    """ن-19: عدد إعادة الإنشاء بالعدد والمعدود على قواعدهما، لا «6 مرة»."""
    n = int(n or 0)
    if n == 0:
        return "ولم يُعَد إنشاؤه"
    word = {1: "مرةً واحدة", 2: "مرتين"}.get(n) or (f"{n} مرات" if n <= 10 else f"{n} مرة")
    return "وأُعيد إنشاؤه " + word


def agreement_gate(con: sqlite3.Connection, matter_id: int) -> Dict[str, Any]:
    """يعيد التكليف وعميله، أو يرفض بسبب مكتوب. هو بوابة الصفحة كلها."""
    con.row_factory = sqlite3.Row
    m = con.execute("SELECT id, client_id, matter_number, title, service_type, status FROM matters WHERE id=?",
                    (matter_id,)).fetchone()
    if not m:
        raise RegisterError("التكليف غير موجود")
    c = con.execute("SELECT id, legal_name, status FROM clients WHERE id=?", (m["client_id"],)).fetchone()
    if not c:
        raise RegisterError("عميل التكليف غير موجود")
    if (c["status"] or "") not in CLIENT_OK:
        # ن-8 من تدقيق الاستخدام: الحالة بالعربية وما يفعله الإداري، لا رمزها المخزَّن
        st = CLIENT_STATUS_AR.get(c["status"] or "", c["status"] or "غير محددة")
        err = RegisterError(f"لا تصدر اتفاقية لهذا العميل بعد؛ لأنه لم يجتز الفحص: حالته «{st}». "
                            "أكمل مرحلتي الفحص من ملف العميل ثم عُد إلى التكليف")
        err.client_id = c["id"]
        raise err
    # C1 من مراجعة فابل 30/09: البوابة تتحقق من دليل الفحص نفسه، ولا تكتفي بالحالة المكتوبة؛
    # لأن «موافَق عليه» يكتبه قرار الشريك ولو لم يُفحص العميل قط. فلا يمرّ عميل عليه أو على أطرافه تطابق مفتوح،
    # ولا «موافَق عليه» إلا بعد مرحلتي الفحص وآخرُ كلٍّ منهما نتيجةٌ لا «القائمة غير متاحة»
    why = screening_evidence_gap(con, c["id"], c["status"] or "")
    if why:
        err = RegisterError(f"لا تصدر اتفاقية لهذا العميل بعد؛ {why}. افتح ملف العميل وأكمل الفحص أو احسم نتيجته")
        err.client_id = c["id"]
        raise err
    return {"matter": dict(m), "client": dict(c)}


OPEN_HARD = ("confirmed_match", "high_similarity", "potential_match", "frozen", "reported")


def screening_evidence_gap(con: sqlite3.Connection, client_id: int, status: str) -> str:
    """سبب المنع إن نقص دليل الفحص، أو "" إن اكتمل."""
    subj = ("((subject_type='client' AND subject_id=?) OR (subject_type='client_related_party' AND subject_id IN "
            "(SELECT id FROM related_parties WHERE parent_type='client' AND parent_id=?)))")
    try:
        ph = ",".join("?" for _ in OPEN_HARD)
        n_open = con.execute(f"SELECT COUNT(*) FROM screenings WHERE {subj} AND status IN ({ph})",
                             (client_id, client_id, *OPEN_HARD)).fetchone()[0]
        if n_open:
            return f"لأن عليه أو على أحد أطرافه {n_open} من نتائج الفحص تنتظر حسماً"
        if status == "approved":
            for scope, name in (("internal", "فحص تعارض المصالح"), ("sanctions", "فحص قوائم العقوبات")):
                r = con.execute("SELECT status FROM screenings WHERE subject_type='client' AND subject_id=? AND screening_scope=? "
                                "ORDER BY id DESC LIMIT 1", (client_id, scope)).fetchone()
                if not r:
                    return f"لأن موافقة الشريك لا تغني عن الفحص، و«{name}» لم يجرِ له"
                if (r[0] or "") == "list_unavailable":
                    return f"لأن آخر «{name}» له لم يكتمل: القائمة لم تكن متاحة"
    except sqlite3.OperationalError:
        return ""
    return ""


def agreement_page_body(con: sqlite3.Connection, matter_id: int, h: Callable[[Any], str]) -> str:
    """ب1: هيكل الصفحة — ما تعرفه المنصة عن التكليف قبل أي إدخال.
    والشاشة الكاملة (ب2) تُبنى على هذا الهيكل."""
    ctx = agreement_gate(con, matter_id)
    m, c = ctx["matter"], ctx["client"]
    snap = client_snapshot(con, c["id"], "ar_en")   # القالب الأصل ثنائي اللغة، كالشاشة
    miss = snap["_missing"]
    team = con.execute("SELECT s.name_ar, t.role FROM matter_team t JOIN staff_directory s ON s.email=t.email "
                       "WHERE t.matter_id=? ORDER BY t.role DESC, s.name_ar", (matter_id,)).fetchall()
    live = con.execute("SELECT reference_no, status, regenerations FROM issued_documents "
                       "WHERE matter_id=? AND doc_type='agreement' AND status!='withdrawn'", (matter_id,)).fetchone()

    def items(xs):
        return "".join(f"<li>{h(x)}</li>" for x in xs) or "<li>لا شيء</li>"

    team_html = "".join(f"<li>{h(r[0])}{' — الشريك المسؤول' if r[1] == 'partner' else ''}</li>" for r in team) \
        or "<li class='error'>لم يُحدَّد فريق التكليف بعد — وهو مانع</li>"
    doc_html = (f"<p>في السجل عقدٌ بالمرجع <b>{h(live[0])}</b>، حالته «{h(DOC_STATUS_AR.get(live[1], live[1]))}»، "
                f"{regen_ar(live[2])}.</p>") if live else "<p>لم يصدر عن هذا التكليف عقد بعد.</p>"
    return f"""
<div class="card"><h2>إصدار الاتفاقية</h2>
<p>التكليف <b>{h(m['matter_number'])}</b> — {h(m['title'])} · العميل <b>{h(c['legal_name'])}</b></p>
{doc_html}
</div>
<div class="card"><h3>فريق التكليف</h3><ul>{team_html}</ul><p><a class="btn secondary" href="/matter/team?id={matter_id}">تعديل الفريق</a></p></div>
<div class="card"><h3>بيانات العميل الناقصة للعقد</h3>
<p><b>تمنع الإنشاء:</b></p><ul>{items(miss['block'])}</ul>
<p><b>ناقصة لا تمنع الإصدار:</b></p><ul>{items(miss['warn'])}</ul>
<p><b>اختيارية:</b></p><ul>{items(miss['optional'])}</ul>
<p><a class="btn secondary" href="/client/contract-fields?id={c['id']}&amp;back={matter_id}">استكمال بيانات العميل للعقد</a></p>
</div>"""



# ═══════════════════════ الشاشة — ب2 ═══════════════════════
# تبني الشاشة وتقرأ ما يُرسل منها، وتحوّله إلى مدخلات المحرّك القائم بأسمائه
# (FEE_BLOCK، CLIENT_NAME_AR، …). وما لا يحمله القالب الأصل بعد لا يظهر في الشاشة:
# العربية وحدها، و«قبول المخرجات»، والجمع بين خيارات الساعة (القرار 93).

# ثوابت مأخوذة من مصادرها — لا تُسأل
CONSTANTS = {
    "GT_VERSION": "2.2",          # من غلاف الشروط العامة 2.2
    "GT_DATE": "2026-08-01",      # «نافذة من 2026-08-01» — من الغلاف نفسه
    "KYC_NOTIFY_DAYS": "15",      # اعتمده المالك مبدئياً — القرار 140
    "A_NOTICE_DAYS": "30",        # القرار 75
    "SUCC_TAIL_MONTHS": "36",     # ثلاث سنوات — القرار 53
}

TERMS = [("سنة (1) واحدة", "one (1) year"), ("سنتين (2)", "two (2) years"),
         ("ثلاث (3) سنوات", "three (3) years")]
INSTALMENTS = [("1", "قسط (1) واحد", "one (1)"), ("2", "قسطين (2)", "two (2)"),
               ("4", "أربعة (4)", "four (4)"), ("12", "اثني عشر (12)", "twelve (12)")]
SUCC_BASES = [
    ("المبلغ المُحصَّل فعلياً", "the amount actually collected"),
    ("المبلغ المحكوم به أو المتفق عليه في التسوية", "the amount awarded or agreed in settlement"),
    ("قيمة المطالبة المستبعدة أو المخفَّضة", "the value of the claim dismissed or reduced"),
    ("الوفر المحقق للعميل", "the saving achieved for the Client"),
    ("قيمة الصفقة أو المعاملة", "the value of the transaction"),
]
# نماذج الأتعاب الأربعة (74)، وخيار الساعة الواحد — الجمع ينتظر تعديل النص
FEE_MODELS = [("annual", "أتعاب سنوية ثابتة"), ("hourly", "بالساعة"),
              ("fixed", "أتعاب ثابتة"), ("phases", "أتعاب على مراحل")]
HOURLY_OPTIONS = [("none", "بلا إضافة", "B"), ("advance", "مع دفعة مقدمة", "C"),
                  ("blended", "بسعر ساعة موحّد", "D"), ("cap", "بسقف للأتعاب", "E")]
MAX_PHASES = 6


def _num(v: str) -> Optional[int]:
    s = (v or "").replace(",", "").replace("٬", "").strip()
    s = s.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
    return int(s) if s.isdigit() else None


def _money(v: str) -> str:
    """المبلغ بفواصل الآلاف، وبالهللات إن وُجدت -خانتان على الأكثر- كما تقرؤه الشاشة (tafqeet.js)؛
    فلا تقرأ الشاشةُ مبلغاً يعدّه الخادم فارغاً."""
    s = (v or "").translate(str.maketrans("٠١٢٣٤٥٦٧٨٩٫", "0123456789.")).replace("٬", "").replace(",", "")
    s = _re.sub(r"[\s‎‏،]", "", s)
    m = _re.fullmatch(r"(\d+)(?:\.(\d{1,2}))?", s)
    if not m:
        return ""
    whole, frac = int(m.group(1)), int((m.group(2) or "").ljust(2, "0") or 0)
    return f"{whole:,}" + (f".{frac:02d}" if frac else "")


def _halalas(money: str) -> int:
    """«1,500.50» ← 150050 هللة؛ لجمع مبالغ المراحل دون خطأ الكسور العشرية."""
    whole, _, frac = (money or "0").replace(",", "").partition(".")
    return int(whole or 0) * 100 + int((frac or "0").ljust(2, "0"))


def engagement_from_service(service_type: str) -> str:
    """طبيعة التكليف رُفعت من الشاشة (32)، والقالب الأصل ما زال يطلبها.
    فتُشتقّ من نوع الخدمة ولا تُثبَّت: تثبيتها «استشاري» يُخرج لعقد قضية
    «لا يشمل التمثيل» — نصّاً معاكساً بصمت."""
    return "D" if (service_type or "").strip() == "litigation" else "A"


def build_engine_data(con: sqlite3.Connection, matter_id: int, f: Dict[str, str]) -> Dict[str, Any]:
    """يحوّل ما أُرسل من الشاشة إلى مدخلات المحرّك، ويعيد معه النواقص بدرجاتها."""
    ctx = agreement_gate(con, matter_id)
    m = ctx["matter"]
    snap = client_snapshot(con, ctx["client"]["id"], "ar_en")   # القالب الأصل ثنائي اللغة
    block, warn, optional = list(snap["_missing"]["block"]), list(snap["_missing"]["warn"]), \
        list(snap["_missing"]["optional"])

    # العميل الفرد له صيغته في القالب بالقرار 158 (بالهوية الوطنية أو الإقامة)؛ فرُفع منع القرار 125.
    # والجهة الحكومية والجمعية على صيغة المنشأة حتى تُكتب صيغتها الثالثة في مراجعة الصياغة
    individual = snap["type"] == "individual"

    team_n = con.execute("SELECT COUNT(*) FROM matter_team WHERE matter_id=?", (matter_id,)).fetchone()[0]
    if team_n < 2:
        block.append("فريق التكليف")
    # ن-7 بقرار المالك 30/09: لا منع، بل تنبيه إن كان في التكليف طرف مقابل لم يُفحص؛
    # والتكليف بلا طرف مقابل -كالاستشارة- لا تنبيه فيه
    try:
        cps = con.execute("SELECT id FROM counterparties WHERE matter_id=?", (matter_id,)).fetchall()
        unscreened = [r[0] for r in cps if not con.execute(
            "SELECT 1 FROM screenings WHERE subject_type='counterparty' AND subject_id=? LIMIT 1", (r[0],)).fetchone()]
    except sqlite3.OperationalError:
        unscreened = []
    if unscreened:
        warn.append(f"الأطراف المقابلة: لم يُفحص {len(unscreened)} من {len(cps)} (من صفحة التكليف)")
    # الموافقة المشروطة: تُعرض شروطها تنبيهاً لا يمنع، كي يراها من يُصدر العقد (القرار 188)
    try:
        pd = con.execute("SELECT decision, conditions FROM partner_decisions WHERE client_id=? ORDER BY id DESC LIMIT 1",
                         (ctx["client"]["id"],)).fetchone()
    except sqlite3.OperationalError:
        pd = None
    if ctx["client"].get("status") == "approved" and pd and (pd[0] or "") == "موافقة مشروطة":
        warn.append("موافقة الشريك مشروطة: " + ((pd[1] or "").strip() or "لم تُكتب الشروط"))

    g = lambda k, d="": (f.get(k) or d).strip()
    # نص تالف الترميز (U+FFFD) لا يُكتب في عقد — وقع فعلاً من أداة إرسال على ويندوز (القرار 136)
    bad = sorted(k for k, v in f.items() if "�" in (v or ""))
    if bad:
        block.append("نص تالف الترميز في: " + "، ".join(bad) + " — أعد كتابته")
    d: Dict[str, Any] = dict(CONSTANTS)
    d.update({
        "REF": m["matter_number"],
        "ENGAGEMENT_TYPE": engagement_from_service(m["service_type"]),
        "CLIENT_NAME_AR": snap["name_ar"], "CLIENT_NAME_EN": snap.get("name_en", ""),
        "CLIENT_CR": snap["cr"] or snap["unified_no"], "CLIENT_EMAIL": snap["email"],
        "CLIENT_TYPE": "I" if individual else "C",
        "CLIENT_ID": snap["national_id"] if individual else "",
        "SALUTATION_AR": {"M": "الأستاذ", "F": "الأستاذة"}.get(snap["gender"], "") if individual else "",
        # العنوان الوطني بلغتيه (10)، ووسيلة التواصل صفٌّ يسقط إن لم تُسجَّل
        "CLIENT_ADDRESS_AR": snap["address"], "CLIENT_ADDRESS_EN": snap.get("address_en", ""),
        "CLIENT_CONTACT": snap["phone"],
        "SCOPE_AR": g("scope_ar"), "SCOPE_EN": g("scope_en"),
        "HIDE_BLOCK_LABEL": True,
    })
    if not d["SCOPE_AR"]:
        block.append("نطاق العمل")
    if not d["SCOPE_EN"]:
        warn.append("نطاق العمل بالإنجليزية")

    term = next((t for t in TERMS if t[0] == g("term", TERMS[0][0])), TERMS[0])
    d["TERM_AR"], d["TERM_EN"] = term

    # تاريخ الاتفاقية: الافتراض اليوم، ويُكتب نصاً ثابتاً لا حقل DATE يتبدّل كلما فُتح الملف (القرار 139)
    iso = lambda s: bool(_re.fullmatch(r"\d{4}-\d{2}-\d{2}", s or ""))
    ad = g("agreement_date") or _dt.date.today().isoformat()
    if not iso(ad):
        block.append("تاريخ الاتفاقية بصيغة سنة-شهر-يوم")
    d["_AGREEMENT_DATE"] = ad
    # التاريخ الهجري: يملؤه المتصفح بتقويم أم القرى ويُراجعه الإداري؛ ويُتحقَّق هنا من موافقته للميلادي
    # بفارق يومين على الأكثر، فلا يدخل العقدَ تاريخٌ هجري لا يوافق يومه (القرار 169)
    ah = g("agreement_date_h")
    if ah:
        if not hijri_plausible(ad, ah):
            block.append("التاريخ الهجري لا يوافق تاريخ الاتفاقية الميلادي — راجِعه")
        d["_AGREEMENT_DATE_H"] = ah
    # تاريخ السريان: اختياري، لا يظهر سطره إلا بتفعيله، ويجوز أن يسبق تاريخ الاتفاقية (36، 43)
    if g("effective_on") == "1":
        ed = g("effective_date")
        if not iso(ed):
            block.append("تاريخ السريان (فُعِّل ولم يُكتب بصيغة سنة-شهر-يوم)")
        d["_EFFECTIVE_DATE"] = ed
    else:
        d["_EFFECTIVE_DATE"] = None

    # الشريك الموقّع — الافتراض: الشريك المسؤول في الفريق
    sigs = {s["email"]: s for s in signatories(con)}
    pa, pn = g("partner_ar").lower(), g("partner_en").lower()
    if pa and pn and pa != pn:
        # بلا جافاسكربت قد تتغيّر قائمة دون أختها؛ فلا يُخمَّن أيّهما المقصود
        block.append("الشريك الموقّع: القائمتان العربية والإنجليزية على شريكين مختلفين")
    pe = pa or pn or g("partner").lower()
    if not pe:
        row = con.execute("SELECT email FROM matter_team WHERE matter_id=? AND role='partner'", (matter_id,)).fetchone()
        pe = row[0] if row else ""
    if pe in sigs:
        s = sigs[pe]
        d.update({"PARTNER_NAME_AR": s["name_ar"], "PARTNER_NAME_EN": s["name_en"],
                  "PARTNER_TITLE_AR": s["title_ar"], "PARTNER_TITLE_EN": s["title_en"],
                  "FIRM_EMAIL": s["email"], "_partner_email": s["email"]})
    else:
        block.append("الشريك الموقّع")

    # الأتعاب
    model = g("fee_model")
    if model == "annual":
        d["FEE_BLOCK"] = "A"
        d["A_FEE"] = _money(g("a_fee"))
        inst = next((i for i in INSTALMENTS if i[0] == g("a_instalments", "4")), INSTALMENTS[2])
        d["A_INSTALMENTS_AR"], d["A_INSTALMENTS_EN"] = inst[1], inst[2]
        if inst[0] != "4":  # ع-28: نص البند أ/2 يقول «ربع سنوية» بأي عدد؛ فلا يصدر إلا الأربعة حتى تُعتمد صيغة كل خيار
            block.append("عدد الأقساط: نص البند أ/2 يقول «أقساط ربع سنوية» أياً كان العدد، فلا يصحّ إلا مع أربعة أقساط حتى تُعتمد صيغة الخيارات الأخرى (ع-28)")
        if g("a_notice_days"):
            d["A_NOTICE_DAYS"] = str(_num(g("a_notice_days")) or CONSTANTS["A_NOTICE_DAYS"])
        if not d["A_FEE"]:
            block.append("الأتعاب السنوية (ريال)")
        amount = d["A_FEE"]
    elif model == "hourly":
        # القرار 74 و172: السقف خيار مستقل يُجمع مع الملحق أو المقدمة أو السعر الموحّد؛ و«cap» القديم = الملحق مع السقف
        ho = g("hourly_option", "none")
        cap = g("cap_on") == "1" or ho == "cap"
        opt = next((o for o in HOURLY_OPTIONS if o[0] == ho and o[0] != "cap"), HOURLY_OPTIONS[0])
        main = opt[2]
        # خ-3 من مراجعة فابل: «الملحق مع السقف» كان بلوك هـ وحده فيسقط ب/1 -أساس الاحتساب بمعدلات الملحق-،
        # فيخرج سقفٌ بلا أساس ويبقى الملحق جدولاً لا يُحيل إليه بند؛ فصار «ب+هـ»
        d["FEE_BLOCK"] = main
        if cap:
            d["FEE_EXTRA"] = "E"
        need = {"C": ("C_ADVANCE", "c_advance", "الدفعة المقدمة (ريال)"),
                "D": ("D_RATE", "d_rate", "سعر الساعة الموحّد (ريال)"),
                "E": ("E_CAP", "e_cap", "سقف الأتعاب (ريال)")}
        amount = ""
        for b in (d["FEE_BLOCK"], d.get("FEE_EXTRA", "")):
            if b in need:
                val = d[need[b][0]] = _money(g(need[b][1]))
                amount = amount or val
                if not val:
                    block.append(need[b][2])
    elif model == "fixed":
        d["FEE_BLOCK"] = "F"
        d["F_FEE"] = amount = _money(g("f_fee"))
        a, b = _num(g("f_pct_sign", "50")), _num(g("f_pct_delivery", "50"))
        d["F_PCT_SIGN"], d["F_PCT_DELIVERY"] = str(a or 0), str(b or 0)
        if not amount:
            block.append("الأتعاب الثابتة (ريال)")
        if (a or 0) + (b or 0) != 100:
            block.append(f"نسبتا الدفع مجموعهما {(a or 0) + (b or 0)}% لا 100%")
    elif model == "phases":
        d["FEE_BLOCK"] = "G"
        phases = []
        for i in range(1, MAX_PHASES + 1):
            if not g(f"ph{i}_desc_ar"):
                continue
            phases.append({"desc_ar": g(f"ph{i}_desc_ar"), "desc_en": g(f"ph{i}_desc_en"),
                           "amount": _money(g(f"ph{i}_amount")),
                           "due_ar": g(f"ph{i}_due_ar"), "due_en": g(f"ph{i}_due_en")})
        d["G_PHASES"] = phases
        if not phases:
            block.append("مراحل التكليف")
        for n, p in enumerate(phases, 1):
            if not p["amount"]:
                block.append(f"مبلغ المرحلة {n} (ريال)")
        total = sum(_halalas(p["amount"]) for p in phases if p["amount"])
        amount = (f"{total // 100:,}" + (f".{total % 100:02d}" if total % 100 else "")) if phases else ""
    else:
        block.append("نموذج الأتعاب")
        amount = ""

    # أتعاب النجاح — مخفية حتى تُطلب (42)
    if g("succ_on") == "1":
        st = g("succ_type")
        if st == "lump":
            d["SUCCESS_TYPE"] = "L"
            d["SUCC_LUMP"] = _money(g("succ_lump"))
            if not d["SUCC_LUMP"]:
                block.append("أتعاب النجاح — المبلغ المقطوع (ريال)")
        elif st == "pct":
            d["SUCCESS_TYPE"] = "P"
            d["SUCC_PCT"] = str(_num(g("succ_pct")) or "")
            basis = next((b for b in SUCC_BASES if b[0] == g("succ_basis")), SUCC_BASES[0])
            d["SUCC_BASIS_AR"], d["SUCC_BASIS_EN"] = basis
            if not d["SUCC_PCT"]:
                block.append("أتعاب النجاح — النسبة")
        else:
            block.append("نوع أتعاب النجاح")
        d["SUCC_CAP_AR"] = g("succ_cap_ar") or "[●]"
        d["SUCC_CAP_EN"] = g("succ_cap_en") or "[●]"
        # الواقعة اختيارية: إن تُركت دخل العقدَ بديلُها النظامي (7) لا «[●]»
        d["SUCC_EVENT_AR"] = g("succ_event_ar")
        d["SUCC_EVENT_EN"] = g("succ_event_en") or ("[●]" if d["SUCC_EVENT_AR"] else "")
        if st == "pct" and not g("succ_cap_ar"):
            optional.append("سقف أتعاب النجاح")      # المبلغ المقطوع لا سقف له في القالب
        # المصفوفة لا تظهر إلا مع أتعاب النجاح (82)
        if g("tasks_on") == "1":
            d["USE_TASKS"] = True
            d["TASKS_AR"], d["TASKS_EN"] = g("tasks_ar"), g("tasks_en")
            if not d["TASKS_AR"]:
                block.append("المهام والمراحل")
    else:
        d["SUCCESS_TYPE"] = "N"
        d["USE_TASKS"] = False

    # ما يلزم المحرّك ولم يُجعل مانعاً (تحذير أو اختياري) يُكتب «[●]» فلا يرفضه المحرّك وقد قالت
    # الشاشة «اكتملت»؛ ويظهر في العقد موضعاً ظاهراً يُستكمل قبل التوقيع.
    import agreement_engine as _ae
    need = list(_ae.CORE_FIELDS) + _ae.BLOCK_FIELDS.get(d.get("FEE_BLOCK", ""), []) \
        + _ae.SUCCESS_FIELDS.get(d.get("SUCCESS_TYPE", "N"), [])
    if d.get("USE_TASKS"):
        need += ["TASKS_AR", "TASKS_EN"]
    for k in need:
        if k not in ("G_PHASES_AR", "G_PHASES_EN") and not str(d.get(k, "")).strip():
            d[k] = "[●]"
    for n, p in enumerate(d.get("G_PHASES") or [], 1):
        for k, label in (("desc_en", "وصف المرحلة %d بالإنجليزية"), ("due_ar", "استحقاق المرحلة %d"),
                         ("due_en", "استحقاق المرحلة %d بالإنجليزية")):
            if not p[k]:
                p[k] = "[●]"
                optional.append(label % n)

    d["_register"] = {"language": "ar_en", "fee_model": model, "fee_amount": amount, "term": term[0]}
    d["_missing"] = {"block": block, "warn": warn, "optional": optional}
    return d


def _fields_from_post(fields: Dict[str, List[str]]) -> Dict[str, str]:
    return {k: (v[0] if isinstance(v, list) and v else (v or "")) for k, v in fields.items()}



# ═══════════════════════ الترابط في الشاشة — ب3 ═══════════════════════
# كل عنصر يحمل data-show="اسم=قيمة" لا يظهر إلا حين يكون الحقل المسمّى على تلك القيمة؛
# والقائمتان data-link تعكس كلٌّ منهما أختها. والشاشة تعمل بلا جافاسكربت أيضاً -تظهر الحقول كلها،
# والخادم يقرأ ما يخصّ الاختيار وحده، ويمنع اختلاف القائمتين-.
SCREEN_SCRIPT = """<style>[data-show][hidden]{display:none!important}</style>
<script>(function(){
var form=document.currentScript.previousElementSibling;while(form&&form.tagName!=='FORM')form=form.previousElementSibling;
if(!form)return;
function val(n){var els=form.querySelectorAll('[name="'+n+'"]');for(var i=0;i<els.length;i++){var e=els[i];
 if(e.type==='radio'||e.type==='checkbox'){if(e.checked)return e.value;}else return e.value;}return '';}
function apply(){form.querySelectorAll('[data-show]').forEach(function(el){var kv=el.getAttribute('data-show').split('=');
 var on=val(kv[0])===kv[1];var p=el.parentElement.closest('[data-show]');if(p&&p.hidden)on=false;el.hidden=!on;});
 var s=form.querySelector('select[name="partner_ar"]'),o=s&&s.options[s.selectedIndex],box=document.getElementById('partner-info');
 if(box)box.textContent=o?(o.getAttribute('data-title-ar')+' — '+o.getAttribute('data-title-en')+' · '+o.value):'';}
form.querySelectorAll('select[data-link]').forEach(function(s){s.addEventListener('change',function(){
 form.querySelectorAll('select[data-link="'+s.getAttribute('data-link')+'"]').forEach(function(t){if(t!==s)t.value=s.value;});apply();});});
form.addEventListener('change',apply);apply();})();</script>"""


# ═══════════════════════ قراءة المبلغ بالحروف تحت كل حقل مالي — ب3أ ═══════════════════════
# التفقيط أصله المولّد المستعمل (agreement/tafqeet.js، من «إنشاء اتفاقية حق أسامة.html»)، وصُحّحت فيه
# قواعد التمييز بقرار المالك (149)؛ والفحص في tools/test_tafqeet.py على صيغ صحيحة مكتوبة باليد.
from pathlib import Path as _Path
TAFQEET_JS = (_Path(__file__).resolve().parent / "agreement" / "tafqeet.js").read_text(encoding="utf-8")
AMOUNT_FIELDS = ["a_fee", "c_advance", "d_rate", "e_cap", "f_fee", "succ_lump"] + [f"ph{i}_amount" for i in range(1, 7)]
AMOUNT_SCRIPT = ("<script>(function(){" + TAFQEET_JS + ";"
    "var names=" + json.dumps(AMOUNT_FIELDS) + ";"
    "names.forEach(function(n){var i=document.querySelector('input[name=\"'+n+'\"]');if(!i)return;"
    "var o=i.nextElementSibling;if(!(o&&o.classList.contains('amount-words'))){o=document.createElement('small');o.className='amount-words';"
    "o.style.display='block';o.style.color='#555';i.insertAdjacentElement('afterend',o);}o.setAttribute('data-for',n);"
    "function u(){var v=i.value.trim(),g=groupDigits(v);"
    "o.textContent=v?(g?g+' — '+tafqeetAr(v):'المبلغ غير مقروء: أرقام فقط، وللهللات خانتان بعد الفاصلة'):'';}"
    "i.addEventListener('input',u);u();});})();</script>")

def screen_html(con: sqlite3.Connection, matter_id: int, h: Callable[[Any], str],
                f: Optional[Dict[str, str]] = None, result: Optional[Dict[str, Any]] = None) -> str:
    """الشاشة. تُرسم من ما أُرسل إن وُجد، فلا يضيع ما كتبه الإداري عند الرفض."""
    f = f or {}
    v = lambda k, d="": h(f.get(k, d))
    sel = lambda k, val, d="": " selected" if (f.get(k) or d) == val else ""
    chk = lambda k, val, d="": " checked" if (f.get(k) or d) == val else ""
    pe_default = con.execute("SELECT email FROM matter_team WHERE matter_id=? AND role='partner'",
                             (matter_id,)).fetchone()
    pe_default = pe_default[0] if pe_default else ""
    chosen = (f.get("partner_ar") or f.get("partner_en") or f.get("partner") or pe_default).lower()
    sigs = signatories(con)
    opt = lambda s, name: (f"<option value='{h(s['email'])}' data-title-ar='{h(s['title_ar'])}' "
                           f"data-title-en='{h(s['title_en'])}'{' selected' if s['email'] == chosen else ''}>{h(name)}</option>")
    partner_opts_ar = "".join(opt(s, s["name_ar"]) for s in sigs)
    partner_opts_en = "".join(opt(s, s["name_en"]) for s in sigs)
    term_opts = "".join(f"<option{sel('term', a, TERMS[0][0])}>{h(a)}</option>" for a, _ in TERMS)
    inst_opts = "".join(f"<option value='{n}'{sel('a_instalments', n, '4')}>{h(a)}</option>" for n, a, _ in INSTALMENTS)
    basis_opts = "".join(f"<option{sel('succ_basis', a)}>{h(a)}</option>" for a, _ in SUCC_BASES)
    fee_radios = "".join(
        f"<label><input type='radio' name='fee_model' value='{k}'{chk('fee_model', k)}> {h(t)}</label> "
        for k, t in FEE_MODELS)
    hourly_radios = "".join(
        f"<label><input type='radio' name='hourly_option' value='{k}'{chk('hourly_option', k, 'none')}> {h(t)}</label> "
        for k, t, _ in HOURLY_OPTIONS)
    phase_rows = "".join(
        f"<tr><td>{i}</td><td><input name='ph{i}_desc_ar' value='{v(f'ph{i}_desc_ar')}'></td>"
        f"<td><input name='ph{i}_desc_en' value='{v(f'ph{i}_desc_en')}'></td>"
        f"<td><input name='ph{i}_amount' value='{v(f'ph{i}_amount')}' inputmode='numeric'></td>"
        f"<td><input name='ph{i}_due_ar' value='{v(f'ph{i}_due_ar')}'></td>"
        f"<td><input name='ph{i}_due_en' value='{v(f'ph{i}_due_en')}'></td></tr>"
        for i in range(1, MAX_PHASES + 1))

    msg = ""
    if result and "_effect" in result:
        eff = result["_effect"]
        if eff is None:
            msg = "<div class='card'><b>أثر الاختيار:</b> اختر نموذج الأتعاب أولاً.</div>"
        else:
            ins = "".join(f"<li>{h(t)}</li>" for t in eff["in"]) or "<li>لا شيء</li>"
            outs = "".join(f"<li>{h(k)} — {'فقرة واحدة' if n == 1 else 'فقرتان' if n == 2 else f'{n} فقرات' if n <= 10 else f'{n} فقرة'}</li>"
                           for k, n in eff["out"]) or "<li>لا شيء</li>"
            # الهاتف لا يُكتب في القالب، فليس موضع «[●]» — يبقى في النواقص الاختيارية وحدها
            opt = [x for x in result["_missing"]["optional"] if x != "وسيلة التواصل"]
            fill = ("<p><b>مواضع «[●]» تُستكمل قبل التوقيع:</b></p><ul>" + "".join(f"<li>{h(x)}</li>" for x in opt)
                    + "</ul>") if opt else ""
            msg = (f"<div class='card' id='effect'><h3>أثر الاختيار</h3>"
                   f"<p>محسوب من القالب نفسه بالاختيار الحالي؛ ولم يُنشأ ملف ولم يُسجَّل شيء.</p>"
                   f"<p><b>يدخل العقد في البنود المتغيّرة:</b></p><ul>{ins}</ul>"
                   f"<p><b>ويخرج منه:</b></p><ul>{outs}</ul>{fill}</div>")
    if result:
        miss = result["_missing"]
        if miss["block"] and "_effect" not in result:
            msg = ("<div class='error'><b>لا يُنشأ العقد قبل استكمال:</b><ul>"
                   + "".join(f"<li>{h(x)}</li>" for x in miss["block"]) + "</ul></div>")
        elif result.get("_ok"):
            msg = "<div class='success'>" + h(result["_ok"]) + "</div>"
        if miss["warn"]:
            msg += ("<div class='card'><b>يُنشأ العقد، ويُسجَّل في سجله نقصُ:</b><ul>"
                    + "".join(f"<li>{h(x)}</li>" for x in miss["warn"]) + "</ul></div>")

    head = agreement_page_body(con, matter_id, h)
    return f"""{msg}{head}
<form method="post" action="{AGREEMENT_PATH}?id={matter_id}">
<div class="card"><h3>نطاق العمل</h3>
<label>نطاق العمل (عربي)</label><textarea name="scope_ar" rows="5" required>{v('scope_ar')}</textarea>
<label>نطاق العمل (إنجليزي)</label><textarea name="scope_en" rows="5" dir="ltr">{v('scope_en')}</textarea>
</div>
<div class="card"><h3>المدة والتاريخ</h3><select name="term">{term_opts}</select>
<label>تاريخ الاتفاقية</label><input type="date" name="agreement_date" value="{v('agreement_date', _dt.date.today().isoformat())}">
<details><summary>خيارات متقدمة</summary>
<label><input type="checkbox" name="effective_on" value="1"{chk('effective_on', '1')}> تاريخ سريان مختلف عن تاريخ الاتفاقية</label>
<div data-show="effective_on=1"><input type="date" name="effective_date" value="{v('effective_date')}"></div></details></div>
<div class="card"><h3>الأتعاب</h3><p>{fee_radios}</p>
<fieldset data-show="fee_model=annual"><legend>أتعاب سنوية ثابتة</legend>
<label>الأتعاب السنوية (ريال)</label><input name="a_fee" value="{v('a_fee')}" inputmode="numeric">
<label>عدد الأقساط</label><select name="a_instalments">{inst_opts}</select>
<details><summary>خيارات متقدمة</summary><label>مهلة إخطار تعديل الأتعاب (يوماً)</label>
<input name="a_notice_days" value="{v('a_notice_days', CONSTANTS['A_NOTICE_DAYS'])}" inputmode="numeric"></details>
</fieldset>
<fieldset data-show="fee_model=hourly"><legend>بالساعة</legend><p>{hourly_radios}</p>
<div data-show="hourly_option=advance"><label>الدفعة المقدمة (ريال)</label><input name="c_advance" value="{v('c_advance')}" inputmode="numeric"></div>
<div data-show="hourly_option=blended"><label>سعر الساعة الموحّد (ريال)</label><input name="d_rate" value="{v('d_rate')}" inputmode="numeric"></div>
<div data-show="hourly_option=cap"><label>سقف الأتعاب (ريال)</label><input name="e_cap" value="{v('e_cap')}" inputmode="numeric"></div>
</fieldset>
<fieldset data-show="fee_model=fixed"><legend>أتعاب ثابتة</legend>
<label>الأتعاب الثابتة (ريال)</label><input name="f_fee" value="{v('f_fee')}" inputmode="numeric">
<details><summary>خيارات متقدمة</summary>
<label>نسبة الدفعة عند التوقيع (%)</label><input name="f_pct_sign" value="{v('f_pct_sign', '50')}" inputmode="numeric">
<label>نسبة الدفعة عند التسليم (%)</label><input name="f_pct_delivery" value="{v('f_pct_delivery', '50')}" inputmode="numeric">
</details></fieldset>
<fieldset data-show="fee_model=phases"><legend>أتعاب على مراحل</legend>
<table><thead><tr><th>#</th><th>المرحلة (عربي)</th><th>(إنجليزي)</th><th>المبلغ (ريال)</th><th>الاستحقاق (عربي)</th><th>(إنجليزي)</th></tr></thead>
<tbody>{phase_rows}</tbody></table></fieldset>
</div>
<div class="card"><h3>أتعاب النجاح</h3>
<label><input type="checkbox" name="succ_on" value="1"{chk('succ_on', '1')}> في الاتفاقية أتعاب نجاح</label>
<fieldset data-show="succ_on=1"><legend>تفاصيلها</legend>
<label><input type="radio" name="succ_type" value="lump"{chk('succ_type', 'lump')}> مبلغ مقطوع</label>
<label><input type="radio" name="succ_type" value="pct"{chk('succ_type', 'pct')}> نسبة</label>
<div data-show="succ_type=lump"><label>المبلغ المقطوع (ريال)</label><input name="succ_lump" value="{v('succ_lump')}" inputmode="numeric"></div>
<div data-show="succ_type=pct">
<label>النسبة (%)</label><input name="succ_pct" value="{v('succ_pct')}" inputmode="numeric">
<label>وعاء احتساب النسبة</label><select name="succ_basis">{basis_opts}</select>
<label>سقف أتعاب النجاح (عربي) — اختياري</label><input name="succ_cap_ar" value="{v('succ_cap_ar')}">
<label>(إنجليزي)</label><input name="succ_cap_en" value="{v('succ_cap_en')}" dir="ltr"></div>
<label>واقعة الاستحقاق (عربي) — اختياري</label><textarea name="succ_event_ar" rows="2">{v('succ_event_ar')}</textarea>
<label>(إنجليزي)</label><textarea name="succ_event_en" rows="2" dir="ltr">{v('succ_event_en')}</textarea>
<label><input type="checkbox" name="tasks_on" value="1"{chk('tasks_on', '1')}> تقسيم التكليف إلى مهام ومراحل</label>
<div data-show="tasks_on=1"><label>المهام (عربي)</label><textarea name="tasks_ar" rows="3">{v('tasks_ar')}</textarea>
<label>(إنجليزي)</label><textarea name="tasks_en" rows="3" dir="ltr">{v('tasks_en')}</textarea></div>
</fieldset></div>
<div class="card"><h3>الشريك الموقّع</h3>
<label>بالعربية</label><select name="partner_ar" data-link="partner">{partner_opts_ar}</select>
<label>بالإنجليزية</label><select name="partner_en" data-link="partner" dir="ltr">{partner_opts_en}</select>
<p id="partner-info"></p></div>
<button type="submit" name="action" value="effect" formnovalidate class="secondary">أثر الاختيار</button>
<button type="submit">إنشاء الاتفاقية</button>
</form>
{SCREEN_SCRIPT}{AMOUNT_SCRIPT}"""


def agreement_file_name(ref: str) -> str:
    """اسم الملف برقم المرجع (ب6)؛ والشرطة المائلة في مرجع الملحق تُبدَّل لأنها ممنوعة في أسماء الملفات."""
    return "اتفاقية خدمات قانونية %s.docx" % (ref or "").replace("/", "-")


def issue_agreement(con: sqlite3.Connection, matter_id: int, data: Dict[str, Any], form: Dict[str, str],
                    actor: str, ip: str, engine) -> tuple:
    """يُنشئ الملف ثم يسجّله؛ فلا يخرج ملف لم يُسجَّل.

    الإنشاء لا أثر له خارج الذاكرة، فإن فشل لم يُمسّ السجل؛ وإن رفض السجل (مستند موقَّع قبله)
    لم يخرج الملف.
    """
    blob, report = engine.generate_docx(data)
    name = agreement_file_name(data["REF"])
    inputs = dict(data["_register"])
    inputs.update({"form": form, "engine": {k: v for k, v in data.items() if not k.startswith("_")},
                   "missing": data["_missing"], "engine_report": report})
    issue(con, matter_id, "agreement", inputs, blob, name, actor, ip)
    return blob, name


def _install_routes(ns: Dict[str, Any]) -> None:
    handler = ns.get("AppHandler")
    if not handler or getattr(handler, "_cr_routes", False):
        return
    base_get = handler.do_GET

    def do_get(self) -> None:
        parsed = ns["urlparse"](self.path)
        if parsed.path != AGREEMENT_PATH:
            return base_get(self)
        user = ns["_v1512_ctx"](self)
        if not user:
            return ns["_auth_send_redirect"](self, "/login")
        if user.get("must_change_password"):
            return ns["_auth_send_redirect"](self, "/account")
        q = ns["parse_qs"](parsed.query)
        try:
            mid = int((q.get("id", ["0"])[0] or 0))
        except (TypeError, ValueError):
            mid = 0
        layout, h = ns["layout"], ns["h"]
        try:
            with ns["db"]() as con:
                ensure_schema(con)
                body = screen_html(con, mid, h)
            return self._send(layout("إصدار الاتفاقية", body, "/matters"))
        except RegisterError as exc:
            cid = getattr(exc, "client_id", None)
            back = ("<p>" + (f"<a class='btn' href='/client?id={cid}'>فتح ملف العميل</a> " if cid else "")
                    + f"<a class='btn secondary' href='/matter?id={mid}'>العودة إلى التكليف</a></p>")
            return self._send(layout("إصدار الاتفاقية", f"<div class='error'>{h(exc)}</div>{back}", "/matters"), 409)

    handler.do_GET = do_get

    base_post = handler.do_POST

    def do_post(self) -> None:
        parsed = ns["urlparse"](self.path)
        if parsed.path != AGREEMENT_PATH:
            return base_post(self)
        user = ns["_v1512_ctx"](self)
        if not user:
            return ns["_auth_send_redirect"](self, "/login")
        if user.get("must_change_password"):
            return ns["_auth_send_redirect"](self, "/account")
        q = ns["parse_qs"](parsed.query)
        try:
            mid = int((q.get("id", ["0"])[0] or 0))
        except (TypeError, ValueError):
            mid = 0
        layout, h = ns["layout"], ns["h"]
        fields, _files, ip = ns["_parse_request_fields"](self)
        form = _fields_from_post(fields)
        try:
            with ns["db"]() as con:
                ensure_schema(con)
                data = build_engine_data(con, mid, form)
                if form.get("action") == "effect":
                    # أثر الاختيار (ب7): عرضٌ فقط — لا ملف ولا صفّ في السجل
                    import agreement_engine as ae
                    data["_effect"] = ae.choice_effect(data) if data.get("FEE_BLOCK") else None
                    body = screen_html(con, mid, h, form, data)
                    return self._send(layout("إصدار الاتفاقية", body, "/matters"))
                if not data["_missing"]["block"]:
                    import agreement_engine as ae
                    try:
                        blob, name = issue_agreement(con, mid, data, form,
                                                     user.get("user_name") or str(user.get("id")), ip or "", ae)
                        return ns["_send_binary_with_disposition"](
                            self, blob, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", name)
                    except ae.EngineError as exc:
                        data["_missing"]["block"].append(f"تعذّر إنشاء الملف: {exc}")
                body = screen_html(con, mid, h, form, data)
            return self._send(layout("إصدار الاتفاقية", body, "/matters"))
        except RegisterError as exc:
            cid = getattr(exc, "client_id", None)
            back = ("<p>" + (f"<a class='btn' href='/client?id={cid}'>فتح ملف العميل</a> " if cid else "")
                    + f"<a class='btn secondary' href='/matter?id={mid}'>العودة إلى التكليف</a></p>")
            return self._send(layout("إصدار الاتفاقية", f"<div class='error'>{h(exc)}</div>{back}", "/matters"), 409)

    handler.do_POST = do_post
    handler._cr_routes = True


_base_install = install
def install(ns: Dict[str, Any]) -> None:  # noqa: F811
    _base_install(ns)
    _install_routes(ns)


# ═══════════════════════ سند التأسيس بحسب شكل الشركة ═══════════════════════
# نظام الشركات (م/132 في 1/12/1443هـ)، المادة السابعة، الفقرة (1) — منقول من موقع هيئة الخبراء:
# «يكون لكل شركة تؤسس وفقاً لأحكام النظام عقد تأسيس، عدا شركة المساهمة وشركة المساهمة
#  المبسطة والشركة ذات المسؤولية المحدودة المملوكة لشخص واحد، فيكون لكل منها نظام أساس.»
# والأشكال الخمسة في المادة الرابعة.

FOUNDING_CONTRACT = ("عقد التأسيس", "Articles of Association")
FOUNDING_BYLAWS = ("النظام الأساس", "Bylaws")

SIGNATORY_AUTHORITIES = [  # noqa: F811 — يحلّ محلّ القائمة السابقة
    FOUNDING_CONTRACT,
    FOUNDING_BYLAWS,
    ("قرار مجلس الإدارة", "Board Resolution"),
    ("قرار الشركاء", "Partners Resolution"),
    ("تفويض", "Delegation of Authority"),
    ("وكالة", "Power of Attorney"),
]


def founding_document(legal_form: str, owners_count: Optional[int] = None) -> Optional[tuple]:
    """يقترح سند التأسيس من شكل الشركة، أو يعيد None حين لا يُعرف يقيناً.

    لا يخمّن: ذات المسؤولية المحدودة بلا عدد ملّاك معروف ← None، فيختار الإداري.
    """
    f = (legal_form or "").replace("ـ", "")
    if not f.strip():
        return None
    if "مساهمة" in f:          # المساهمة والمساهمة المبسطة
        return FOUNDING_BYLAWS
    if "تضامن" in f or "توصية" in f:
        return FOUNDING_CONTRACT
    if "مسؤولية محدودة" in f or "ذات مسئولية" in f:
        if "شخص واحد" in f:
            return FOUNDING_BYLAWS
        if owners_count is None:
            return None
        return FOUNDING_BYLAWS if owners_count == 1 else FOUNDING_CONTRACT
    return None


def authority_en_for(authority_ar: str) -> str:
    return dict(SIGNATORY_AUTHORITIES).get((authority_ar or "").strip(), "")



# ═══════════════════════ صفحتا الفريق وبيانات العميل للعقد — ب3 ═══════════════════════
# بُنيت طبقتاهما في أ2 وأ3 بلا صفحة، فكان الفريق لا يُضبط إلا بالشيفرة؛ وهذا يسدّ ذلك.
# والوصول إليهما من صفحة إصدار الاتفاقية.

TEAM_PATH = "/matter/team"
CLIENT_FIELDS_PATH = "/client/contract-fields"


def suggested_authority(con: sqlite3.Connection, client_id: int):
    """سند الصلاحية المقترح من الشكل النظامي المجلوب من واثق (القرار 118)، أو None حين لا يُعرف يقيناً."""
    try:
        row = con.execute("SELECT legal_form FROM client_registry WHERE client_id=?", (client_id,)).fetchone()
    except sqlite3.OperationalError:
        return None, ""
    form = (row[0] or "") if row else ""
    return founding_document(form), form


def _partner_from(fields_get, block: List[str]) -> str:
    pa, pn = fields_get("partner_ar").lower(), fields_get("partner_en").lower()
    if pa and pn and pa != pn:
        block.append("الشريك: القائمتان العربية والإنجليزية على شريكين مختلفين")
    return pa or pn


def team_page(con: sqlite3.Connection, matter_id: int, h: Callable[[Any], str],
              error: str = "", posted: Optional[Dict[str, Any]] = None) -> str:
    con.row_factory = sqlite3.Row
    m = con.execute("SELECT id, matter_number, title FROM matters WHERE id=?", (matter_id,)).fetchone()
    if not m:
        raise RegisterError("التكليف غير موجود")
    cur = {r[0]: r[1] for r in con.execute("SELECT email, role FROM matter_team WHERE matter_id=?", (matter_id,))}
    partner = (posted or {}).get("partner") or next((e for e, r in cur.items() if r == "partner"), "")
    members = set((posted or {}).get("members") or [e for e, r in cur.items() if r != "partner"])
    sigs = signatories(con)
    opt = lambda s, name: (f"<option value='{h(s['email'])}' data-title-ar='{h(s['title_ar'])}' data-title-en='{h(s['title_en'])}'"
                           f"{' selected' if s['email'] == partner else ''}>{h(name)}</option>")
    blank = "<option value=''>— اختر —</option>"
    groups: Dict[str, List[str]] = {}
    for c in team_candidates(con):
        groups.setdefault(dept_ar(c["department"]), []).append(
            f"<label><input type='checkbox' name='member' value='{h(c['email'])}'"
            f"{' checked' if c['email'] in members else ''}> {h(c['name_ar'])}</label>")
    boxes = "".join(f"<fieldset><legend>{h(dep)}</legend>{''.join(xs)}</fieldset>" for dep, xs in groups.items())
    err = f"<div class='error'>{h(error)}</div>" if error else ""
    locked = team_lock_reason(con, matter_id)
    if locked:
        err += f"<div class='card'><b>الفريق مقفل:</b> {h(locked)}.</div>"
    opts_ar = "".join(opt(s, s["name_ar"]) for s in sigs)
    opts_en = "".join(opt(s, s["name_en"]) for s in sigs)
    return f"""{err}<div class="card"><h2>فريق التكليف</h2>
<p>التكليف <b>{h(m['matter_number'])}</b> — {h(m['title'])}</p>
<p>الفريق هو الذي يحدّد من يطّلع على ملف العميل في شيربوينت؛ والشريك المسؤول فيه تلقائياً، ويلزمه عضو آخر على الأقل.</p></div>
<form method="post" action="{TEAM_PATH}?id={matter_id}"><fieldset{' disabled' if locked else ''} style="border:0;padding:0;margin:0">
<div class="card"><h3>الشريك المسؤول</h3>
<label>بالعربية</label><select name="partner_ar" data-link="partner">{blank}{opts_ar}</select>
<label>بالإنجليزية</label><select name="partner_en" data-link="partner" dir="ltr">{blank}{opts_en}</select>
<p id="partner-info"></p></div>
<div class="card"><h3>الأعضاء</h3>{boxes}</div>
<button type="submit">حفظ الفريق</button></fieldset>
<a class="btn secondary" href="{AGREEMENT_PATH}?id={matter_id}">العودة إلى إصدار الاتفاقية</a>
</form>
{SCREEN_SCRIPT}"""


def save_team(con: sqlite3.Connection, matter_id: int, fields: Dict[str, List[str]], actor: str) -> List[str]:
    g = lambda k: ((fields.get(k) or [""])[0] or "").strip()
    block: List[str] = []
    partner = _partner_from(g, block)
    if block:
        raise RegisterError(block[0])
    if not con.execute("SELECT 1 FROM matters WHERE id=?", (matter_id,)).fetchone():
        raise RegisterError("التكليف غير موجود")
    if partner not in {s["email"] for s in signatories(con)}:
        raise RegisterError("الشريك المسؤول يُختار من قائمة الشركاء الموقّعين")
    return set_team(con, matter_id, partner, [e for e in (fields.get("member") or []) if e.lower() != partner], actor)


CLIENT_FIELD_LABELS = [
    # البريد: بريد الإشعارات في العقد، وهو CustomerEmail في «تسجيل عميل»؛ ولم يكن له مدخل في المنصة
    # لعميلٍ يُنشأ يدوياً -كشفه اختبار الدورة الكاملة هـ3- (القرار 156)
    ("email", "بريد العميل للإشعارات", "ltr"),
    ("name_en", "اسم العميل بالإنجليزية", "ltr"),
    ("address_en", "العنوان بالإنجليزية (يُترك إن كان العنوان مختصراً)", "ltr"),
    ("vat_number", "الرقم الضريبي", "ltr"),
    ("signatory_name_ar", "اسم ممثل التوقيع (عربي)", "rtl"),
    ("signatory_name_en", "اسم ممثل التوقيع (إنجليزي)", "ltr"),
    ("signatory_id", "هوية ممثل التوقيع", "ltr"),
]
MANUAL = "__manual__"


def client_fields_page(con: sqlite3.Connection, client_id: int, h: Callable[[Any], str],
                       back: int = 0, error: str = "", posted: Optional[Dict[str, str]] = None) -> str:
    con.row_factory = sqlite3.Row
    c = con.execute("SELECT * FROM clients WHERE id=?", (client_id,)).fetchone()
    if not c:
        raise RegisterError("العميل غير موجود")
    c = dict(c)
    val = lambda k: (posted or {}).get(k, c.get(k) or "")
    rows = "".join(f"<label>{h(lbl)}</label><input name='{k}' value='{h(val(k))}' dir='{d}'>"
                   for k, lbl, d in CLIENT_FIELD_LABELS)
    t_ar = (posted or {}).get("title_manual_ar") if (posted or {}).get("signatory_title_ar") == MANUAL \
        else val("signatory_title_ar")
    known_t = t_ar in dict(SIGNATORY_TITLES)
    manual_sel = bool(t_ar) and not known_t
    t_opts = "<option value=''>— اختر —</option>" + "".join(
        f"<option value='{h(a)}'{' selected' if a == t_ar else ''}>{h(a)} — {h(e)}</option>" for a, e in SIGNATORY_TITLES) \
        + f"<option value='{MANUAL}'{' selected' if manual_sel else ''}>صفة أخرى تُكتب يدوياً</option>"
    t_en_manual = (posted or {}).get("title_manual_en", c.get("signatory_title_en") or "") if manual_sel else ""
    sug, form = suggested_authority(con, client_id)
    a_ar = val("signatory_authority_ar") or (sug[0] if sug else "")
    a_opts = "<option value=''>— اختر —</option>" + "".join(
        f"<option value='{h(a)}'{' selected' if a == a_ar else ''}>{h(a)} — {h(e)}</option>" for a, e in SIGNATORY_AUTHORITIES)
    if sug:
        hint = (f"مقترح من الشكل النظامي في واثق «{h(form)}»: <b>{h(sug[0])}</b> "
                "(المادة السابعة، الفقرة 1 من نظام الشركات). ويُغيَّر إن كان التوقيع بقرار أو تفويض أو وكالة.")
    elif form:
        hint = f"الشكل النظامي في واثق «{h(form)}» لا يحدّد سند التأسيس وحده (عدد الملّاك غير معروف)؛ فيُختار يدوياً."
    else:
        hint = "لم يُجلب الشكل النظامي من واثق لهذا العميل؛ فيُختار السند يدوياً."
    addr = c.get("address") or ""
    if not addr:
        addr_note = "غير مسجَّل — يُسجَّل من صفحة العميل"
    elif is_short_address(addr):
        addr_note = "مختصر، فيُكتب كما هو في اللغتين"
    else:
        addr_note = ""
    err = f"<div class='error'>{h(error)}</div>" if error else ""
    back_link = f"<a class='btn secondary' href='{AGREEMENT_PATH}?id={back}'>العودة إلى إصدار الاتفاقية</a>" if back else ""
    gv = val("salutation_gender")
    gender_card = ("<div class=\"card\"><h3>مخاطبة العميل الفرد</h3><select name=\"salutation_gender\">"
                   + "".join(f"<option value='{k}'{' selected' if gv == k else ''}>{h(t)}</option>"
                             for k, t in (("", "— اختر —"), ("M", "الأستاذ"), ("F", "الأستاذة")))
                   + "</select><p>تُكتب في سطر المخاطبة بالعقد: «الأستاذ/» أو «الأستاذة/».</p></div>"
                   ) if c.get("client_type") == "individual" else ""
    note = f" ({h(addr_note)})" if addr_note else ""
    return f"""{err}<div class="card"><h2>بيانات العميل للعقد</h2>
<p>العميل <b>{h(c.get('legal_name'))}</b> · العنوان الوطني: {h(addr) or '—'}{note}</p></div>
<form method="post" action="{CLIENT_FIELDS_PATH}?id={client_id}&amp;back={back}">
<div class="card">{rows}</div>
{gender_card}<div class="card"><h3>صفة ممثل التوقيع</h3><select name="signatory_title_ar">{t_opts}</select>
<div data-show="signatory_title_ar={MANUAL}"><label>الصفة (عربي)</label><input name="title_manual_ar" value="{h(t_ar if manual_sel else '')}">
<label>(إنجليزي)</label><input name="title_manual_en" dir="ltr" value="{h(t_en_manual)}"></div>
<p>والإنجليزية تتبع العربية في الصفات المدرجة.</p></div>
<div class="card"><h3>سند الصلاحية</h3><select name="signatory_authority_ar">{a_opts}</select><p>{hint}</p></div>
<button type="submit">حفظ</button> {back_link}
</form>
{SCREEN_SCRIPT}"""


def save_client_fields(con: sqlite3.Connection, client_id: int, fields: Dict[str, List[str]], actor: str) -> None:
    g = lambda k: ((fields.get(k) or [""])[0] or "").strip()
    if "�" in "".join(v for vs in fields.values() for v in vs):
        raise RegisterError("نص تالف الترميز — أعد كتابته")
    if not con.execute("SELECT 1 FROM clients WHERE id=?", (client_id,)).fetchone():
        raise RegisterError("العميل غير موجود")
    # لا يتغيّر إلا حقلٌ وصل في الطلب: فالحقل الغائب يبقى كما هو، والمرسَل فارغاً يُفرَّغ؛
    # كان الغائب يُفرَّغ فمحا بريداً أُدخل من معالج الاستيراد (كشفه هـ3 — القرار 156)
    upd = {k: g(k) for k, _, _ in CLIENT_FIELD_LABELS if k in fields}
    if "vat_number" in upd:
        vat = upd["vat_number"].translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")).replace(" ", "")
        if vat and not (vat.isdigit() and len(vat) == 15):
            raise RegisterError("الرقم الضريبي خمسة عشر رقماً")
        upd["vat_number"] = vat
    if "email" in upd:
        upd["email"] = upd["email"].lower()
        if upd["email"] and not _re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", upd["email"]):
            raise RegisterError("بريد العميل غير صالح")
    if "salutation_gender" in fields:
        sg = g("salutation_gender").upper()
        if sg not in ("", "M", "F"):
            raise RegisterError("مخاطبة العميل: الأستاذ أو الأستاذة")
        upd["salutation_gender"] = sg
    if "signatory_title_ar" in fields:
        t = g("signatory_title_ar")
        if t == MANUAL:
            upd["signatory_title_ar"], upd["signatory_title_en"] = g("title_manual_ar"), g("title_manual_en")
            if not upd["signatory_title_ar"]:
                raise RegisterError("اخترتَ صفة يدوية ولم تكتبها")
        else:
            upd["signatory_title_ar"], upd["signatory_title_en"] = t, title_en_for(t)
    if "signatory_authority_ar" in fields:
        a = g("signatory_authority_ar")
        if a and a not in dict(SIGNATORY_AUTHORITIES):
            raise RegisterError("سند الصلاحية يُختار من القائمة")
        upd["signatory_authority_ar"] = a
    if not upd:
        return
    con.execute("UPDATE clients SET " + ", ".join(f"{k}=?" for k in upd) + ", updated_at=? WHERE id=?",
                (*[v or None for v in upd.values()], _now(), client_id))
    fn = _NS.get("audit")
    if fn:
        fn(con, "client_contract_fields_set", "client", client_id, ", ".join(k for k, v in upd.items() if v), "")
    con.commit()


def _install_b3_routes(ns: Dict[str, Any]) -> None:
    handler = ns.get("AppHandler")
    if not handler or getattr(handler, "_cr_b3", False):
        return
    base_get, base_post = handler.do_GET, handler.do_POST

    def ctx(self):
        parsed = ns["urlparse"](self.path)
        if parsed.path not in (TEAM_PATH, CLIENT_FIELDS_PATH):
            return None, None, None
        user = ns["_v1512_ctx"](self)
        q = ns["parse_qs"](parsed.query)
        num = lambda k: int(q.get(k, ["0"])[0]) if (q.get(k, ["0"])[0] or "").isdigit() else 0
        return parsed.path, user, (num("id"), num("back"))

    def guard(self, user):
        if not user:
            ns["_auth_send_redirect"](self, "/login")
            return False
        if user.get("must_change_password"):
            ns["_auth_send_redirect"](self, "/account")
            return False
        return True

    def render(self, path, oid, back, error="", posted=None, status=200):
        layout, h = ns["layout"], ns["h"]
        try:
            with ns["db"]() as con:
                ensure_schema(con)
                if path == TEAM_PATH:
                    body, title, active = team_page(con, oid, h, error, posted), "فريق التكليف", "/matters"
                else:
                    body, title, active = client_fields_page(con, oid, h, back, error, posted), "بيانات العميل للعقد", "/clients"
            return self._send(layout(title, body, active), status)
        except RegisterError as exc:
            return self._send(layout("خطأ", f"<div class='error'>{h(exc)}</div>", "/matters"), 404)

    def do_get(self):
        path, user, ids = ctx(self)
        if not path:
            return base_get(self)
        if guard(self, user):
            return render(self, path, *ids)

    def do_post(self):
        path, user, ids = ctx(self)
        if not path:
            return base_post(self)
        if not guard(self, user):
            return
        oid, back = ids
        fields, _files, _ip = ns["_parse_request_fields"](self)
        actor = user.get("user_name") or str(user.get("id"))
        try:
            with ns["db"]() as con:
                ensure_schema(con)
                if path == TEAM_PATH:
                    save_team(con, oid, fields, actor)
                    return ns["_auth_send_redirect"](self, f"{AGREEMENT_PATH}?id={oid}")
                save_client_fields(con, oid, fields, actor)
            return ns["_auth_send_redirect"](self, f"{AGREEMENT_PATH}?id={back}" if back else f"/client?id={oid}")
        except RegisterError as exc:
            g = lambda k: ((fields.get(k) or [""])[0] or "")
            posted = ({"partner": (g("partner_ar") or g("partner_en")).lower(), "members": fields.get("member") or []}
                      if path == TEAM_PATH else {k: g(k) for k in fields})
            return render(self, path, oid, back, str(exc), posted, 409)

    handler.do_GET, handler.do_POST = do_get, do_post
    handler._cr_b3 = True


_base_install_b3 = install
def install(ns: Dict[str, Any]) -> None:  # noqa: F811
    _base_install_b3(ns)
    _install_b3_routes(ns)



# ═══════════════════════ صفحة استيراد دليل الموظفين ═══════════════════════
# كان الاستيراد من الشيفرة وحدها (ملاحظة التسليم لمحمد). للمدير وحده، ولا يُحفظ الملف المرفوع:
# تصدير مايكروسوفت يحمل أرقام الهواتف، والاستيراد يأخذ منه الأعمدة اللازمة وحدها.

STAFF_PATH = "/staff/import"
MAX_STAFF_CSV = 2 * 1024 * 1024


def staff_page(con: sqlite3.Connection, h: Callable[[Any], str], result: Optional[Dict[str, int]] = None,
               error: str = "") -> str:
    ensure_staff_schema(con)
    active = con.execute("SELECT COUNT(*) FROM staff_directory WHERE is_active=1").fetchone()[0]
    inactive = con.execute("SELECT COUNT(*) FROM staff_directory WHERE is_active=0").fetchone()[0]
    sigs = "".join(f"<li>{h(s['name_ar'])} — {h(s['title_ar'])} · <span dir='ltr'>{h(s['email'])}</span></li>"
                   for s in signatories(con)) or "<li>لا أحد بعد</li>"
    msg = f"<div class='error'>{h(error)}</div>" if error else ""
    if result:
        msg += ("<div class='success'>تمّ الاستيراد: أُضيف {added}، وحُدّث {updated}، وعُلِّم غير نشط {deactivated}، "
                "وتُرك {skipped} من الحسابات المستبعدة أو غير الصالحة.</div>").format(**result)
    return f"""{msg}<div class="card"><h2>دليل الموظفين</h2>
<p>النشطون الآن: <b>{active}</b> · غير النشطين: <b>{inactive}</b></p>
<p>المصدر: مركز إدارة مايكروسوفت 365 ← Users ← Active users ← Export users، ويُرفع الملف كما صُدِّر.
ومن لا ترخيص له في مايكروسوفت («Unlicensed») أو غاب عن التصدير يُعلَّم غير نشط ولا يُحذف؛ والحسابات غير الشخصية والمغادرون المسمَّون
مستبعدون تلقائياً. ولا يُحفظ الملف المرفوع، ولا يُمسّ مسمّى التوقيع واسمه.</p></div>
<form method="post" action="{STAFF_PATH}" enctype="multipart/form-data">
<div class="card"><label>ملف التصدير (CSV)</label><input type="file" name="csv" accept=".csv,text/csv" required></div>
<button type="submit">استيراد</button></form>
<div class="card"><h3>الموقّعون</h3><ul>{sigs}</ul>
<p>يُضبط الموقّعون ومسمّياتهم عند المدير التقني، لا من هذه الصفحة.</p></div>"""


def _install_staff_route(ns: Dict[str, Any]) -> None:
    handler = ns.get("AppHandler")
    if not handler or getattr(handler, "_cr_staff", False):
        return
    base_get, base_post = handler.do_GET, handler.do_POST

    def allowed(self):
        if ns["urlparse"](self.path).path != STAFF_PATH:
            return None
        user = ns["_v1512_ctx"](self)
        if not user:
            ns["_auth_send_redirect"](self, "/login")
            return False
        if user.get("must_change_password"):
            ns["_auth_send_redirect"](self, "/account")
            return False
        if (user.get("role") or "") != "admin":
            self._send(ns["layout"]("دليل الموظفين", "<div class='error'>هذه الصفحة للمدير وحده.</div>", "/production"), 403)
            return False
        return user

    def do_get(self):
        user = allowed(self)
        if user is None:
            return base_get(self)
        if user:
            with ns["db"]() as con:
                return self._send(ns["layout"]("دليل الموظفين", staff_page(con, ns["h"]), "/production"))

    def do_post(self):
        user = allowed(self)
        if user is None:
            return base_post(self)
        if not user:
            return
        _fields, files, _ip = ns["_parse_request_fields"](self)
        name, data = files.get("csv", ("", b""))
        with ns["db"]() as con:
            try:
                if not data:
                    raise RegisterError("لم يُرفع ملف")
                if len(data) > MAX_STAFF_CSV:
                    raise RegisterError("الملف أكبر مما يُنتظر من تصدير الموظفين")
                try:
                    text = data.decode("utf-8-sig")
                except UnicodeDecodeError:
                    raise RegisterError("الملف ليس بترميز UTF-8 كما يُصدِّره مايكروسوفت 365")
                stats = import_directory(con, text, user.get("user_name") or "admin")
                return self._send(ns["layout"]("دليل الموظفين", staff_page(con, ns["h"], stats), "/production"))
            except RegisterError as exc:
                return self._send(ns["layout"]("دليل الموظفين", staff_page(con, ns["h"], error=str(exc)), "/production"), 409)

    handler.do_GET, handler.do_POST = do_get, do_post
    handler._cr_staff = True


_base_install_staff = install
def install(ns: Dict[str, Any]) -> None:  # noqa: F811
    _base_install_staff(ns)
    _install_staff_route(ns)



# ═══════════════════════ التصميم البصري لصفحات الاتفاقية — د2 ═══════════════════════
# البنية والأصناف من تسليم جلسة التصميم (`legaltracks-design/ship/agreement-screens/`: lt-agr.css
# والمعاينة)؛ والخيارات والقيم والنصوص التوضيحية والسلوك من شيفرتنا وقراراتنا (القرار 167).
# وهذه الدوال تحلّ محلّ screen_html وteam_page وclient_fields_page السابقة (الأخير يغلب).

import hashlib as _hashlib

_UI_DIR = _Path(__file__).resolve().parent / "agreement" / "ui"
_UI_CSS = ((_UI_DIR / "fonts.css").read_text(encoding="utf-8") + "\n"
           + (_UI_DIR / "lt-agr.css").read_text(encoding="utf-8") + "\n"
           + (_UI_DIR / "platform-bridge.css").read_text(encoding="utf-8")).encode("utf-8")
UI_ASSET_PATH = "/lt-agr/assets.css"
UI_LINK = '<link rel="stylesheet" href="%s?v=%s">' % (UI_ASSET_PATH, _hashlib.sha256(_UI_CSS).hexdigest()[:10])

UI_KEY = ('<div class="lt-agr-key"><b>معنى الألوان:</b>'
          '<span><i class="lt-agr-k-done"></i>مكتمل</span><span><i class="lt-agr-k-todo"></i>ينتظر التعبئة</span>'
          '<span><i class="lt-agr-k-err"></i>يحتاج تصحيحاً</span><span><i class="lt-agr-k-cond"></i>ظهر باختيارك</span></div>')

FEE_PICKS = [("annual", "أتعاب سنوية ثابتة", "مبلغ سنوي يُسدَّد على أقساط متساوية."),
             ("hourly", "بالساعة", "بمعدلات الملحق (ب)، أو بدفعة مقدمة، أو بسعر موحّد، أو بسقف."),
             ("fixed", "أتعاب ثابتة", "مبلغ واحد يُقسَّم بين التوقيع والتسليم."),
             ("phases", "على مراحل", "حتى ست مراحل، لكلٍّ وصفها ومبلغها واستحقاقها.")]
HOURLY_PICKS = [("none", "بمعدلات الملحق (ب)", "بلا إضافة، والملحق مرفق بالعقد."),
                ("advance", "دفعة مقدمة", "تُخصم منها الأتعاب الشهرية."),
                ("blended", "سعر موحّد", "سعر واحد للفريق كله، بلا ملحق.")]
ORD_AR = ["", "الأولى", "الثانية", "الثالثة", "الرابعة", "الخامسة", "السادسة"]


def _ui_tells(result, h):
    """رسائل الخادم الثلاث بطقم العلامات: مانع برتقالي، وتحذير أصفر، ونجاح تيل."""
    if not result:
        return ""
    out, miss = "", result["_missing"]
    if miss["block"] and "_effect" not in result:
        out += ('<div class="lt-agr-tell lt-agr-stop"><div><b>لا يُنشأ العقد قبل استكمال:</b><ul>'
                + "".join(f"<li>{h(x)}</li>" for x in miss["block"]) + "</ul></div></div>")
    elif result.get("_ok"):
        out += f'<div class="lt-agr-tell lt-agr-ok"><div>{h(result["_ok"])}</div></div>'
    if miss["warn"]:
        out += ('<div class="lt-agr-tell lt-agr-warn"><div><b>يُنشأ العقد، ويُسجَّل في سجله نقصُ:</b><ul>'
                + "".join(f"<li>{h(x)}</li>" for x in miss["warn"]) + "</ul></div></div>")
    return out


def _ui_effect(result, h):
    """اللوحة الجانبية: نتيجة «أثر الاختيار» من القالب نفسه إن طُلبت، وإلا ملخّص حيّ يملؤه السكربت."""
    if result and "_effect" in result:
        eff = result["_effect"]
        if eff is None:
            body = '<li class="lt-agr-gap">اختر نموذج الأتعاب أولاً.</li>'
        else:
            opt = [x for x in result["_missing"]["optional"] if x != "وسيلة التواصل"]
            body = ("".join(f'<li class="lt-agr-in">{h(t)}</li>' for t in eff["in"])
                    + "".join(f'<li class="lt-agr-out">{h(k)}</li>' for k, _n in eff["out"])
                    + "".join(f'<li class="lt-agr-gap">{h(x)} — <span class="lt-agr-slot">[●]</span></li>' for x in opt))
        return ('<aside class="lt-agr-side" id="effect"><h3>أثر الاختيار</h3>'
                '<p>محسوب من القالب نفسه بالاختيار الحالي؛ ولم يُنشأ ملف ولم يُسجَّل شيء.</p>'
                f'<ul>{body}</ul></aside>')
    return ('<aside class="lt-agr-side" id="effect" data-live="1"><h3>ما يدخل العقد</h3>'
            '<p>يتغيّر مع كل اختيار، قبل الإنشاء.</p><ul id="live-summary"></ul></aside>')


def screen_html(con: sqlite3.Connection, matter_id: int, h: Callable[[Any], str],  # noqa: F811
                f: Optional[Dict[str, str]] = None, result: Optional[Dict[str, Any]] = None) -> str:
    f = dict(f or {})
    if f.get("hourly_option") == "cap":              # الخيار القديم (القرار 172): الملحق مع السقف
        f.update(hourly_option="none", cap_on="1")
    v = lambda k, d="": h(f.get(k, d))
    sel = lambda k, val, d="": " selected" if (f.get(k) or d) == val else ""
    chk = lambda k, val, d="": " checked" if (f.get(k) or d) == val else ""
    pe_default = con.execute("SELECT email FROM matter_team WHERE matter_id=? AND role='partner'", (matter_id,)).fetchone()
    chosen = (f.get("partner_ar") or f.get("partner_en") or f.get("partner") or (pe_default[0] if pe_default else "")).lower()
    sigs = signatories(con)
    popt = lambda s, name: (f"<option value='{h(s['email'])}' data-title-ar='{h(s['title_ar'])}' "
                            f"data-title-en='{h(s['title_en'])}'{' selected' if s['email'] == chosen else ''}>{h(name)}</option>")
    term_opts = "".join(f"<option{sel('term', a, TERMS[0][0])}>{h(a)}</option>" for a, _ in TERMS)
    inst_opts = "".join(f"<option value='{n}'{sel('a_instalments', n, '4')}>{h(a)}</option>" for n, a, _ in INSTALMENTS)
    basis_opts = "".join(f"<option{sel('succ_basis', a)}>{h(a)}</option>" for a, _ in SUCC_BASES)
    money = lambda name, label: (f'<div class="lt-agr-f"><label for="{name}">{h(label)}</label>'
                                 f'<input type="text" id="{name}" name="{name}" value="{v(name)}" class="lt-agr-ltr" inputmode="numeric">'
                                 f'<small class="amount-words"></small></div>')
    picks = lambda field, items, d: "".join(
        f'<label class="lt-agr-pick"><input type="radio" name="{field}" value="{k}"{chk(field, k, d)}>'
        f'<b>{h(t)}</b><span>{h(s)}</span></label>' for k, t, s in items)

    def phase(i):
        return (f'<div class="lt-agr-phase"><h4><i>{i}</i> المرحلة {ORD_AR[i]}</h4><div class="lt-agr-grid">'
                f'<div class="lt-agr-f"><label for="ph{i}_desc_ar">الوصف (عربي)</label>'
                f'<input type="text" id="ph{i}_desc_ar" name="ph{i}_desc_ar" value="{v(f"ph{i}_desc_ar")}"></div>'
                f'<div class="lt-agr-f"><label for="ph{i}_amount">المبلغ (ريال)</label>'
                f'<input type="text" id="ph{i}_amount" name="ph{i}_amount" value="{v(f"ph{i}_amount")}" class="lt-agr-ltr ph-amt" inputmode="numeric">'
                f'<small class="amount-words"></small></div>'
                f'<div class="lt-agr-f"><label for="ph{i}_due_ar">الاستحقاق (عربي)</label>'
                f'<input type="text" id="ph{i}_due_ar" name="ph{i}_due_ar" value="{v(f"ph{i}_due_ar")}"></div>'
                f'<details class="lt-agr-more"><summary>النص الإنجليزي</summary><div class="lt-agr-grid">'
                f'<div class="lt-agr-f"><label for="ph{i}_desc_en">الوصف (إنجليزي)</label>'
                f'<input type="text" id="ph{i}_desc_en" name="ph{i}_desc_en" value="{v(f"ph{i}_desc_en")}" class="lt-agr-ltr"></div>'
                f'<div class="lt-agr-f"><label for="ph{i}_due_en">الاستحقاق (إنجليزي)</label>'
                f'<input type="text" id="ph{i}_due_en" name="ph{i}_due_en" value="{v(f"ph{i}_due_en")}" class="lt-agr-ltr"></div>'
                f'</div></details></div></div>')

    more_open = " open" if any(f.get(f"ph{i}_desc_ar") for i in range(3, MAX_PHASES + 1)) else ""
    head = agreement_page_body(con, matter_id, h)
    return f"""{UI_LINK}{head}
<form class="lt-agr lt-agr-nojs" method="post" action="{AGREEMENT_PATH}?id={matter_id}">
<div class="lt-agr-wrap"><div class="lt-agr-main">
{UI_KEY}{_ui_tells(result, h)}
<section class="lt-agr-sec"><h3>نطاق العمل</h3><div class="lt-agr-grid">
<div class="lt-agr-f lt-agr-wide"><label for="scope_ar">نطاق العمل (عربي)</label>
<textarea id="scope_ar" name="scope_ar" rows="5" required>{v('scope_ar')}</textarea></div>
<details class="lt-agr-more"{' open' if f.get('scope_en') else ''}><summary>النص الإنجليزي</summary><div class="lt-agr-grid">
<div class="lt-agr-f lt-agr-wide"><label for="scope_en">نطاق العمل (إنجليزي)</label>
<textarea id="scope_en" name="scope_en" rows="5" class="lt-agr-ltr">{v('scope_en')}</textarea>
<div class="lt-agr-hint">يُترك فارغاً فيُكتب في العقد <span class="lt-agr-slot">[●]</span> ويُستكمل قبل التوقيع.</div></div>
</div></details></div></section>

<section class="lt-agr-sec"><h3>المدة والتاريخ</h3><div class="lt-agr-grid">
<div class="lt-agr-f"><label for="term">مدة الاتفاقية</label><select id="term" name="term">{term_opts}</select>
<div class="lt-agr-hint">تتجدد تلقائياً لمدد مماثلة.</div></div>
<div class="lt-agr-f"><label for="agreement_date">تاريخ الاتفاقية</label>
<input type="date" id="agreement_date" name="agreement_date" value="{v('agreement_date', _dt.date.today().isoformat())}" class="lt-agr-ltr"></div>
<div class="lt-agr-f"><label for="agreement_date_h">التاريخ الهجري الموافق</label>
<input type="text" id="agreement_date_h" name="agreement_date_h" value="{v('agreement_date_h')}" data-auto="{'0' if f.get('agreement_date_h') else '1'}" class="lt-agr-ltr" inputmode="numeric" placeholder="18/04/1448">
<div class="lt-agr-hint">يُحسب بتقويم أم القرى عند اختيار التاريخ؛ راجِعه، ويُعدَّل إن لزم.</div></div>
<label class="lt-agr-chk"><input type="checkbox" id="effective_on" name="effective_on" value="1"{chk('effective_on', '1')}>
<span>تاريخ سريان مختلف عن تاريخ الاتفاقية <em>يُستعمل حين بدأ العمل قبل التوقيع، ولا يظهر سطره في العقد إلا بتفعيله.</em></span></label>
<div class="lt-agr-f" data-show="effective_on=1"><label for="effective_date">تاريخ السريان</label>
<input type="date" id="effective_date" name="effective_date" value="{v('effective_date')}" class="lt-agr-ltr"></div>
</div></section>

<section class="lt-agr-sec"><h3>الأتعاب</h3>
<p class="lt-agr-why">اختر نموذجاً واحداً؛ يظهر ما يخصّه وحده، ويُحذف ما سواه من العقد.</p>
<div class="lt-agr-fork">{picks('fee_model', FEE_PICKS, '')}</div></section>

<section class="lt-agr-sec lt-agr-cond" data-show="fee_model=annual"><h3>أتعاب سنوية ثابتة</h3>
<p class="lt-agr-why">ظهر لأنك اخترت «أتعاب سنوية ثابتة».</p><div class="lt-agr-grid">
{money('a_fee', 'الأتعاب السنوية (ريال)')}
<div class="lt-agr-f"><label for="a_instalments">عدد الأقساط</label><select id="a_instalments" name="a_instalments">{inst_opts}</select></div>
<details class="lt-agr-more"><summary>خيارات متقدمة</summary><div class="lt-agr-grid">
<div class="lt-agr-f"><label for="a_notice_days">مهلة إخطار تعديل الأتعاب (يوماً)</label>
<input type="text" id="a_notice_days" name="a_notice_days" value="{v('a_notice_days', CONSTANTS['A_NOTICE_DAYS'])}" class="lt-agr-ltr" inputmode="numeric">
<div class="lt-agr-hint">ثلاثون يوماً ما لم تُغيَّر.</div></div>
</div></details></div></section>

<section class="lt-agr-sec lt-agr-cond" data-show="fee_model=hourly"><h3>الأتعاب بالساعة</h3>
<p class="lt-agr-why">ظهر لأنك اخترت «بالساعة».</p>
<div class="lt-agr-fork">{picks('hourly_option', HOURLY_PICKS, 'none')}</div>
<div class="lt-agr-grid" style="margin-top:12px">
<div data-show="hourly_option=advance">{money('c_advance', 'الدفعة المقدمة (ريال)')}</div>
<div data-show="hourly_option=blended">{money('d_rate', 'سعر الساعة الموحّد (ريال)')}</div>
</div>
<label class="lt-agr-chk" style="margin-top:12px"><input type="checkbox" id="cap_on" name="cap_on" value="1"{chk('cap_on', '1')}>
<span>وسقفٌ للأتعاب <em>لا تتجاوز الأتعاب حدّاً متفقاً عليه؛ يُجمع مع أيّ مما سبق.</em></span></label>
<div class="lt-agr-grid" data-show="cap_on=1">{money('e_cap', 'سقف الأتعاب (ريال)')}</div>
</section>

<section class="lt-agr-sec lt-agr-cond" data-show="fee_model=fixed"><h3>أتعاب ثابتة</h3>
<p class="lt-agr-why">ظهر لأنك اخترت «أتعاب ثابتة».</p><div class="lt-agr-grid">
{money('f_fee', 'الأتعاب الثابتة (ريال)')}
<details class="lt-agr-more"><summary>خيارات متقدمة — نسبتا الدفع</summary><div class="lt-agr-grid">
<div class="lt-agr-f"><label for="f_pct_sign">نسبة الدفعة عند التوقيع (%)</label>
<input type="text" id="f_pct_sign" name="f_pct_sign" value="{v('f_pct_sign', '50')}" class="lt-agr-ltr" inputmode="numeric"></div>
<div class="lt-agr-f"><label for="f_pct_delivery">نسبة الدفعة عند التسليم (%)</label>
<input type="text" id="f_pct_delivery" name="f_pct_delivery" value="{v('f_pct_delivery', '50')}" class="lt-agr-ltr" inputmode="numeric">
<div class="lt-agr-msg" id="pctMsg" hidden>مجموع النسبتين ليس مئة.</div></div>
</div></details></div></section>

<section class="lt-agr-sec lt-agr-cond" data-show="fee_model=phases"><h3>أتعاب على مراحل</h3>
<p class="lt-agr-why">ظهر لأنك اخترت «على مراحل». املأ ما تحتاجه واترك الباقي فارغاً — المرحلة الفارغة لا تدخل العقد.</p>
{phase(1)}{phase(2)}
<details class="lt-agr-more"{more_open} style="border:none;margin:0;padding:0"><summary>مراحل إضافية — من الثالثة إلى السادسة</summary>
<div style="margin-top:12px">{''.join(phase(i) for i in range(3, MAX_PHASES + 1))}</div></details>
<div class="lt-agr-sum" id="phSum"><span>مجموع مبالغ المراحل</span><b>0</b></div></section>

<section class="lt-agr-sec"><h3>أتعاب النجاح</h3><div class="lt-agr-grid">
<label class="lt-agr-chk"><input type="checkbox" id="succ_on" name="succ_on" value="1"{chk('succ_on', '1')}>
<span>في الاتفاقية أتعاب نجاح <em>تُضاف إلى الأتعاب الأساسية عند تحقق واقعة الاستحقاق.</em></span></label>
</div></section>

<section class="lt-agr-sec lt-agr-cond" data-show="succ_on=1"><h3>تفاصيل أتعاب النجاح</h3>
<p class="lt-agr-why">ظهر لأنك فعّلت أتعاب النجاح.</p>
<div class="lt-agr-fork">{picks('succ_type', [("lump", "مبلغ مقطوع", "مبلغ واحد معلوم."), ("pct", "نسبة", "من وعاء يُحدَّد.")], '')}</div>
<div class="lt-agr-grid" style="margin-top:12px">
<div data-show="succ_type=lump">{money('succ_lump', 'المبلغ المقطوع (ريال)')}</div>
<div class="lt-agr-f" data-show="succ_type=pct"><label for="succ_pct">النسبة (%)</label>
<input type="text" id="succ_pct" name="succ_pct" value="{v('succ_pct')}" class="lt-agr-ltr" inputmode="numeric"></div>
<div class="lt-agr-f" data-show="succ_type=pct"><label for="succ_basis">وعاء احتساب النسبة</label>
<select id="succ_basis" name="succ_basis">{basis_opts}</select></div>
<details class="lt-agr-more"><summary>خيارات متقدمة — السقف وواقعة الاستحقاق والمهام</summary><div class="lt-agr-grid">
<div class="lt-agr-f" data-show="succ_type=pct"><label for="succ_cap_ar">سقف أتعاب النجاح (عربي) — اختياري</label>
<input type="text" id="succ_cap_ar" name="succ_cap_ar" value="{v('succ_cap_ar')}"></div>
<div class="lt-agr-f" data-show="succ_type=pct"><label for="succ_cap_en">سقف أتعاب النجاح (إنجليزي)</label>
<input type="text" id="succ_cap_en" name="succ_cap_en" value="{v('succ_cap_en')}" class="lt-agr-ltr"></div>
<div class="lt-agr-f lt-agr-wide"><label for="succ_event_ar">واقعة الاستحقاق (عربي) — اختياري</label>
<textarea id="succ_event_ar" name="succ_event_ar" rows="2">{v('succ_event_ar')}</textarea>
<div class="lt-agr-hint">تُترك فارغة فيدخل العقدَ البديلُ النظامي لواقعة الاستحقاق.</div></div>
<div class="lt-agr-f lt-agr-wide"><label for="succ_event_en">واقعة الاستحقاق (إنجليزي)</label>
<textarea id="succ_event_en" name="succ_event_en" rows="2" class="lt-agr-ltr">{v('succ_event_en')}</textarea></div>
<label class="lt-agr-chk"><input type="checkbox" id="tasks_on" name="tasks_on" value="1"{chk('tasks_on', '1')}>
<span>تقسيم التكليف إلى مهام ومراحل <em>يضيف جدول المهام ويربط الأتعاب بها.</em></span></label>
<div class="lt-agr-f lt-agr-wide" data-show="tasks_on=1"><label for="tasks_ar">المهام (عربي)</label>
<textarea id="tasks_ar" name="tasks_ar" rows="3">{v('tasks_ar')}</textarea></div>
<div class="lt-agr-f lt-agr-wide" data-show="tasks_on=1"><label for="tasks_en">المهام (إنجليزي)</label>
<textarea id="tasks_en" name="tasks_en" rows="3" class="lt-agr-ltr">{v('tasks_en')}</textarea></div>
</div></details></div></section>

<section class="lt-agr-sec"><h3>الشريك الموقّع</h3><div class="lt-agr-grid">
<div class="lt-agr-f"><label for="partner_ar">بالعربية</label>
<select id="partner_ar" name="partner_ar" data-link="partner">{''.join(popt(s, s['name_ar']) for s in sigs)}</select></div>
<div class="lt-agr-f"><label for="partner_en">بالإنجليزية</label>
<select id="partner_en" name="partner_en" data-link="partner" class="lt-agr-ltr">{''.join(popt(s, s['name_en']) for s in sigs)}</select></div>
<div class="lt-agr-f lt-agr-wide"><div class="lt-agr-hint" id="partner-info"></div></div>
</div></section>
</div>
{_ui_effect(result, h)}
</div>
<div class="lt-agr-bar">
<button type="submit" name="action" value="effect" formnovalidate class="lt-agr-btn">أثر الاختيار</button>
<button type="submit" name="action" value="create" class="lt-agr-btn lt-agr-btn-go">إنشاء الاتفاقية</button>
<span class="lt-agr-note">«أثر الاختيار» يعاين ولا يُنشئ شيئاً.</span></div>
</form>
{SCREEN_SCRIPT}{AMOUNT_SCRIPT}{LIVE_SCRIPT}{FIELD_STATE_SCRIPT}"""


# ألوان حالة الحقول (سأل المالك 30/09: المفتاح مطبوع والحقول لا تتلوّن): كل حقلٍ ظاهر يأخذ حاله في
# data-state على غلافه .lt-agr-f: done مملوء، todo مطلوبٌ فارغ، err قيمةٌ خاطئة؛ والاختياري الفارغ بلا لون.
# والمطلوب هنا ما يمنع فراغُه الإنشاءَ في build_engine_data، فلا يُعلَّم أصفرَ ما لا يمنع
FIELD_STATE_SCRIPT = """<script>(function(){
var form=document.querySelector('form.lt-agr');if(!form)return;
var REQ={scope_ar:1,partner_ar:1,partner_en:1,agreement_date:1,a_fee:1,c_advance:1,d_rate:1,e_cap:1,f_fee:1,
 f_pct_sign:1,f_pct_delivery:1,succ_lump:1,succ_pct:1,ph1_desc_ar:1,ph1_amount:1,effective_date:1};
var MONEY=/^(a_fee|c_advance|d_rate|e_cap|f_fee|succ_lump|ph[1-6]_amount)$/;
function shown(el){return !!(el.offsetWidth||el.offsetHeight||el.getClientRects().length);}
function num(s){s=(s||'').replace(/[\\u0660-\\u0669]/g,function(c){return String(c.charCodeAt(0)-1632);}).replace(/[,\\s\\u066c]/g,'');return s;}
function state(c){var v=(c.value||'').trim(),n=c.name;
 if(!v)return REQ[n]?'todo':'';
 if(MONEY.test(n)&&!/^\\d+(\\.\\d{1,2})?$/.test(num(v)))return 'err';
 if(n==='agreement_date_h'&&!/^\\d{1,2}\\/\\d{1,2}\\/\\d{4}$/.test(v))return 'err';
 if(n==='f_pct_sign'||n==='f_pct_delivery'){var a=parseFloat(num(form.querySelector('[name=f_pct_sign]').value)),
  b=parseFloat(num(form.querySelector('[name=f_pct_delivery]').value));if(!isNaN(a)&&!isNaN(b)&&a+b!==100)return 'err';}
 return 'done';}
function paint(){form.querySelectorAll('.lt-agr-f').forEach(function(f){
 var c=f.querySelector('input:not([type=hidden]):not([type=checkbox]):not([type=radio]),select,textarea');
 if(!c||!c.name||!shown(f)){f.removeAttribute('data-state');return;}
 var s=state(c);if(s)f.setAttribute('data-state',s);else f.removeAttribute('data-state');});}
form.addEventListener('input',paint);form.addEventListener('change',function(){setTimeout(paint,0);});paint();})();</script>"""


# الملخّص الحيّ والمجموع ونسبتا الدفع — سلوك الشاشة عندنا (المعاينة محاكاة لا تُنسخ)
LIVE_SCRIPT = """<script>(function(){
var form=document.querySelector('form.lt-agr');if(!form)return;form.classList.remove('lt-agr-nojs');
function val(n){var els=form.querySelectorAll('[name="'+n+'"]');for(var i=0;i<els.length;i++){var e=els[i];
 if(e.type==='radio'||e.type==='checkbox'){if(e.checked)return e.value;}else return e.value;}return '';}
function num(s){s=(s||'').replace(/[\\u0660-\\u0669]/g,function(c){return String(c.charCodeAt(0)-1632);}).replace(/[,\\s\\u066c]/g,'').replace('\\u066b','.');var x=parseFloat(s);return isNaN(x)?null:x;}
var MODELS={annual:'أتعاب سنوية ثابتة',hourly:'بالساعة',fixed:'أتعاب ثابتة',phases:'على مراحل'};
var AMT={annual:'a_fee',fixed:'f_fee'};
function li(cls,t){var e=document.createElement('li');e.className=cls;e.textContent=t;return e;}
function gap(t){var e=li('lt-agr-gap',t+' — ');var s=document.createElement('span');s.className='lt-agr-slot';s.textContent='[●]';e.appendChild(s);return e;}
function live(){
 var t=0,any=false;form.querySelectorAll('.ph-amt').forEach(function(i){var x=num(i.value);if(x!==null){t+=x;any=true;}});
 var s=document.getElementById('phSum');if(s)s.querySelector('b').textContent=any?t.toLocaleString('en-US'):'0';
 var a=num(val('f_pct_sign')),b=num(val('f_pct_delivery')),m=document.getElementById('pctMsg');if(m)m.hidden=((a||0)+(b||0)===100);
 var ul=document.getElementById('live-summary');if(!ul)return;ul.innerHTML='';
 var fm=val('fee_model');
 if(!fm){ul.appendChild(gap('نموذج الأتعاب'));}
 else{Object.keys(MODELS).forEach(function(k){ul.appendChild(k===fm?li('lt-agr-in','بند الأتعاب — '+MODELS[k]):li('lt-agr-out','بند الأتعاب — '+MODELS[k]));});
  if(AMT[fm]&&num(val(AMT[fm]))===null)ul.appendChild(gap('مبلغ الأتعاب'));
  if(fm==='hourly'){var ho=val('hourly_option');ul.appendChild(li(ho==='blended'?'lt-agr-out':'lt-agr-in','الملحق (ب) — معدلات الساعة'));
   ul.appendChild(li(val('cap_on')==='1'?'lt-agr-in':'lt-agr-out','سقف الأتعاب'));}
  else ul.appendChild(li('lt-agr-out','الملحق (ب) — معدلات الساعة'));}
 if(val('succ_on')==='1'){var st=val('succ_type');ul.appendChild(st?li('lt-agr-in','أتعاب النجاح — '+(st==='pct'?'نسبة':'مبلغ مقطوع')):gap('نوع أتعاب النجاح'));
  ul.appendChild(li('lt-agr-in',val('succ_event_ar').trim()?'واقعة الاستحقاق — المكتوبة':'واقعة الاستحقاق — البديل النظامي'));
  if(val('tasks_on')==='1')ul.appendChild(li('lt-agr-in','المهام والمراحل'));}
 else ul.appendChild(li('lt-agr-out','بند أتعاب النجاح'));
 ul.appendChild(li(val('effective_on')==='1'?'lt-agr-in':'lt-agr-out','سطر تاريخ السريان'));
 if(!val('scope_en').trim())ul.appendChild(gap('نطاق العمل بالإنجليزية'));
}
// التاريخ الهجري بتقويم أم القرى (القرار 169): تعديل الإداري بيده يبقى ما بقي الميلادي، وتغيير الميلادي يعيد الحساب كي لا يبقى هجريٌّ قديم
var gd=document.getElementById('agreement_date'),hd=document.getElementById('agreement_date_h');
function hijri(){if(!gd||!hd||hd.getAttribute('data-auto')!=='1'||!gd.value)return;
 try{var p={};new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn',{day:'2-digit',month:'2-digit',year:'numeric',timeZone:'UTC'})
  .formatToParts(new Date(gd.value+'T00:00:00Z')).forEach(function(x){p[x.type]=x.value;});hd.value=p.day+'/'+p.month+'/'+p.year;}catch(e){}}
if(hd)hd.addEventListener('input',function(){hd.setAttribute('data-auto','0');});
if(gd)['change','input'].forEach(function(t){gd.addEventListener(t,function(){hd.setAttribute('data-auto','1');hijri();});});hijri();
form.addEventListener('change',live);form.addEventListener('input',live);live();})();</script>"""


# صفحة الفريق: بحث بالاسم في أربعين موظفاً، وسطر بالمختارين (ن-23 من تدقيق الاستخدام)
TEAM_SCRIPT = """<script>(function(){var f=document.getElementById('team-find'),p=document.getElementById('team-picked');if(!f)return;
var boxes=[].slice.call(document.querySelectorAll('.lt-agr-members input[name=member]'));
function picked(){var n=boxes.filter(function(b){return b.checked}).map(function(b){return b.parentNode.textContent.trim()});p.textContent=n.length?n.join('، '):'لم يُختر أحد';}
f.addEventListener('input',function(){var q=f.value.trim();document.querySelectorAll('.lt-agr-members').forEach(function(g){var any=false;
 g.querySelectorAll('label').forEach(function(l){var on=!q||l.textContent.indexOf(q)>-1;l.hidden=!on;any=any||on;});g.closest('section').hidden=!any;});});
boxes.forEach(function(b){b.addEventListener('change',picked)});picked();})();</script>"""


# أسماء أقسام سمّاها المالك بالعربية (30/09)
DEPT_AR = {"Transactions": "المعاملات التجارية"}


def dept_ar(dep: str) -> str:
    """اسم القسم كما يُعرض: الشطر العربي إن جاء التصدير بالاسمين («Litigation | التقاضي»)، والفارغ «غير مصنّف»؛
    ولا يُترجَم اسمٌ إنجليزي وحده تخميناً -اسم القسم عند المكتب لا يُخترع-؛ والمخزَّن لا يتغير."""
    d = (dep or "").strip()
    if not d:
        return "غير مصنّف"
    if d in DEPT_AR:
        return DEPT_AR[d]
    if "|" in d:
        ar = [x.strip() for x in d.split("|") if any("؀" <= ch <= "ۿ" for ch in x)]
        if ar:
            return ar[0]
    return d


def team_page(con: sqlite3.Connection, matter_id: int, h: Callable[[Any], str],  # noqa: F811
              error: str = "", posted: Optional[Dict[str, Any]] = None) -> str:
    con.row_factory = sqlite3.Row
    m = con.execute("SELECT id, matter_number, title FROM matters WHERE id=?", (matter_id,)).fetchone()
    if not m:
        raise RegisterError("التكليف غير موجود")
    cur = {r[0]: r[1] for r in con.execute("SELECT email, role FROM matter_team WHERE matter_id=?", (matter_id,))}
    partner = (posted or {}).get("partner") or next((e for e, r in cur.items() if r == "partner"), "")
    members = set((posted or {}).get("members") or [e for e, r in cur.items() if r != "partner"])
    sigs = signatories(con)
    opt = lambda s, name: (f"<option value='{h(s['email'])}' data-title-ar='{h(s['title_ar'])}' data-title-en='{h(s['title_en'])}'"
                           f"{' selected' if s['email'] == partner else ''}>{h(name)}</option>")
    blank = "<option value=''>— اختر —</option>"
    locked = team_lock_reason(con, matter_id)
    groups: Dict[str, List[str]] = {}
    for c in team_candidates(con):
        groups.setdefault(dept_ar(c["department"]), []).append(
            f'<label class="lt-agr-chk"><input type="checkbox" name="member" value="{h(c["email"])}"'
            f'{" checked" if c["email"] in members else ""}><span>{h(c["name_ar"])}</span></label>')
    boxes = "".join(f'<section class="lt-agr-sec"><h3>{h(dep)}</h3><div class="lt-agr-grid lt-agr-members">{"".join(xs)}</div></section>'
                    for dep, xs in groups.items())
    tells = f'<div class="lt-agr-tell lt-agr-stop"><div>{h(error)}</div></div>' if error else ""
    if locked:
        tells += f'<div class="lt-agr-tell lt-agr-opt"><div><b>الفريق مقفل:</b> {h(locked)}.</div></div>'
    return f"""{UI_LINK}<div class="card"><h2>فريق التكليف</h2>
<p>التكليف <b>{h(m['matter_number'])}</b> — {h(m['title'])}</p></div>
<form class="lt-agr lt-agr-nojs" data-page="team" method="post" action="{TEAM_PATH}?id={matter_id}"><div class="lt-agr-main">
{tells}<fieldset{' disabled' if locked else ''} style="border:0;padding:0;margin:0">
<section class="lt-agr-sec"><h3>الشريك المسؤول</h3>
<p class="lt-agr-why">الفريق يحدّد من يطّلع على ملف العميل في شيربوينت؛ والشريك المسؤول فيه تلقائياً، ويلزمه عضو آخر على الأقل.</p>
<div class="lt-agr-grid">
<div class="lt-agr-f"><label for="partner_ar">بالعربية</label><select id="partner_ar" name="partner_ar" data-link="partner">{blank}{''.join(opt(s, s['name_ar']) for s in sigs)}</select></div>
<div class="lt-agr-f"><label for="partner_en">بالإنجليزية</label><select id="partner_en" name="partner_en" data-link="partner" class="lt-agr-ltr">{blank}{''.join(opt(s, s['name_en']) for s in sigs)}</select></div>
<div class="lt-agr-f lt-agr-wide"><div class="lt-agr-hint" id="partner-info"></div></div>
</div></section>
<section class="lt-agr-sec"><h3>أعضاء الفريق</h3>
<p class="lt-agr-why">ابحث بالاسم، والمختارون يظهرون هنا: <b id="team-picked">—</b></p>
<div class="lt-agr-f"><input type="search" id="team-find" placeholder="اكتب جزءاً من الاسم" autocomplete="off"></div></section>
{boxes}
</fieldset></div>
<div class="lt-agr-bar"><button type="submit" class="lt-agr-btn lt-agr-btn-go"{' disabled' if locked else ''}>حفظ الفريق</button>
<a class="lt-agr-btn" href="{AGREEMENT_PATH}?id={matter_id}">العودة إلى إصدار الاتفاقية</a></div>
</form>{TEAM_SCRIPT}
{SCREEN_SCRIPT}<script>(function(){{var f=document.querySelector('form.lt-agr');if(f)f.classList.remove('lt-agr-nojs');}})();</script>"""


def client_fields_page(con: sqlite3.Connection, client_id: int, h: Callable[[Any], str],  # noqa: F811
                       back: int = 0, error: str = "", posted: Optional[Dict[str, str]] = None) -> str:
    con.row_factory = sqlite3.Row
    c = con.execute("SELECT * FROM clients WHERE id=?", (client_id,)).fetchone()
    if not c:
        raise RegisterError("العميل غير موجود")
    c = dict(c)
    val = lambda k: (posted or {}).get(k, c.get(k) or "")
    cls = ' class="lt-agr-ltr"'
    field = lambda k, lbl, d, extra="": (f'<div class="lt-agr-f"><label for="{k}">{h(lbl)}</label>'
                                         f'<input type="text" id="{k}" name="{k}" value="{h(val(k))}"'
                                         f"{cls if d == 'ltr' else ''}>{extra}</div>")
    ar_fields = [x for x in CLIENT_FIELD_LABELS if x[2] == "rtl" or x[0] in ("email", "vat_number", "signatory_id")]
    en_fields = [x for x in CLIENT_FIELD_LABELS if x not in ar_fields]
    t_ar = (posted or {}).get("title_manual_ar") if (posted or {}).get("signatory_title_ar") == MANUAL else val("signatory_title_ar")
    known_t = t_ar in dict(SIGNATORY_TITLES)
    manual_sel = bool(t_ar) and not known_t
    t_opts = "<option value=''>— اختر —</option>" + "".join(
        f"<option value='{h(a)}'{' selected' if a == t_ar else ''}>{h(a)} — {h(e)}</option>" for a, e in SIGNATORY_TITLES) \
        + f"<option value='{MANUAL}'{' selected' if manual_sel else ''}>صفة أخرى تُكتب يدوياً</option>"
    t_en_manual = (posted or {}).get("title_manual_en", c.get("signatory_title_en") or "") if manual_sel else ""
    sug, form = suggested_authority(con, client_id)
    a_ar = val("signatory_authority_ar") or (sug[0] if sug else "")
    a_opts = "<option value=''>— اختر —</option>" + "".join(
        f"<option value='{h(a)}'{' selected' if a == a_ar else ''}>{h(a)} — {h(e)}</option>" for a, e in SIGNATORY_AUTHORITIES)
    if sug:
        hint = (f"مقترح من الشكل النظامي في واثق «{h(form)}»: <b>{h(sug[0])}</b> "
                "(المادة السابعة، الفقرة 1 من نظام الشركات). ويُغيَّر إن كان التوقيع بقرار أو تفويض أو وكالة.")
    elif form:
        hint = f"الشكل النظامي في واثق «{h(form)}» لا يحدّد سند التأسيس وحده (عدد الملّاك غير معروف)؛ فيُختار يدوياً."
    else:
        hint = "لم يُجلب الشكل النظامي من واثق لهذا العميل؛ فيُختار السند يدوياً."
    addr = c.get("address") or ""
    addr_note = "غير مسجَّل — يُسجَّل من صفحة العميل" if not addr else ("مختصر، فيُكتب كما هو في اللغتين" if is_short_address(addr) else "")
    gv = val("salutation_gender")
    gender_sec = ('<section class="lt-agr-sec"><h3>مخاطبة العميل الفرد</h3><div class="lt-agr-grid">'
                  '<div class="lt-agr-f"><label for="salutation_gender">المخاطبة في العقد</label><select id="salutation_gender" name="salutation_gender">'
                  + "".join(f"<option value='{k}'{' selected' if gv == k else ''}>{h(t)}</option>"
                            for k, t in (("", "— اختر —"), ("M", "الأستاذ"), ("F", "الأستاذة")))
                  + '</select><div class="lt-agr-hint">تُكتب «الأستاذ/» أو «الأستاذة/»؛ وإن تُركت كُتب <span class="lt-agr-slot">[●]</span>.</div></div></div></section>'
                  ) if c.get("client_type") == "individual" else ""
    tells = f'<div class="lt-agr-tell lt-agr-stop"><div>{h(error)}</div></div>' if error else ""
    back_link = f'<a class="lt-agr-btn" href="{AGREEMENT_PATH}?id={back}">العودة إلى إصدار الاتفاقية</a>' if back else ""
    return f"""{UI_LINK}<div class="card"><h2>بيانات العميل للعقد</h2>
<p>العميل <b>{h(c.get('legal_name'))}</b> · العنوان الوطني: {h(addr) or '—'}{(' (' + h(addr_note) + ')') if addr_note else ''}</p></div>
<form class="lt-agr lt-agr-nojs" method="post" action="{CLIENT_FIELDS_PATH}?id={client_id}&amp;back={back}"><div class="lt-agr-main">
{tells}
<section class="lt-agr-sec"><h3>بيانات العميل</h3><div class="lt-agr-grid">
{''.join(field(k, lbl, d) for k, lbl, d in ar_fields)}
<details class="lt-agr-more"><summary>النص الإنجليزي</summary><div class="lt-agr-grid">
{''.join(field(k, lbl, d) for k, lbl, d in en_fields)}</div></details>
</div></section>
{gender_sec}
<section class="lt-agr-sec"><h3>صفة ممثل التوقيع وسند الصلاحية</h3><div class="lt-agr-grid">
<div class="lt-agr-f lt-agr-wide"><label for="signatory_title_ar">صفة ممثل التوقيع</label><select id="signatory_title_ar" name="signatory_title_ar">{t_opts}</select>
<div class="lt-agr-hint">والإنجليزية تتبع العربية في الصفات المدرجة.</div></div>
<div class="lt-agr-f lt-agr-cond" data-show="signatory_title_ar={MANUAL}"><label for="title_manual_ar">الصفة (عربي)</label>
<input type="text" id="title_manual_ar" name="title_manual_ar" value="{h(t_ar if manual_sel else '')}"></div>
<div class="lt-agr-f lt-agr-cond" data-show="signatory_title_ar={MANUAL}"><label for="title_manual_en">الصفة (إنجليزي)</label>
<input type="text" id="title_manual_en" name="title_manual_en" value="{h(t_en_manual)}" class="lt-agr-ltr"></div>
<div class="lt-agr-f lt-agr-wide"><label for="signatory_authority_ar">سند الصلاحية</label><select id="signatory_authority_ar" name="signatory_authority_ar">{a_opts}</select>
<div class="lt-agr-hint">{hint}</div></div>
</div></section>
</div>
<div class="lt-agr-bar"><button type="submit" class="lt-agr-btn lt-agr-btn-go">حفظ</button> {back_link}</div>
</form>
{SCREEN_SCRIPT}<script>(function(){{var f=document.querySelector('form.lt-agr');if(f)f.classList.remove('lt-agr-nojs');}})();</script>"""


def _install_ui_asset_route(ns: Dict[str, Any]) -> None:
    """ورقة الأنماط ووجوه الخطوط من المنصة نفسها، بملفٍّ يُخزَّن في المتصفح (القرار 167)."""
    handler = ns.get("AppHandler")
    if not handler or getattr(handler, "_cr_ui", False):
        return
    base_get = handler.do_GET

    def do_get(self):
        if ns["urlparse"](self.path).path != UI_ASSET_PATH:
            return base_get(self)
        self.send_response(200)
        self.send_header("Content-Type", "text/css; charset=utf-8")
        self.send_header("Content-Length", str(len(_UI_CSS)))
        self.send_header("Cache-Control", "public, max-age=604800")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(_UI_CSS)

    handler.do_GET = do_get
    handler._cr_ui = True


_base_install_ui = install
def install(ns: Dict[str, Any]) -> None:  # noqa: F811
    _base_install_ui(ns)
    _install_ui_asset_route(ns)


def agreement_page_body(con: sqlite3.Connection, matter_id: int, h: Callable[[Any], str]) -> str:  # noqa: F811
    """رأس صفحة الإصدار في بطاقة واحدة مدمجة (د2): التكليف والعميل، والفريق في سطر، والنواقص أعداداً
    تنفتح بالنقر — فيبدأ النموذج قرب أعلى الشاشة. والمضمون نفسه، لا يُحذف منه شيء."""
    ctx = agreement_gate(con, matter_id)
    m, c = ctx["matter"], ctx["client"]
    snap = client_snapshot(con, c["id"], "ar_en")
    miss = snap["_missing"]
    team = con.execute("SELECT s.name_ar, t.role FROM matter_team t JOIN staff_directory s ON s.email=t.email "
                       "WHERE t.matter_id=? ORDER BY t.role DESC, s.name_ar", (matter_id,)).fetchall()
    live = con.execute("SELECT reference_no, status, regenerations FROM issued_documents "
                       "WHERE matter_id=? AND doc_type='agreement' AND status!='withdrawn'", (matter_id,)).fetchone()
    team_txt = "، ".join(h(r[0]) + (" (الشريك المسؤول)" if r[1] == "partner" else "") for r in team) \
        or "<b>لم يُحدَّد فريق التكليف بعد — وهو مانع</b>"
    doc_txt = (f"في السجل عقدٌ بالمرجع <b>{h(live[0])}</b>، حالته «{h(DOC_STATUS_AR.get(live[1], live[1]))}»، {regen_ar(live[2])}."
               if live else "لم يصدر عن هذا التكليف عقد بعد.")

    def group(title, xs):
        return f"<b>{title}:</b> " + ("، ".join(h(x) for x in xs) if xs else "لا شيء")
    n_block, n_warn, n_opt = len(miss["block"]), len(miss["warn"]), len(miss["optional"])
    return f"""<div class="card"><h2>إصدار الاتفاقية</h2>
<p>التكليف <b>{h(m['matter_number'])}</b> — {h(m['title'])} · العميل <b>{h(c['legal_name'])}</b> · {doc_txt}</p>
<p><b>فريق التكليف:</b> {team_txt} · <a href="/matter/team?id={matter_id}">تعديل الفريق</a></p>
<details><summary><b>بيانات العميل الناقصة للعقد:</b> تمنع الإنشاء {n_block} · ناقصة لا تمنع {n_warn} · اختيارية {n_opt}</summary>
<p>{group('تمنع الإنشاء', miss['block'])}</p><p>{group('ناقصة لا تمنع الإصدار', miss['warn'])}</p><p>{group('اختيارية', miss['optional'])}</p>
</details>
<p><a href="/client/contract-fields?id={c['id']}&amp;back={matter_id}">استكمال بيانات العميل للعقد</a></p></div>"""


# ═══════════════════════ التاريخ الهجري — القرار 169 ═══════════════════════
# لا تقويم أم القرى في مكتبة بايثون القياسية؛ فالمتصفح يملأ الهجري بتقويم أم القرى (Intl) ويراجعه
# الإداري، والخادم يتحقّق هنا من موافقته للميلادي بالتقويم الحسابي بفارق يومين على الأكثر.
# ولا يدخل الهجريُّ العقدَ حتى يعتمد المالك صيغته في مراجعة الصياغة (HIJRI_IN_CONTRACT في المحرّك).

_HIJRI_RE = _re.compile(r"(\d{1,2})/(\d{1,2})/(\d{4})")


def _greg_jdn(y: int, m: int, d: int) -> int:
    a = (14 - m) // 12
    yy, mm = y + 4800 - a, m + 12 * a - 3
    return d + (153 * mm + 2) // 5 + 365 * yy + yy // 4 - yy // 100 + yy // 400 - 32045


def _hijri_arith_jdn(y: int, m: int, d: int) -> int:
    """التقويم الهجري الحسابي (الجدولي) — تقريب يُقاس به المُدخل، لا مصدرٌ يُكتب منه."""
    return d + int(29.5 * (m - 1) + 0.99) + (y - 1) * 354 + (3 + 11 * y) // 30 + 1948439 - 1


def hijri_plausible(greg_iso: str, hijri_dmy: str, tolerance: int = 2) -> bool:
    m = _HIJRI_RE.fullmatch((hijri_dmy or "").strip())
    g = _re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", greg_iso or "")
    if not (m and g):
        return False
    d, mo, y = (int(x) for x in m.groups())
    if not (1 <= d <= 30 and 1 <= mo <= 12 and 1300 <= y <= 1600):
        return False
    return abs(_hijri_arith_jdn(y, mo, d) - _greg_jdn(*(int(x) for x in g.groups()))) <= tolerance

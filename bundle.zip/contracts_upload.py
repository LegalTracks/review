# -*- coding: utf-8 -*-
"""إرفاق النسخة الموقّعة والرفع إلى شيربوينت: المرحلتان ج1 وج3.

ملف مستقل عن app.py وعن contracts_register.py؛ يُربط بسطرين في آخر app.py بعد سطري السجل:
    import contracts_upload as _cu
    _cu.install(globals())
ويُزال بحذفهما.

ما يطبّقه (من rules/DECISIONS.md):
- لا يُرفع شيء قبل التوقيع (56)؛ والرفع يبدأ من صفّ الوثيقة في السجل (81).
- الرفع حزمة من ثلاثة (62) في خطوتين، بأسماء الأبواب في مجموعات Postman المعتمدة (25/09):
  1- «فتح العميل» (Customer Onboarding): الاسم والرقم الموحّد والبريد، ومستندات الامتثال
     وتقرير الامتثال معاً في KYCFiles (72)؛ مرة واحدة لكل عميل.
  2- «فتح المشروع» (Project Onboarding): الفريق ورقم المرجع في ContractNo والعقد الموقّع
     في خانته (SIGNED_CONTRACT_FIELD)؛ مرة واحدة لكل تكليف.
  ولا نداء لـ«تغيير فريق المشروع» عند الرفع الأول: المشروع لم يوجد بعد.
- مفتاحان (64): الرقم الموحّد لما يخصّ العميل، ورقم المرجع لما يخصّ التكليف.
- ما بعد الرفع الأول دالتان غير موصولتين بصفحة: send_kyc_update لمستند امتثال جديد
  (باب «تحديث مستندات الامتثال»)، و change_team_after_upload لتغيير الفريق بعد القفل (141).
- لا ملف بلا صفّ في السجل (133): الموقَّع لا يُحفظ إلا لوثيقة مسجَّلة، ويُحذف إن رفض السجل الانتقال.
- الفريق يُقفل بعد الرفع (141): يتولاه team_lock_reason في السجل متى صارت الوثيقة «مرفوعة».

منع التكرار (مسألتا التكامل 1 و2 في source/sameh-specs/README.md):
كل خطوة تمّت تُقيَّد في contract_upload_steps، فإعادة المحاولة بعد نجاح جزئي تبدأ مما لم يتمّ؛
وإن قُسم طلب على أجزاء قُيّدت أسماء الملفات الواصلة فلا تُرسل ثانية. والتقسيم نفسه معطَّل
افتراضياً (ALLOW_SPLIT) حتى يجيب سامح عن أثره على المجلدات. ولا يُمنع تكرارٌ سببه انقطاع
الاتصال بعد وصول الطلب؛ فذلك لا يُعرف من جهتنا، ولذلك تُرسل كل محاولة مرة واحدة بلا إعادة داخلية
(BRIDGE_ATTEMPTS) وتُقيَّد في سجل الأحداث، فيُتتبَّع أي تكرار إلى محاولته.

لا خيط في الخلفية يبدأ عند التحميل: retry_due تستدعيها مهمة مجدولة أو زرّ المدير.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import io
import json
import re
import sqlite3
import zipfile
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import contracts_register as cr
import sharepoint_bridge as spb

_NS: Dict[str, Any] = {}

# ─────────────────────────── ثوابت تُراجع ───────────────────────────

# المسألة المعلَّقة «ل»: العقد الموقّع في FinancialFiles أم في خانة مخصّصة يُطلب من سامح فتحها؟
# الافتراض FinancialFiles لأنها خانة الملفات الوحيدة في باب «فتح المشروع» اليوم. وتغييرها هنا
# يكفي متى أضاف سامح الخانة وأُضيفت إلى تعريف الباب في sharepoint_bridge.
SIGNED_CONTRACT_FIELD = "FinancialFiles"

# مسألة التكامل 2: لا نعتمد على تقسيم الطلب قبل جواب سامح؛ فالحزمة التي تجاوز الحدّ تُرفض بسببها.
ALLOW_SPLIT = False
MAX_BYTES: Optional[int] = None          # None = حدّ الجسر (متغير البيئة أو 90,000,000 بايت)
BRIDGE_ATTEMPTS = 1                      # إعادة المحاولة هنا بجدولها، لا داخل الجسر
BRIDGE_TIMEOUT = 120.0

# جدول إعادة المحاولة: 5 دقائق ثم ضعفها في كل مرة، بسقف 6 ساعات؛ وبعد 8 إخفاقات لا يُعاد آلياً
BACKOFF_BASE_SECONDS = 300
BACKOFF_CAP_SECONDS = 6 * 3600
MAX_AUTO_ATTEMPTS = 8
STALE_CLAIM_SECONDS = 1800               # محاولة معلّقة أقدم من هذا تُعدّ منتهية

# القرار 81: إرفاق الموقَّع يُطلق الرفع
UPLOAD_ON_ATTACH = True
# العرض يُرفع مع حزمة العقد (80) ولم يُبنَ ضمّه بعد. والملحق لا باب له اليوم: المشروع قائم،
# و«تغيير فريق المشروع» لا يحمل ملفات، و«فتح المشروع» ثانيةً قد يُنشئ مشروعاً مكرراً؛ فالسؤال لسامح.
UPLOADABLE_TYPES = ("agreement",)
ADDENDUM_NOTE = ("لا باب اليوم يحمل ملف ملحق لمشروع قائم: «تغيير فريق المشروع» لا يحمل ملفات، "
                 "و«فتح المشروع» ثانيةً قد يُنشئ مشروعاً مكرراً؛ والسؤال عند سامح، فيبقى الملحق في السجل حتى يجيب")
ADMIN_ROLES = {"admin"}

ALLOWED_EXT = {".pdf": "application/pdf",
               ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"}
# 60 مليون بايت خام = نحو 80 مليوناً بعد base64؛ فيبقى طلب الباب الرابع دون حدّ الجسر بلا تقسيم
MAX_SIGNED_BYTES = 60_000_000

SIGNED_PATH = "/document/signed"
SIGNED_FILE_PATH = "/document/signed/file"
UNSIGNED_REPORT_PATH = "/reports/contracts/unsigned"
PENDING_REPORT_PATH = "/reports/contracts/signed-not-uploaded"

STEP_CUSTOMER, STEP_PROJECT = "customer", "project"
STEP_LABELS = {STEP_CUSTOMER: "فتح العميل بمستندات الامتثال وتقرير الامتثال",
               STEP_PROJECT: "فتح المشروع بفريقه والعقد الموقّع"}
STATUS_LABELS = {"issued": "صادر", "signed": "موقَّع", "uploaded": "مرفوع", "withdrawn": "مسحوب"}
TYPE_LABELS = {"agreement": "اتفاقية", "offer": "عرض", "addendum": "ملحق"}
EVENT_LABELS = {"issued": "صدر", "regenerated": "أُعيد إنشاؤه", "signed": "أُرفقت النسخة الموقّعة",
                "uploaded": "رُفع إلى شيربوينت", "withdrawn": "سُحب", "upload_failed": "تعذّر الرفع",
                "upload_step": "تمّت خطوة من الرفع"}


class UploadNotReady(cr.RegisterError):
    """مصدر لازم للحزمة لم يُهيَّأ أو لم يُحسم؛ فلا يُرسل شيء."""


# ─────────────────────────── البنية ───────────────────────────

def ensure_schema(con: sqlite3.Connection) -> None:
    cr.ensure_schema(con)
    con.execute("""
        CREATE TABLE IF NOT EXISTS issued_document_signed(
            document_id INTEGER PRIMARY KEY REFERENCES issued_documents(id),
            stored_at TEXT NOT NULL,
            original_name TEXT,
            send_name TEXT NOT NULL,
            file_path TEXT NOT NULL,
            file_sha256 TEXT NOT NULL,
            size_bytes INTEGER NOT NULL,
            stored_by TEXT
        )""")
    # scope: client (خطوة العميل) · matter (خطوة المشروع) · document (خطوة العقد)
    con.execute("""
        CREATE TABLE IF NOT EXISTS contract_upload_steps(
            scope TEXT NOT NULL,
            scope_id INTEGER NOT NULL,
            step TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            document_id INTEGER,
            delivered_files TEXT NOT NULL DEFAULT '[]',
            attempts INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            completed_at TEXT,
            PRIMARY KEY(scope, scope_id, step)
        )""")
    # بصمات ما وصل شيربوينت من مستندات كل عميل، فلا يُرسل مستند مرتين
    con.execute("""
        CREATE TABLE IF NOT EXISTS sharepoint_kyc_sent(
            client_id INTEGER NOT NULL,
            file_sha256 TEXT NOT NULL,
            file_name TEXT,
            door TEXT NOT NULL,
            sent_at TEXT NOT NULL,
            PRIMARY KEY(client_id, file_sha256)
        )""")
    con.execute("""
        CREATE TABLE IF NOT EXISTS sharepoint_team_changes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            matter_id INTEGER NOT NULL,
            sent_at TEXT NOT NULL,
            actor TEXT,
            team_json TEXT NOT NULL,
            ok INTEGER NOT NULL,
            error TEXT
        )""")
    con.execute("""
        CREATE TABLE IF NOT EXISTS contract_upload_runs(
            document_id INTEGER PRIMARY KEY REFERENCES issued_documents(id),
            failures INTEGER NOT NULL DEFAULT 0,
            last_attempt_at TEXT,
            next_attempt_at TEXT,
            running_since TEXT
        )""")


def _now_dt() -> _dt.datetime:
    return _dt.datetime.now().replace(microsecond=0)


def _iso(d: _dt.datetime) -> str:
    return d.isoformat(timespec="seconds")


def _audit(con, action: str, doc_id: int, details: str, ip: str = "") -> None:
    fn = _NS.get("audit")
    if fn:
        fn(con, action, "issued_document", doc_id, details, ip)


def _data_dir() -> Path:
    d = _NS.get("DATA_DIR")
    if d is None:
        raise cr.RegisterError("مجلد البيانات غير معروف؛ والوحدة لم تُربط بالمنصة")
    return Path(d)


# ─────────────────────────── ج1: إرفاق الموقَّع ───────────────────────────

def check_signed_file(file_name: str, content: bytes) -> str:
    """يقبل PDF أو DOCX وحدهما، ويتحقق أن المحتوى يطابق الامتداد؛ ويعيد الامتداد."""
    name = (file_name or "").strip()
    if not name or not content:
        raise cr.RegisterError("لم يُختر ملف؛ والنسخة الموقّعة تُرفع PDF أو DOCX")
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED_EXT:
        raise cr.RegisterError(f"النسخة الموقّعة تُرفع PDF أو DOCX وحدهما؛ والملف المختار «{name}» ليس منهما")
    if len(content) > MAX_SIGNED_BYTES:
        raise cr.RegisterError(f"حجم الملف {len(content):,} بايت يجاوز الحدّ ({MAX_SIGNED_BYTES:,})؛ "
                               "فيُضغط الملف الممسوح ثم يُرفع")
    if ext == ".pdf":
        if b"%PDF-" not in content[:1024]:
            raise cr.RegisterError("امتداد الملف PDF ومحتواه ليس PDF")
    else:
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as z:
                if "word/document.xml" not in z.namelist():
                    raise cr.RegisterError("امتداد الملف DOCX ومحتواه ليس مستند وورد")
        except zipfile.BadZipFile:
            raise cr.RegisterError("امتداد الملف DOCX ومحتواه ليس مستند وورد") from None
    return ext


def send_name_for(doc: Dict[str, Any], ext: str) -> str:
    """اسم الملف الذي يصل شيربوينت، برقم المرجع كما في اسم المسودة (القرار 57)."""
    ref = (doc["reference_no"] or "").replace("/", "-")
    base = {"agreement": "اتفاقية خدمات قانونية", "addendum": "ملحق اتفاقية خدمات قانونية",
            "offer": "عرض خدمات قانونية"}.get(doc["doc_type"], "مستند")
    return f"{base} {ref} موقعة{ext}"


def attach_signed(con: sqlite3.Connection, doc_id: int, file_name: str, content: bytes,
                  actor: str, ip: str = "") -> Dict[str, Any]:
    """يحفظ الموقَّع ثم ينقل الوثيقة إلى «موقَّع»؛ وإن رفض السجل الانتقال حُذف الملف المحفوظ."""
    ensure_schema(con)
    doc = cr.get(con, doc_id)
    if "signed" not in cr.TRANSITIONS.get(doc["status"], set()):
        raise cr.RegisterError(
            f"لا تُرفق نسخة موقّعة لمستند حالته «{STATUS_LABELS.get(doc['status'], doc['status'])}»؛ "
            "والإرفاق للمستند الصادر وحده")
    ext = check_signed_file(file_name, content)
    sha = hashlib.sha256(content).hexdigest()
    folder = _data_dir() / "uploads" / "matter" / str(int(doc["matter_id"])) / "signed"
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"doc{int(doc_id)}_{sha[:12]}{ext}"
    target.write_bytes(content)
    try:
        cr.mark_signed(con, doc_id, content, actor, ip)
    except Exception:
        try:
            target.unlink()
        except OSError:
            pass
        raise
    con.execute("INSERT OR REPLACE INTO issued_document_signed(document_id,stored_at,original_name,send_name,"
                "file_path,file_sha256,size_bytes,stored_by) VALUES(?,?,?,?,?,?,?,?)",
                (doc_id, _iso(_now_dt()), Path(file_name).name, send_name_for(doc, ext), str(target), sha,
                 len(content), actor))
    con.commit()
    return cr.get(con, doc_id)


def signed_file(con: sqlite3.Connection, doc_id: int) -> Optional[Dict[str, Any]]:
    ensure_schema(con)
    con.row_factory = sqlite3.Row
    row = con.execute("SELECT * FROM issued_document_signed WHERE document_id=?", (doc_id,)).fetchone()
    return dict(row) if row else None


def _read_signed(con, doc_id: int) -> Tuple[str, bytes]:
    info = signed_file(con, doc_id)
    if not info:
        raise UploadNotReady("لا نسخة موقّعة محفوظة لهذا المستند؛ فتُرفق أولاً")
    p = Path(info["file_path"])
    if not p.exists():
        raise UploadNotReady(f"ملف النسخة الموقّعة غير موجود على القرص: {p.name}")
    data = p.read_bytes()
    if hashlib.sha256(data).hexdigest() != info["file_sha256"]:
        raise UploadNotReady("بصمة النسخة الموقّعة على القرص لا تطابق المسجَّلة؛ فلا تُرسل")
    return info["send_name"], data


# ─────────────────────────── مصادر الحزمة ───────────────────────────

def default_kyc_files(con: sqlite3.Connection, client_id: int) -> List[Tuple[str, bytes]]:
    """مستندات الامتثال المحفوظة للعميل في المنصة، من مواضعها الثلاثة:
    entity_documents (وثائق العميل عدا العقود)، و clients.document_scan_path (المرفوع عند الإنشاء)،
    و ubo_verifications.document_path (مستند المستفيد الحقيقي).

    TODO(المالك): هل هذه المواضع الثلاثة هي «مستندات الامتثال» المقصودة في القرار 62 كلها،
    أم يُختار منها بنوع الوثيقة؟ وما يُستبعد اليوم: الوثائق من نوع «contract».
    """
    paths: List[Tuple[str, str]] = []
    q = [("SELECT original_filename, file_path FROM entity_documents WHERE entity_type='client' "
          "AND entity_id=? AND COALESCE(document_type,'')<>'contract' ORDER BY id", (client_id,)),
         ("SELECT document_original_filename, document_scan_path FROM clients WHERE id=? "
          "AND COALESCE(document_scan_path,'')<>''", (client_id,)),
         ("SELECT document_filename, document_path FROM ubo_verifications WHERE client_id=? "
          "AND COALESCE(document_path,'')<>'' ORDER BY id", (client_id,))]
    for sql, args in q:
        try:
            paths += [(r[0] or Path(r[1]).name, r[1]) for r in con.execute(sql, args).fetchall()]
        except sqlite3.OperationalError:
            continue            # جدول أو عمود غير موجود في هذه النسخة
    out, seen = [], set()
    for name, path in paths:
        p = Path(path)
        if not p.exists():
            raise UploadNotReady(f"مستند امتثال مسجَّل للعميل غير موجود على القرص: {name}")
        data = p.read_bytes()
        sha = hashlib.sha256(data).hexdigest()
        if sha not in seen:
            seen.add(sha)
            out.append((Path(name).name, data))
    return out


def _safe_name(text: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "-", text).strip()


def default_compliance_report(con: sqlite3.Connection, client_id: int) -> List[Tuple[str, bytes]]:
    """تقرير الامتثال في الحزمة = ثلاثته كلها (القرار 148):
    1- كل تقرير PDF لنتيجة فحص محفوظ للعميل (screening_reports.pdf_path بعمود client_id)؛
    2- تقرير فحص القوائم المحلية والدولية للعميل (kind=sanctions)؛
    3- تقرير التعارض الداخلي التفصيلي للعميل (kind=internal).
    والثاني والثالث يُولَّدان بدوال المنصة نفسها التي تستدعيها _serve_client_report
    (_CLIENT_REPORT_KINDS ثم _batch_pdf_bytes) بلا طلب HTTP ولا نسخ لشيفرة PDF.
    وإن تعذّر واحد منها رُفع UploadNotReady باسمه، فلا يصل شيربوينت نصف حزمة.
    """
    ns = _NS.get("_ns") or {}
    kinds, pdf = ns.get("_CLIENT_REPORT_KINDS"), ns.get("_batch_pdf_bytes")
    if not kinds or not pdf:
        raise UploadNotReady("مولّدا تقريري العميل غير متاحين؛ والوحدة لم تُربط بالمنصة")
    con.row_factory = sqlite3.Row
    c = con.execute("SELECT legal_name, client_code FROM clients WHERE id=?", (client_id,)).fetchone()
    if not c:
        raise UploadNotReady("العميل غير موجود")
    code = _safe_name(str(c["client_code"] or client_id))
    day = _now_dt().date().isoformat()
    out: List[Tuple[str, bytes]] = []

    rows = con.execute("SELECT report_number, pdf_path FROM screening_reports WHERE client_id=? ORDER BY id",
                       (client_id,)).fetchall()
    if not rows:
        raise UploadNotReady("تقارير نتائج الفحص: لا تقرير PDF محفوظ لهذا العميل؛ فيُصدَر من صفحة الفحص ثم يُعاد الرفع")
    for r in rows:
        path = Path(r["pdf_path"] or "")
        if not path.is_file():
            raise UploadNotReady(f"تقارير نتائج الفحص: ملف التقرير {r['report_number']} غير موجود على القرص")
        out.append((_safe_name(f"تقرير نتيجة فحص {r['report_number']} - {code} - {day}.pdf"), path.read_bytes()))

    for kind, label in (("sanctions", "تقرير فحص القوائم المحلية والدولية"),
                        ("internal", "تقرير فحص تعارض المصالح")):
        try:
            title_base, fn, weights = kinds[kind]
            headers, table = fn(con, client_id)
            data = pdf(f"{title_base} — العميل {c['client_code'] or client_id}: {c['legal_name']}", headers, table, weights)
        except Exception as exc:  # noqa: BLE001 — أي عطل في المولّد يمنع الحزمة كلها
            raise UploadNotReady(f"{label}: تعذّر توليده ({type(exc).__name__}: {exc})") from None
        if not data or not bytes(data).startswith(b"%PDF"):
            raise UploadNotReady(f"{label}: المولّد لم يُخرج ملف PDF")
        out.append((_safe_name(f"{label} - {code} - {day}.pdf"), bytes(data)))
    fn_audit = _NS.get("audit")
    if fn_audit:
        fn_audit(con, "compliance_report_for_upload", "client", client_id, f"files={len(out)}", "")
        con.commit()
    return out


PROVIDERS: Dict[str, Callable[[sqlite3.Connection, int], List[Tuple[str, bytes]]]] = {
    "kyc_files": default_kyc_files,
    "compliance_report": default_compliance_report,
}


def project_name_for(matter: Dict[str, Any]) -> str:
    """اسم المشروع في شيربوينت: رقم التكليف ثم عنوانه. TODO(المالك/سامح): الصيغة مقترحة لا مقرّة."""
    title = (matter.get("title") or "").strip()
    return f"{matter['matter_number']} - {title}" if title else matter["matter_number"]


def project_type_for(con, service_type: str) -> str:
    """من القائمة الثابتة ref_service_types (الافتراض 5 في README سامح)."""
    try:
        row = con.execute("SELECT label_ar FROM ref_service_types WHERE code=?", (service_type,)).fetchone()
    except sqlite3.OperationalError:
        row = None
    return (row[0] if row and row[0] else service_type) or ""


# ─────────────────────────── سجل الخطوات ───────────────────────────

def _step_row(con, scope: str, scope_id: int, step: str) -> Dict[str, Any]:
    con.execute("INSERT OR IGNORE INTO contract_upload_steps(scope,scope_id,step) VALUES(?,?,?)",
                (scope, scope_id, step))
    con.row_factory = sqlite3.Row
    return dict(con.execute("SELECT * FROM contract_upload_steps WHERE scope=? AND scope_id=? AND step=?",
                            (scope, scope_id, step)).fetchone())


def steps_for(con, doc: Dict[str, Any]) -> List[Tuple[str, str, int]]:
    return [(STEP_CUSTOMER, "client", int(doc["client_id"])),
            (STEP_PROJECT, "matter", int(doc["matter_id"]))]


def _docs_ar(n: int) -> str:
    """ن-19: «مستند واحد، مستندان، 3 مستندات، 11 مستنداً» لا «2 مستنداً»."""
    if n == 0:
        return "لا مستندات"
    return {1: "مستند واحد", 2: "مستندان"}.get(n) or (f"{n} مستندات" if n <= 10 else f"{n} مستنداً")


def _step_state(s: Dict[str, Any], doc: Dict[str, Any]) -> str:
    """ن-22: خطوةٌ لا سجلّ لها في مستندٍ «مرفوع» ليست خطوةً فشلت؛ فتُكتب «لا سجل لها» لا «لم تتمّ»."""
    if s.get("status") == "done":
        return "تمّت"
    if "id" not in s and doc.get("status") == "uploaded":
        return "لا سجل لها"
    return "لم تتمّ"


def step_status(con, doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    ensure_schema(con)
    out = []
    for step, scope, sid in steps_for(con, doc):
        con.row_factory = sqlite3.Row
        r = con.execute("SELECT * FROM contract_upload_steps WHERE scope=? AND scope_id=? AND step=?",
                        (scope, sid, step)).fetchone()
        out.append({"step": step, "label": STEP_LABELS[step], **(dict(r) if r else {"status": "pending"})})
    return out


def _unique_names(files: Sequence[Tuple[str, bytes]]) -> List[Tuple[str, bytes]]:
    """أسماء الملفات مفتاح ما وصل منها؛ فلا يتكرر اسم في الطلب الواحد."""
    seen: Dict[str, int] = {}
    out = []
    for name, data in files:
        n = name
        if n in seen:
            seen[n] += 1
            p = Path(name)
            n = f"{p.stem} ({seen[name]}){p.suffix}"
        seen.setdefault(n, 1)
        out.append((n, data))
    return out


# ─────────────────────────── الإرسال ───────────────────────────

def default_sender(door, body):
    return spb.send(door, body, BRIDGE_TIMEOUT, max_attempts=BRIDGE_ATTEMPTS, max_bytes=MAX_BYTES)


def _send_step(con, doc_id: int, step: str, scope: str, sid: int, door, build: Callable[[list], dict],
               files: Optional[List[Tuple[str, bytes]]], sender, actor: str) -> None:
    """يرسل خطوة واحدة لم تتمّ، مستبعداً ما وصل من ملفاتها من قبل؛ ويرفع RegisterError عند الفشل."""
    row = _step_row(con, scope, sid, step)
    delivered = set(json.loads(row["delivered_files"] or "[]"))
    pending = [f for f in (files or []) if f[0] not in delivered] if files is not None else None
    body = build(pending if pending is not None else [])
    parts = spb.split_body(door, body, MAX_BYTES)
    if len(parts) > 1 and not ALLOW_SPLIT:
        raise cr.RegisterError(
            f"خطوة «{STEP_LABELS[step]}» تجاوز حدّ الطلب وتحتاج {len(parts)} طلبات؛ والتقسيم معطَّل "
            "حتى يجيب سامح عن أثره على مجلدات شيربوينت (مسألة التكامل 2)")
    con.execute("UPDATE contract_upload_steps SET attempts=attempts+1, document_id=? WHERE scope=? AND scope_id=? AND step=?",
                (doc_id, scope, sid, step))
    con.commit()
    res = sender(door, body)
    arrived = [n for p in (res.parts or []) if p.ok for n in (p.file_names or [])]
    if arrived:
        delivered.update(arrived)
        con.execute("UPDATE contract_upload_steps SET delivered_files=? WHERE scope=? AND scope_id=? AND step=?",
                    (json.dumps(sorted(delivered), ensure_ascii=False), scope, sid, step))
        con.commit()
    if not res.ok:
        err = spb.scrub(res.error or "فشل غير موصوف")
        con.execute("UPDATE contract_upload_steps SET last_error=? WHERE scope=? AND scope_id=? AND step=?",
                    (err[:500], scope, sid, step))
        con.commit()
        raise cr.RegisterError(f"خطوة «{STEP_LABELS[step]}»: {err}")
    con.execute("UPDATE contract_upload_steps SET status='done', completed_at=?, last_error=NULL "
                "WHERE scope=? AND scope_id=? AND step=?", (_iso(_now_dt()), scope, sid, step))
    cr._event(con, doc_id, "upload_step", actor, f"{step} ({door.spec_name})")
    con.commit()


def _claim(con, doc_id: int, now: _dt.datetime) -> bool:
    con.execute("INSERT OR IGNORE INTO contract_upload_runs(document_id) VALUES(?)", (doc_id,))
    stale = _iso(now - _dt.timedelta(seconds=STALE_CLAIM_SECONDS))
    n = con.execute("UPDATE contract_upload_runs SET running_since=? WHERE document_id=? "
                    "AND (running_since IS NULL OR running_since < ?)", (_iso(now), doc_id, stale)).rowcount
    con.commit()
    return n == 1


def backoff_seconds(failures: int) -> int:
    return int(min(BACKOFF_BASE_SECONDS * (2 ** max(failures - 1, 0)), BACKOFF_CAP_SECONDS))


def upload_document(con: sqlite3.Connection, doc_id: int, actor: str = "system", *,
                    sender: Optional[Callable] = None, providers: Optional[Dict[str, Callable]] = None,
                    now: Optional[_dt.datetime] = None) -> Dict[str, Any]:
    """يرسل حزمة الوثيقة الموقّعة خطوةً خطوة، ويبدأ مما لم يتمّ؛ ولا يرفع استثناءً على فشل الرفع.

    يعيد {"ok", "status", "error", "sent_steps"}؛ وكل فشل يُقيَّد بـ record_upload_failure.
    """
    ensure_schema(con)
    sender = sender or default_sender
    prov = dict(PROVIDERS)
    prov.update(providers or {})
    now = now or _now_dt()
    doc = cr.get(con, doc_id)
    if doc["status"] == "uploaded":
        return {"ok": True, "status": "uploaded", "error": "", "sent_steps": []}
    if doc["status"] != "signed":
        raise cr.RegisterError("لا يُرفع إلا المستند الموقَّع (القرار 56)")
    if doc["doc_type"] == "addendum":
        raise cr.RegisterError(ADDENDUM_NOTE)
    if doc["doc_type"] not in UPLOADABLE_TYPES:
        raise cr.RegisterError("العرض الموقَّع يُرفع مع حزمة الاتفاقية (القرار 80)، ولم يُبنَ ضمّه إليها بعد")
    if not _claim(con, doc_id, now):
        return {"ok": False, "status": "busy", "error": "محاولة رفع أخرى جارية لهذا المستند", "sent_steps": []}
    sent: List[str] = []
    try:
        con.row_factory = sqlite3.Row
        m = dict(con.execute("SELECT id, matter_number, title, service_type FROM matters WHERE id=?",
                             (doc["matter_id"],)).fetchone())
        c = dict(con.execute("SELECT id, legal_name, unified_number, email FROM clients WHERE id=?",
                             (doc["client_id"],)).fetchone())
        customer = (c["legal_name"] or "").strip()           # من سجل العميل نفسه في كل باب (71)
        team = cr.team_for_sharepoint(con, int(doc["matter_id"]))
        pname, ptype = project_name_for(m), project_type_for(con, m["service_type"] or "")
        for step, scope, sid in steps_for(con, doc):
            if _step_row(con, scope, sid, step)["status"] == "done":
                continue
            if step == STEP_CUSTOMER:
                no, email = customer_keys(c)
                files = _unique_names(list(prov["kyc_files"](con, int(c["id"])))
                                      + list(prov["compliance_report"](con, int(c["id"]))))
                door = spb.CUSTOMER_ONBOARDING
                build = (lambda fs: spb.customer_onboarding(customer, no, email, fs))
            else:
                prior = _step_row(con, scope, sid, step)["document_id"]
                if prior and int(prior) != int(doc_id):
                    raise UploadNotReady("مشروع هذا التكليف فُتح في شيربوينت بمستند آخر؛ فلا يُفتح ثانية")
                door = spb.PROJECT_ONBOARDING
                if door.files_field != SIGNED_CONTRACT_FIELD:
                    raise UploadNotReady(f"خانة العقد الموقّع «{SIGNED_CONTRACT_FIELD}» ليست خانة ملفات باب "
                                         "«فتح المشروع» في الجسر؛ فيُحدَّث تعريف الباب قبل تغيير الثابت")
                files = [_read_signed(con, doc_id)]
                build = (lambda fs: spb.project_onboarding(pname, customer, ptype, team, doc["reference_no"], fs))
            _send_step(con, doc_id, step, scope, sid, door, build, files, sender, actor)
            if step == STEP_CUSTOMER:
                _remember_kyc(con, int(c["id"]), files, door.key)
            sent.append(step)
        ref = f"power-automate:{doc['reference_no']}"     # الأبواب لا تعيد معرّفاً (مسألة التكامل 3)
        cr.mark_uploaded(con, doc_id, ref, actor)
        con.execute("UPDATE contract_upload_runs SET last_attempt_at=?, next_attempt_at=NULL WHERE document_id=?",
                    (_iso(now), doc_id))
        con.commit()
        return {"ok": True, "status": "uploaded", "error": "", "sent_steps": sent}
    except (cr.RegisterError, spb.BridgeError, OSError) as exc:
        reason = spb.scrub(str(exc) if not isinstance(exc, OSError) else f"خطأ في قراءة ملف: {exc}")
        cr.record_upload_failure(con, doc_id, reason, actor)
        row = con.execute("SELECT failures FROM contract_upload_runs WHERE document_id=?", (doc_id,)).fetchone()
        failures = (row[0] if row else 0) + 1
        nxt = now + _dt.timedelta(seconds=backoff_seconds(failures))
        con.execute("UPDATE contract_upload_runs SET failures=?, last_attempt_at=?, next_attempt_at=? WHERE document_id=?",
                    (failures, _iso(now), _iso(nxt), doc_id))
        _audit(con, "document_upload_failed", doc_id, f"{doc['reference_no']} · {reason[:200]}")
        con.commit()
        return {"ok": False, "status": "signed", "error": reason, "sent_steps": sent}
    finally:
        con.execute("UPDATE contract_upload_runs SET running_since=NULL WHERE document_id=?", (doc_id,))
        con.commit()


def retry_due(con: sqlite3.Connection, actor: str = "system", *, sender: Optional[Callable] = None,
              providers: Optional[Dict[str, Callable]] = None,
              now: Optional[_dt.datetime] = None) -> List[Dict[str, Any]]:
    """للمهمة المجدولة: يعيد رفع كل موقَّع حلّ موعده، ويترك ما بلغ MAX_AUTO_ATTEMPTS لزرّ المدير."""
    ensure_schema(con)
    now = now or _now_dt()
    out = []
    for d in cr.signed_not_uploaded(con):
        if d["doc_type"] not in UPLOADABLE_TYPES:
            continue
        run = con.execute("SELECT failures, next_attempt_at FROM contract_upload_runs WHERE document_id=?",
                          (d["id"],)).fetchone()
        if run:
            if run[0] >= MAX_AUTO_ATTEMPTS:
                continue
            if run[1] and run[1] > _iso(now):
                continue
        res = upload_document(con, d["id"], actor, sender=sender, providers=providers, now=now)
        out.append({"id": d["id"], "reference_no": d["reference_no"], **res})
    return out


def run_scheduled(actor: str = "scheduler") -> List[Dict[str, Any]]:
    """نقطة دخول للمهمة المجدولة بعد الربط؛ ولا تُستدعى عند التحميل."""
    with _NS["db"]() as con:
        return retry_due(con, actor)


def customer_keys(client: Dict[str, Any]) -> Tuple[str, str]:
    """CustomerNo هو الرقم الموحّد 700 (القرار 64 والافتراض 1)، و CustomerEmail بريد العميل في سجله.
    ولا بديل عن أيهما: لا يُرسل السجل التجاري مكان الرقم الموحّد تخميناً."""
    no = (client.get("unified_number") or "").strip()
    email = (client.get("email") or "").strip()
    if not no:
        raise UploadNotReady("الرقم الموحّد (700) غير مسجَّل للعميل، وهو CustomerNo في باب «فتح العميل»؛ "
                             "فيُستكمل في سجل العميل ثم يُعاد الرفع")
    if not email:
        raise UploadNotReady("بريد العميل غير مسجَّل، وهو CustomerEmail في باب «فتح العميل»")
    return no, email


def _remember_kyc(con, client_id: int, files: Sequence[Tuple[str, bytes]], door_key: str) -> None:
    now = _iso(_now_dt())
    for name, data in files or []:
        con.execute("INSERT OR IGNORE INTO sharepoint_kyc_sent(client_id,file_sha256,file_name,door,sent_at) "
                    "VALUES(?,?,?,?,?)", (client_id, hashlib.sha256(data).hexdigest(), name, door_key, now))
    con.commit()


def client_onboarded(con, client_id: int) -> bool:
    ensure_schema(con)
    r = con.execute("SELECT status FROM contract_upload_steps WHERE scope='client' AND scope_id=? AND step=?",
                    (client_id, STEP_CUSTOMER)).fetchone()
    return bool(r and r[0] == "done")


def pending_kyc_files(con, client_id: int, providers: Optional[Dict[str, Callable]] = None) -> List[Tuple[str, bytes]]:
    """مستندات الامتثال المحفوظة للعميل ولم تصل شيربوينت بعد، ببصمة المحتوى لا بالاسم."""
    ensure_schema(con)
    prov = dict(PROVIDERS)
    prov.update(providers or {})
    sent = {r[0] for r in con.execute("SELECT file_sha256 FROM sharepoint_kyc_sent WHERE client_id=?", (client_id,))}
    return [(n, d) for n, d in prov["kyc_files"](con, client_id) if hashlib.sha256(d).hexdigest() not in sent]


def send_kyc_update(con: sqlite3.Connection, client_id: int, actor: str, *,
                    files: Optional[Sequence[Tuple[str, bytes]]] = None, sender: Optional[Callable] = None,
                    providers: Optional[Dict[str, Callable]] = None) -> Dict[str, Any]:
    """مستند امتثال وصل بعد فتح العميل في شيربوينت ← باب «تحديث مستندات الامتثال» (Update KYC).

    غير موصولة بصفحة. والافتراض: ما لم يصل من مستندات العميل؛ ولا يُرسل ما وصل ثانية.
    ويعيد {"ok", "sent", "error"}، ولا يرفع استثناءً على فشل الإرسال.
    """
    ensure_schema(con)
    if not client_onboarded(con, client_id):
        raise cr.RegisterError("العميل لم يُفتح في شيربوينت بعد؛ ومستنداته تصل مع أول رفع لعقده")
    con.row_factory = sqlite3.Row
    c = con.execute("SELECT legal_name FROM clients WHERE id=?", (client_id,)).fetchone()
    if not c:
        raise cr.RegisterError("العميل غير موجود")
    sent_shas = {r[0] for r in con.execute("SELECT file_sha256 FROM sharepoint_kyc_sent WHERE client_id=?", (client_id,))}
    todo = list(files) if files is not None else pending_kyc_files(con, client_id, providers)
    todo = _unique_names([(n, d) for n, d in todo if hashlib.sha256(d).hexdigest() not in sent_shas])
    if not todo:
        return {"ok": True, "sent": [], "error": "لا مستند جديد يُرسل"}
    body = spb.update_kyc((c["legal_name"] or "").strip(), todo)
    try:
        if len(spb.split_body(spb.UPDATE_KYC, body, MAX_BYTES)) > 1 and not ALLOW_SPLIT:
            raise cr.RegisterError("المستندات تجاوز حدّ الطلب، والتقسيم معطَّل حتى يجيب سامح (مسألة التكامل 2)")
        res = (sender or default_sender)(spb.UPDATE_KYC, body)
    except (cr.RegisterError, spb.BridgeError) as exc:
        return {"ok": False, "sent": [], "error": spb.scrub(str(exc))}
    arrived = {n for p in (res.parts or []) if p.ok for n in (p.file_names or [])}
    _remember_kyc(con, client_id, [f for f in todo if f[0] in arrived], spb.UPDATE_KYC.key)
    fn = _NS.get("audit")
    if fn:
        fn(con, "sharepoint_kyc_update", "client", client_id,
           f"{len(arrived)}/{len(todo)} · {'ok' if res.ok else spb.scrub(res.error)[:200]}", "")
        con.commit()
    return {"ok": bool(res.ok), "sent": sorted(arrived), "error": "" if res.ok else spb.scrub(res.error)}


def change_team_after_upload(con: sqlite3.Connection, matter_id: int, partner_email: str,
                             member_emails: Sequence[str], actor: str, *,
                             sender: Optional[Callable] = None) -> Dict[str, Any]:
    """تغيير الفريق بعد القفل (141) ← باب «تغيير فريق المشروع» (Change Project Team). غير موصولة بصفحة.

    الترتيب مقصود: يُتحقَّق من الفريق الجديد بقواعد set_team نفسها، ثم يُرسل، ولا يُكتب في المنصة
    إلا بعد نجاح الإرسال؛ فإن فشل بقي الفريقان -في المنصة وفي شيربوينت- كما كانا متطابقين.
    تنبيه: قواعد التحقق منسوخة من cr.set_team لأنها ترفض كل تعديل بعد القفل؛ فأي تغيير فيها يُنقل هنا.
    """
    ensure_schema(con)
    if not cr.team_lock_reason(con, matter_id):
        raise cr.RegisterError("الفريق غير مقفل بعد؛ فيُعدَّل من صفحة الفريق لا من هذا الباب")
    if not con.execute("SELECT 1 FROM contract_upload_steps WHERE scope='matter' AND scope_id=? AND step=? "
                       "AND status='done'", (matter_id, STEP_PROJECT)).fetchone():
        raise cr.RegisterError("مشروع هذا التكليف لم يُفتح في شيربوينت من المنصة؛ فلا يُرسل تغيير فريقه")
    partner = (partner_email or "").strip().lower()
    emails = {e.strip().lower() for e in member_emails if e and e.strip()}
    if not partner:
        raise cr.RegisterError("الشريك المسؤول مطلوب")
    if partner not in {s["email"] for s in cr.signatories(con)}:
        raise cr.RegisterError("الشريك المسؤول يُختار من قائمة الشركاء الموقّعين")
    emails.add(partner)
    active = {e for (e,) in con.execute("SELECT email FROM staff_directory WHERE is_active=1")}
    unknown = sorted(emails - active)
    if unknown:
        raise cr.RegisterError("ليسوا موظفين نشطين في السجل: " + "، ".join(unknown))
    if len(emails) < 2:
        raise cr.RegisterError("فريق التكليف يلزمه عضو واحد على الأقل غير الشريك المسؤول")
    team = {"ProjectManager": [{"Email": partner}],
            "ProjectTeam": [{"Email": e} for e in sorted(emails) if e != partner]}
    con.row_factory = sqlite3.Row
    m = dict(con.execute("SELECT m.id, m.matter_number, m.title, m.service_type, c.legal_name FROM matters m "
                         "JOIN clients c ON c.id=m.client_id WHERE m.id=?", (matter_id,)).fetchone())
    body = spb.update_project_team(project_name_for(m), (m["legal_name"] or "").strip(),
                                   project_type_for(con, m["service_type"] or ""), team)
    now = _iso(_now_dt())
    try:
        res = (sender or default_sender)(spb.UPDATE_PROJECT_TEAM, body)
        ok_, err = bool(res.ok), ("" if res.ok else spb.scrub(res.error))
    except spb.BridgeError as exc:
        ok_, err = False, spb.scrub(str(exc))
    con.execute("INSERT INTO sharepoint_team_changes(matter_id,sent_at,actor,team_json,ok,error) VALUES(?,?,?,?,?,?)",
                (matter_id, now, actor, json.dumps(team, ensure_ascii=False), 1 if ok_ else 0, err[:500]))
    if ok_:
        con.execute("DELETE FROM matter_team WHERE matter_id=?", (matter_id,))
        for e in sorted(emails):
            con.execute("INSERT INTO matter_team(matter_id,email,role,added_at,added_by) VALUES(?,?,?,?,?)",
                        (matter_id, e, "partner" if e == partner else "member", now, actor))
    fn = _NS.get("audit")
    if fn:
        fn(con, "matter_team_changed_after_upload", "matter", matter_id,
           f"{'ok' if ok_ else 'failed'} · {', '.join(sorted(emails))}", "")
    con.commit()
    return {"ok": ok_, "error": err, "team": sorted(emails)}


def pending_report(con: sqlite3.Connection) -> List[Dict[str, Any]]:
    """تقرير «الموقَّع غير المرفوع» من السجل، ومعه حال المحاولات وآخر سبب فشل."""
    ensure_schema(con)
    rows = []
    for d in cr.signed_not_uploaded(con):
        run = con.execute("SELECT failures, last_attempt_at, next_attempt_at FROM contract_upload_runs WHERE document_id=?",
                          (d["id"],)).fetchone()
        last = con.execute("SELECT details FROM issued_document_events WHERE document_id=? AND event='upload_failed' "
                           "ORDER BY id DESC LIMIT 1", (d["id"],)).fetchone()
        rows.append({**d, "failures": run[0] if run else 0, "last_attempt_at": run[1] if run else None,
                     "next_attempt_at": run[2] if run else None, "last_error": last[0] if last else ""})
    return rows


# ─────────────────────────── الصفحات ───────────────────────────

def _actor_ar(con, actor: str) -> str:
    """ن-9: الفاعل باسم صاحبه في المنصة لا باسم دخوله، و«system» = «المنصة»؛ والمخزَّن لا يتغير."""
    a = (actor or "").strip()
    if a in ("", "system"):
        return "المنصة" if a else ""
    try:
        r = con.execute("SELECT full_name FROM app_users WHERE user_name=?", (a,)).fetchone()
        return (r[0] if r and r[0] else a)
    except Exception:
        return a


def _details_ar(d: str) -> str:
    return (d or "").replace("sha256=", "البصمة: ")


def _events_table(con, doc_id: int, h) -> str:
    trs = "".join(f"<tr><td>{h(e['created_at'])}</td><td>{h(EVENT_LABELS.get(e['event'], e['event']))}</td>"
                  f"<td>{h(_actor_ar(con, e['actor']))}</td><td>{h(_details_ar(e['details']))}</td></tr>" for e in cr.events(con, doc_id))
    return ("<table><thead><tr><th>الوقت</th><th>الحدث</th><th>الفاعل</th><th>التفاصيل</th></tr></thead>"
            f"<tbody>{trs or '<tr><td colspan=4>لا أحداث</td></tr>'}</tbody></table>")


def signed_page(con: sqlite3.Connection, doc_id: int, h, message: str = "", error: str = "",
                is_admin: bool = False) -> str:
    ensure_schema(con)
    doc = cr.get(con, doc_id)
    info = signed_file(con, doc_id)
    msg = (f"<div class='success'>{h(message)}</div>" if message else "") + \
          (f"<div class='error'>{h(error)}</div>" if error else "")
    status = STATUS_LABELS.get(doc["status"], doc["status"])
    head = (f"<div class='card'><h2>النسخة الموقّعة</h2>"
            f"<p>المرجع <b>{h(doc['reference_no'])}</b> · {h(TYPE_LABELS.get(doc['doc_type'], doc['doc_type']))} · "
            f"الحالة <b>{h(status)}</b></p>")
    if info:
        head += (f"<p>الملف المحفوظ: {h(info['original_name'] or '')} ({info['size_bytes']:,} بايت)، "
                 f"أُرفق في {h(info['stored_at'])}؛ ويصل شيربوينت باسم «{h(info['send_name'])}» "
                 f"<a class='btn secondary' href='{SIGNED_FILE_PATH}?id={doc_id}'>تنزيل</a></p>")
    head += "</div>"
    form = ""
    if doc["status"] == "issued":
        form = (f"<form method='post' action='{SIGNED_PATH}?id={doc_id}' enctype='multipart/form-data'>"
                "<div class='card'><h3>إرفاق النسخة الموقّعة</h3>"
                "<p>PDF أو DOCX وحدهما؛ والإرفاق ينقل المستند إلى «موقَّع» ويبدأ رفعه إلى شيربوينت.</p>"
                "<input type='file' name='signed_file' required accept='.pdf,.docx'>"
                "<button type='submit'>إرفاق</button></div></form>")
    steps = ""
    if doc["status"] == "signed" and doc["doc_type"] == "addendum":
        steps = f"<div class='card'><h3>الرفع</h3><p>{h(ADDENDUM_NOTE)}.</p></div>"
    if doc["status"] in ("signed", "uploaded") and doc["doc_type"] in UPLOADABLE_TYPES:
        trs = "".join(
            f"<tr><td>{h(s['label'])}</td><td>{_step_state(s, doc)}</td>"
            f"<td>{h(s.get('completed_at') or '')}</td><td>{h(s.get('last_error') or '')}</td></tr>"
            for s in step_status(con, doc))
        steps = ("<div class='card'><h3>خطوات الرفع</h3><table><thead><tr><th>الخطوة</th><th>الحال</th>"
                 f"<th>تمّت في</th><th>آخر سبب فشل</th></tr></thead><tbody>{trs}</tbody></table>")
        if doc["status"] == "signed" and is_admin:
            steps += (f"<form method='post' action='{PENDING_REPORT_PATH}'><input type='hidden' name='id' value='{doc_id}'>"
                      "<button type='submit'>إعادة محاولة الرفع</button></form>")
        steps += "</div>"
    return (f"{msg}{head}{form}{steps}<div class='card'><h3>سجل الأحداث</h3>{_events_table(con, doc_id, h)}</div>"
            f"<p><a class='btn secondary' href='{PENDING_REPORT_PATH}'>الموقَّع غير المرفوع</a> "
            f"<a class='btn secondary' href='{UNSIGNED_REPORT_PATH}'>الصادر غير الموقَّع</a></p>")


def unsigned_page(con: sqlite3.Connection, h, days: int = 0) -> str:
    ensure_schema(con)
    rows = cr.unsigned_report(con, days)
    trs = "".join(
        f"<tr><td>{h(r['reference_no'])}</td><td>{h(TYPE_LABELS.get(r['doc_type'], r['doc_type']))}</td>"
        f"<td>{h(r['client_name'] or '')}</td><td>{h(r['created_at'])}</td><td>{int(r['age_days'] or 0)}</td>"
        f"<td>{h(_actor_ar(con, r['issued_by']))}</td>"
        f"<td><a class='btn secondary' href='{SIGNED_PATH}?id={r['id']}'>إرفاق الموقَّع</a></td></tr>" for r in rows)
    return (f"<div class='card'><h2>الصادر غير الموقَّع</h2>"
            f"<form method='get' action='{UNSIGNED_REPORT_PATH}'><label>صدرت منذ أكثر من (يوماً)</label>"
            f"<input name='days' value='{int(days)}' inputmode='numeric'><button type='submit'>عرض</button></form>"
            f"<p>{_docs_ar(len(rows))}.</p>"
            "<table><thead><tr><th>المرجع</th><th>النوع</th><th>العميل</th><th>صدر في</th><th>العمر (يوماً)</th>"
            "<th>أصدره</th><th></th></tr></thead>"
            f"<tbody>{trs or '<tr><td colspan=7>لا شيء</td></tr>'}</tbody></table></div>")


def pending_page(con: sqlite3.Connection, h, is_admin: bool, message: str = "", error: str = "") -> str:
    rows = pending_report(con)
    msg = (f"<div class='success'>{h(message)}</div>" if message else "") + \
          (f"<div class='error'>{h(error)}</div>" if error else "")

    def action(r):
        if not is_admin or r["doc_type"] not in UPLOADABLE_TYPES:
            return ""
        return (f"<form method='post' action='{PENDING_REPORT_PATH}'><input type='hidden' name='id' value='{r['id']}'>"
                "<button type='submit'>إعادة محاولة الرفع</button></form>")
    trs = "".join(
        f"<tr><td><a href='{SIGNED_PATH}?id={r['id']}'>{h(r['reference_no'])}</a></td>"
        f"<td>{h(TYPE_LABELS.get(r['doc_type'], r['doc_type']))}</td><td>{h(r['signed_at'] or '')}</td>"
        f"<td>{r['failures']}{' (توقفت الإعادة الآلية)' if r['failures'] >= MAX_AUTO_ATTEMPTS else ''}</td>"
        f"<td>{h(r['next_attempt_at'] or '')}</td><td>{h(r['last_error'] or '')}</td><td>{action(r)}</td></tr>"
        for r in rows)
    return (f"{msg}<div class='card'><h2>الموقَّع غير المرفوع</h2><p>{_docs_ar(len(rows))}.</p>"
            "<table><thead><tr><th>المرجع</th><th>النوع</th><th>وُقّع في</th><th>مرات الإخفاق</th>"
            "<th>المحاولة التالية</th><th>آخر سبب فشل</th><th></th></tr></thead>"
            f"<tbody>{trs or '<tr><td colspan=7>لا شيء</td></tr>'}</tbody></table></div>")


# ─────────────────────────── الربط بالمنصة ───────────────────────────

_ROUTES = {SIGNED_PATH, SIGNED_FILE_PATH, UNSIGNED_REPORT_PATH, PENDING_REPORT_PATH}


def _install_routes(ns: Dict[str, Any]) -> None:
    handler = ns.get("AppHandler")
    if not handler or getattr(handler, "_cu_routes", False):
        return
    base_get, base_post = handler.do_GET, handler.do_POST

    def ctx(self):
        parsed = ns["urlparse"](self.path)
        if parsed.path not in _ROUTES:
            return None, None, None
        user = ns["_v1512_ctx"](self)
        return parsed.path, user, ns["parse_qs"](parsed.query)

    def guard(self, user) -> bool:
        if not user:
            ns["_auth_send_redirect"](self, "/login")
            return False
        if user.get("must_change_password"):
            ns["_auth_send_redirect"](self, "/account")
            return False
        return True

    def num(q, k) -> int:
        v = ((q.get(k) or ["0"])[0] or "0").strip()
        return int(v) if v.isdigit() else 0

    def actor_of(user) -> str:
        return user.get("user_name") or str(user.get("id"))

    def is_admin(user) -> bool:
        return user.get("role") in ADMIN_ROLES

    def page(self, title, body, status=200, active="/reports"):
        return self._send(ns["layout"](title, body, active), status)

    def do_get(self):
        path, user, q = ctx(self)
        if not path:
            return base_get(self)
        if not guard(self, user):
            return
        h = ns["h"]
        try:
            with ns["db"]() as con:
                ensure_schema(con)
                if path == SIGNED_PATH:
                    return page(self, "النسخة الموقّعة", signed_page(con, num(q, "id"), h, is_admin=is_admin(user)),
                                active="/matters")
                if path == SIGNED_FILE_PATH:
                    info = signed_file(con, num(q, "id"))
                    p = Path(info["file_path"]) if info else None
                    if not p or not p.exists():
                        return page(self, "غير موجود", "<div class='error'>لا نسخة موقّعة محفوظة لهذا المستند</div>", 404)
                    ext = p.suffix.lower()
                    return ns["_send_binary_with_disposition"](self, p.read_bytes(), ALLOWED_EXT.get(ext, "application/octet-stream"),
                                                               info["send_name"])
                if path == UNSIGNED_REPORT_PATH:
                    return page(self, "الصادر غير الموقَّع", unsigned_page(con, h, num(q, "days")))
                return page(self, "الموقَّع غير المرفوع", pending_page(con, h, is_admin(user)))
        except cr.RegisterError as exc:
            return page(self, "خطأ", f"<div class='error'>{h(exc)}</div>", 404)

    def do_post(self):
        path, user, q = ctx(self)
        if not path:
            return base_post(self)
        if not guard(self, user):
            return
        h = ns["h"]
        fields, files, ip = ns["_parse_request_fields"](self)
        actor = actor_of(user)
        if path == SIGNED_PATH:
            doc_id = num(q, "id")
            name, content = (files or {}).get("signed_file", ("", b""))
            with ns["db"]() as con:
                ensure_schema(con)
                try:
                    attach_signed(con, doc_id, name, content, actor, ip or "")
                except cr.RegisterError as exc:
                    try:
                        body = signed_page(con, doc_id, h, error=str(exc), is_admin=is_admin(user))
                    except cr.RegisterError:
                        body = f"<div class='error'>{h(exc)}</div>"
                    return page(self, "النسخة الموقّعة", body, 409, "/matters")
                msg, err = "أُرفقت النسخة الموقّعة وصار المستند «موقَّعاً»", ""
                if UPLOAD_ON_ATTACH and cr.get(con, doc_id)["doc_type"] in UPLOADABLE_TYPES:
                    res = upload_document(con, doc_id, actor)
                    if res["ok"]:
                        msg += "؛ ورُفعت حزمته إلى شيربوينت"
                    else:
                        err = "تعذّر الرفع، والمستند في تقرير «الموقَّع غير المرفوع» حتى يُعاد: " + res["error"]
                return page(self, "النسخة الموقّعة", signed_page(con, doc_id, h, msg, err, is_admin(user)),
                            active="/matters")
        if path == PENDING_REPORT_PATH:
            with ns["db"]() as con:
                ensure_schema(con)
                if not is_admin(user):
                    return page(self, "الموقَّع غير المرفوع",
                                pending_page(con, h, False, error="إعادة محاولة الرفع للمدير وحده"), 403)
                raw = ((fields.get("id") or ["0"])[0] or "0").strip()
                doc_id = int(raw) if raw.isdigit() else 0
                try:
                    res = upload_document(con, doc_id, actor)
                except cr.RegisterError as exc:
                    return page(self, "الموقَّع غير المرفوع", pending_page(con, h, True, error=str(exc)), 409)
                ref = cr.get(con, doc_id)["reference_no"]
                if res["ok"]:
                    return page(self, "الموقَّع غير المرفوع", pending_page(con, h, True, message=f"رُفع المستند {ref}"))
                return page(self, "الموقَّع غير المرفوع",
                            pending_page(con, h, True, error=f"تعذّر رفع {ref}: {res['error']}"), 502)
        return page(self, "طلب غير صالح", "<div class='error'>لا يُقبل هذا الطلب هنا</div>", 405)

    handler.do_GET, handler.do_POST = do_get, do_post
    handler._cu_routes = True


def install(ns: Dict[str, Any]) -> None:
    """يُستدعى من آخر app.py بـ globals()، بعد _cr.install(globals())."""
    _NS.clear()
    _NS["_ns"] = ns
    for name in ("audit", "db"):
        if name in ns:
            _NS[name] = cr._Live(ns, name)
    if "DATA_DIR" in ns:
        _NS["DATA_DIR"] = ns["DATA_DIR"]
    base_init = ns.get("init_db")
    if base_init and not getattr(base_init, "_cu_wrapped", False):
        def init_db() -> None:
            base_init()
            with ns["db"]() as con:
                ensure_schema(con)
                con.commit()
        init_db._cu_wrapped = True  # type: ignore[attr-defined]
        ns["init_db"] = init_db
    _install_routes(ns)

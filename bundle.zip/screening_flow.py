# -*- coding: utf-8 -*-
"""مسارات قانونية — فحص العميل وإعادة فحصه الدوري (ملف مستقل؛ يُزال بحذف سطرَي الوصل في آخر app.py).

1- عيبٌ ثبت بالتجربة 30/09: زرّا «المرحلة الأولى» و«المرحلة الثانية» في صفحة العميل يشغّل كلٌّ منهما مرحلته وحدها،
   والمنصة لا تجعل العميل «نشطاً» إلا إذا جرت المرحلتان في تشغيلٍ واحد (run_client_screening بوضع both)؛
   فالعميل النظيف يبقى «مسودة» بعد الزرّين، ويبقى المولّد مغلقاً دونه. وفي المنصة مسارٌ يجمعهما
   (/client/run_screening) بلا زرّ؛ فيُضاف زرٌّ رئيس «افحص العميل (المرحلتان معاً)»، ويبقى الزرّان لإعادة مرحلة وحدها.
2- الفحص الدوري: آخر فحصٍ كامل للعميل = أقدمُ آخرِ مرحلتيه، والموعد القادم بحسب درجة مخاطره (REVIEW_DAYS)؛
   ويُعرض في صفحة العميل، ويظهر من حلّ موعده في «ما ينتظرك» بالرئيسية لمدير النظام ومسؤول الامتثال.
3- المراجعة الدورية بشرية (القرار 203، ملاحظة فابل H1 وموافقة المالك): زرّ «سجّل مراجعة ملف العميل» للشريك ومسؤول
   الامتثال ومدير النظام، والموعد القادم يُحسب من آخر مراجعة؛ والفحص الآلي مراقبة مستمرة منفصلة عنها.
"""
from __future__ import annotations

import datetime as _dt
import re
from typing import Any, Dict, Optional

# مدة إعادة الفحص بحسب درجة المخاطر (بالأيام) — اعتمدها المالك 30/09: ستة أشهر للمرتفع وسنة لغيره
REVIEW_DAYS = {"high": 182, "medium": 365, "normal": 365}
_NS: Dict[str, Any] = {}


def last_full_screening(con, client_id: int) -> Optional[str]:
    """تاريخ آخر فحصٍ كامل: أقدم «آخر مرحلة» من المرحلتين؛ ولا شيء إن نقصت إحداهما."""
    got = []
    for scope in ("internal", "sanctions"):
        # H1 من مراجعة فابل: لا يُعدّ فحصاً ما لم يكتمل لأن القائمة لم تكن متاحة
        r = con.execute("SELECT MAX(created_at) FROM screenings WHERE subject_type='client' AND subject_id=? "
                        "AND screening_scope=? AND COALESCE(status,'')<>'list_unavailable'", (client_id, scope)).fetchone()
        if not r or not r[0]:
            return None
        got.append(r[0])
    return min(got)


def next_due(last: Optional[str], risk: str) -> Optional[_dt.date]:
    if not last:
        return None
    try:
        d = _dt.date.fromisoformat(str(last)[:10])
    except ValueError:
        return None
    return d + _dt.timedelta(days=REVIEW_DAYS.get((risk or "normal").lower(), 365))


REVIEWERS = {"partner", "admin", "compliance"}
REVIEW_PATH = "/client/review_record"


def ensure_reviews(con) -> None:
    con.execute("CREATE TABLE IF NOT EXISTS client_reviews(id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL, "
                "reviewed_at TEXT NOT NULL, reviewer TEXT NOT NULL, note TEXT)")


def last_review(con, client_id: int) -> Optional[str]:
    """آخر مراجعة بشرية لملف العميل (القرار 203)؛ وهي غير الفحص الآلي."""
    ensure_reviews(con)
    r = con.execute("SELECT MAX(reviewed_at) FROM client_reviews WHERE client_id=?", (client_id,)).fetchone()
    return r[0] if r and r[0] else None


def review_due(con, client_id: int, risk: str) -> Optional[_dt.date]:
    """موعد المراجعة القادمة: من آخر مراجعة بشرية، وإن لم يُراجَع الملف قط فمن آخر فحص كامل."""
    return next_due(last_review(con, client_id) or last_full_screening(con, client_id), risk)


def due_clients(con) -> list:
    """العملاء النشطون أو الموافَق عليهم الذين حلّ موعد مراجعة ملفاتهم، أو لم يُفحصوا فحصاً كاملاً ولم يُراجَعوا قط."""
    today = _dt.date.today()
    out = []
    for r in con.execute("SELECT id, risk_level FROM clients WHERE status IN ('active','approved')").fetchall():
        nd = review_due(con, r[0], r[1])
        if nd is None or nd <= today:
            out.append(r[0])
    return out


def _fmt(d) -> str:
    return d.strftime("%d/%m/%Y") + "م" if d else ""


def _client_block(client_id: int) -> str:
    try:
        with _NS["db"]() as con:
            row = con.execute("SELECT risk_level, status FROM clients WHERE id=?", (client_id,)).fetchone()
            last = last_full_screening(con, client_id)
            rev = last_review(con, client_id)
            nd = review_due(con, client_id, row[0] if row else "normal") if row else None
    except Exception:
        return ""
    if not row:
        return ""
    fn = _NS.get("_auth_current_user")
    try:
        role = str(((fn() if fn else None) or {}).get("role") or "")
    except Exception:
        role = ""
    d = lambda v: _fmt(_dt.date.fromisoformat(str(v)[:10]))
    auto = f"آخر فحص آلي كامل: {d(last)}" if last else "لم يُفحص فحصاً كاملاً بعد"
    human = f"آخر مراجعة لملف العميل: {d(rev)}" if rev else "لم يُراجَع ملف العميل بعد"
    due = f"المراجعة القادمة: {_fmt(nd)}" if nd else ""
    late = bool(nd and nd <= _dt.date.today()) or not last
    btn = (f'<form method="post" action="{REVIEW_PATH}" class="ltx-rev"><input type="hidden" name="client_id" value="{client_id}">'
           '<input name="note" placeholder="ملاحظة المراجعة (اختيارية)" autocomplete="off">'
           '<button type="submit" class="btn secondary">سجّل مراجعة ملف العميل</button></form>') if role in REVIEWERS else ""
    return (f'<div class="ltx-screen {"ltx-due" if late else ""}"><form method="post" action="/client/run_screening">'
            f'<input type="hidden" name="client_id" value="{client_id}">'
            f'<button type="submit">افحص العميل (المرحلتان معاً)</button></form>'
            f'<span>{auto} · {human}{" · " + due if due else ""}. والفحص الآلي مراقبة مستمرة؛ والمراجعة الدورية يسجّلها '
            f'الشريك أو مسؤول الامتثال بعد أن يراجع الملف.</span>{btn}</div>')


_ANCHOR = '<div class="grid"><form method="post" action="/client/run_internal_screening">'


def install(ns: Dict[str, Any]) -> None:
    _NS.update(ns)
    base = ns.get("client_detail")
    if not base or getattr(base, "_ltx_screen", False):
        return

    def client_detail(client_id: int) -> bytes:
        raw = base(client_id).decode("utf-8")
        if _ANCHOR in raw and 'class="ltx-screen' not in raw:
            raw = raw.replace(_ANCHOR, _client_block(int(client_id)) + _ANCHOR, 1)
        return raw.encode("utf-8")

    client_detail._ltx_screen = True
    ns["client_detail"] = client_detail
    handler = ns.get("AppHandler")
    if handler and not getattr(handler, "_ltx_review", False):
        base_post = handler.do_POST

        def do_post(self) -> None:
            if ns["urlparse"](self.path).path != REVIEW_PATH:
                return base_post(self)
            user = ns["_v1512_ctx"](self)
            if not user:
                return ns["_auth_send_redirect"](self, "/login")
            fields, _f, ip = ns["_parse_request_fields"](self)
            g = lambda k: ((fields.get(k) or [""])[0] or "").strip()
            cid = int(g("client_id") or 0)
            if user.get("role") not in REVIEWERS:
                return self._send(ns["layout"]("غير مصرّح", "<div class='error'>مراجعة ملف العميل يسجّلها الشريك أو مسؤول "
                                               "الامتثال أو مدير النظام.</div>", "/clients"), 403)
            with ns["db"]() as con:
                ensure_reviews(con)
                con.execute("INSERT INTO client_reviews(client_id, reviewed_at, reviewer, note) VALUES(?,?,?,?)",
                            (cid, ns["now_iso"](), user.get("full_name") or user.get("user_name") or "", g("note")[:1000]))
                ns["audit"](con, "client_periodic_review", "client", cid, g("note")[:200], ip or "")
                con.commit()
            return ns["_auth_send_redirect"](self, f"/client?id={cid}")

        handler.do_POST = do_post
        handler._ltx_review = True

# -*- coding: utf-8 -*-
"""مسارات قانونية — عرض سجل التدقيق بالعربية (موافقة المالك 30/09؛ عرضٌ فقط).

السجل دليل رقابي: لا يُمسّ المحفوظ في القاعدة ولا ملف التصدير؛ والتغيير في صفحة /audit وحدها:
1- قيود «system_init» (تهيئة قاعدة البيانات عند كل تشغيل للخادم، 329 قيداً في نسخة التجربة) تُخفى من الجدول،
   ويُذكر عددها فوقه، ويبقى كلها في السجل المحفوظ والتصدير.
2- رمز الإجراء ونوع الكيان يُعرضان بالعربية، ويبقى الرمز الأصلي في تلميح الخانة (title) لمن يحتاجه.
"""
from __future__ import annotations

import re
from html import escape

ACTIONS = {
    "access_report": "فتح تقرير فحص", "add_client_type": "إضافة نوع عميل", "add_ownership_trace": "إضافة طبقة ملكية",
    "add_service_type": "إضافة نوع خدمة", "add_user": "إضافة مستخدم", "assign_client_partners": "تعيين شريكَي العميل",
    "assign_matter_partners": "تعيين شريكَي التكليف", "background_job_abandoned": "توقّف مهمة خلفية",
    "background_job_enqueued": "بدء مهمة خلفية", "bulk_close_internal_weak": "إغلاق تشابهات داخلية ضعيفة دفعةً",
    "bulk_screening": "فحص جماعي", "change_password": "تغيير كلمة المرور", "client_screening_flag_change": "تغيير علامة فحص العميل",
    "complete_document_obligation": "استكمال مستند مؤجَّل", "compliance_case_created": "فتح حالة امتثال",
    "compliance_report_for_upload": "إعداد تقرير الامتثال للرفع", "controlled_clients_projects_import": "استيراد عملاء وتكليفات",
    "create_backup": "نسخ احتياطي", "create_client": "إنشاء عميل", "create_counterparty": "إضافة طرف مقابل",
    "create_matter": "فتح تكليف", "create_screening_pdf_report": "إصدار تقرير فحص", "create_suspicion_case": "تسجيل بلاغ اشتباه",
    "add_suspicion_case": "تسجيل بلاغ اشتباه", "daily_continuous_screening": "إعادة الفحص الشامل",
    "defer_document": "تأجيل مستند", "delete_or_disable_client_type": "تعطيل نوع عميل",
    "delete_or_disable_service_type": "تعطيل نوع خدمة", "delete_ownership_trace": "حذف طبقة ملكية",
    "evaluate_counterparty_risk": "تقييم مخاطر طرف مقابل", "evaluate_matter_risk": "تقييم مخاطر تكليف",
    "export_audit_log": "تصدير سجل التدقيق", "export_bulk_screening_excel": "تصدير فحص جماعي",
    "export_sanctions_excel": "تصدير قائمة عقوبات", "extend_document_obligation": "تمديد موعد مستند",
    "generate_batch_report": "إصدار تقرير دوري", "generate_client_report": "إصدار تقرير عميل",
    "governance_facts_update": "تحديث بيانات الحوكمة", "import_sanctions_list": "رفع قائمة عقوبات",
    "import_sanctions_list_multiformat": "رفع قائمة عقوبات", "import_sanctions_list_multiformat_failed": "تعذّر رفع قائمة عقوبات",
    "import_sanctions_list_multiformat_validated": "التحقق من قائمة عقوبات", "inspection_auto_fill": "تعبئة جاهزية التفتيش تلقائياً",
    "inspection_item_update": "تحديث بند في جاهزية التفتيش", "maintenance_check": "فحص الصيانة",
    "matter_add_client": "إضافة عميل إلى التكليف", "matter_remove_client": "إزالة عميل من التكليف",
    "matter_screening_no_subjects": "فحص تكليف بلا أطراف", "matter_set_instructing_clients": "تحديد العملاء الموكِّلين",
    "matter_set_lead_client": "تحديد العميل الرئيس", "official_lists_refresh": "تحديث القوائم الرسمية",
    "partner_decision": "قرار الشريك", "pep_assessment": "تقييم المعرّض سياسياً", "quick_screening": "فحص سريع",
    "reclassify_sameseat_links": "إعادة تصنيف صلات المقعد الواحد", "reset_user_password": "إعادة تعيين كلمة مرور",
    "restore_backup": "استعادة نسخة احتياطية", "run_screening": "تشغيل الفحص", "toggle_client_type": "تفعيل نوع عميل أو تعطيله",
    "toggle_service_type": "تفعيل نوع خدمة أو تعطيله", "toggle_user_active": "تفعيل مستخدم أو تعطيله",
    "ubo_verification": "التحقق من المستفيد الحقيقي", "update_client": "تعديل بيانات عميل", "update_client_type": "تعديل نوع عميل",
    "update_company_settings": "تعديل بيانات الشركة", "update_counterparty": "تعديل طرف مقابل",
    "update_document_policy": "تعديل سياسة المستندات", "update_matter": "تعديل تكليف", "update_matter_partners": "تعديل شريكَي التكليف",
    "update_ownership_trace": "تعديل طبقة ملكية", "update_screening_status": "قرار في نتيجة فحص", "update_service_type": "تعديل نوع خدمة",
    "update_user": "تعديل مستخدم", "view_screening_detail": "الاطلاع على تفاصيل نتيجة فحص", "wathq_apply": "اعتماد بيانات واثق",
    "wathq_selftest": "اختبار الربط بواثق", "client_periodic_review": "مراجعة دورية لملف العميل", "system_init": "تهيئة قاعدة البيانات",
    # وحداتنا
    "document_issued": "إصدار اتفاقية", "document_regenerated": "إعادة إنشاء اتفاقية", "document_signed": "إرفاق النسخة الموقّعة",
    "document_uploaded": "رفع إلى شيربوينت", "document_withdrawn": "سحب اتفاقية", "document_upload_failed": "تعذّر الرفع إلى شيربوينت",
    "matter_team_set": "تحديد فريق التكليف", "client_contract_fields_set": "بيانات العميل للعقد",
    "staff_directory_imported": "استيراد دليل الموظفين", "matter_number_duplicates_found": "رقم تكليف مكرر",
}
ENTITIES = {
    "client": "عميل", "matter": "تكليف", "counterparty": "طرف مقابل", "screening": "فحص", "screening_report": "تقرير فحص",
    "settings": "الإعدادات", "app_user": "مستخدم", "job": "مهمة خلفية", "outstanding_document": "مستند مؤجَّل",
    "data_import": "استيراد", "backup": "نسخة احتياطية", "suspicion_case": "بلاغ اشتباه", "audit": "سجل التدقيق",
    "sanctions_list": "قائمة عقوبات", "report": "تقرير", "governance": "الحوكمة", "sanctions_import": "رفع قائمة",
    "inspection": "جاهزية التفتيش", "database": "قاعدة البيانات", "sanctions": "القوائم", "wathq": "واثق",
    "issued_document": "اتفاقية", "staff": "الموظفون",
}

_HEAD = "<th>الإجراء</th><th>الكيان</th>"
_ROW = re.compile(r"<tr>((?:<td>.*?</td>){3,}?)</tr>", re.S)


def apply(raw: str) -> str:
    if _HEAD not in raw or "ltx-audit" in raw:
        return raw
    heads = re.findall(r"<th>(.*?)</th>", raw[raw.rfind("<thead>", 0, raw.find(_HEAD)):raw.find("</thead>", raw.find(_HEAD))])
    try:
        ia, ie = heads.index("الإجراء"), heads.index("الكيان")
    except ValueError:
        return raw
    hidden = 0

    def row(m: "re.Match[str]") -> str:
        nonlocal hidden
        cells = re.findall(r"<td>(.*?)</td>", m.group(0), re.S)
        if len(cells) <= max(ia, ie):
            return m.group(0)
        code, ent = cells[ia].strip(), cells[ie].strip()
        if code == "system_init":
            hidden += 1
            return ""
        out = list(cells)
        if code in ACTIONS:
            out[ia] = f'<span title="{escape(code)}">{ACTIONS[code]}</span>'
        if ent in ENTITIES:
            out[ie] = f'<span title="{escape(ent)}">{ENTITIES[ent]}</span>'
        return "<tr>" + "".join(f"<td>{c}</td>" for c in out) + "</tr>"

    body_start = raw.find("<tbody>", raw.find(_HEAD))
    body_end = raw.find("</tbody>", body_start)
    if body_start == -1 or body_end == -1:
        return raw
    body = _ROW.sub(row, raw[body_start:body_end])
    word = ({1: "قيد واحد", 2: "قيدان"}.get(hidden) or (f"{hidden} قيود" if hidden <= 10 else f"{hidden} قيداً"))
    note = (f'<p class="small ltx-audit">أُخفي من هذا العرض {word} لتهيئة قاعدة البيانات عند تشغيل الخادم؛ '
            'وهي باقية في السجل المحفوظ وفي التصدير.</p>') if hidden else '<span class="ltx-audit"></span>'
    tbl = raw.rfind("<table", 0, body_start)
    return raw[:tbl] + note + raw[tbl:body_start] + body + raw[body_end:]

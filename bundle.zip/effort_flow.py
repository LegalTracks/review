# -*- coding: utf-8 -*-
"""مسارات قانونية — تقليل جهد الإداري في رحلة العميل (ملف مستقل؛ يُزال بحذف سطرَي الوصل في آخر app.py).

المواصفة: rules/FABLE-EFFORT-REVIEW-2026-10-01.md — التوصيات العشر، ووافق المالك 01/10 على تطبيقها كلها.
1- الفحص بالمرحلتين يجري تلقائياً عند حفظ العميل وبعد إضافة طرف، والنتيجة شريطٌ أعلى صفحة العميل بدل صفحة
   «تم تشغيل الفحص… العودة للعميل». المسار نفسه (run_client_screening) وصفوف التدقيق نفسها، والبوابة لا تتغير.
2- مصدر الأموال: اختيارٌ من ثلاثة، وتحقّقٌ في الصفحة قبل الإرسال، وإن ردّ الخادم خطأً عاد النموذج بما كُتب فيه؛
   وقاعدة «السبب عند عدم التوثيق» باقية كما هي.
3- الشريك مرة واحدة: شريكا التكليف من ملف العميل، والشريك المسؤول في الفريق من الشريك المدير بربط حسابه ببريده
   في سجل الموظفين (user_name = البريد، القرار 192)، ثم بالاسم إن لم يكن الحساب بريداً.
4- المالك مرة واحدة: الطبقة الأولى من سلسلة الملكية تُشتق من أطراف العميل ذوي النسبة (source='party')،
   ولا يُعدّ المشتق في مؤشر «هيكل ملكية متعدد الطبقات».
5- الفريق في نموذج التكليف: الشريك المسؤول والمنشئ وحدهما افتراضاً؛ وصفحة الفريق باقية للتعديل.
6- بيانات العميل للعقد مطويّة في صفحة الإصدار، وتُحفظ عند «إنشاء الاتفاقية»؛ وممثل التوقيع يُختار من أطراف العميل.
7- أربعة أنماط جاهزة في صفحة الإصدار؛ لا تُنشئ شيئاً، وأثرها في «ما يدخل العقد».
8- بعد «إنشاء الاتفاقية» صفحة «صدرت الاتفاقية» بالملف والمرجع والخطوة التالية؛ والملف في ذاكرة الخادم ساعةً
   لا يُخزَّن (القرار 58: لا نسخة قبل التوقيع).
9- العميل الفرد يرى صفحة فرد: بلا أطراف مجلس ولا سلسلة ملكية ولا رقم موحّد ولا حقول ممثل منشأة.
10- افتراضات النماذج الصغيرة، وتنبيه السجل المكرر، وحقل العنوان الوطني، ومنع العميل بلا اسم في الخادم.
ومعها «اجلب من واثق» في نموذج العميل الجديد بمعاينته ومصدره؛ ويعمل كما اليوم إن لم تُفعَّل الخدمة.

لا يُضعف ضابطاً: لا فحص يُتجاوز، ولا موافقة تلقائية، ولا سبب افتراضي لعدم توثيق المصدر، ولا فريق مختار سلفاً
فوق الشريك والمنشئ، ولا ممثل توقيع يُختار خفيةً، والتكرار تنبيهٌ يُتجاوز بإقرارٍ مقيَّد في سجل التدقيق.
"""
from __future__ import annotations

import html as _html
import io
import json
import re
import secrets
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

_NS: Dict[str, Any] = {}
_TL = threading.local()             # ما يمرّ من المسار إلى صانع الصفحة في الطلب نفسه (الشريط، والخطأ)
_FILES: Dict[str, Dict[str, Any]] = {}
_FILES_LOCK = threading.Lock()
FILE_TTL = 3600                     # ساعة: الملف في الذاكرة وحدها، ولا يُكتب على القرص

NEW_CLIENT = "/clients/new"
WATHQ_NEW = "/clients/new/wathq"
DUP_CHECK = "/clients/dup-check"
ISSUED_PATH = "/matter/agreement/issued"
ISSUED_FILE = "/matter/agreement/file"
WATHQ_ROLES = {"admin", "compliance"}   # كما في /wathq/fetch

# ─────────────── الجنسية من الدولة (التوصية 10) ───────────────
# النسبة المذكّرة للفرد والطرف؛ وللمنشأة تؤنَّث («سعودية»). وما لا نسبة له هنا تُكتب الدولة نفسها، ويُعدَّل باليد.
DEMONYM = {
    "المملكة العربية السعودية": "سعودي", "الإمارات العربية المتحدة": "إماراتي", "البحرين": "بحريني", "الكويت": "كويتي",
    "قطر": "قطري", "عُمان": "عماني", "اليمن": "يمني", "العراق": "عراقي", "الأردن": "أردني", "سوريا": "سوري",
    "لبنان": "لبناني", "فلسطين": "فلسطيني", "مصر": "مصري", "السودان": "سوداني", "ليبيا": "ليبي", "تونس": "تونسي",
    "الجزائر": "جزائري", "المغرب": "مغربي", "موريتانيا": "موريتاني", "الصومال": "صومالي", "جيبوتي": "جيبوتي",
    "تركيا": "تركي", "إيران": "إيراني", "أفغانستان": "أفغاني", "باكستان": "باكستاني", "الهند": "هندي",
    "بنغلاديش": "بنغلاديشي", "سريلانكا": "سريلانكي", "نيبال": "نيبالي", "الصين": "صيني", "اليابان": "ياباني",
    "إندونيسيا": "إندونيسي", "ماليزيا": "ماليزي", "الفلبين": "فلبيني", "المملكة المتحدة": "بريطاني",
    "فرنسا": "فرنسي", "ألمانيا": "ألماني", "إيطاليا": "إيطالي", "إسبانيا": "إسباني", "البرتغال": "برتغالي",
    "هولندا": "هولندي", "سويسرا": "سويسري", "اليونان": "يوناني", "روسيا": "روسي", "الولايات المتحدة": "أمريكي",
    "كندا": "كندي", "أستراليا": "أسترالي", "إثيوبيا": "إثيوبي", "نيجيريا": "نيجيري", "كينيا": "كيني",
}


def nationality_for(country: str, entity: bool = False) -> str:
    c = (country or "").strip()
    d = DEMONYM.get(c)
    if not d:
        return c
    return d + "ة" if entity else d


# ─────────────── أدوات ───────────────
def _h(v: Any) -> str:
    return _NS["h"](v)


def _one(fields: Dict[str, List[str]], k: str) -> str:
    return ((fields.get(k) or [""])[0] or "").strip()


def _digits(s: str) -> str:
    s = (s or "").translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
    return "".join(ch for ch in s if ch.isdigit())


def _ctx(handler) -> Optional[Dict[str, Any]]:
    return _NS["_v1512_ctx"](handler)


def _guard(handler, user) -> bool:
    if not user:
        _NS["_auth_send_redirect"](handler, "/login")
        return False
    if user.get("must_change_password"):
        _NS["_auth_send_redirect"](handler, "/account")
        return False
    return True


def _read(handler) -> Tuple[Dict[str, List[str]], Dict[str, Any], str, bytes]:
    """يقرأ الطلب ثم يعيد جسمه كما كان، فيقرؤه المسار الأصلي إن سُلِّم إليه."""
    length = int(handler.headers.get("Content-Length", "0") or 0)
    raw = handler.rfile.read(length)
    handler.rfile = io.BytesIO(raw)
    fields, files, ip = _NS["_parse_request_fields"](handler)
    handler.rfile = io.BytesIO(raw)
    return fields, files, ip, raw


def _actor(user: Dict[str, Any]) -> str:
    return str(user.get("user_name") or user.get("id") or "")


# ─────────────── إعادة ملء النموذج بما كُتب (التوصية 2) ───────────────
_RE_ATTR_NAME = re.compile(r"""\bname\s*=\s*(["'])(.*?)\1""", re.S)
_RE_ATTR_TYPE = re.compile(r"""\btype\s*=\s*(["']?)([\w-]+)\1""", re.I)
_RE_ATTR_VALUE = re.compile(r"""\svalue\s*=\s*(["'])(.*?)\1""", re.S)


def _set_select(page: str, name: str, value: str) -> str:
    pat = re.compile(r"(<select\b[^>]*\bname\s*=\s*[\"']" + re.escape(name) + r"[\"'][^>]*>)(.*?)(</select>)", re.S)

    def one(m: "re.Match[str]") -> str:
        body = re.sub(r"\sselected(?:=[\"']selected[\"'])?(?=[\s>])", "", m.group(2))

        def opt(o: "re.Match[str]") -> str:
            v = _RE_ATTR_VALUE.search(o.group(0))
            ov = _html.unescape(v.group(2)) if v else ""
            return o.group(0)[:-1] + " selected>" if ov == value else o.group(0)
        return m.group(1) + re.sub(r"<option\b[^>]*>", opt, body) + m.group(3)
    return pat.sub(one, page, count=1)


def refill(page: str, fields: Dict[str, List[str]], only: Optional[str] = None) -> str:
    """يملأ حقول النموذج بما أُرسل: النص والنص الطويل والقوائم والخيارات. والمخفي والملف لا يُمسّان."""
    if only:                                     # نموذج واحد بعينه في الصفحة
        m = re.search(r"<form\b[^>]*action=[\"']" + re.escape(only) + r"[\"'?][^>]*>.*?</form>", page, re.S)
        if not m:
            return page
        return page[:m.start()] + refill(m.group(0), fields) + page[m.end():]

    def inp(m: "re.Match[str]") -> str:
        tag = m.group(0)
        nm = _RE_ATTR_NAME.search(tag)
        if not nm or nm.group(2) not in fields:
            return tag
        t = (_RE_ATTR_TYPE.search(tag).group(2).lower() if _RE_ATTR_TYPE.search(tag) else "text")
        if t in ("hidden", "file", "submit", "button", "password"):
            return tag
        vals = fields.get(nm.group(2)) or []
        if t in ("checkbox", "radio"):
            v = _RE_ATTR_VALUE.search(tag)
            on = (_html.unescape(v.group(2)) if v else "on") in vals
            tag = re.sub(r"\schecked(?:=[\"']checked[\"'])?(?=[\s/>])", "", tag)
            return tag[:-1].rstrip("/") + (" checked>" if on else ">")
        val = _h(vals[0] if vals else "")
        if _RE_ATTR_VALUE.search(tag):
            return _RE_ATTR_VALUE.sub(lambda _m: f' value="{val}"', tag, count=1)
        return tag[:-1] + f' value="{val}">'
    page = re.sub(r"<input\b[^>]*>", inp, page)
    for name, vals in fields.items():
        v = vals[0] if vals else ""
        page = re.sub(r"(<textarea\b[^>]*\bname\s*=\s*[\"']" + re.escape(name) + r"[\"'][^>]*>).*?(</textarea>)",
                      lambda m: m.group(1) + _h(v) + m.group(2), page, count=1, flags=re.S)
        if re.search(r"<select\b[^>]*\bname\s*=\s*[\"']" + re.escape(name) + r"[\"'][^>]*\bmultiple", page):
            continue
        page = _set_select(page, name, v)
    return page


def _card_span(page: str, anchor: str) -> Optional[Tuple[int, int]]:
    """موضع البطاقة <div class="card"> التي تحوي النص المرتكز، بعدّ الوسوم المفتوحة والمغلقة."""
    p = page.find(anchor)
    if p < 0:
        return None
    start = page.rfind('<div class="card"', 0, p)
    if start < 0:
        return None
    depth, i = 0, start
    for m in re.finditer(r"<div\b|</div>", page[start:]):
        depth += 1 if m.group(0) == "<div" else -1
        if depth == 0:
            end = start + m.end()
            return (start, end) if start <= p < end else None
    return None


def _cut_card(page: str, anchor: str, replacement: str = "") -> str:
    span = _card_span(page, anchor)
    return page[:span[0]] + replacement + page[span[1]:] if span else page


def _after_main(page: str, snippet: str) -> str:
    tag = '<main id="lt-main" tabindex="-1">'
    return page.replace(tag, tag + snippet, 1) if tag in page else snippet + page


STYLE = """<style id="ltx-effort">
.ltx-banner{margin:0 0 14px;padding:12px 16px;line-height:1.9}
.ltx-banner b{font-weight:700}.ltx-banner a{font-weight:700;text-decoration:underline;text-underline-offset:4px}
fieldset.ltx-src{border:1px solid var(--lx-line,#DDD5C7);border-radius:3px;padding:12px 16px;margin:14px 0}
fieldset.ltx-src legend{font-weight:700;padding:0 6px}
.ltx-src label.ltx-opt{display:flex;gap:8px;align-items:flex-start;margin:6px 0;font-weight:400;cursor:pointer}
.ltx-src label.ltx-opt input{width:auto;margin-top:6px}
.ltx-src label.ltx-opt.ltx-off{opacity:.55;cursor:not-allowed}
.ltx-msg{color:#9A3412;font-weight:700;margin:8px 0}
.ltx-dup{margin:6px 0;padding:8px 12px;background:#FBF6EC;border:1px solid #E6D5B8;border-radius:3px;font-size:14px}
.ltx-presets{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:4px 0 12px}
.ltx-presets span{font-weight:700}
.ltx-presets button[aria-pressed=true]{outline:2px solid #244037;outline-offset:1px}
.ltx-check{list-style:none;margin:8px 0 12px;padding:0;display:flex;flex-wrap:wrap;gap:6px 22px;font-size:14px}
.ltx-check li::before{content:"○";margin-inline-end:6px;color:#B45309}.ltx-check li.ltx-have::before{content:"✓";color:#2E8C73}
.ltx-issued ol{line-height:2}.ltx-issued .btn{margin-inline-end:8px}
.ltx-derived{font-size:12px;color:#6B6B6B}
#ltx-team .ltx-members{display:flex;flex-wrap:wrap;gap:6px 18px;margin:8px 0}
#ltx-team .ltx-members label{display:flex;gap:6px;align-items:center;font-weight:400}
#ltx-team .ltx-members input{width:auto}
details.ltx-cf-fold>summary{cursor:pointer;list-style:none}
details.ltx-cf-fold>summary::-webkit-details-marker{display:none}
details.ltx-cf-fold>summary h3{display:inline;margin:0}
details.ltx-cf-fold>summary .ltx-cf-sum{font-size:14px;color:#6B6B6B;margin-inline-start:10px}
</style>"""


# ═══════════════════════ 1- الفحص التلقائي والشريط ═══════════════════════
def screen_now(cid: int, ip: str = "") -> str:
    """المرحلتان معاً بالمسار نفسه؛ وتعذّره لا يمنع الحفظ، بل يقوله الشريط."""
    try:
        r = _NS["run_client_screening"](int(cid), ip, "both") or {}
        return f"{int(r.get('created', 0))}.{int(r.get('hits', 0))}.{int(r.get('warnings', 0))}"
    except Exception:
        return "fail"


def banner_html(cid: int, screened: str, frm: str) -> str:
    try:
        with _NS["db"]() as con:
            c = con.execute("SELECT status FROM clients WHERE id=?", (cid,)).fetchone()
            if not c:
                return ""
            status = c[0] or ""
            last = {}
            for scope in ("internal", "sanctions"):
                r = con.execute("SELECT status FROM screenings WHERE subject_type='client' AND subject_id=? AND screening_scope=? "
                                "ORDER BY id DESC LIMIT 1", (cid, scope)).fetchone()
                last[scope] = (r[0] if r else "") or ""
            n_matters = con.execute("SELECT COUNT(*) FROM matters WHERE client_id=?", (cid,)).fetchone()[0]
    except Exception:
        return ""
    lead = {"new": "حُفظ ملف العميل؛ و", "party": "أُضيف الطرف؛ و"}.get(frm, "")
    if screened == "fail":
        return (f'<div class="error ltx-banner" role="alert">{lead}تعذّر الفحص التلقائي هذه المرة؛ '
                'فاضغط «افحص العميل (المرحلتان معاً)» أدناه.</div>')
    parts = (screened or "0.0.0").split(".")
    hits = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
    if not hits and "list_unavailable" in last.values():
        # الفحص بلا قوائم يُبقي العميل «قيد المراجعة» بتصميم المنصة؛ فيُقال سببه لا أن تطابقاً ظهر
        return (f'<div class="notice ltx-banner" role="status">{lead}جرى فحص العميل بالمرحلتين ولم يكتمل؛ لأن قوائم العقوبات '
                'غير محمَّلة في المنصة الآن، فتبقى حالته «قيد المراجعة» حتى تُحمَّل ويُعاد الفحص.</div>')
    if status == "under_review" or hits:
        return (f'<div class="error ltx-banner" role="alert">{lead}فُحص العميل بالمرحلتين فظهر في الفحص ما يشبه اسماً في القوائم '
                'أو في ملفات المكتب؛ فحالته «قيد المراجعة»، ولا يُفتح له تكليف ولا تصدر له اتفاقية حتى يحسم مسؤول الامتثال '
                'النتيجة: <a href="/screenings?filter=open">افتح النتائج التي تنتظر قراراً</a>.</div>')
    if status in ("active", "approved"):
        nxt = (f'؛ والخطوة التالية: <a href="/matters/new?client_id={cid}">افتح أول تكليف له</a>' if not n_matters else "")
        return (f'<div class="success ltx-banner" role="status">{lead}فُحص العميل الآن بالمرحلتين -تعارض المصالح وقوائم العقوبات- '
                f'فلم يظهر تطابق؛ وحالته «نشط»{nxt}.</div>')
    import contracts_register as cr
    st_ar = cr.CLIENT_STATUS_AR.get(status, "غير محددة")
    return (f'<div class="notice ltx-banner" role="status">{lead}جرى فحص العميل؛ وحالته «{_h(st_ar)}»، '
            'فراجع «آخر نتائج الفحص» أدناه.</div>')


# ═══════════════════════ 2- مصدر الأموال: الاختيار والتحقق ═══════════════════════
NOT_NEEDED_REASON = ("لا يلزم توثيق مصدر الأموال والثروة لعميل عادي المخاطر عند فتح ملفه؛ ويُطلب إن ارتفعت المخاطر "
                     "أو طلبه مسؤول الامتثال.")
_RE_SRC_BLOCK = re.compile(r'<label>[^<]*</label><textarea name="source_of_funds"></textarea>.*?'
                           r'<textarea name="source_notes"[^>]*></textarea>\s*<p class="notice">.*?</p>', re.S)


def _src_block() -> str:
    return f"""<div class="ltx-dup" id="ltx-dup" role="status" hidden></div><fieldset class="ltx-src" id="ltx-src"><legend>مصدر الأموال والثروة</legend>
<p class="small">اختر واحداً مما يلي؛ ولا يُحفظ العميل حتى يُكتب المصدر أو سبب عدم توثيقه.</p>
<label class="ltx-opt"><input type="radio" name="src_mode" value="documented"><span><b>موثَّق</b>: اكتب مصدر الأموال، ومصدر الثروة إن عُرف.</span></label>
<div data-src="documented"><label>مصدر الأموال</label><textarea name="source_of_funds"></textarea>
<label>مصدر الثروة (إن عُرف)</label><textarea name="source_of_wealth"></textarea></div>
<label class="ltx-opt" id="ltx-src-nn"><input type="radio" name="src_mode" value="not_needed"><span><b>لا يلزم توثيقه</b> لأن مخاطر العميل «عادي»؛ ويُكتب السبب تلقائياً وتعدّله إن شئت.</span></label>
<label class="ltx-opt"><input type="radio" name="src_mode" value="unavailable"><span><b>تعذّر توثيقه</b>، واكتب السبب.</span></label>
<div data-src="skip"><label>سبب عدم توثيق مصدر الأموال أو الثروة</label><textarea name="source_notes" placeholder="مثال: لم تتوفر المعلومة في مرحلة الرأي المبدئي، وسيتم طلبها عند ارتفاع المخاطر أو قبل القبول النهائي."></textarea></div>
<div class="ltx-msg" id="ltx-src-msg" role="alert" hidden></div>
</fieldset>"""


def src_problem(fields: Dict[str, List[str]]) -> str:
    """ما يمنع الحفظ في مصدر الأموال، بالقاعدة نفسها التي في create_client، مع الاختيار الجديد."""
    mode = _one(fields, "src_mode")
    funds, wealth, notes = _one(fields, "source_of_funds"), _one(fields, "source_of_wealth"), _one(fields, "source_notes")
    if mode == "documented" and not (funds or wealth):
        return "اخترتَ «موثَّق» ولم تكتب مصدر الأموال أو الثروة؛ فاكتبه، أو اختر «تعذّر توثيقه» واذكر السبب."
    if mode == "not_needed" and (_one(fields, "risk_level") or "normal") != "normal":
        return "«لا يلزم توثيقه» لعميلٍ مخاطره «عادي» وحده؛ ومخاطر هذا العميل أعلى، فاكتب المصدر أو سبب تعذّره."
    if mode == "unavailable" and not notes:
        return "اخترتَ «تعذّر توثيقه» ولم تكتب السبب؛ والسبب يلزم كلما لم يُوثَّق المصدر."
    if not mode and not (funds or wealth) and not notes:
        return "مصدر الأموال: اختر «موثَّق» واكتبه، أو اذكر سبب عدم توثيقه؛ فالسبب يلزم كلما لم يُوثَّق المصدر."
    return ""


def normalize_src(fields: Dict[str, List[str]]) -> None:
    mode = _one(fields, "src_mode")
    if mode == "documented":
        fields["source_notes"] = [""]
    elif mode in ("not_needed", "unavailable"):
        fields["source_of_funds"], fields["source_of_wealth"] = [""], [""]
        if mode == "not_needed" and not _one(fields, "source_notes"):
            fields["source_notes"] = [NOT_NEEDED_REASON]      # الاختيار نفسه هو السبب المكتوب، لا افتراض خفي


CLIENT_FORM_SCRIPT = """<script>(function(){
var f=document.querySelector('form[action="/clients/new"]');if(!f)return;
var NAT=__NAT__,NN='__NN__';
function el(n){return f.querySelector('[name="'+n+'"]');}
function row(n){var e=el(n);return e?e.closest('div'):null;}
function show(r,on){if(r)r.hidden=!on;}
var ct=el('client_type'),dt=el('document_type'),dtTouched=false,natAuto='';
if(dt)dt.addEventListener('change',function(e){if(e.isTrusted)dtTouched=true;});
function kind(){var t=ct?ct.value:'company',ind=t==='individual';
 show(row('id_number'),ind);show(row('registration_number'),!ind);show(row('unified_number'),!ind);show(row('listed_saudi_market'),t==='company');
 if(dt&&!dtTouched){if(ind&&dt.value==='commercial_registration')dt.value='national_id';if(!ind&&dt.value==='national_id')dt.value='commercial_registration';}
 nat();}
function nat(){var c=el('country'),n=el('nationality');if(!c||!n)return;var ent=ct&&ct.value!=='individual';
 var d=NAT[c.value.trim()];var v=d?(ent?d+'\\u0629':d):c.value.trim();
 if(!n.value.trim()||n.value===natAuto){n.value=v;natAuto=v;}}
if(ct)ct.addEventListener('change',kind);var cc=el('country');if(cc){cc.addEventListener('change',nat);cc.addEventListener('input',nat);}
// مصدر الأموال
var box=document.getElementById('ltx-src'),msg=document.getElementById('ltx-src-msg'),risk=el('risk_level');
function mode(){var r=f.querySelector('[name=src_mode]:checked');return r?r.value:'';}
function src(){var m=mode();box.querySelectorAll('[data-src]').forEach(function(d){var k=d.getAttribute('data-src');
  d.hidden=!(m?(k==='documented'?m==='documented':m!=='documented'):true);});
 var nn=document.getElementById('ltx-src-nn'),ok=!risk||risk.value==='normal',ri=nn.querySelector('input');
 ri.disabled=!ok;nn.classList.toggle('ltx-off',!ok);if(!ok&&ri.checked){ri.checked=false;}
 var notes=el('source_notes');if(m==='not_needed'&&notes&&!notes.value.trim())notes.value=NN;
 if(m!=='not_needed'&&notes&&notes.value===NN)notes.value='';msg.hidden=true;}
if(box){box.addEventListener('change',src);if(risk)risk.addEventListener('change',src);src();}
function problem(){var m=mode(),fu=(el('source_of_funds').value+el('source_of_wealth').value).trim(),no=el('source_notes').value.trim();
 if(m==='documented'&&!fu)return 'اخترتَ «موثَّق» ولم تكتب مصدر الأموال أو الثروة.';
 if(m==='unavailable'&&!no)return 'اكتب سبب تعذّر التوثيق؛ فالسبب يلزم كلما لم يُوثَّق المصدر.';
 if(!m&&!fu&&!no)return 'اختر واحداً في «مصدر الأموال والثروة»: موثَّق، أو لا يلزم، أو تعذّر مع سببه.';return '';}
f.addEventListener('submit',function(e){var sb=e.submitter;if(sb&&sb.getAttribute('formaction'))return;
 var p=box?problem():'';if(!p)return;e.preventDefault();msg.textContent=p;msg.hidden=false;box.scrollIntoView({block:'center'});
 var r=f.querySelector('[name=src_mode]');if(r)r.focus();});
// تنبيه السجل المكرر عند الكتابة (تنبيه لا منع)
var dup=document.getElementById('ltx-dup'),timer=null;
function check(){if(!dup)return;var q=['registration_number','unified_number','id_number'].map(function(n){var e=el(n);return n+'='+encodeURIComponent(e?e.value.trim():'');}).join('&');
 fetch('__DUP__?'+q,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
  if(!j.matches||!j.matches.length){dup.hidden=true;dup.innerHTML='';return;}
  dup.innerHTML='';var b=document.createElement('b');b.textContent='تنبيه: في المنصة ملفٌّ بالرقم نفسه: ';dup.appendChild(b);
  j.matches.forEach(function(m,i){var a=document.createElement('a');a.href='/client?id='+m.id;a.textContent=m.name+' ('+m.by+')';
   if(i)dup.appendChild(document.createTextNode('، '));dup.appendChild(a);});
  dup.appendChild(document.createTextNode('؛ فافتحه بدل ملف جديد، أو أكمل إن كان عميلاً آخر.'));dup.hidden=false;}).catch(function(){});}
['registration_number','unified_number','id_number'].forEach(function(n){var e=el(n);if(e)e.addEventListener('change',function(){clearTimeout(timer);timer=setTimeout(check,150);});});
kind();})();</script>"""


def _client_form_page(user: Optional[Dict[str, Any]], fields: Optional[Dict[str, List[str]]] = None, error: str = "",
                      notice: str = "", extra: str = "") -> bytes:
    raw = _NS["client_form"]().decode("utf-8")
    if fields:
        raw = refill(raw, fields, only=NEW_CLIENT)
    box = ""
    if error:
        box += f'<div class="error ltx-banner" role="alert">{_h(error)}</div>'
    if notice:
        box += f'<div class="notice ltx-banner" role="status">{notice}</div>'
    keep = ""
    if fields and _one(fields, "wathq_cr") and "wathq_cr" not in extra:
        # معاينة واثق التي سبقت تبقى مع إعادة النموذج، فلا يضيع مصدر البيانات
        keep = (f'<input type="hidden" name="wathq_cr" value="{_h(_one(fields, "wathq_cr"))}" form="ltx-newclient">'
                f'<input type="hidden" name="import_parties" value="{_h(_one(fields, "import_parties"))}" form="ltx-newclient">')
    if box or extra or keep:
        raw = raw.replace('<form id="ltx-newclient"', box + extra + keep + '<form id="ltx-newclient"', 1)
    return raw.encode("utf-8")


# ═══════════════════════ 10- السجل المكرر ═══════════════════════
def duplicates(con, reg: str, uni: str, idn: str, exclude: int = 0) -> List[Dict[str, Any]]:
    keys = [("registration_number", _digits(reg), "السجل التجاري"), ("unified_number", _digits(uni), "الرقم الموحّد"),
            ("id_number", _digits(idn), "رقم الهوية")]
    keys = [k for k in keys if len(k[1]) >= 5]
    if not keys:
        return []
    out = []
    for r in con.execute("SELECT id, legal_name, client_code, registration_number, unified_number, id_number FROM clients"):
        if int(r[0]) == int(exclude or 0):
            continue
        by = [lbl for col, val, lbl in keys if _digits(r[{"registration_number": 3, "unified_number": 4, "id_number": 5}[col]] or "") == val]
        if by:
            out.append({"id": int(r[0]), "name": r[1] or "", "code": r[2] or "", "by": "، ".join(by)})
    return out


def _dup_box(dups: List[Dict[str, Any]]) -> str:
    links = "، ".join(f'<a href="/client?id={d["id"]}">{_h(d["name"])}</a> ({_h(d["by"])})' for d in dups)
    return (f'<div class="notice ltx-banner" role="alert"><b>في المنصة ملفٌّ بالرقم نفسه:</b> {links}؛ '
            'فافتحه بدل فتح ملف جديد. وإن كان عميلاً آخر حقاً فضع علامة الإقرار ثم احفظ؛ ويُقيَّد الإقرار في سجل التدقيق.'
            '<label style="display:flex;gap:8px;align-items:center;margin-top:8px;font-weight:700">'
            '<input type="checkbox" name="dup_ok" value="1" form="ltx-newclient" style="width:auto">'
            'أعلم أن له ملفاً، وأريد فتح ملف جديد له</label></div>')


# ═══════════════════════ 3- ربط الشريك بسجل الموظفين ═══════════════════════
def partner_email(con, full_name: str) -> str:
    """بريد الشريك في سجل الموظفين من اسم حسابه: الحساب بريدٌ (القرار 192) فيُطابَق، وإلا فالاسم إن انفرد."""
    name = (full_name or "").strip()
    if not name:
        return ""
    sig = {r[0].lower(): r for r in con.execute(
        "SELECT email, name_ar, COALESCE(sign_name_ar,'') FROM staff_directory WHERE is_signatory=1 AND is_active=1")}
    for (un,) in con.execute("SELECT user_name FROM app_users WHERE role='partner' AND is_active=1 AND full_name=?", (name,)):
        if (un or "").lower() in sig:
            return (un or "").lower()
    hits = [e for e, r in sig.items() if name in ((r[1] or "").strip(), (r[2] or "").strip())]
    return hits[0] if len(hits) == 1 else ""


def partner_map(con) -> Dict[str, str]:
    out = {}
    for (fn,) in con.execute("SELECT full_name FROM app_users WHERE role='partner' AND is_active=1"):
        em = partner_email(con, fn or "")
        if em:
            out[fn] = em
    return out


def matter_partner_email(con, matter_id: int) -> str:
    r = con.execute("SELECT m.managing_partner, m.executing_partner, c.managing_partner FROM matters m "
                    "LEFT JOIN clients c ON c.id=m.client_id WHERE m.id=?", (matter_id,)).fetchone()
    if not r:
        return ""
    for name in r:
        em = partner_email(con, name or "")
        if em:
            return em
    return ""


# ═══════════════════════ 5- الفريق في نموذج التكليف ═══════════════════════
TEAM_SCRIPT = """<script>(function(){
var f=document.querySelector('form[action="/matters/new"]');if(!f)return;var PM=__PM__,CL=__CL__;
var cs=f.querySelector('[name=client_id]'),mp=f.querySelector('[name=managing_partner]'),ep=f.querySelector('[name=executing_partner]');
var tp=f.querySelector('[name=team_partner]'),msg=document.getElementById('ltx-team-msg'),touched={};
[mp,ep,tp].forEach(function(s){if(s)s.addEventListener('change',function(e){if(e.isTrusted)touched[s.name]=1;});});
function fire(s){s.dispatchEvent(new Event('change',{bubbles:true}));}
function fromClient(){var c=CL[cs&&cs.value]||{};
 if(mp&&!touched.managing_partner&&c.mp!==undefined){mp.value=c.mp;fire(mp);}
 if(ep&&!touched.executing_partner&&c.ep!==undefined){ep.value=c.ep;}
 var j=f.querySelector('[name=joint_client_id]');if(j&&cs){[].forEach.call(j.options,function(o){var me=o.value===cs.value;o.hidden=me;if(me)o.selected=false;});}}
function fromPartner(){if(tp&&!touched.team_partner&&mp){var e=PM[mp.value];if(e!==undefined)tp.value=e;}}
if(cs)cs.addEventListener('change',fromClient);if(mp)mp.addEventListener('change',fromPartner);
var q=document.getElementById('ltx-team-find');if(q)q.addEventListener('input',function(){var v=q.value.trim();
 f.querySelectorAll('#ltx-team-more label').forEach(function(l){l.hidden=!!v&&l.textContent.indexOf(v)<0;});});
f.addEventListener('submit',function(e){if(!tp||!tp.value)return;
 var any=[].some.call(f.querySelectorAll('[name=team_member]:checked'),function(b){return b.value!==tp.value;});
 if(any)return;e.preventDefault();msg.textContent='فريق التكليف يلزمه عضو واحد على الأقل غير الشريك المسؤول؛ فاختر عضواً، أو اترك «الشريك المسؤول» فارغاً وحدّد الفريق لاحقاً.';
 msg.hidden=false;msg.scrollIntoView({block:'center'});});
fromClient();fromPartner();})();</script>"""


def team_block(con, user: Optional[Dict[str, Any]], partner: str = "", members: Optional[List[str]] = None) -> str:
    import contracts_register as cr
    cr.ensure_schema(con)
    sigs = cr.signatories(con)
    cands = cr.team_candidates(con)
    me = str((user or {}).get("user_name") or "").lower()
    emails = {c["email"].lower() for c in cands}
    chosen = set(m.lower() for m in (members if members is not None else ([me] if me in emails else [])))
    popts = "<option value=''>— لا أحدّده الآن —</option>" + "".join(
        f"<option value='{_h(s['email'])}'{' selected' if s['email'] == partner else ''}>{_h(s['name_ar'])} — {_h(s['name_en'])}</option>"
        for s in sigs)
    box = lambda c: (f'<label><input type="checkbox" name="team_member" value="{_h(c["email"])}"'
                     f'{" checked" if c["email"].lower() in chosen else ""}> {_h(c["name_ar"])}</label>')
    first = "".join(box(c) for c in cands if c["email"].lower() in chosen)
    rest = "".join(box(c) for c in cands if c["email"].lower() not in chosen)
    mine = ("" if first else '<span class="small">لم يُختر أحد بعد؛ ومنشئ التكليف يُختار تلقائياً متى كان في سجل الموظفين.</span>')
    return (f'<div class="card" id="ltx-team"><h3>فريق التكليف</h3>'
            '<p class="small">الفريق يحدّد من يطّلع على ملف العميل في شيربوينت؛ والشريك المسؤول فيه تلقائياً، ويلزمه عضو آخر '
            'على الأقل. والافتراض: الشريك المدير ومنشئ التكليف وحدهما؛ ويُعدَّل الفريق لاحقاً من صفحته.</p>'
            f'<div class="grid"><div><label>الشريك المسؤول</label><select name="team_partner">{popts}</select></div></div>'
            f'<label>الأعضاء</label><div class="ltx-members">{first}{mine}</div>'
            '<details class="ltx-fold"><summary>إضافة أعضاء آخرين</summary>'
            '<input type="search" id="ltx-team-find" placeholder="اكتب جزءاً من الاسم" autocomplete="off">'
            f'<div class="ltx-members" id="ltx-team-more">{rest}</div></details>'
            '<div class="ltx-msg" id="ltx-team-msg" role="alert" hidden></div></div>')


def _matter_form_page(user, prefill: str = "", fields: Optional[Dict[str, List[str]]] = None, error: str = "") -> bytes:
    raw = _NS["matter_form"](prefill).decode("utf-8")
    if fields:
        raw = refill(raw, fields, only="/matters/new")
    if error:
        raw = raw.replace('<form method="post" action="/matters/new"',
                          f'<div class="error ltx-banner" role="alert">{_h(error)}</div><form method="post" action="/matters/new"', 1)
    return raw.encode("utf-8")


# ═══════════════════════ 4- الطبقة الأولى من أطراف العميل ═══════════════════════
_OWN_READY = {"done": False}


def ensure_ownership_source(con) -> None:
    if _OWN_READY["done"]:
        return
    cols = {r[1] for r in con.execute("PRAGMA table_info(ownership_tracing)")}
    if not cols:
        return
    if "source" not in cols:
        con.execute("ALTER TABLE ownership_tracing ADD COLUMN source TEXT")
    if "party_id" not in cols:
        con.execute("ALTER TABLE ownership_tracing ADD COLUMN party_id INTEGER")
    con.commit()
    _OWN_READY["done"] = True


def sync_layer1(con, client_id: int, ip: str = "") -> int:
    """يكتب الطبقة الأولى من الأطراف ذوي نسبة الملكية، ويحذف ما زال طرفه أو نسبته؛ ولا يمسّ الطبقات المكتوبة يدوياً."""
    ensure_ownership_source(con)
    c = con.execute("SELECT legal_name, client_type FROM clients WHERE id=?", (client_id,)).fetchone()
    if not c:
        return 0
    have = {int(r[0]): r for r in con.execute(
        "SELECT party_id, id, owner_name, id_number, registration_number, country, ownership_percent, parent_owner, owner_type "
        "FROM ownership_tracing WHERE client_id=? AND source='party'", (client_id,)) if r[0] is not None}
    want = {}
    if (c[1] or "") != "individual":
        for p in con.execute("SELECT id, full_name, id_number, registration_number, country, ownership_percent FROM related_parties "
                             "WHERE parent_type='client' AND parent_id=? AND ownership_percent>0", (client_id,)):
            otype = "company" if (p[3] or "").strip() else "individual"
            want[int(p[0])] = (p[1] or "", p[2] or None, p[3] or None, p[4] or None, float(p[5]), c[0] or "", otype)
    changed = 0
    for pid, row in have.items():
        if pid not in want:
            con.execute("DELETE FROM ownership_tracing WHERE id=?", (row[1],))
            changed += 1
        elif tuple(row[2:]) != want[pid]:
            v = want[pid]
            con.execute("UPDATE ownership_tracing SET owner_name=?, id_number=?, registration_number=?, country=?, ownership_percent=?, "
                        "parent_owner=?, owner_type=? WHERE id=?", (*v, row[1]))
            changed += 1
    for pid, v in want.items():
        if pid not in have:
            con.execute("INSERT INTO ownership_tracing(created_at, client_id, sequence_no, owner_name, owner_type, id_number, "
                        "registration_number, country, ownership_percent, parent_owner, control_description, notes, source, party_id) "
                        "VALUES(?,?,1,?,?,?,?,?,?,?,?,?,?,?)",
                        (_NS["now_iso"](), client_id, v[0], v[6], v[1], v[2], v[3], v[4], v[5], "",
                         "مشتقة من أطراف العميل", "party", pid))
            changed += 1
    if changed:
        _NS["audit"](con, "ownership_layer1_derived", "client", client_id,
                     f"الطبقة الأولى من أطراف العميل: {len(want)} مالكاً مباشراً ({changed} تغيير)", ip)
    return changed


def _owner_rows_html(con, client_id: int) -> str:
    """جدول سلسلة الملكية (كما في app.py v10.7) مع تمييز الطبقة المشتقة: تُعدَّل من الطرف نفسه، فلا تعديل لها هنا ولا حذف."""
    ensure_ownership_source(con)
    h, auto_dir = _NS["h"], _NS["auto_dir"]
    out = []
    for r in con.execute("SELECT * FROM ownership_tracing WHERE client_id=? ORDER BY sequence_no, id", (client_id,)).fetchall():
        derived = (r["source"] or "") == "party"
        plus = ""
        if (r["owner_type"] or "company") != "individual":
            js_arg = h(json.dumps(r["owner_name"] or "", ensure_ascii=False))
            plus = (f"<button type='button' class='btn ok' style='padding:6px 10px;margin:0' "
                    f"onclick='pfOwn({js_arg},{int(r['sequence_no'] or 1) + 1})' "
                    f"title='إضافة ملاك هذا الكيان كطبقة تالية'>+ ملاك الكيان</button> ")
        if derived:
            actions = f"{plus}<span class='ltx-derived'>من أطراف العميل؛ ويُعدَّل من الطرف نفسه</span>"
        else:
            actions = (
                f"{plus}<a class='btn secondary' style='padding:6px 10px;margin:0' href='/ownership/edit?id={r['id']}'>تعديل</a> "
                f"<form method='post' action='/ownership/delete' style='display:inline'>"
                f"<input type='hidden' name='trace_id' value='{r['id']}'>"
                f"<button class='btn danger' style='padding:6px 10px;margin:0' onclick=\"return confirm('حذف طبقة الملكية هذه؟')\">حذف</button></form>")
        out.append(
            f"<tr><td>{r['sequence_no']}</td><td>{auto_dir(r['owner_name'])}</td><td>{h(r['owner_type'])}</td>"
            f"<td>{h(r['registration_number'] or r['id_number'])}</td><td>{h(r['country'])}</td><td>{h(r['ownership_percent'])}</td>"
            f"<td>{auto_dir(r['parent_owner'])}</td><td>{auto_dir(r['control_description'])}</td><td>{actions}</td></tr>")
    return "".join(out) or "<tr><td colspan='9'>لا يوجد تتبع ملكية</td></tr>"


# ═══════════════════════ 6 و9- بيانات العميل للعقد في صفحة الإصدار ═══════════════════════
CF_KEYS = ("email", "name_en", "address_en", "vat_number", "signatory_name_ar", "signatory_name_en", "signatory_id",
           "signatory_title_ar", "title_manual_ar", "title_manual_en", "signatory_authority_ar", "salutation_gender")
ROLE_AR = {"authorized_signatory": "مفوض بالتوقيع", "board_member": "عضو مجلس إدارة", "manager": "عضو هيئة مديرين",
           "ubo": "مستفيد حقيقي", "controller": "مسيطر فعلي"}


def cf_section(con, client_id: int, f: Optional[Dict[str, str]] = None) -> str:
    import contracts_register as cr
    con.row_factory = sqlite3.Row
    c = con.execute("SELECT * FROM clients WHERE id=?", (client_id,)).fetchone()
    if not c:
        return ""
    c = dict(c)
    posted = dict(f or {}) if (f or {}).get("cf_present") == "1" else {}
    val = lambda k: posted.get(k, c.get(k) or "")
    individual = (c.get("client_type") or "") == "individual"
    parties = [dict(r) for r in con.execute(
        "SELECT id, party_role, full_name, id_number FROM related_parties WHERE parent_type='client' AND parent_id=? "
        "ORDER BY CASE party_role WHEN 'authorized_signatory' THEN 0 ELSE 1 END, id", (client_id,))]
    sigs = [p for p in parties if p["party_role"] == "authorized_signatory"]
    pre_note = ""
    chosen_party = posted.get("signatory_party", "")
    if not posted:
        saved = (c.get("signatory_name_ar") or "").strip()
        match = [p for p in parties if saved and (p["full_name"] or "").strip() == saved]
        if match:
            chosen_party = str(match[0]["id"])
        elif not saved and len(sigs) == 1 and not individual:
            # لا يُختار ممثل خفيةً: يُقترح المفوَّض الوحيد ظاهراً في الحقول، ولا يُحفظ إلا بـ«إنشاء الاتفاقية»
            chosen_party = str(sigs[0]["id"])
            posted_sig = sigs[0]
            c["signatory_name_ar"], c["signatory_id"] = posted_sig["full_name"] or "", posted_sig["id_number"] or ""
            pre_note = ("اقتُرح لأنه المفوَّض بالتوقيع الوحيد في أطراف العميل؛ فغيّره إن كان الموقّع غيره. "
                        "ولا يُحفظ في ملف العميل إلا عند «إنشاء الاتفاقية».")
    field = lambda k, lbl, ltr=False, hint="": (
        f'<div class="lt-agr-f"><label for="{k}">{_h(lbl)}</label><input type="text" id="{k}" name="{k}" value="{_h(val(k))}"'
        f'{" class=\"lt-agr-ltr\"" if ltr else ""}>{hint}</div>')
    t_ar = posted.get("title_manual_ar") if posted.get("signatory_title_ar") == cr.MANUAL else val("signatory_title_ar")
    manual_sel = bool(t_ar) and t_ar not in dict(cr.SIGNATORY_TITLES)
    t_opts = "<option value=''>— اختر —</option>" + "".join(
        f"<option value='{_h(a)}'{' selected' if a == t_ar else ''}>{_h(a)} — {_h(e)}</option>" for a, e in cr.SIGNATORY_TITLES) \
        + f"<option value='{cr.MANUAL}'{' selected' if manual_sel else ''}>صفة أخرى تُكتب يدوياً</option>"
    t_en_manual = posted.get("title_manual_en", c.get("signatory_title_en") or "") if manual_sel else ""
    sug, form = cr.suggested_authority(con, client_id)
    a_ar = val("signatory_authority_ar") or (sug[0] if sug else "")
    a_opts = "<option value=''>— اختر —</option>" + "".join(
        f"<option value='{_h(a)}'{' selected' if a == a_ar else ''}>{_h(a)} — {_h(e)}</option>" for a, e in cr.SIGNATORY_AUTHORITIES)
    a_hint = (f"مقترح من الشكل النظامي في واثق «{_h(form)}»: <b>{_h(sug[0])}</b>؛ ويُغيَّر إن كان التوقيع بقرار أو تفويض أو وكالة."
              if sug else "لم يُجلب الشكل النظامي من واثق لهذا العميل؛ فيُختار السند يدوياً.")
    popts = ("<option value=''>— اختر من أطراف العميل —</option>" + "".join(
        f"<option value='{p['id']}' data-name='{_h(p['full_name'])}' data-id='{_h(p['id_number'] or '')}'"
        f"{' selected' if str(p['id']) == chosen_party else ''}>{_h(p['full_name'])} — {_h(ROLE_AR.get(p['party_role'], p['party_role']))}</option>"
        for p in parties) + f"<option value='__other__'{' selected' if chosen_party == '__other__' else ''}>شخص آخر يُكتب يدوياً</option>")
    picker = (f'<div class="lt-agr-f lt-agr-wide"><label for="signatory_party">ممثل العميل في التوقيع</label>'
              f'<select id="signatory_party" name="signatory_party">{popts}</select>'
              f'<div class="lt-agr-hint">{_h(pre_note) if pre_note else "اختيارك يملأ الاسم والهوية أدناه من ملف العميل؛ ويبقيان قابلين للتعديل."}</div></div>'
              if parties else "")
    sign = (picker + field("signatory_name_ar", "اسم ممثل التوقيع (عربي)") + field("signatory_id", "هوية ممثل التوقيع", True)
            + f'<div class="lt-agr-f lt-agr-wide"><label for="signatory_title_ar">صفة ممثل التوقيع</label><select id="signatory_title_ar" name="signatory_title_ar">{t_opts}</select>'
            '<div class="lt-agr-hint">والإنجليزية تتبع العربية في الصفات المدرجة.</div></div>'
            f'<div class="lt-agr-f lt-agr-cond" data-show="signatory_title_ar={cr.MANUAL}"><label for="title_manual_ar">الصفة (عربي)</label>'
            f'<input type="text" id="title_manual_ar" name="title_manual_ar" value="{_h(t_ar if manual_sel else "")}"></div>'
            f'<div class="lt-agr-f lt-agr-cond" data-show="signatory_title_ar={cr.MANUAL}"><label for="title_manual_en">الصفة (إنجليزي)</label>'
            f'<input type="text" id="title_manual_en" name="title_manual_en" value="{_h(t_en_manual)}" class="lt-agr-ltr"></div>'
            f'<div class="lt-agr-f lt-agr-wide"><label for="signatory_authority_ar">سند الصلاحية</label><select id="signatory_authority_ar" name="signatory_authority_ar">{a_opts}</select>'
            f'<div class="lt-agr-hint">{a_hint}</div></div>')
    addr = field("address", "العنوان الوطني", False,
                 '<div class="lt-agr-hint">العنوان المختصر -مثل RHOC7906- أو الكامل من وثيقة العنوان الوطني؛ ويُكتب في العقد كما هو.</div>')
    english = ('<details class="lt-agr-more"><summary>النص الإنجليزي</summary><div class="lt-agr-grid">'
               + field("name_en", "اسم العميل بالإنجليزية", True)
               + field("address_en", "العنوان بالإنجليزية (يُترك إن كان العنوان مختصراً)", True)
               + ("" if individual else field("signatory_name_en", "اسم ممثل التوقيع (إنجليزي)", True))
               + "</div></details>")
    snap = cr.client_snapshot(con, client_id, "ar_en")
    miss = snap["_missing"]
    # مطويّ ما لم يمنع شيءٌ الإنشاء؛ والملخّص يقول ما ينقص فيُفتح بنقرة
    open_ = " open" if (miss["block"] or posted or pre_note) else ""
    summary = f"تمنع الإنشاء {len(miss['block'])} · ناقصة لا تمنع {len(miss['warn'])}"
    if individual:
        gv = val("salutation_gender")
        sal = ('<div class="lt-agr-f"><label for="salutation_gender">المخاطبة في العقد</label><select id="salutation_gender" name="salutation_gender">'
               + "".join(f"<option value='{k}'{' selected' if gv == k else ''}>{_h(t)}</option>"
                         for k, t in (("", "— اختر —"), ("M", "الأستاذ"), ("F", "الأستاذة")))
               + '</select><div class="lt-agr-hint">تُكتب «الأستاذ/» أو «الأستاذة/»؛ وإن تُركت كُتب <span class="lt-agr-slot">[●]</span>.</div></div>')
        body = (f'<div class="lt-agr-grid">{field("email", "بريد العميل للإشعارات", True)}{sal}{addr}{english}</div>'
                '<details class="lt-agr-more"><summary>يوقّع عنه وكيل أو مفوَّض، أو له رقم ضريبي</summary><div class="lt-agr-grid">'
                + field("vat_number", "الرقم الضريبي (إن كان مسجَّلاً في ضريبة القيمة المضافة)", True)
                + field("signatory_name_ar", "اسم الوكيل أو المفوَّض") + field("signatory_id", "هوية الوكيل أو المفوَّض", True)
                + "</div></details>")
    else:
        body = (f'<div class="lt-agr-grid">{field("email", "بريد العميل للإشعارات", True)}{field("vat_number", "الرقم الضريبي", True)}{addr}</div>'
                f'<h4>ممثل العميل وسند صلاحيته</h4><div class="lt-agr-grid">{sign}</div><div class="lt-agr-grid">{english}</div>')
    return (f'<section class="lt-agr-sec" id="ltx-cf"><details class="ltx-cf-fold"{open_}><summary><h3>بيانات العميل للعقد</h3>'
            f'<span class="ltx-cf-sum">{summary}</span></summary><input type="hidden" name="cf_present" value="1">'
            '<p class="lt-agr-why">تُحفظ في ملف العميل عند «إنشاء الاتفاقية»؛ و«أثر الاختيار» يعاين ولا يحفظها.</p>'
            f'{body}</details></section>')


CF_SCRIPT = """<script>(function(){var f=document.querySelector('form.lt-agr');if(!f)return;
var sp=f.querySelector('[name=signatory_party]');if(!sp)return;
sp.addEventListener('change',function(){var o=sp.options[sp.selectedIndex];if(!o||!o.value||o.value==='__other__')return;
 [['signatory_name_ar',o.getAttribute('data-name')],['signatory_id',o.getAttribute('data-id')]].forEach(function(p){
  var e=f.querySelector('[name='+p[0]+']');if(e){e.value=p[1]||'';e.dispatchEvent(new Event('input',{bubbles:true}));}});});})();</script>"""

# ═══════════════════════ 7- الأنماط الأربعة ═══════════════════════
PRESETS = [("annual", "سنوي على أربعة أقساط"), ("fixed", "ثابتة 50/50"),
           ("hourly", "بالساعة بمعدلات الملحق"), ("phases", "على مراحل")]
PRESET_HTML = ('<div class="ltx-presets" role="group" aria-label="أنماط جاهزة"><span>أنماط جاهزة:</span>'
               + "".join(f'<button type="button" class="lt-agr-btn" data-preset="{k}" aria-pressed="false">{t}</button>' for k, t in PRESETS)
               + '</div><div class="lt-agr-hint">النمط يختار نموذج الأتعاب وافتراضاته، ويظهر أثره في «ما يدخل العقد»؛ '
               'ولا يُنشئ شيئاً، وكل حقل يبقى قابلاً للتغيير.</div>')
PRESET_SCRIPT = """<script>(function(){var f=document.querySelector('form.lt-agr');if(!f)return;
var P={annual:{fee_model:'annual',a_instalments:'4',_focus:'a_fee'},fixed:{fee_model:'fixed',f_pct_sign:'50',f_pct_delivery:'50',_focus:'f_fee'},
 hourly:{fee_model:'hourly',hourly_option:'none',cap_on:false,_focus:''},phases:{fee_model:'phases',_focus:'ph1_desc_ar'}};
function put(n,v){var els=f.querySelectorAll('[name="'+n+'"]');els.forEach(function(e){
 if(e.type==='radio'){if(e.value===v){e.checked=true;e.dispatchEvent(new Event('change',{bubbles:true}));}}
 else if(e.type==='checkbox'){if(e.checked!==v){e.checked=v;e.dispatchEvent(new Event('change',{bubbles:true}));}}
 else{e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));}});}
f.querySelectorAll('[data-preset]').forEach(function(b){b.addEventListener('click',function(){var p=P[b.getAttribute('data-preset')];
 Object.keys(p).forEach(function(k){if(k!=='_focus')put(k,p[k]);});
 f.querySelectorAll('[data-preset]').forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false');});
 if(p._focus){var e=f.querySelector('[name="'+p._focus+'"]');if(e)setTimeout(function(){e.focus();},0);}});});})();</script>"""


def _agreement_extras(con, matter_id: int, page: str, f: Optional[Dict[str, str]]) -> str:
    row = con.execute("SELECT client_id FROM matters WHERE id=?", (matter_id,)).fetchone()
    if not row:
        return page
    sec = cf_section(con, int(row[0]), f)
    err = getattr(_TL, "cf_error", "")
    if err:
        sec = (f'<div class="lt-agr-tell lt-agr-stop"><div><b>لم تُحفظ بيانات العميل للعقد، ولم يُنشأ العقد:</b> '
               f'{_h(err)}</div></div>') + sec
    anchor = '<section class="lt-agr-sec"><h3>نطاق العمل</h3>'
    if anchor in page and 'id="ltx-cf"' not in page:
        page = page.replace(anchor, sec + anchor, 1)
    fee = '<p class="lt-agr-why">اختر نموذجاً واحداً؛ يظهر ما يخصّه وحده، ويُحذف ما سواه من العقد.</p>'
    if fee in page and "ltx-presets" not in page:
        page = page.replace(fee, fee + PRESET_HTML, 1)
    page = re.sub(r'<p><a href="/client/contract-fields\?id=(\d+)&amp;back=(\d+)">استكمال بيانات العميل للعقد</a></p>',
                  r'<p><a href="#ltx-cf">استكمال بيانات العميل للعقد في هذه الصفحة</a> · '
                  r'<a href="/client/contract-fields?id=\1&amp;back=\2">أو في صفحة مستقلة</a></p>', page, count=1)
    return STYLE + page + CF_SCRIPT + PRESET_SCRIPT + ('<script>(function(){var d=document.querySelector("#ltx-cf details");'
                                                       'if(d&&location.hash==="#ltx-cf")d.open=true;'
                                                       'document.querySelectorAll(\'a[href="#ltx-cf"]\').forEach(function(a){a.addEventListener("click",function(){if(d)d.open=true;});});})();</script>')


def save_cf(con, matter_id: int, fields: Dict[str, List[str]], actor: str, ip: str = "") -> None:
    """يحفظ ما في القسم المطوي بالدالة نفسها التي تحفظ صفحة «بيانات العميل للعقد»، والعنوانَ الوطني معه."""
    import contracts_register as cr
    ctx = cr.agreement_gate(con, matter_id)
    cid = int(ctx["client"]["id"])
    sub = {k: fields[k] for k in CF_KEYS if k in fields}
    cr.save_client_fields(con, cid, sub, actor)
    if "address" in fields:
        save_address(con, cid, _one(fields, "address"), ip)


def save_address(con, cid: int, addr: str, ip: str = "") -> None:
    addr = (addr or "").strip()
    cur = con.execute("SELECT COALESCE(address,'') FROM clients WHERE id=?", (cid,)).fetchone()
    if cur is None or (cur[0] or "") == addr:
        return
    if "�" in addr:
        raise ValueError("العنوان الوطني: نص تالف الترميز؛ أعد كتابته")
    con.execute("UPDATE clients SET address=?, updated_at=? WHERE id=?", (addr or None, _NS["now_iso"](), cid))
    _NS["audit"](con, "client_address_set", "client", cid, "العنوان الوطني" + ("" if addr else " (مُسح)"), ip)
    con.commit()


# ═══════════════════════ 8- صفحة «صدرت الاتفاقية» ═══════════════════════
def _stash(user_id: Any, matter_id: int, blob: bytes, name: str) -> str:
    tok = secrets.token_urlsafe(18)
    now = time.time()
    with _FILES_LOCK:
        for k in [k for k, v in _FILES.items() if v["exp"] < now]:
            _FILES.pop(k, None)
        while len(_FILES) >= 40:
            _FILES.pop(min(_FILES, key=lambda k: _FILES[k]["exp"]), None)
        _FILES[tok] = {"blob": blob, "name": name, "mid": int(matter_id), "uid": user_id, "exp": now + FILE_TTL}
    return tok


def issued_page(con, matter_id: int, tok: str) -> str:
    import contracts_register as cr
    con.row_factory = sqlite3.Row
    m = con.execute("SELECT m.id, m.matter_number, m.title, c.legal_name FROM matters m JOIN clients c ON c.id=m.client_id "
                    "WHERE m.id=?", (matter_id,)).fetchone()
    doc = con.execute("SELECT id, reference_no, status, regenerations FROM issued_documents WHERE matter_id=? AND doc_type='agreement' "
                      "AND status!='withdrawn' ORDER BY id DESC LIMIT 1", (matter_id,)).fetchone()
    if not m or not doc:
        return "<div class='error'>لا اتفاقية صادرة لهذا التكليف.</div>"
    with _FILES_LOCK:
        have = tok in _FILES and _FILES[tok]["mid"] == int(matter_id) and _FILES[tok]["exp"] > time.time()
    file_url = f"{ISSUED_FILE}?t={_h(tok)}"
    if have:
        dl = (f'<p><a class="btn" id="ltx-dl" href="{file_url}">نزّل ملف الاتفاقية</a>'
              '<span class="small">يبدأ التنزيل تلقائياً؛ فإن لم يبدأ فاضغط الزر. ويبقى الرابط ساعة واحدة، لأن المنصة '
              'لا تحتفظ بنسخة الاتفاقية قبل توقيعها.</span></p>'
              f'<script>setTimeout(function(){{location.href="{file_url}";}},600);</script>')
    else:
        dl = (f'<p class="notice">انتهت مهلة تنزيل الملف؛ لأن المنصة لا تحتفظ بنسخة الاتفاقية قبل توقيعها. فأعد إنشاءه من '
              f'<a href="{cr.AGREEMENT_PATH}?id={matter_id}">صفحة الإصدار</a>؛ ولا يستهلك ذلك رقماً جديداً.</p>')
    regen = cr.regen_ar(doc["regenerations"])
    return (f'{STYLE}<div class="card ltx-issued"><h2>صدرت الاتفاقية</h2>'
            f'<p>المرجع <b>{_h(doc["reference_no"])}</b> · التكليف {_h(m["matter_number"])} - {_h(m["title"])} · '
            f'العميل <b>{_h(m["legal_name"])}</b>. وقُيِّدت في سجل الوثائق الصادرة بحالة '
            f'«{_h(cr.DOC_STATUS_AR.get(doc["status"], doc["status"]))}»، {regen}.</p>{dl}'
            '<h3>الخطوة التالية</h3><ol>'
            '<li>راجع الملف، واستكمل فيه ما عُلِّم بالعلامة [●] قبل إرساله.</li>'
            '<li>أرسله إلى العميل ليوقّعه.</li>'
            f'<li>إذا عاد موقَّعاً فأرفقه وارفعه: <a class="btn" href="/document/signed?id={doc["id"]}">أرفق الموقَّعة وارفعها</a></li></ol>'
            f'<p><a class="btn secondary" href="/matter?id={matter_id}">العودة إلى التكليف</a> '
            f'<a class="btn secondary" href="{cr.AGREEMENT_PATH}?id={matter_id}">العودة إلى صفحة الإصدار</a></p></div>')


# ═══════════════════════ 9 و10- صفحة العميل ═══════════════════════
EXPECTED_DOCS = {
    "company": [("commercial_registration", "السجل التجاري"), ("articles_of_association", "عقد التأسيس أو النظام الأساس"),
                ("poa_authorization", "وكالة أو تفويض لممثل التوقيع")],
    "individual": [("national_id|iqama|passport", "الهوية الوطنية أو الإقامة أو الجواز")],
}


def _doc_checklist(con, c) -> str:
    kind = "individual" if (c["client_type"] or "") == "individual" else ("company" if (c["client_type"] or "") == "company" else "")
    if not kind:
        return ""
    have = {r[0] for r in con.execute("SELECT document_type FROM entity_documents WHERE entity_type='client' AND entity_id=?", (c["id"],))}
    if c["document_scan_path"] and c["document_type"]:
        have.add(c["document_type"])
    lis = "".join(f'<li class="{"ltx-have" if any(x in have for x in codes.split("|")) else ""}">{_h(lbl)}</li>'
                  for codes, lbl in EXPECTED_DOCS[kind])
    return f'<p class="small">المستندات المتوقَّعة لهذا العميل -وعلامة ✓ لما رُفع منها-:</p><ul class="ltx-check">{lis}</ul>'


def _client_page(raw: str, cid: int) -> str:
    try:
        with _NS["db"]() as con:
            c = con.execute("SELECT * FROM clients WHERE id=?", (cid,)).fetchone()
            if not c:
                return raw
            checklist = _doc_checklist(con, c)
    except Exception:
        return raw
    individual = (c["client_type"] or "") == "individual"
    # نموذج الطرف: الدولة دولة العميل، والجنسية تتبعها
    perr = getattr(_TL, "party_error", "")
    party_form = ""
    m = re.search(r'<form method="post" action="/client/add_party">.*?</form>', raw, re.S)
    if m:
        form = m.group(0)
        country = (c["country"] or "").strip()
        if country:
            form = re.sub(r'<input name="country"(?: value="[^"]*")?', f'<input name="country" value="{_h(country)}"', form, count=1)
            form = form.replace('<input name="nationality">', f'<input name="nationality" value="{_h(nationality_for(country))}">', 1)
        if individual:
            form = _set_select(form, "party_role", "authorized_signatory")
            form = re.sub(r'<div><label>رقم السجل</label><input name="registration_number"></div>', "", form, count=1)
            form = re.sub(r'<div><label>نسبة الملكية</label><input name="ownership_percent"[^>]*></div>', "", form, count=1)
        label = "يوقّع عنه وكيل أو مفوَّض" if individual else "إضافة طرف"
        if perr:
            form = refill(form, getattr(_TL, "party_fields", {}) or {})
            party_form = (f'<div class="error ltx-banner" role="alert">{_h(perr)}</div>'
                          f'<details class="ltx-fold" open><summary>{label}</summary><!--ltx-fold-->{form}</details>')
        else:
            party_form = f'<details class="ltx-fold"><summary>{label}</summary><!--ltx-fold-->{form}</details>'
        raw = raw[:m.start()] + party_form + raw[m.end():]
    # الوثائق: النوع الافتراضي نوع الوثيقة الرئيسية، أو الهوية للفرد؛ وقائمة المتوقَّع بعلاماتها
    m = re.search(r'<form method="post" action="/documents/upload".*?</form>', raw, re.S)
    if m:
        dtype = (c["document_type"] or "") or ("national_id" if individual else "commercial_registration")
        form = _set_select(m.group(0), "document_type", dtype)
        raw = raw[:m.start()] + checklist + form + raw[m.end():]
    # سلسلة الملكية: الطبقة الأولى من الأطراف، والنموذج للطبقات الأعمق
    m = re.search(r'<form method="post" action="/client/add_ownership_trace">.*?</form>', raw, re.S)
    if m and not individual:
        form = m.group(0).replace('<input type="number" name="sequence_no" value="1">', '<input type="number" name="sequence_no" value="2">', 1)
        note = ('<p class="small">الطبقة الأولى -الملّاك المباشرون- تُكتب تلقائياً من أطراف العميل الذين لهم نسبة ملكية؛ '
                'فهذا النموذج للطبقات الأعمق: ملّاك شركةٍ مالكة، أو سيطرة فعلية غير مباشرة.</p>')
        raw = raw[:m.start()] + note + form + raw[m.end():]
    if individual:
        raw = re.sub(r"<tr><th>الرقم الموحّ?د للمنشأة(?: \(700\))?</th>.*?</tr>", "", raw, count=1, flags=re.S)
        raw = re.sub(r'<p class="notice">(?:أضف ما يلزم من مستندات:|يمكن إضافة أكثر من وثيقة،)[^<]*</p>',
                     '<p class="notice">أضف هوية العميل، ووكالة من يوقّع عنه إن كان له وكيل.</p>', raw, count=1)
        span = _card_span(raw, 'action="/client/add_party"')
        if span:
            card = raw[span[0]:span[1]]
            tm = re.search(r"<table>.*</table>", card, re.S)       # جدول الأطراف يبقى إن أُضيف وكيل
            has_rows = bool(tm and "لا توجد أطراف" not in tm.group(0))
            agent = ('<div class="card"><h3>من يوقّع عن العميل</h3><p class="small">العميل الفرد يوقّع بنفسه في الغالب؛ '
                     'فإن وقّع عنه وكيل أو مفوَّض فأضفه هنا ليُفحص مع العميل.</p>'
                     + party_form + (tm.group(0) if has_rows else "") + "</div>")
            raw = raw[:span[0]] + agent + raw[span[1]:]
        raw = _cut_card(raw, 'action="/client/add_ownership_trace"')
        raw = _cut_card(raw, "/wathq/fetch?client_id=")
        raw = _cut_card(raw, "توثيق واثق")
    banner = getattr(_TL, "banner", None)
    top = banner_html(cid, *banner) if banner else ""
    return _after_main(raw, STYLE + top) if "ltx-effort" not in raw else raw


EDIT_ADDRESS = ('<div><label>العنوان الوطني</label><input name="address" value="{v}" autocomplete="off" '
                'placeholder="العنوان المختصر مثل RHOC7906، أو العنوان كاملاً"></div>')


# ═══════════════════════ الوصل ═══════════════════════
def install(ns: Dict[str, Any]) -> None:
    # مساحة أسماء المنصة نفسها لا نسخة منها: فيُقرأ أحدث تعريف ساعة الاستدعاء، ولو لفّته طبقة بعد هذه
    global _NS
    _NS = ns
    if ns.get("_ltx_effort"):
        return
    import contracts_register as cr

    # ── قاعدة البيانات: عمودا مصدر الطبقة ──
    base_init = ns["init_db"]

    def init_db() -> None:
        base_init()
        try:
            with ns["db"]() as con:
                ensure_ownership_source(con)
        except Exception:
            pass
    ns["init_db"] = init_db

    # ── 2 و10: نموذج العميل الجديد ──
    base_client_form = ns["client_form"]

    def client_form() -> bytes:
        raw = base_client_form().decode("utf-8")
        raw = _RE_SRC_BLOCK.sub(lambda _m: _src_block(), raw, count=1)
        raw = raw.replace('<form method="post" action="/clients/new"', '<form id="ltx-newclient" method="post" action="/clients/new"', 1)
        raw = re.sub(r'(<div><label>الجنسية</label><input name="nationality"></div>)',
                     r'\1<div><label>العنوان الوطني</label><input name="address" autocomplete="off" '
                     r'placeholder="العنوان المختصر مثل RHOC7906، أو العنوان كاملاً"><p class="small">من وثيقة العنوان الوطني؛ '
                     r'ويُكتب في العقد كما هو.</p></div>', raw, count=1)
        user = (ns["_auth_current_user"]() or {})
        if str(user.get("role") or "") in WATHQ_ROLES:
            raw = re.sub(r'(<input name="unified_number"[^>]*>)',
                         r'\1<button type="submit" class="btn secondary" formaction="' + WATHQ_NEW + r'" formnovalidate '
                         r'style="margin-top:6px">اجلب من واثق</button><p class="small">اكتب الرقم الموحّد ثم اضغط؛ '
                         r'فتُعرض البيانات للمراجعة قبل الحفظ.</p>', raw, count=1)
        if str(user.get("role") or "") == "partner" and user.get("full_name"):
            raw = _set_select(raw, "managing_partner", str(user.get("full_name")))
        js = (CLIENT_FORM_SCRIPT.replace("__NAT__", json.dumps(DEMONYM, ensure_ascii=False))
              .replace("__NN__", NOT_NEEDED_REASON).replace("__DUP__", DUP_CHECK))
        return raw.replace("</main>", STYLE + js + "</main>", 1).encode("utf-8")
    ns["client_form"] = client_form

    base_create = ns["create_client"]

    def create_client(fields, files=None, ip=""):
        cid = base_create(fields, files, ip)
        if "address" in fields and _one(fields, "address"):
            with ns["db"]() as con:
                save_address(con, cid, _one(fields, "address"), ip)
        return cid
    ns["create_client"] = create_client

    base_update = ns["update_client"]

    def update_client(fields, ip=""):
        cid = base_update(fields, ip)
        if "address" in fields:
            with ns["db"]() as con:
                save_address(con, cid, _one(fields, "address"), ip)
        return cid
    ns["update_client"] = update_client

    base_edit = ns["client_edit_page"]

    def client_edit_page(cid: int, message: str = "") -> bytes:
        raw = base_edit(cid, message).decode("utf-8")
        try:
            with ns["db"]() as con:
                r = con.execute("SELECT COALESCE(address,'') FROM clients WHERE id=?", (cid,)).fetchone()
            v = _h(r[0] if r else "")
        except Exception:
            return raw.encode("utf-8")
        raw = re.sub(r'(<div><label>الجنسية</label><input name="nationality"[^>]*></div>)',
                     lambda m: m.group(1) + EDIT_ADDRESS.format(v=v), raw, count=1)
        return raw.encode("utf-8")
    ns["client_edit_page"] = client_edit_page

    # ── 4: الطبقة الأولى ──
    base_add_party = ns["add_related_party"]

    def add_related_party(fields, parent_type, parent_id_key, ip=""):
        pid = base_add_party(fields, parent_type, parent_id_key, ip)
        if parent_type == "client":
            with ns["db"]() as con:
                cid = int(_one(fields, parent_id_key) or 0)
                if sync_layer1(con, cid, ip):
                    ns["evaluate_client_risk"](con, cid)
                con.commit()
        return pid
    ns["add_related_party"] = add_related_party

    base_update_party = ns["update_related_party"]

    def update_related_party(fields, ip=""):
        ptype, pid = base_update_party(fields, ip)
        if ptype == "client":
            with ns["db"]() as con:
                if sync_layer1(con, int(pid), ip):
                    ns["evaluate_client_risk"](con, int(pid))
                con.commit()
        return ptype, pid
    ns["update_related_party"] = update_related_party

    base_wathq_apply = ns.get("wathq_apply")
    if base_wathq_apply:
        def wathq_apply(fields, ip=""):
            cid = base_wathq_apply(fields, ip)
            with ns["db"]() as con:
                if sync_layer1(con, int(cid), ip):
                    ns["evaluate_client_risk"](con, int(cid))
                con.commit()
            return cid
        ns["wathq_apply"] = wathq_apply

    base_eval = ns["evaluate_client_risk"]

    def evaluate_client_risk(con, client_id):
        base_eval(con, client_id)
        # «هيكل ملكية متعدد الطبقات» للطبقات المكتوبة يدوياً وحدها كما كان، أو لطبقةٍ أعمق من الأولى؛
        # والطبقة المشتقة من الأطراف هي الملّاك المباشرون، فلا تجعل كل شركة «معقدة»
        try:
            ensure_ownership_source(con)
            rows = con.execute("SELECT sequence_no, COALESCE(source,'') FROM ownership_tracing WHERE client_id=?",
                               (int(client_id),)).fetchall()
        except Exception:
            return
        manual = [r for r in rows if r[1] != "party"]
        complex_ = len(manual) >= 2 or any(int(r[0] or 1) >= 2 for r in manual)
        if not complex_ and len(rows) >= 2:
            con.execute("DELETE FROM risk_flags WHERE entity_type='client' AND entity_id=? AND flag_code='COMPLEX_OWNERSHIP'",
                        (int(client_id),))
    ns["evaluate_client_risk"] = evaluate_client_risk

    def ownership_trace_table(con, client_id):
        return _owner_rows_html(con, int(client_id))
    ns["ownership_trace_table"] = ownership_trace_table

    # ── 1 و9 و10: صفحة العميل ──
    base_detail = ns["client_detail"]

    def client_detail(client_id: int) -> bytes:
        return _client_page(base_detail(client_id).decode("utf-8"), int(client_id)).encode("utf-8")
    ns["client_detail"] = client_detail

    # ── 3 و5: نموذج التكليف ──
    base_matter_form = ns["matter_form"]

    def matter_form(prefill_client_id: str = "") -> bytes:
        raw = base_matter_form(prefill_client_id).decode("utf-8")
        user = ns["_auth_current_user"]() or {}
        try:
            with ns["db"]() as con:
                cl = {str(r[0]): {"mp": r[1] or "", "ep": r[2] or ""} for r in
                      con.execute("SELECT id, COALESCE(managing_partner,''), COALESCE(executing_partner,'') FROM clients")}
                pm = partner_map(con)
                pre = cl.get(str(prefill_client_id or ""), {})
                partner = pm.get(pre.get("mp", ""), "") if pre else ""
                block = team_block(con, user, partner)
        except Exception:
            return raw.encode("utf-8")
        if pre.get("mp"):
            raw = _set_select(raw, "managing_partner", pre["mp"])
        if pre.get("ep"):
            raw = _set_select(raw, "executing_partner", pre["ep"])
        raw = re.sub(r"(<button>حفظ (?:المشروع / القضية|التكليف)</button>\s*</form>)", lambda m: block + m.group(1), raw, count=1)
        js = TEAM_SCRIPT.replace("__PM__", json.dumps(pm, ensure_ascii=False)).replace("__CL__", json.dumps(cl, ensure_ascii=False))
        return raw.replace("</main>", STYLE + js + "</main>", 1).encode("utf-8")
    ns["matter_form"] = matter_form

    # ── 3: صفحة الفريق تفترض الشريك المسؤول من التكليف ──
    base_team_page = cr.team_page

    def team_page(con, matter_id, h, error="", posted=None):
        note = ""
        if posted is None and not con.execute("SELECT 1 FROM matter_team WHERE matter_id=?", (matter_id,)).fetchone():
            em = matter_partner_email(con, int(matter_id))
            if em:
                posted = {"partner": em, "members": []}
                note = ('<div class="lt-agr-tell lt-agr-ok"><div>اختير الشريك المسؤول من الشريك المدير في التكليف؛ '
                        'فغيّره إن لزم، واختر عضواً آخر على الأقل.</div></div>')
        page = base_team_page(con, matter_id, h, error, posted)
        page = page.replace('<fieldset', note + '<fieldset', 1) if note else page
        rule = ("<script>(function(){var f=document.querySelector('form[data-page=team]');if(!f)return;"
                "f.addEventListener('submit',function(e){var p=f.querySelector('[name=partner_ar]');p=p?p.value:'';"
                "var any=[].some.call(f.querySelectorAll('[name=member]:checked'),function(b){return b.value!==p;});"
                "var m=document.getElementById('ltx-team-rule');if(p&&any){return;}e.preventDefault();"
                "m.textContent=p?'فريق التكليف يلزمه عضو واحد على الأقل غير الشريك المسؤول.':'اختر الشريك المسؤول أولاً.';"
                "m.hidden=false;m.scrollIntoView({block:'center'});});})();</script>")
        page = page.replace('<div class="lt-agr-bar">', '<div class="ltx-msg" id="ltx-team-rule" role="alert" hidden></div><div class="lt-agr-bar">', 1)
        return STYLE + page + rule
    cr.team_page = team_page

    # ── 6 و7: صفحة الإصدار ──
    base_screen = cr.screen_html

    def screen_html(con, matter_id, h, f=None, result=None):
        page = base_screen(con, matter_id, h, f, result)
        try:
            return _agreement_extras(con, int(matter_id), page, f)
        except Exception:
            return page
    cr.screen_html = screen_html

    # ── 9: صفحة «بيانات العميل للعقد» المستقلة للفرد، والعنوان الوطني فيها ──
    base_cf_page = cr.client_fields_page

    def client_fields_page(con, client_id, h, back=0, error="", posted=None):
        page = base_cf_page(con, client_id, h, back, error, posted)
        try:
            r = con.execute("SELECT client_type, COALESCE(address,'') FROM clients WHERE id=?", (client_id,)).fetchone()
        except Exception:
            return page
        if not r:
            return page
        addr_v = (posted or {}).get("address", r[1])
        addr = ('<div class="lt-agr-f"><label for="address">العنوان الوطني</label><input type="text" id="address" name="address" '
                f'value="{_h(addr_v)}"><div class="lt-agr-hint">العنوان المختصر -مثل RHOC7906- أو الكامل؛ ويُكتب في العقد كما هو.</div></div>')
        page = re.sub(r'(<div class="lt-agr-f"><label for="email">.*?</div>)', lambda m: m.group(1) + addr, page, count=1, flags=re.S)
        page = page.replace("غير مسجَّل — يُسجَّل من صفحة العميل", "غير مسجَّل؛ ويُكتب في الحقل أدناه", 1)
        if (r[0] or "") == "individual":
            take = []
            for k in ("vat_number", "signatory_name_ar", "signatory_id", "signatory_name_en"):
                m = re.search(r'<div class="lt-agr-f"><label for="' + k + r'">.*?</div>', page, re.S)
                if m:
                    take.append(m.group(0))
                    page = page[:m.start()] + page[m.end():]
            m = re.search(r'<section class="lt-agr-sec"><h3>صفة ممثل التوقيع وسند الصلاحية</h3>.*?</section>', page, re.S)
            sec = m.group(0) if m else ""
            if m:
                page = page[:m.start()] + page[m.end():]
            fold = ('<details class="lt-agr-more"><summary>يوقّع عنه وكيل أو مفوَّض، أو له رقم ضريبي</summary>'
                    f'<div class="lt-agr-grid">{"".join(take)}</div>{sec}</details>')
            page = page.replace("</div>\n<div class=\"lt-agr-bar\">", fold + "</div>\n<div class=\"lt-agr-bar\">", 1)
        return page
    cr.client_fields_page = client_fields_page

    # ── 8: الملف بعد الإنشاء يذهب إلى صفحة «صدرت الاتفاقية» ──
    base_bin = ns["_send_binary_with_disposition"]

    def send_bin(handler, data, content_type, filename, disposition="attachment"):
        land = getattr(handler, "_ltx_landing", None)
        if land and str(filename).lower().endswith(".docx"):
            handler._ltx_landing = None
            mid, uid = land
            tok = _stash(uid, mid, data, filename)
            return ns["_auth_send_redirect"](handler, f"{ISSUED_PATH}?id={mid}&t={tok}")
        return base_bin(handler, data, content_type, filename, disposition)
    ns["_send_binary_with_disposition"] = send_bin

    _install_routes(ns)
    ns["_ltx_effort"] = True


def _render_client(handler, cid: int, status: int = 200) -> None:
    handler._send(_NS["client_detail"](int(cid)), status)


def _install_routes(ns: Dict[str, Any]) -> None:
    handler_cls = ns.get("AppHandler")
    if not handler_cls or getattr(handler_cls, "_ltx_effort", False):
        return
    import contracts_register as cr
    base_get, base_post = handler_cls.do_GET, handler_cls.do_POST

    def do_get(self) -> None:
        parsed = ns["urlparse"](self.path)
        q = ns["parse_qs"](parsed.query)
        path = parsed.path
        if path == "/client" and "screened" in q:
            _TL.banner = ((q.get("screened") or [""])[0][:20], (q.get("from") or [""])[0][:10])
            try:
                return base_get(self)
            finally:
                _TL.banner = None
        if path not in (DUP_CHECK, ISSUED_PATH, ISSUED_FILE):
            return base_get(self)
        user = _ctx(self)
        if not _guard(self, user):
            return
        if path == DUP_CHECK:
            g = lambda k: (q.get(k) or [""])[0]
            with ns["db"]() as con:
                res = duplicates(con, g("registration_number"), g("unified_number"), g("id_number"),
                                 int(_digits(g("exclude")) or 0))
            data = json.dumps({"matches": [{k: d[k] for k in ("id", "name", "by")} for d in res]}, ensure_ascii=False).encode("utf-8")
            return self._send(data, 200, "application/json; charset=utf-8")
        tok = (q.get("t") or [""])[0]
        if path == ISSUED_FILE:
            with _FILES_LOCK:
                ent = _FILES.get(tok)
            if not ent or ent["exp"] < time.time() or ent["uid"] != user.get("id"):
                return self._send(ns["layout"]("انتهت المهلة", "<div class='error'>انتهت مهلة تنزيل الملف؛ فأعد إنشاءه من صفحة "
                                               "الإصدار، ولا يستهلك ذلك رقماً جديداً.</div>", "/matters"), 404)
            return ns["_send_binary_with_disposition"](
                self, ent["blob"], "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ent["name"])
        try:
            mid = int(_digits((q.get("id") or ["0"])[0]) or 0)
        except ValueError:
            mid = 0
        with ns["db"]() as con:
            cr.ensure_schema(con)
            body = issued_page(con, mid, tok)
        return self._send(ns["layout"]("صدرت الاتفاقية", body, "/matters"))

    def do_post(self) -> None:
        path = ns["urlparse"](self.path).path
        if path not in (NEW_CLIENT, WATHQ_NEW, "/client/add_party", "/client/run_screening", "/matters/new",
                        cr.AGREEMENT_PATH, cr.CLIENT_FIELDS_PATH):
            return base_post(self)
        user = _ctx(self)
        if not _guard(self, user):
            return
        ns["init_db"]()
        if path == cr.AGREEMENT_PATH:
            return _post_agreement(self, user, base_post)
        if path == cr.CLIENT_FIELDS_PATH:
            return _post_cf_page(self, user, base_post)
        fields, files, ip, _raw = _read(self)
        if path == NEW_CLIENT:
            return _post_new_client(self, user, fields, files, ip)
        if path == WATHQ_NEW:
            return _post_wathq_new(self, user, fields, ip)
        if path == "/client/add_party":
            return _post_add_party(self, user, fields, ip)
        if path == "/client/run_screening":
            cid = int(_digits(_one(fields, "client_id")) or 0)
            scr = screen_now(cid, ip)
            return ns["_auth_send_redirect"](self, f"/client?id={cid}&screened={scr}&from=run")
        return _post_new_matter(self, user, fields, ip)

    handler_cls.do_GET, handler_cls.do_POST = do_get, do_post
    handler_cls._ltx_effort = True


def _post_new_client(self, user, fields, files, ip) -> None:
    ns = _NS
    if not _one(fields, "legal_name"):
        return self._send(_client_form_page(user, fields, "اسم العميل مطلوب؛ فاكتبه ثم احفظ."), 400)
    problem = src_problem(fields)
    if problem:
        return self._send(_client_form_page(user, fields, problem), 400)
    with ns["db"]() as con:
        dups = duplicates(con, _one(fields, "registration_number"), _one(fields, "unified_number"), _one(fields, "id_number"))
    if dups and _one(fields, "dup_ok") != "1":
        return self._send(_client_form_page(user, fields, extra=_dup_box(dups)), 409)
    normalize_src(fields)
    try:
        cid = ns["create_client"](fields, files, ip)
    except ValueError as exc:
        note = " وإن كنتَ اخترت ملفاً فأعد اختياره." if files else ""
        return self._send(_client_form_page(user, fields, f"لم يُحفظ العميل: {exc}.{note}".replace("..", ".")), 400)
    if dups:
        with ns["db"]() as con:
            ns["audit"](con, "duplicate_client_override", "client", cid,
                        "أُقرّ بفتح ملف مع وجود ملف بالرقم نفسه: " + "، ".join(f"#{d['id']} ({d['by']})" for d in dups), ip)
            con.commit()
    wcr = _digits(_one(fields, "wathq_cr"))
    if wcr and str(user.get("role") or "") in WATHQ_ROLES:
        try:
            ns["wathq_apply"]({"client_id": [str(cid)], "cr": [wcr],
                               "import_parties": ["1" if _one(fields, "import_parties") == "1" else ""]}, ip)
            scr = "0.0.0"                                  # wathq_apply يعيد الفحص بنفسه
            with ns["db"]() as con:
                r = con.execute("SELECT COUNT(*) FROM screenings WHERE subject_type='client' AND subject_id=?", (cid,)).fetchone()
            if not r or not r[0]:
                scr = screen_now(cid, ip)
        except Exception:
            scr = screen_now(cid, ip)
    else:
        scr = screen_now(cid, ip)
    return ns["_auth_send_redirect"](self, f"/client?id={cid}&screened={scr}&from=new")


def _post_wathq_new(self, user, fields, ip) -> None:
    ns = _NS
    if str(user.get("role") or "") not in WATHQ_ROLES:
        return self._send(_client_form_page(user, fields, "الجلب من واثق لمدير النظام ومسؤول الامتثال."), 403)
    num = _digits(_one(fields, "unified_number")) or _digits(_one(fields, "registration_number"))
    if not num:
        return self._send(_client_form_page(user, fields, notice="اكتب الرقم الموحّد للمنشأة -يبدأ بالرقم 7- أو رقم السجل التجاري، ثم اضغط «اجلب من واثق»."))
    configured = ns.get("_wathq_configured")
    if not configured or not configured("cr"):
        return self._send(_client_form_page(user, fields, notice="خدمة واثق غير مفعّلة في المنصة الآن؛ فأكمل البيانات يدوياً، "
                                            "ويمكن توثيقها من واثق لاحقاً من ملف العميل."))
    try:
        status, data, _msg = ns["wathq_cr_fullinfo"](num)
    except Exception:
        status, data = 0, None
    if status != 200 or data is None:
        return self._send(_client_form_page(user, fields, notice="تعذّر الجلب من واثق الآن؛ فأكمل البيانات يدوياً، أو أعد المحاولة بعد قليل."))
    m = ns["_wathq_enrich_parties"](ns["_wathq_map_cr"](data), num)
    for k in ("legal_name", "unified_number", "registration_number"):
        if m.get(k):
            fields[k] = [str(m[k])]
    fields["client_type"] = ["company"]
    people = (m.get("parties") or []) + (m.get("managers") or [])
    rows = "".join(f"<tr><td dir='auto'>{_h(p.get('full_name'))}</td><td dir='ltr'>{_h(p.get('id_number') or '')}</td>"
                   f"<td>{_h(p.get('type_name') or p.get('role') or '')}</td><td>{_h(p.get('ownership_percent') or '')}</td></tr>"
                   for p in people) or "<tr><td colspan='4'>لا يوجد</td></tr>"
    facts = "؛ ".join(f"{lbl}: {_h(m.get(k))}" for k, lbl in (("status_text", "الحالة"), ("form_text", "الشكل النظامي"),
                                                             ("city_text", "المدينة")) if m.get(k))
    preview = (f'<div class="card"><h3>ما جُلب من واثق -راجعه قبل الحفظ-</h3><p class="small">رقم الاستعلام <span dir="ltr">{_h(num)}</span>'
               f'{"؛ " + facts if facts else ""}. وملئت به خانات الاسم والرقمين أدناه؛ وعند الحفظ يُقيَّد مصدرها «واثق» وتاريخها، '
               'ويُفحص العميل وأطرافه.</p><div class="table-wrap"><table><thead><tr><th>الاسم</th><th>رقم الهوية</th><th>الصفة</th>'
               f'<th>نسبة الملكية</th></tr></thead><tbody>{rows}</tbody></table></div>'
               '<label style="display:flex;gap:8px;align-items:center;font-weight:700"><input type="checkbox" name="import_parties" '
               f'value="1" form="ltx-newclient" checked style="width:auto">استيراد الملّاك والمديرين أطرافاً للعميل ({len(people)})</label>'
               f'<input type="hidden" name="wathq_cr" value="{_h(num)}" form="ltx-newclient"></div>')
    return self._send(_client_form_page(user, fields, extra=preview))


def _post_add_party(self, user, fields, ip) -> None:
    ns = _NS
    cid = int(_digits(_one(fields, "client_id")) or 0)
    try:
        ns["add_related_party"](fields, "client", "client_id", ip)
    except ValueError as exc:
        _TL.party_error, _TL.party_fields = f"لم يُحفظ الطرف: {exc}", fields
        try:
            return _render_client(self, cid, 400)
        finally:
            _TL.party_error, _TL.party_fields = "", None
    scr = screen_now(cid, ip)
    return ns["_auth_send_redirect"](self, f"/client?id={cid}&screened={scr}&from=party")


def _post_new_matter(self, user, fields, ip) -> None:
    ns = _NS
    import contracts_register as cr
    tp = _one(fields, "team_partner").lower()
    members = [m.strip().lower() for m in (fields.get("team_member") or []) if m and m.strip().lower() != tp]
    prefill = _one(fields, "client_id")
    if tp and not members:
        return self._send(_matter_form_page(user, prefill, fields, "فريق التكليف يلزمه عضو واحد على الأقل غير الشريك المسؤول؛ "
                                            "فاختر عضواً، أو اترك «الشريك المسؤول» فارغاً وحدّد الفريق لاحقاً."), 400)
    try:
        mid = ns["create_matter"](fields, ip)
    except (ValueError, KeyError) as exc:
        return self._send(_matter_form_page(user, prefill, fields, f"لم يُحفظ التكليف: {exc}"), 400)
    if tp:
        try:
            with ns["db"]() as con:
                cr.ensure_schema(con)
                cr.save_team(con, mid, {"partner_ar": [tp], "partner_en": [tp], "member": members}, _actor(user))
        except cr.RegisterError as exc:
            with ns["db"]() as con:
                cr.ensure_schema(con)
                body = cr.team_page(con, mid, ns["h"], f"حُفظ التكليف ولم يُحفظ فريقه: {exc}",
                                    {"partner": tp, "members": members})
            return self._send(ns["layout"]("فريق التكليف", body, "/matters"), 409)
    return ns["_auth_send_redirect"](self, f"/matter?id={mid}")


def _post_agreement(self, user, base_post) -> None:
    ns = _NS
    import contracts_register as cr
    fields, _files, ip, raw = _read(self)
    q = ns["parse_qs"](ns["urlparse"](self.path).query)
    mid = int(_digits((q.get("id") or ["0"])[0]) or 0)
    if _one(fields, "action") == "create" and _one(fields, "cf_present") == "1":
        try:
            with ns["db"]() as con:
                cr.ensure_schema(con)
                save_cf(con, mid, fields, _actor(user), ip)
        except (cr.RegisterError, ValueError) as exc:
            if isinstance(exc, cr.RegisterError) and getattr(exc, "client_id", None):
                self.rfile = io.BytesIO(raw)
                return base_post(self)              # البوابة ترفض بسببها، كما كانت
            _TL.cf_error = str(exc)
            try:
                with ns["db"]() as con:
                    cr.ensure_schema(con)
                    body = cr.screen_html(con, mid, ns["h"], cr._fields_from_post(fields))
                return self._send(ns["layout"]("إصدار الاتفاقية", body, "/matters"), 409)
            except cr.RegisterError:
                self.rfile = io.BytesIO(raw)
                return base_post(self)
            finally:
                _TL.cf_error = ""
    if _one(fields, "action") == "create":
        self._ltx_landing = (mid, user.get("id"))
    self.rfile = io.BytesIO(raw)
    try:
        return base_post(self)
    finally:
        self._ltx_landing = None


def _post_cf_page(self, user, base_post) -> None:
    ns = _NS
    fields, _files, ip, raw = _read(self)
    q = ns["parse_qs"](ns["urlparse"](self.path).query)
    cid = int(_digits((q.get("id") or ["0"])[0]) or 0)
    if "address" in fields and cid:
        try:
            with ns["db"]() as con:
                save_address(con, cid, _one(fields, "address"), ip)
        except ValueError:
            pass
    self.rfile = io.BytesIO(raw)
    return base_post(self)

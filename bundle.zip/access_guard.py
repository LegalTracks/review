# -*- coding: utf-8 -*-
"""مسارات قانونية — حارس سجل الاشتباه (ملف مستقل؛ يُزال بحذف سطرَي الوصل في آخر app.py).

ثبت بالتجربة (29/09، حساب «مستخدم» وحساب «شريك» على قاعدة مؤقتة) أن صفحة /suspicion-cases
تعرض السجل السري كاملاً -الوقائع والمؤشرات وقرار الامتثال- لكل من دخل المنصة، والصفحة نفسها تقول
«سري ومقيد، ولا يجوز إبلاغ العميل بوجود البلاغ». فالخطر خطر تنبيه المشتبه به.

القاعدة هنا:
– البلاغ الداخلي مفتوح لكل موظف -لا يُغلق باب الإبلاغ-، لكنه يكتب الوقائع والمؤشرات وحدها:
  اسمه يؤخذ من حسابه، والحالة «جديد»، ولا يكتب قرار الامتثال ولا يزعم إبلاغاً خارجياً.
– السجل ومحتواه لمدير النظام ومسؤول الامتثال وحدهما، كما تحصر المنصة غيره من الإجراءات السرية.
"""
from __future__ import annotations

import datetime as _dt
import secrets
from typing import Any, Dict

PRIVILEGED = {"admin", "compliance"}
CASES_PATH = "/suspicion-cases"
ADD_PATH = "/suspicion-cases/add"
PARTNER_DECISION_PATH = "/regulatory-review/partner"
PARTNER_DECIDERS = {"partner", "admin", "compliance"}

_NS: Dict[str, Any] = {}


def _report_form(ns: Dict[str, Any], message: str = "", error: str = "") -> bytes:
    h = ns["h"]
    with ns["db"]() as con:
        ns["ensure_schema"](con)
        clients = ns["_v105_clients_options"](con)
    msg = (f"<div class='success'>{h(message)}</div>" if message else "") + (f"<div class='error'>{h(error)}</div>" if error else "")
    body = f"""<div class="card"><h2>بلاغ اشتباه داخلي</h2>{msg}
<p>يصل البلاغ إلى مسؤول الامتثال وحده، ولا يُطلع عليه غيره؛ ولا يجوز إبلاغ العميل أو غيره بوجوده.</p>
<form method="post" action="{ADD_PATH}"><label>العميل</label><select name="client_id"><option value="">غير محدد</option>{clients}</select>
<label>الوقائع</label><textarea name="facts" required></textarea>
<label>مؤشرات الاشتباه</label><textarea name="indicators"></textarea>
<button>إرسال البلاغ إلى مسؤول الامتثال</button></form></div>"""
    return ns["layout"]("بلاغ اشتباه داخلي", body, CASES_PATH)


# قائمة الدول عالية المخاطر: تُعتمد الثماني في app.py كما هي (قرار المالك 30/09)، وتُضاف ميانمار وحدها،
# لأنها في قائمة «الدعوة إلى اتخاذ إجراء» لمجموعة العمل المالي (بيان 19/06/2026) مع كوريا الشمالية وإيران؛
# والإضافة في المجموعة نفسها فتسري على فحص العميل والطرف المقابل معاً (القرار 188)
ADDED_HIGH_RISK = {"myanmar", "burma", "ميانمار"}


def install(ns: Dict[str, Any]) -> None:
    _NS.update(ns)
    hrc = ns.get("HIGH_RISK_COUNTRIES")
    if isinstance(hrc, set):
        hrc.update(ADDED_HIGH_RISK)
    handler = ns.get("AppHandler")
    if not handler or getattr(handler, "_lt_guard", False):
        return
    base_get, base_post = handler.do_GET, handler.do_POST

    def do_get(self) -> None:
        path = ns["urlparse"](self.path).path
        if path != CASES_PATH:
            return base_get(self)
        user = ns["_v1512_ctx"](self)
        if not user or user.get("must_change_password") or user.get("role") in PRIVILEGED:
            return base_get(self)                    # الدخول وتغيير كلمة المرور والمخوَّلون: كما كان
        return self._send(_report_form(ns))

    def do_post(self) -> None:
        path = ns["urlparse"](self.path).path
        if path == PARTNER_DECISION_PATH:
            # C1 من مراجعة فابل: قرار الشريك بالموافقة يغيّر حالة العميل، فلا يسجّله إلا الشريك ومسؤول الامتثال ومدير النظام
            u = ns["_v1512_ctx"](self)
            if u and not u.get("must_change_password") and u.get("role") not in PARTNER_DECIDERS:
                return self._send(ns["layout"]("غير مصرّح", "<div class='error'>قرار الشريك يسجّله الشريك أو مسؤول الامتثال "
                                                "أو مدير النظام.</div>", "/regulatory-review"), 403)
            return base_post(self)
        if path != ADD_PATH:
            return base_post(self)
        user = ns["_v1512_ctx"](self)
        if not user or user.get("must_change_password") or user.get("role") in PRIVILEGED:
            return base_post(self)
        fields, _files, ip = ns["_parse_request_fields"](self)
        g = lambda k: ((fields.get(k) or [""])[0] or "").strip()
        facts = g("facts")
        if not facts:
            return self._send(_report_form(ns, error="اكتب الوقائع"), 400)
        cid = g("client_id")
        num = "SUS-" + _dt.datetime.now().strftime("%Y%m%d%H%M%S") + "-" + secrets.token_hex(2).upper()
        with ns["db"]() as con:
            ns["ensure_schema"](con)
            cur = con.execute("INSERT INTO suspicion_cases(created_at,case_number,client_id,reported_by,facts,indicators,status,external_reported) "
                        "VALUES(?,?,?,?,?,?,'new',0)",
                        (ns["now_iso"](), num, int(cid) if cid.isdigit() else None,
                         user.get("full_name") or user.get("user_name") or "", facts, g("indicators")))
            ns["audit"](con, "add_suspicion_case", "suspicion_case", cur.lastrowid, num + " — بلاغ داخلي من غير المخوَّلين", ip or "")
            con.commit()
        return self._send(_report_form(ns, message=f"وصل البلاغ إلى مسؤول الامتثال برقم {num}."))

    handler.do_GET, handler.do_POST = do_get, do_post
    handler._lt_guard = True

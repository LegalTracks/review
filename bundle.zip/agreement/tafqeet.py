# -*- coding: utf-8 -*-
"""تفقيط المبالغ بالريال السعودي — نقلٌ حرفي إلى بايثون لـ tafqeet.js المجاور.

المصدر الوحيد للقواعد هو tafqeet.js (قواعد التمييز المصحَّحة بالقرار 149)؛ وهذا الملف
يتبعه ولا يسبقه: أي تعديل على القواعد يُجرى في JS أولاً ثم يُنقل هنا، ويكشف أيَّ تباعد
بينهما اختبارُ tools/test_tafqeet_py.py (مطابقة مع node على آلاف المبالغ).

الانحراف المقصود الوحيد عن JS: إذا بلغ الجزء الصحيح 10^12 فأكثر أعادت tafqeet_ar
وtafqeet_en نصاً فارغاً؛ لأن JS يُخرج هناك نصاً فاسداً («فقط  مليار ريال»،
«ten hundred billion»، وفوق 2^53 «undefined»)، ولا يُكتب الفاسد في عقد.
"""
import re

__all__ = ["parse_amount", "group_digits", "tafqeet_ar", "tafqeet_en",
           "words_ar_parenthetical", "words_en_parenthetical", "MAX_WHOLE"]

# أعلى جزء صحيح يُفقَّط (دون ألف مليار)؛ وما فوقه يفسد في JS فيُرفض هنا
MAX_WHOLE = 10 ** 12 - 1

A_ONES = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة']
A_TENS = ['', 'عشرة', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون']
A_HUND = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة',
          'ثمانمائة', 'تسعمائة']
A_TEENS = {11: 'أحد عشر', 12: 'اثنا عشر', 13: 'ثلاثة عشر', 14: 'أربعة عشر', 15: 'خمسة عشر',
           16: 'ستة عشر', 17: 'سبعة عشر', 18: 'ثمانية عشر', 19: 'تسعة عشر'}
# (القيمة، المفرد، المثنى، المثنى مضافاً، الجمع، المفرد منصوباً منوّناً) — كما في A_SCALES في JS
A_SCALES = [(1000000000, 'مليار', 'ملياران', 'مليارا', 'مليارات', 'ملياراً'),
            (1000000, 'مليون', 'مليونان', 'مليونا', 'ملايين', 'مليوناً'),
            (1000, 'ألف', 'ألفان', 'ألفا', 'آلاف', 'ألفاً')]
# أعداد المؤنث (الهللة مؤنثة): من ثلاث إلى تسع يخالف العددُ المعدودَ
F_ONES = ['', 'واحدة', 'اثنتان', 'ثلاث', 'أربع', 'خمس', 'ست', 'سبع', 'ثماني', 'تسع']
F_TEENS = {11: 'إحدى عشرة', 12: 'اثنتا عشرة', 13: 'ثلاث عشرة', 14: 'أربع عشرة', 15: 'خمس عشرة',
           16: 'ست عشرة', 17: 'سبع عشرة', 18: 'ثماني عشرة', 19: 'تسع عشرة'}


def _ar_below_thousand(n):
    parts = []
    h, r = divmod(n, 100)
    if h:
        parts.append(A_HUND[h])
    if r:
        if r < 10:
            parts.append(A_ONES[r])
        elif r == 10:
            parts.append('عشرة')
        elif r < 20:
            parts.append(A_TEENS[r])
        else:
            t, u = divmod(r, 10)
            parts.append(A_ONES[u] + ' و' + A_TENS[t] if u else A_TENS[t])
    return ' و'.join(parts)


def _construct(w):
    """«مائتان» إذا أُضيفت إلى ما بعدها حُذفت نونها: مائتا ريال، مائتا ألف."""
    return w[:-1] if w.endswith('مائتان') else w


def _ar_scale(c, sc, last):
    """عدد مقطع واحد (آلاف أو ملايين أو مليارات) بتمييزه؛ و«last» أن يليه المعدود مباشرة
    فيُضاف إليه (أحدَ عشرَ ألفَ ريالٍ، ألفا ريال)، وإلا نُصب ونُوّن (اثنا عشر ألفاً وخمسمائة)."""
    _, single, dual, dual_c, plural, acc = sc
    if c == 1:
        return single
    if c == 2:
        return dual_c if last else dual
    r = c % 100
    if c <= 10 or 3 <= r <= 10:
        return _ar_below_thousand(c) + ' ' + plural
    if r >= 11:
        return _ar_below_thousand(c) + ' ' + (single if last else acc)
    if r in (1, 2):
        return (_construct(_ar_below_thousand(c - r)) + ' ' + single + ' و'
                + (single if r == 1 else (dual_c if last else dual)))
    return _construct(_ar_below_thousand(c)) + ' ' + single      # مائة ألف، مائتا ألف…


def _ar_int(n):
    if n == 0:
        return 'صفر'
    segs = []
    for sc in A_SCALES:
        c, n = divmod(n, sc[0])
        if c:
            segs.append((c, sc))
    parts = [_ar_scale(c, sc, i == len(segs) - 1 and not n) for i, (c, sc) in enumerate(segs)]
    if n:
        parts.append(_ar_below_thousand(n))
    return ' و'.join(parts)


def _ar_riyals(n):
    """الريال بتمييزه على العدد الأخير: 3–10 ريالات، 11–99 ريالاً، والمئات وما انتهى بمقطع: ريال (إضافة)."""
    if n == 1:
        return 'ريال سعودي واحد'
    if n == 2:
        return 'ريالان سعوديان'
    b, r = n % 1000, n % 100
    if b == 0 or r == 0:
        return _construct(_ar_int(n)) + ' ريال سعودي'
    if 3 <= r <= 10:
        return _ar_int(n) + ' ريالات سعودية'
    if r >= 11:
        return _ar_int(n) + ' ريالاً سعودياً'
    return _construct(_ar_int(n - r)) + ' ريال سعودي و' + ('ريال' if r == 1 else 'ريالان')   # 101، 1002…


def _ar_halalas(f):
    if f == 1:
        return 'هللة واحدة'
    if f == 2:
        return 'هللتان'
    if f < 10:
        w = F_ONES[f]
    elif f == 10:
        w = 'عشر'
    elif f < 20:
        w = F_TEENS[f]
    else:
        t, u = divmod(f, 10)
        w = F_ONES[u] + ' و' + A_TENS[t] if u else A_TENS[t]
    return w + (' هللات' if f <= 10 else ' هللة')


E_ONES = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
          'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen',
          'nineteen']
E_TENS = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety']
E_SCALES = [(1000000000, 'billion'), (1000000, 'million'), (1000, 'thousand')]


def _en_below_thousand(n):
    parts = []
    h, r = divmod(n, 100)
    if h:
        parts.append(E_ONES[h] + ' hundred')
    if r:
        if r < 20:
            parts.append(E_ONES[r])
        else:
            t, u = divmod(r, 10)
            parts.append(E_TENS[t] + ('-' + E_ONES[u] if u else ''))
    return ' '.join(parts)


def _en_int(n):
    if n == 0:
        return 'zero'
    parts = []
    for unit, name in E_SCALES:
        c, n = divmod(n, unit)
        if c:
            parts.append(_en_below_thousand(c) + ' ' + name)
    if n:
        parts.append(_en_below_thousand(n))
    return ' '.join(parts)


# المسافات كما يعرّفها JS في \s وفي String.prototype.trim — وهي تخالف str.isspace في بايثون
# (بايثون يعدّ \x1c-\x1f و\x85 مسافةً ولا يعدّ ﻿؛ وJS بالعكس)، فتُسرد صراحةً.
_JS_WS = ('\t\n\x0b\x0c\r           '
          '       　﻿')
# ما يحذفه JS قبل الفحص: الفاصلة العربية «،» والفاصلة اللاتينية والمسافات وعلامتا الاتجاه LRM/RLM
_STRIP_RE = re.compile('[،,' + re.escape(_JS_WS) + '‎‏]')
# \d في JS بلا راية u أرقامٌ لاتينية فقط؛ و\d في بايثون تقبل كل أرقام يونيكود، فتُكتب [0-9]
_AMOUNT_RE = re.compile(r'[0-9]+(?:\.[0-9]{1,2})?')
_AR_DIGITS = str.maketrans('٠١٢٣٤٥٦٧٨٩٫٬', '0123456789.,')


def _js_string(v):
    """محاكاة String(v) في JS لما قد يمرره المحرك من أنواع بايثون."""
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, float) and v == v and abs(v) < 1e21 and v == int(v):
        return str(int(v))          # JS: String(1500.0) = "1500"
    return str(v)


def parse_amount(v):
    """يقرأ المبلغ كما يقرؤه parseAmount في JS؛ يعيد (الجزء الصحيح، الهللات) أو None.
    يقبل: الأرقام العربية-الهندية (٠-٩ فقط لا الفارسية)، و«٫» فاصلةً عشرية، و«٬» و«،» و«,» فواصلَ آلاف،
    والمسافات وLRM/RLM في أي موضع؛ ولا يقبل أكثر من خانتي هللة ولا الإشارة ولا الأُسّ."""
    if v is None:
        return None
    s = _js_string(v).strip(_JS_WS).translate(_AR_DIGITS)
    if not s:
        return None
    s = _STRIP_RE.sub('', s)
    if not _AMOUNT_RE.fullmatch(s):
        return None
    whole, _, frac = s.partition('.')
    return int(whole), (int((frac + '00')[:2]) if frac else 0)


def group_digits(v):
    """المبلغ بأرقام لاتينية وفواصل آلاف، وبخانتي الهللة إن وُجدت: 1,200.50 — أو None."""
    p = parse_amount(v)
    if p is None:
        return None
    return '{:,}'.format(p[0]) + ('.%02d' % p[1] if p[1] else '')


def tafqeet_ar(v):
    """«فقط ثلاثمائة وستون ألف ريال سعودي لا غير» — نص فارغ إن لم يُقرأ المبلغ."""
    p = parse_amount(v)
    if p is None or p[0] > MAX_WHOLE:
        return ''
    whole, frac = p
    out = 'فقط ' + (_ar_riyals(whole) if whole else '')
    if frac:
        out += (' و' if whole else '') + _ar_halalas(frac)
    if not whole and not frac:
        out += 'صفر ريال'
    return out + ' لا غير'


def tafqeet_en(v):
    """«SAR three hundred sixty thousand only» — نص فارغ إن لم يُقرأ المبلغ."""
    p = parse_amount(v)
    if p is None or p[0] > MAX_WHOLE:
        return ''
    out = 'SAR ' + _en_int(p[0])
    if p[1]:
        out += ' and ' + _en_int(p[1]) + ' halalas'
    return out + ' only'


def words_ar_parenthetical(v):
    """ما يُكتب بين القوسين في «{{X}} ريال سعودي ({{X_WORDS_AR}})»: عبارة الشاشة كاملة بلا تقطيع.
    لا تُحذف «ريال سعودي» رغم ورودها قبل القوسين: فالتمييز جزء من العدد بعد التصحيح
    («مائتا ريال»، «ريالان سعوديان»، «خمسون ريالاً سعودياً») وقطعه يترك العدد معلّقاً؛
    وهي صيغة محرك 2.3 نفسها في هذا الوسم. التفصيل في rules/agents/tafqeet-py-STATE.md."""
    return tafqeet_ar(v)


def words_en_parenthetical(v):
    """ما يُكتب بين القوسين في «SAR {{X}} ({{X_WORDS_EN}})»: «SAR ... only» كما في محرك 2.3 والشاشة."""
    return tafqeet_en(v)

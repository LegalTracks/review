const A_ONES = ['','واحد','اثنان','ثلاثة','أربعة','خمسة','ستة','سبعة','ثمانية','تسعة'];
const A_TENS = ['','عشرة','عشرون','ثلاثون','أربعون','خمسون','ستون','سبعون','ثمانون','تسعون'];
const A_HUND = ['','مائة','مائتان','ثلاثمائة','أربعمائة','خمسمائة','ستمائة','سبعمائة',
                'ثمانمائة','تسعمائة'];
const A_TEENS = {11:'أحد عشر',12:'اثنا عشر',13:'ثلاثة عشر',14:'أربعة عشر',15:'خمسة عشر',
                 16:'ستة عشر',17:'سبعة عشر',18:'ثمانية عشر',19:'تسعة عشر'};
// [القيمة، المفرد، المثنى، المثنى مضافاً، الجمع، المفرد منصوباً منوّناً] — تصحيح قواعد التمييز بقرار المالك 26/09/2026م
const A_SCALES = [[1000000000,'مليار','ملياران','مليارا','مليارات','ملياراً'],
                  [1000000,'مليون','مليونان','مليونا','ملايين','مليوناً'],
                  [1000,'ألف','ألفان','ألفا','آلاف','ألفاً']];
// أعداد المؤنث (الهللة مؤنثة): من ثلاث إلى تسع يخالف العددُ المعدودَ
const F_ONES = ['','واحدة','اثنتان','ثلاث','أربع','خمس','ست','سبع','ثماني','تسع'];
const F_TEENS = {11:'إحدى عشرة',12:'اثنتا عشرة',13:'ثلاث عشرة',14:'أربع عشرة',15:'خمس عشرة',
                 16:'ست عشرة',17:'سبع عشرة',18:'ثماني عشرة',19:'تسع عشرة'};

function arBelowThousand(n) {
  const parts = [];
  const h = Math.floor(n/100), r = n%100;
  if (h) parts.push(A_HUND[h]);
  if (r) {
    if (r < 10) parts.push(A_ONES[r]);
    else if (r === 10) parts.push('عشرة');
    else if (r < 20) parts.push(A_TEENS[r]);
    else {
      const t = Math.floor(r/10), u = r%10;
      parts.push(u ? A_ONES[u] + ' و' + A_TENS[t] : A_TENS[t]);
    }
  }
  return parts.join(' و');
}
// «مائتان» إذا أُضيفت إلى ما بعدها حُذفت نونها: مائتا ريال، مائتا ألف
function construct(w) { return w.endsWith('مائتان') ? w.slice(0, -1) : w; }
// عدد مقطع واحد (آلاف أو ملايين أو مليارات) بتمييزه؛ و«last» أن يليه المعدود مباشرة
// فيُضاف إليه (أحدَ عشرَ ألفَ ريالٍ، ألفا ريال)، وإلا نُصب ونُوّن (اثنا عشر ألفاً وخمسمائة).
function arScale(c, sc, last) {
  const [, single, dual, dualC, plural, acc] = sc;
  if (c === 1) return single;
  if (c === 2) return last ? dualC : dual;
  const r = c % 100;
  if (c <= 10 || (r >= 3 && r <= 10)) return arBelowThousand(c) + ' ' + plural;
  if (r >= 11) return arBelowThousand(c) + ' ' + (last ? single : acc);
  if (r === 1 || r === 2) return construct(arBelowThousand(c - r)) + ' ' + single + ' و' + (r === 1 ? single : (last ? dualC : dual));
  return construct(arBelowThousand(c)) + ' ' + single;      // مائة ألف، مائتا ألف…
}
function arInt(n) {
  if (n === 0) return 'صفر';
  const segs = [];
  for (const sc of A_SCALES) {
    const c = Math.floor(n/sc[0]); n = n % sc[0];
    if (c) segs.push([c, sc]);
  }
  const parts = segs.map(([c, sc], i) => arScale(c, sc, i === segs.length - 1 && !n));
  if (n) parts.push(arBelowThousand(n));
  return parts.join(' و');
}
// الريال بتمييزه على العدد الأخير: 3–10 ريالات، 11–99 ريالاً، والمئات وما انتهى بمقطع: ريال (إضافة)
function arRiyals(n) {
  if (n === 1) return 'ريال سعودي واحد';
  if (n === 2) return 'ريالان سعوديان';
  const b = n % 1000, r = n % 100;
  if (b === 0 || r === 0) return construct(arInt(n)) + ' ريال سعودي';
  if (r >= 3 && r <= 10) return arInt(n) + ' ريالات سعودية';
  if (r >= 11) return arInt(n) + ' ريالاً سعودياً';
  return construct(arInt(n - r)) + ' ريال سعودي و' + (r === 1 ? 'ريال' : 'ريالان');   // 101، 1002…
}
function arHalalas(f) {
  if (f === 1) return 'هللة واحدة';
  if (f === 2) return 'هللتان';
  let w;
  if (f < 10) w = F_ONES[f];
  else if (f === 10) w = 'عشر';
  else if (f < 20) w = F_TEENS[f];
  else { const t = Math.floor(f/10), u = f % 10; w = u ? F_ONES[u] + ' و' + A_TENS[t] : A_TENS[t]; }
  return w + (f <= 10 ? ' هللات' : ' هللة');
}
const E_ONES = ['zero','one','two','three','four','five','six','seven','eight','nine','ten',
  'eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen',
  'nineteen'];
const E_TENS = ['','','twenty','thirty','forty','fifty','sixty','seventy','eighty','ninety'];
const E_SCALES = [[1000000000,'billion'],[1000000,'million'],[1000,'thousand']];
function enBelowThousand(n) {
  const parts = [];
  const h = Math.floor(n/100), r = n%100;
  if (h) parts.push(E_ONES[h] + ' hundred');
  if (r) {
    if (r < 20) parts.push(E_ONES[r]);
    else {
      const t = Math.floor(r/10), u = r%10;
      parts.push(E_TENS[t] + (u ? '-' + E_ONES[u] : ''));
    }
  }
  return parts.join(' ');
}
function enInt(n) {
  if (n === 0) return 'zero';
  const parts = [];
  for (const [unit, name] of E_SCALES) {
    const c = Math.floor(n/unit); n = n%unit;
    if (c) parts.push(enBelowThousand(c) + ' ' + name);
  }
  if (n) parts.push(enBelowThousand(n));
  return parts.join(' ');
}

const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
function asciiDigits(s) {
  return String(s).replace(/[٠-٩]/g, c => String(AR_DIGITS.indexOf(c)))
                  .replace(/٫/g, '.').replace(/٬/g, ',');
}
function parseAmount(v) {
  if (v === null || v === undefined) return null;
  let s = asciiDigits(String(v).trim());
  if (!s) return null;
  s = s.replace(/[،,\s‎‏]/g, '');
  if (!/^\d+(\.\d{1,2})?$/.test(s)) return null;
  const parts = s.split('.');
  return [parseInt(parts[0], 10), parts[1] ? parseInt((parts[1]+'00').slice(0,2), 10) : 0];
}
function groupDigits(v) {
  const p = parseAmount(v);
  if (!p) return null;
  const s = p[0].toLocaleString('en-US');
  return s + (p[1] ? '.' + String(p[1]).padStart(2,'0') : '');
}
function tafqeetAr(v) {
  const p = parseAmount(v);
  if (!p) return '';
  let out = 'فقط ' + (p[0] ? arRiyals(p[0]) : '');
  if (p[1]) out += (p[0] ? ' و' : '') + arHalalas(p[1]);
  if (!p[0] && !p[1]) out += 'صفر ريال';
  return out + ' لا غير';
}
function tafqeetEn(v) {
  const p = parseAmount(v);
  if (!p) return '';
  let out = 'SAR ' + enInt(p[0]);
  if (p[1]) out += ' and ' + enInt(p[1]) + ' halalas';
  return out + ' only';
}
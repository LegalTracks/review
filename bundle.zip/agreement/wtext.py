# -*- coding: utf-8 -*-
"""Run-aware find/replace for WordprocessingML.

Word splits a visible phrase across many <w:r> runs whose rPr differ only in
hints, language or spell-check state, so the phrase does not exist as a
contiguous string in the XML. These helpers concatenate the <w:t> content of a
paragraph, apply replacements on that flat string, then splice the result back
into the runs — the replacement inherits the formatting of the first run of the
matched span, and the remaining overlapped runs are emptied.
"""
import re
from xml.sax.saxutils import escape as _escape, unescape as _unescape

T_RE = re.compile(r'(<w:t(?: [^>]*)?>)(.*?)(</w:t>)', re.S)
P_RE = re.compile(r'<w:p\b(?:[^>]*)>.*?</w:p>', re.S)

# saxutils handles only &amp; &lt; &gt; by default. Word writes &quot; and &apos;
# inside element text, so they must be added or the leading & gets double-escaped
# on the way back out (the classic `&quot;` appearing literally in the document).
_UNESC = {"&quot;": '"', "&apos;": "'", "&#39;": "'", "&#34;": '"'}


def unescape(s):
    return _unescape(s, _UNESC)


def escape(s):
    # " and ' need no escaping in element content, so round-tripping is stable
    return _escape(s)


class Para:
    """Flat text view of one paragraph's <w:t> nodes."""

    def __init__(self, xml):
        self.xml = xml
        self.spans = [(m.start(2), m.end(2), unescape(m.group(2)))
                      for m in T_RE.finditer(xml)]
        self.texts = [s[2] for s in self.spans]

    @property
    def flat(self):
        return ''.join(self.texts)

    def _locate(self, gpos):
        """global char offset -> (node index, offset within node)"""
        acc = 0
        for i, t in enumerate(self.texts):
            if gpos <= acc + len(t):
                return i, gpos - acc
            acc += len(t)
        return len(self.texts) - 1, len(self.texts[-1])

    def replace(self, old, new):
        n = 0
        while True:
            flat = self.flat
            pos = flat.find(old)
            if pos < 0:
                break
            si, so = self._locate(pos)
            ei, eo = self._locate(pos + len(old))
            if si == ei:
                self.texts[si] = self.texts[si][:so] + new + self.texts[si][eo:]
            else:
                self.texts[si] = self.texts[si][:so] + new
                for k in range(si + 1, ei):
                    self.texts[k] = ''
                self.texts[ei] = self.texts[ei][eo:]
            n += 1
            if n > 50:
                break
        return n

    def render(self):
        if not self.spans:
            return self.xml
        out, cursor = [], 0
        for (s, e, _), txt in zip(self.spans, self.texts):
            out.append(self.xml[cursor:s])
            out.append(escape(txt))
            cursor = e
        out.append(self.xml[cursor:])
        xml = ''.join(out)
        # a <w:t> holding leading/trailing spaces needs xml:space="preserve"
        xml = re.sub(r'<w:t>(?=[ ])', '<w:t xml:space="preserve">', xml)
        return xml


def replace_all(xml, pairs, *, report=True):
    """Apply (old, new) replacements paragraph by paragraph across the document.
    Returns (new_xml, counts_dict)."""
    counts = {old: 0 for old, _ in pairs}
    out, cursor = [], 0
    for m in P_RE.finditer(xml):
        out.append(xml[cursor:m.start()])
        p = Para(m.group())
        touched = False
        for old, new in pairs:
            c = p.replace(old, new)
            if c:
                counts[old] += c
                touched = True
        out.append(p.render() if touched else m.group())
        cursor = m.end()
    out.append(xml[cursor:])
    return ''.join(out), counts


def para_text(p_xml):
    return ''.join(unescape(m.group(2)) for m in T_RE.finditer(p_xml))
